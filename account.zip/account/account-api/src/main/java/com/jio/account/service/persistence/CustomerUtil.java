/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence;

import com.jio.account.model.Customer;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the customer service. This utility wraps <code>com.jio.account.service.persistence.impl.CustomerPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CustomerPersistence
 * @generated
 */
@ProviderType
public class CustomerUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(Customer customer) {
		getPersistence().clearCache(customer);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, Customer> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Customer> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Customer> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Customer> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static Customer update(Customer customer) {
		return getPersistence().update(customer);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static Customer update(
		Customer customer, ServiceContext serviceContext) {

		return getPersistence().update(customer, serviceContext);
	}

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByCustomerId(String customerId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByCustomerId(customerId, companyId);
	}

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByCustomerId(
		String customerId, long companyId) {

		return getPersistence().fetchByCustomerId(customerId, companyId);
	}

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByCustomerId(
		String customerId, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByCustomerId(
			customerId, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where customerId = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByCustomerId(String customerId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByCustomerId(customerId, companyId);
	}

	/**
	 * Returns the number of customers where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByCustomerId(String customerId, long companyId) {
		return getPersistence().countByCustomerId(customerId, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAN_VCID_ASN(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId) {

		return getPersistence().fetchByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId,
		boolean retrieveFromCache) {

		return getPersistence().fetchByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByAN_VCID_ASN(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId) {

		return getPersistence().countByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAN_STBNO_ASN(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName,
		long companyId) {

		return getPersistence().fetchByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName, long companyId,
		boolean retrieveFromCache) {

		return getPersistence().fetchByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByAN_STBNO_ASN(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName,
		long companyId) {

		return getPersistence().countByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAN_MACID_ASN(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName,
		long companyId) {

		return getPersistence().fetchByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName, long companyId,
		boolean retrieveFromCache) {

		return getPersistence().fetchByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByAN_MACID_ASN(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName,
		long companyId) {

		return getPersistence().countByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAccountNo(String accountNo, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAccountNo(accountNo, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAccountNo(String accountNo, long companyId) {
		return getPersistence().fetchByAccountNo(accountNo, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAccountNo(
		String accountNo, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByAccountNo(
			accountNo, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where accountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByAccountNo(String accountNo, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByAccountNo(accountNo, companyId);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAccountNo(String accountNo, long companyId) {
		return getPersistence().countByAccountNo(accountNo, companyId);
	}

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByVcId_C(String vcId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVcId_C(vcId, companyId);
	}

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByVcId_C(String vcId, long companyId) {
		return getPersistence().fetchByVcId_C(vcId, companyId);
	}

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByVcId_C(
		String vcId, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByVcId_C(
			vcId, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where vcId = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByVcId_C(String vcId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByVcId_C(vcId, companyId);
	}

	/**
	 * Returns the number of customers where vcId = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByVcId_C(String vcId, long companyId) {
		return getPersistence().countByVcId_C(vcId, companyId);
	}

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByStbNo_C(String stbNo, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStbNo_C(stbNo, companyId);
	}

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByStbNo_C(String stbNo, long companyId) {
		return getPersistence().fetchByStbNo_C(stbNo, companyId);
	}

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByStbNo_C(
		String stbNo, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByStbNo_C(
			stbNo, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByStbNo_C(String stbNo, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByStbNo_C(stbNo, companyId);
	}

	/**
	 * Returns the number of customers where stbNo = &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByStbNo_C(String stbNo, long companyId) {
		return getPersistence().countByStbNo_C(stbNo, companyId);
	}

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByMacId_C(String macId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMacId_C(macId, companyId);
	}

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByMacId_C(String macId, long companyId) {
		return getPersistence().fetchByMacId_C(macId, companyId);
	}

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByMacId_C(
		String macId, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByMacId_C(
			macId, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where macId = &#63; and companyId = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByMacId_C(String macId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByMacId_C(macId, companyId);
	}

	/**
	 * Returns the number of customers where macId = &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByMacId_C(String macId, long companyId) {
		return getPersistence().countByMacId_C(macId, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAN_SCN(
			String accountNo, String screenName, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_SCN(accountNo, screenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_SCN(
		String accountNo, String screenName, long companyId) {

		return getPersistence().fetchByAN_SCN(accountNo, screenName, companyId);
	}

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_SCN(
		String accountNo, String screenName, long companyId,
		boolean retrieveFromCache) {

		return getPersistence().fetchByAN_SCN(
			accountNo, screenName, companyId, retrieveFromCache);
	}

	/**
	 * Removes the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public static Customer removeByAN_SCN(
			String accountNo, String screenName, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().removeByAN_SCN(
			accountNo, screenName, companyId);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and screenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAN_SCN(
		String accountNo, String screenName, long companyId) {

		return getPersistence().countByAN_SCN(accountNo, screenName, companyId);
	}

	/**
	 * Returns all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId) {

		return getPersistence().findBySCN_P(screenName, primary, companyId);
	}

	/**
	 * Returns a range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start,
		int end) {

		return getPersistence().findBySCN_P(
			screenName, primary, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findBySCN_P(
			screenName, primary, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findBySCN_P(
			screenName, primary, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findBySCN_P_First(
			String screenName, boolean primary, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySCN_P_First(
			screenName, primary, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchBySCN_P_First(
		String screenName, boolean primary, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchBySCN_P_First(
			screenName, primary, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findBySCN_P_Last(
			String screenName, boolean primary, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySCN_P_Last(
			screenName, primary, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchBySCN_P_Last(
		String screenName, boolean primary, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchBySCN_P_Last(
			screenName, primary, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findBySCN_P_PrevAndNext(
			String customerId, String screenName, boolean primary,
			long companyId, OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySCN_P_PrevAndNext(
			customerId, screenName, primary, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where screenName = &#63; and primary = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 */
	public static void removeBySCN_P(
		String screenName, boolean primary, long companyId) {

		getPersistence().removeBySCN_P(screenName, primary, companyId);
	}

	/**
	 * Returns the number of customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countBySCN_P(
		String screenName, boolean primary, long companyId) {

		return getPersistence().countBySCN_P(screenName, primary, companyId);
	}

	/**
	 * Returns all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByScreenName(
		String screenName, long companyId) {

		return getPersistence().findByScreenName(screenName, companyId);
	}

	/**
	 * Returns a range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end) {

		return getPersistence().findByScreenName(
			screenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByScreenName(
			screenName, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByScreenName(
			screenName, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByScreenName_First(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByScreenName_First(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByScreenName_First(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByScreenName_First(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByScreenName_Last(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByScreenName_Last(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByScreenName_Last(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByScreenName_Last(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByScreenName_PrevAndNext(
			String customerId, String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByScreenName_PrevAndNext(
			customerId, screenName, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	public static void removeByScreenName(String screenName, long companyId) {
		getPersistence().removeByScreenName(screenName, companyId);
	}

	/**
	 * Returns the number of customers where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByScreenName(String screenName, long companyId) {
		return getPersistence().countByScreenName(screenName, companyId);
	}

	/**
	 * Returns all the customers where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByCompanyId(long companyId) {
		return getPersistence().findByCompanyId(companyId);
	}

	/**
	 * Returns a range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByCompanyId(
		long companyId, int start, int end) {

		return getPersistence().findByCompanyId(companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByCompanyId_First(
			long companyId, OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByCompanyId_First(
		long companyId, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByCompanyId_Last(
			long companyId, OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByCompanyId_Last(
		long companyId, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByCompanyId_PrevAndNext(
			String customerId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByCompanyId_PrevAndNext(
			customerId, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public static void removeByCompanyId(long companyId) {
		getPersistence().removeByCompanyId(companyId);
	}

	/**
	 * Returns the number of customers where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByCompanyId(long companyId) {
		return getPersistence().countByCompanyId(companyId);
	}

	/**
	 * Returns all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByAN_C(String accountNo, long companyId) {
		return getPersistence().findByAN_C(accountNo, companyId);
	}

	/**
	 * Returns a range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end) {

		return getPersistence().findByAN_C(accountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByAN_C(
			accountNo, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAN_C(
			accountNo, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAN_C_First(
			String accountNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_C_First(
			accountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_C_First(
		String accountNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByAN_C_First(
			accountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAN_C_Last(
			String accountNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_C_Last(
			accountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAN_C_Last(
		String accountNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByAN_C_Last(
			accountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByAN_C_PrevAndNext(
			String customerId, String accountNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAN_C_PrevAndNext(
			customerId, accountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where accountNo LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 */
	public static void removeByAN_C(String accountNo, long companyId) {
		getPersistence().removeByAN_C(accountNo, companyId);
	}

	/**
	 * Returns the number of customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAN_C(String accountNo, long companyId) {
		return getPersistence().countByAN_C(accountNo, companyId);
	}

	/**
	 * Returns all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findBySN_C(String screenName, long companyId) {
		return getPersistence().findBySN_C(screenName, companyId);
	}

	/**
	 * Returns a range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end) {

		return getPersistence().findBySN_C(screenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findBySN_C(
			screenName, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findBySN_C(
			screenName, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findBySN_C_First(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySN_C_First(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchBySN_C_First(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchBySN_C_First(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findBySN_C_Last(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySN_C_Last(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchBySN_C_Last(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchBySN_C_Last(
			screenName, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findBySN_C_PrevAndNext(
			String customerId, String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySN_C_PrevAndNext(
			customerId, screenName, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where screenName LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	public static void removeBySN_C(String screenName, long companyId) {
		getPersistence().removeBySN_C(screenName, companyId);
	}

	/**
	 * Returns the number of customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countBySN_C(String screenName, long companyId) {
		return getPersistence().countBySN_C(screenName, companyId);
	}

	/**
	 * Returns all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByS_C(String status, long companyId) {
		return getPersistence().findByS_C(status, companyId);
	}

	/**
	 * Returns a range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByS_C(
		String status, long companyId, int start, int end) {

		return getPersistence().findByS_C(status, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByS_C(
		String status, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByS_C(
			status, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByS_C(
		String status, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByS_C(
			status, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByS_C_First(
			String status, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByS_C_First(
			status, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByS_C_First(
		String status, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByS_C_First(
			status, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByS_C_Last(
			String status, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByS_C_Last(
			status, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByS_C_Last(
		String status, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByS_C_Last(
			status, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByS_C_PrevAndNext(
			String customerId, String status, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByS_C_PrevAndNext(
			customerId, status, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where status LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 */
	public static void removeByS_C(String status, long companyId) {
		getPersistence().removeByS_C(status, companyId);
	}

	/**
	 * Returns the number of customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByS_C(String status, long companyId) {
		return getPersistence().countByS_C(status, companyId);
	}

	/**
	 * Returns all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByVC_C(String vcId, long companyId) {
		return getPersistence().findByVC_C(vcId, companyId);
	}

	/**
	 * Returns a range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end) {

		return getPersistence().findByVC_C(vcId, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByVC_C(
			vcId, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByVC_C(
			vcId, companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByVC_C_First(
			String vcId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVC_C_First(
			vcId, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByVC_C_First(
		String vcId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByVC_C_First(
			vcId, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByVC_C_Last(
			String vcId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVC_C_Last(
			vcId, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByVC_C_Last(
		String vcId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByVC_C_Last(
			vcId, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByVC_C_PrevAndNext(
			String customerId, String vcId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVC_C_PrevAndNext(
			customerId, vcId, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where vcId LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 */
	public static void removeByVC_C(String vcId, long companyId) {
		getPersistence().removeByVC_C(vcId, companyId);
	}

	/**
	 * Returns the number of customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByVC_C(String vcId, long companyId) {
		return getPersistence().countByVC_C(vcId, companyId);
	}

	/**
	 * Returns all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findBySTB_C(String stbNo, long companyId) {
		return getPersistence().findBySTB_C(stbNo, companyId);
	}

	/**
	 * Returns a range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end) {

		return getPersistence().findBySTB_C(stbNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findBySTB_C(
			stbNo, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findBySTB_C(
			stbNo, companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findBySTB_C_First(
			String stbNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySTB_C_First(
			stbNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchBySTB_C_First(
		String stbNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchBySTB_C_First(
			stbNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findBySTB_C_Last(
			String stbNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySTB_C_Last(
			stbNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchBySTB_C_Last(
		String stbNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchBySTB_C_Last(
			stbNo, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findBySTB_C_PrevAndNext(
			String customerId, String stbNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findBySTB_C_PrevAndNext(
			customerId, stbNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where stbNo LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 */
	public static void removeBySTB_C(String stbNo, long companyId) {
		getPersistence().removeBySTB_C(stbNo, companyId);
	}

	/**
	 * Returns the number of customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countBySTB_C(String stbNo, long companyId) {
		return getPersistence().countBySTB_C(stbNo, companyId);
	}

	/**
	 * Returns all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByMAC_C(String macId, long companyId) {
		return getPersistence().findByMAC_C(macId, companyId);
	}

	/**
	 * Returns a range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end) {

		return getPersistence().findByMAC_C(macId, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByMAC_C(
			macId, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMAC_C(
			macId, companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByMAC_C_First(
			String macId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMAC_C_First(
			macId, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByMAC_C_First(
		String macId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByMAC_C_First(
			macId, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByMAC_C_Last(
			String macId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMAC_C_Last(
			macId, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByMAC_C_Last(
		String macId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByMAC_C_Last(
			macId, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByMAC_C_PrevAndNext(
			String customerId, String macId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMAC_C_PrevAndNext(
			customerId, macId, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where macId LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 */
	public static void removeByMAC_C(String macId, long companyId) {
		getPersistence().removeByMAC_C(macId, companyId);
	}

	/**
	 * Returns the number of customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByMAC_C(String macId, long companyId) {
		return getPersistence().countByMAC_C(macId, companyId);
	}

	/**
	 * Returns all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public static List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId) {

		return getPersistence().findByAgentScreenName(
			agentScreenName, companyId);
	}

	/**
	 * Returns a range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end) {

		return getPersistence().findByAgentScreenName(
			agentScreenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByAgentScreenName(
			agentScreenName, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAgentScreenName(
			agentScreenName, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAgentScreenName_First(
			String agentScreenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAgentScreenName_First(
			agentScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAgentScreenName_First(
		String agentScreenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByAgentScreenName_First(
			agentScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByAgentScreenName_Last(
			String agentScreenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAgentScreenName_Last(
			agentScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByAgentScreenName_Last(
		String agentScreenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByAgentScreenName_Last(
			agentScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByAgentScreenName_PrevAndNext(
			String customerId, String agentScreenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByAgentScreenName_PrevAndNext(
			customerId, agentScreenName, companyId, orderByComparator);
	}

	/**
	 * Removes all the customers where agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 */
	public static void removeByAgentScreenName(
		String agentScreenName, long companyId) {

		getPersistence().removeByAgentScreenName(agentScreenName, companyId);
	}

	/**
	 * Returns the number of customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public static int countByAgentScreenName(
		String agentScreenName, long companyId) {

		return getPersistence().countByAgentScreenName(
			agentScreenName, companyId);
	}

	/**
	 * Returns all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public static List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName) {

		return getPersistence().findByScreenNameSearch(
			screenName, companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end) {

		return getPersistence().findByScreenNameSearch(
			screenName, companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByScreenNameSearch(
			screenName, companyId, agentScreenName, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByScreenNameSearch(
			screenName, companyId, agentScreenName, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByScreenNameSearch_First(
			String screenName, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByScreenNameSearch_First(
			screenName, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByScreenNameSearch_First(
		String screenName, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByScreenNameSearch_First(
			screenName, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByScreenNameSearch_Last(
			String screenName, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByScreenNameSearch_Last(
			screenName, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByScreenNameSearch_Last(
		String screenName, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByScreenNameSearch_Last(
			screenName, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByScreenNameSearch_PrevAndNext(
			String customerId, String screenName, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByScreenNameSearch_PrevAndNext(
			customerId, screenName, companyId, agentScreenName,
			orderByComparator);
	}

	/**
	 * Removes all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByScreenNameSearch(
		String screenName, long companyId, String agentScreenName) {

		getPersistence().removeByScreenNameSearch(
			screenName, companyId, agentScreenName);
	}

	/**
	 * Returns the number of customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public static int countByScreenNameSearch(
		String screenName, long companyId, String agentScreenName) {

		return getPersistence().countByScreenNameSearch(
			screenName, companyId, agentScreenName);
	}

	/**
	 * Returns all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public static List<Customer> findByStatus(
		String status, long companyId, String agentScreenName) {

		return getPersistence().findByStatus(
			status, companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end) {

		return getPersistence().findByStatus(
			status, companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByStatus(
			status, companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByStatus(
			status, companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByStatus_First(
			String status, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStatus_First(
			status, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByStatus_First(
		String status, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByStatus_First(
			status, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByStatus_Last(
			String status, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStatus_Last(
			status, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByStatus_Last(
		String status, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByStatus_Last(
			status, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByStatus_PrevAndNext(
			String customerId, String status, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStatus_PrevAndNext(
			customerId, status, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Removes all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByStatus(
		String status, long companyId, String agentScreenName) {

		getPersistence().removeByStatus(status, companyId, agentScreenName);
	}

	/**
	 * Returns the number of customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public static int countByStatus(
		String status, long companyId, String agentScreenName) {

		return getPersistence().countByStatus(
			status, companyId, agentScreenName);
	}

	/**
	 * Returns all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public static List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName) {

		return getPersistence().findByVcId(vcId, companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start,
		int end) {

		return getPersistence().findByVcId(
			vcId, companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByVcId(
			vcId, companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByVcId(
			vcId, companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByVcId_First(
			String vcId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVcId_First(
			vcId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByVcId_First(
		String vcId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByVcId_First(
			vcId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByVcId_Last(
			String vcId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVcId_Last(
			vcId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByVcId_Last(
		String vcId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByVcId_Last(
			vcId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByVcId_PrevAndNext(
			String customerId, String vcId, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByVcId_PrevAndNext(
			customerId, vcId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Removes all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByVcId(
		String vcId, long companyId, String agentScreenName) {

		getPersistence().removeByVcId(vcId, companyId, agentScreenName);
	}

	/**
	 * Returns the number of customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public static int countByVcId(
		String vcId, long companyId, String agentScreenName) {

		return getPersistence().countByVcId(vcId, companyId, agentScreenName);
	}

	/**
	 * Returns all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public static List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName) {

		return getPersistence().findByStbNo(stbNo, companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end) {

		return getPersistence().findByStbNo(
			stbNo, companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByStbNo(
			stbNo, companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByStbNo(
			stbNo, companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByStbNo_First(
			String stbNo, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStbNo_First(
			stbNo, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByStbNo_First(
		String stbNo, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByStbNo_First(
			stbNo, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByStbNo_Last(
			String stbNo, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStbNo_Last(
			stbNo, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByStbNo_Last(
		String stbNo, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByStbNo_Last(
			stbNo, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByStbNo_PrevAndNext(
			String customerId, String stbNo, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByStbNo_PrevAndNext(
			customerId, stbNo, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Removes all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByStbNo(
		String stbNo, long companyId, String agentScreenName) {

		getPersistence().removeByStbNo(stbNo, companyId, agentScreenName);
	}

	/**
	 * Returns the number of customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public static int countByStbNo(
		String stbNo, long companyId, String agentScreenName) {

		return getPersistence().countByStbNo(stbNo, companyId, agentScreenName);
	}

	/**
	 * Returns all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public static List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName) {

		return getPersistence().findByMacId(macId, companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public static List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end) {

		return getPersistence().findByMacId(
			macId, companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findByMacId(
			macId, companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public static List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMacId(
			macId, companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByMacId_First(
			String macId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMacId_First(
			macId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByMacId_First(
		String macId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByMacId_First(
			macId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public static Customer findByMacId_Last(
			String macId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMacId_Last(
			macId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public static Customer fetchByMacId_Last(
		String macId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		return getPersistence().fetchByMacId_Last(
			macId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer[] findByMacId_PrevAndNext(
			String customerId, String macId, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByMacId_PrevAndNext(
			customerId, macId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Removes all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByMacId(
		String macId, long companyId, String agentScreenName) {

		getPersistence().removeByMacId(macId, companyId, agentScreenName);
	}

	/**
	 * Returns the number of customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public static int countByMacId(
		String macId, long companyId, String agentScreenName) {

		return getPersistence().countByMacId(macId, companyId, agentScreenName);
	}

	/**
	 * Caches the customer in the entity cache if it is enabled.
	 *
	 * @param customer the customer
	 */
	public static void cacheResult(Customer customer) {
		getPersistence().cacheResult(customer);
	}

	/**
	 * Caches the customers in the entity cache if it is enabled.
	 *
	 * @param customers the customers
	 */
	public static void cacheResult(List<Customer> customers) {
		getPersistence().cacheResult(customers);
	}

	/**
	 * Creates a new customer with the primary key. Does not add the customer to the database.
	 *
	 * @param customerId the primary key for the new customer
	 * @return the new customer
	 */
	public static Customer create(String customerId) {
		return getPersistence().create(customerId);
	}

	/**
	 * Removes the customer with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer that was removed
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer remove(String customerId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().remove(customerId);
	}

	public static Customer updateImpl(Customer customer) {
		return getPersistence().updateImpl(customer);
	}

	/**
	 * Returns the customer with the primary key or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public static Customer findByPrimaryKey(String customerId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return getPersistence().findByPrimaryKey(customerId);
	}

	/**
	 * Returns the customer with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer, or <code>null</code> if a customer with the primary key could not be found
	 */
	public static Customer fetchByPrimaryKey(String customerId) {
		return getPersistence().fetchByPrimaryKey(customerId);
	}

	/**
	 * Returns all the customers.
	 *
	 * @return the customers
	 */
	public static List<Customer> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of customers
	 */
	public static List<Customer> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of customers
	 */
	public static List<Customer> findAll(
		int start, int end, OrderByComparator<Customer> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of customers
	 */
	public static List<Customer> findAll(
		int start, int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the customers from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of customers.
	 *
	 * @return the number of customers
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static CustomerPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<CustomerPersistence, CustomerPersistence>
		_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(CustomerPersistence.class);

		ServiceTracker<CustomerPersistence, CustomerPersistence>
			serviceTracker =
				new ServiceTracker<CustomerPersistence, CustomerPersistence>(
					bundle.getBundleContext(), CustomerPersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}