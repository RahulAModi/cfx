/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link AgentCustomerMapping}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AgentCustomerMapping
 * @generated
 */
@ProviderType
public class AgentCustomerMappingWrapper
	extends BaseModelWrapper<AgentCustomerMapping>
	implements AgentCustomerMapping, ModelWrapper<AgentCustomerMapping> {

	public AgentCustomerMappingWrapper(
		AgentCustomerMapping agentCustomerMapping) {

		super(agentCustomerMapping);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("mappingId", getMappingId());
		attributes.put("agentScreenName", getAgentScreenName());
		attributes.put("customerScreenName", getCustomerScreenName());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String mappingId = (String)attributes.get("mappingId");

		if (mappingId != null) {
			setMappingId(mappingId);
		}

		String agentScreenName = (String)attributes.get("agentScreenName");

		if (agentScreenName != null) {
			setAgentScreenName(agentScreenName);
		}

		String customerScreenName = (String)attributes.get(
			"customerScreenName");

		if (customerScreenName != null) {
			setCustomerScreenName(customerScreenName);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	 * Returns the agent screen name of this agent customer mapping.
	 *
	 * @return the agent screen name of this agent customer mapping
	 */
	@Override
	public String getAgentScreenName() {
		return model.getAgentScreenName();
	}

	/**
	 * Returns the company ID of this agent customer mapping.
	 *
	 * @return the company ID of this agent customer mapping
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the create by of this agent customer mapping.
	 *
	 * @return the create by of this agent customer mapping
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this agent customer mapping.
	 *
	 * @return the create date of this agent customer mapping
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the customer screen name of this agent customer mapping.
	 *
	 * @return the customer screen name of this agent customer mapping
	 */
	@Override
	public String getCustomerScreenName() {
		return model.getCustomerScreenName();
	}

	/**
	 * Returns the group ID of this agent customer mapping.
	 *
	 * @return the group ID of this agent customer mapping
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the mapping ID of this agent customer mapping.
	 *
	 * @return the mapping ID of this agent customer mapping
	 */
	@Override
	public String getMappingId() {
		return model.getMappingId();
	}

	/**
	 * Returns the modified date of this agent customer mapping.
	 *
	 * @return the modified date of this agent customer mapping
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the primary key of this agent customer mapping.
	 *
	 * @return the primary key of this agent customer mapping
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the agent screen name of this agent customer mapping.
	 *
	 * @param agentScreenName the agent screen name of this agent customer mapping
	 */
	@Override
	public void setAgentScreenName(String agentScreenName) {
		model.setAgentScreenName(agentScreenName);
	}

	/**
	 * Sets the company ID of this agent customer mapping.
	 *
	 * @param companyId the company ID of this agent customer mapping
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the create by of this agent customer mapping.
	 *
	 * @param createBy the create by of this agent customer mapping
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this agent customer mapping.
	 *
	 * @param createDate the create date of this agent customer mapping
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the customer screen name of this agent customer mapping.
	 *
	 * @param customerScreenName the customer screen name of this agent customer mapping
	 */
	@Override
	public void setCustomerScreenName(String customerScreenName) {
		model.setCustomerScreenName(customerScreenName);
	}

	/**
	 * Sets the group ID of this agent customer mapping.
	 *
	 * @param groupId the group ID of this agent customer mapping
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the mapping ID of this agent customer mapping.
	 *
	 * @param mappingId the mapping ID of this agent customer mapping
	 */
	@Override
	public void setMappingId(String mappingId) {
		model.setMappingId(mappingId);
	}

	/**
	 * Sets the modified date of this agent customer mapping.
	 *
	 * @param modifiedDate the modified date of this agent customer mapping
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the primary key of this agent customer mapping.
	 *
	 * @param primaryKey the primary key of this agent customer mapping
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	@Override
	protected AgentCustomerMappingWrapper wrap(
		AgentCustomerMapping agentCustomerMapping) {

		return new AgentCustomerMappingWrapper(agentCustomerMapping);
	}

}