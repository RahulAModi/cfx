/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class AgentSoap implements Serializable {

	public static AgentSoap toSoapModel(Agent model) {
		AgentSoap soapModel = new AgentSoap();

		soapModel.setAgentId(model.getAgentId());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateBy(model.getCreateBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setScreenName(model.getScreenName());
		soapModel.setName(model.getName());
		soapModel.setParentCode(model.getParentCode());
		soapModel.setPrimary(model.isPrimary());
		soapModel.setPrefDom(model.getPrefDom());
		soapModel.setPoId(model.getPoId());
		soapModel.setAccountNo(model.getAccountNo());
		soapModel.setGstinNo(model.getGstinNo());
		soapModel.setStatus(model.getStatus());
		soapModel.setAutoRenew(model.isAutoRenew());
		soapModel.setLegacyCode(model.getLegacyCode());
		soapModel.setClientCode(model.getClientCode());
		soapModel.setBouquetCode(model.getBouquetCode());
		soapModel.setJvNo(model.getJvNo());
		soapModel.setDirectNo(model.getDirectNo());
		soapModel.setDistributor(model.getDistributor());
		soapModel.setSubDistributor(model.getSubDistributor());
		soapModel.setJvPoId(model.getJvPoId());
		soapModel.setDirectPoId(model.getDirectPoId());
		soapModel.setDistributorPoId(model.getDistributorPoId());
		soapModel.setSubDistributorPoId(model.getSubDistributorPoId());
		soapModel.setJvName(model.getJvName());
		soapModel.setDirectName(model.getDirectName());
		soapModel.setDistributorName(model.getDistributorName());
		soapModel.setSubDistributorName(model.getSubDistributorName());
		soapModel.setPanNo(model.getPanNo());
		soapModel.setReportDate(model.getReportDate());
		soapModel.setPpType(model.getPpType());
		soapModel.setLocator(model.getLocator());

		return soapModel;
	}

	public static AgentSoap[] toSoapModels(Agent[] models) {
		AgentSoap[] soapModels = new AgentSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static AgentSoap[][] toSoapModels(Agent[][] models) {
		AgentSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new AgentSoap[models.length][models[0].length];
		}
		else {
			soapModels = new AgentSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static AgentSoap[] toSoapModels(List<Agent> models) {
		List<AgentSoap> soapModels = new ArrayList<AgentSoap>(models.size());

		for (Agent model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new AgentSoap[soapModels.size()]);
	}

	public AgentSoap() {
	}

	public String getPrimaryKey() {
		return _agentId;
	}

	public void setPrimaryKey(String pk) {
		setAgentId(pk);
	}

	public String getAgentId() {
		return _agentId;
	}

	public void setAgentId(String agentId) {
		_agentId = agentId;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public String getCreateBy() {
		return _createBy;
	}

	public void setCreateBy(String createBy) {
		_createBy = createBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public String getScreenName() {
		return _screenName;
	}

	public void setScreenName(String screenName) {
		_screenName = screenName;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public String getParentCode() {
		return _parentCode;
	}

	public void setParentCode(String parentCode) {
		_parentCode = parentCode;
	}

	public boolean getPrimary() {
		return _primary;
	}

	public boolean isPrimary() {
		return _primary;
	}

	public void setPrimary(boolean primary) {
		_primary = primary;
	}

	public String getPrefDom() {
		return _prefDom;
	}

	public void setPrefDom(String prefDom) {
		_prefDom = prefDom;
	}

	public String getPoId() {
		return _poId;
	}

	public void setPoId(String poId) {
		_poId = poId;
	}

	public String getAccountNo() {
		return _accountNo;
	}

	public void setAccountNo(String accountNo) {
		_accountNo = accountNo;
	}

	public String getGstinNo() {
		return _gstinNo;
	}

	public void setGstinNo(String gstinNo) {
		_gstinNo = gstinNo;
	}

	public int getStatus() {
		return _status;
	}

	public void setStatus(int status) {
		_status = status;
	}

	public boolean getAutoRenew() {
		return _autoRenew;
	}

	public boolean isAutoRenew() {
		return _autoRenew;
	}

	public void setAutoRenew(boolean autoRenew) {
		_autoRenew = autoRenew;
	}

	public String getLegacyCode() {
		return _legacyCode;
	}

	public void setLegacyCode(String legacyCode) {
		_legacyCode = legacyCode;
	}

	public String getClientCode() {
		return _clientCode;
	}

	public void setClientCode(String clientCode) {
		_clientCode = clientCode;
	}

	public String getBouquetCode() {
		return _bouquetCode;
	}

	public void setBouquetCode(String bouquetCode) {
		_bouquetCode = bouquetCode;
	}

	public String getJvNo() {
		return _jvNo;
	}

	public void setJvNo(String jvNo) {
		_jvNo = jvNo;
	}

	public String getDirectNo() {
		return _directNo;
	}

	public void setDirectNo(String directNo) {
		_directNo = directNo;
	}

	public String getDistributor() {
		return _distributor;
	}

	public void setDistributor(String distributor) {
		_distributor = distributor;
	}

	public String getSubDistributor() {
		return _subDistributor;
	}

	public void setSubDistributor(String subDistributor) {
		_subDistributor = subDistributor;
	}

	public String getJvPoId() {
		return _jvPoId;
	}

	public void setJvPoId(String jvPoId) {
		_jvPoId = jvPoId;
	}

	public String getDirectPoId() {
		return _directPoId;
	}

	public void setDirectPoId(String directPoId) {
		_directPoId = directPoId;
	}

	public String getDistributorPoId() {
		return _distributorPoId;
	}

	public void setDistributorPoId(String distributorPoId) {
		_distributorPoId = distributorPoId;
	}

	public String getSubDistributorPoId() {
		return _subDistributorPoId;
	}

	public void setSubDistributorPoId(String subDistributorPoId) {
		_subDistributorPoId = subDistributorPoId;
	}

	public String getJvName() {
		return _jvName;
	}

	public void setJvName(String jvName) {
		_jvName = jvName;
	}

	public String getDirectName() {
		return _directName;
	}

	public void setDirectName(String directName) {
		_directName = directName;
	}

	public String getDistributorName() {
		return _distributorName;
	}

	public void setDistributorName(String distributorName) {
		_distributorName = distributorName;
	}

	public String getSubDistributorName() {
		return _subDistributorName;
	}

	public void setSubDistributorName(String subDistributorName) {
		_subDistributorName = subDistributorName;
	}

	public String getPanNo() {
		return _panNo;
	}

	public void setPanNo(String panNo) {
		_panNo = panNo;
	}

	public Date getReportDate() {
		return _reportDate;
	}

	public void setReportDate(Date reportDate) {
		_reportDate = reportDate;
	}

	public String getPpType() {
		return _ppType;
	}

	public void setPpType(String ppType) {
		_ppType = ppType;
	}

	public String getLocator() {
		return _locator;
	}

	public void setLocator(String locator) {
		_locator = locator;
	}

	private String _agentId;
	private long _groupId;
	private long _companyId;
	private String _createBy;
	private Date _createDate;
	private Date _modifiedDate;
	private String _screenName;
	private String _name;
	private String _parentCode;
	private boolean _primary;
	private String _prefDom;
	private String _poId;
	private String _accountNo;
	private String _gstinNo;
	private int _status;
	private boolean _autoRenew;
	private String _legacyCode;
	private String _clientCode;
	private String _bouquetCode;
	private String _jvNo;
	private String _directNo;
	private String _distributor;
	private String _subDistributor;
	private String _jvPoId;
	private String _directPoId;
	private String _distributorPoId;
	private String _subDistributorPoId;
	private String _jvName;
	private String _directName;
	private String _distributorName;
	private String _subDistributorName;
	private String _panNo;
	private Date _reportDate;
	private String _ppType;
	private String _locator;

}