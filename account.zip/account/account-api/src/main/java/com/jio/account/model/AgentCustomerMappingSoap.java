/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class AgentCustomerMappingSoap implements Serializable {

	public static AgentCustomerMappingSoap toSoapModel(
		AgentCustomerMapping model) {

		AgentCustomerMappingSoap soapModel = new AgentCustomerMappingSoap();

		soapModel.setMappingId(model.getMappingId());
		soapModel.setAgentScreenName(model.getAgentScreenName());
		soapModel.setCustomerScreenName(model.getCustomerScreenName());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateBy(model.getCreateBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());

		return soapModel;
	}

	public static AgentCustomerMappingSoap[] toSoapModels(
		AgentCustomerMapping[] models) {

		AgentCustomerMappingSoap[] soapModels =
			new AgentCustomerMappingSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static AgentCustomerMappingSoap[][] toSoapModels(
		AgentCustomerMapping[][] models) {

		AgentCustomerMappingSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels =
				new AgentCustomerMappingSoap[models.length][models[0].length];
		}
		else {
			soapModels = new AgentCustomerMappingSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static AgentCustomerMappingSoap[] toSoapModels(
		List<AgentCustomerMapping> models) {

		List<AgentCustomerMappingSoap> soapModels =
			new ArrayList<AgentCustomerMappingSoap>(models.size());

		for (AgentCustomerMapping model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(
			new AgentCustomerMappingSoap[soapModels.size()]);
	}

	public AgentCustomerMappingSoap() {
	}

	public String getPrimaryKey() {
		return _mappingId;
	}

	public void setPrimaryKey(String pk) {
		setMappingId(pk);
	}

	public String getMappingId() {
		return _mappingId;
	}

	public void setMappingId(String mappingId) {
		_mappingId = mappingId;
	}

	public String getAgentScreenName() {
		return _agentScreenName;
	}

	public void setAgentScreenName(String agentScreenName) {
		_agentScreenName = agentScreenName;
	}

	public String getCustomerScreenName() {
		return _customerScreenName;
	}

	public void setCustomerScreenName(String customerScreenName) {
		_customerScreenName = customerScreenName;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public String getCreateBy() {
		return _createBy;
	}

	public void setCreateBy(String createBy) {
		_createBy = createBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	private String _mappingId;
	private String _agentScreenName;
	private String _customerScreenName;
	private long _groupId;
	private long _companyId;
	private String _createBy;
	private Date _createDate;
	private Date _modifiedDate;

}