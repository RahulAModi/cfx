/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the agent service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AgentUtil
 * @generated
 */
@ProviderType
public interface AgentPersistence extends BasePersistence<Agent> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link AgentUtil} to access the agent persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the agents where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching agents
	 */
	public java.util.List<Agent> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the agents where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	public java.util.List<Agent> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the agents where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agents where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the first agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the last agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the last agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the agents before and after the current agent in the ordered set where companyId = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	public Agent[] findByCompanyId_PrevAndNext(
			String agentId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Removes all the agents where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of agents where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching agents
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByScreenName(long companyId, String screenName)
		throws NoSuchAgentException;

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByScreenName(long companyId, String screenName);

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByScreenName(
		long companyId, String screenName, boolean retrieveFromCache);

	/**
	 * Removes the agent where companyId = &#63; and screenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the agent that was removed
	 */
	public Agent removeByScreenName(long companyId, String screenName)
		throws NoSuchAgentException;

	/**
	 * Returns the number of agents where companyId = &#63; and screenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the number of matching agents
	 */
	public int countByScreenName(long companyId, String screenName);

	/**
	 * Returns the agent where companyId = &#63; and legacyCode = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByLegacyCode(long companyId, String legacyCode)
		throws NoSuchAgentException;

	/**
	 * Returns the agent where companyId = &#63; and legacyCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByLegacyCode(long companyId, String legacyCode);

	/**
	 * Returns the agent where companyId = &#63; and legacyCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByLegacyCode(
		long companyId, String legacyCode, boolean retrieveFromCache);

	/**
	 * Removes the agent where companyId = &#63; and legacyCode = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the agent that was removed
	 */
	public Agent removeByLegacyCode(long companyId, String legacyCode)
		throws NoSuchAgentException;

	/**
	 * Returns the number of agents where companyId = &#63; and legacyCode = &#63;.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the number of matching agents
	 */
	public int countByLegacyCode(long companyId, String legacyCode);

	/**
	 * Returns the agent where companyId = &#63; and clientCode = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByClientCode(long companyId, String clientCode)
		throws NoSuchAgentException;

	/**
	 * Returns the agent where companyId = &#63; and clientCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByClientCode(long companyId, String clientCode);

	/**
	 * Returns the agent where companyId = &#63; and clientCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByClientCode(
		long companyId, String clientCode, boolean retrieveFromCache);

	/**
	 * Removes the agent where companyId = &#63; and clientCode = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the agent that was removed
	 */
	public Agent removeByClientCode(long companyId, String clientCode)
		throws NoSuchAgentException;

	/**
	 * Returns the number of agents where companyId = &#63; and clientCode = &#63;.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the number of matching agents
	 */
	public int countByClientCode(long companyId, String clientCode);

	/**
	 * Returns all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @return the matching agents
	 */
	public java.util.List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary);

	/**
	 * Returns a range of all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	public java.util.List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary, int start, int end);

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByParentCodeAndIsPrimary_First(
			long companyId, String parentCode, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByParentCodeAndIsPrimary_First(
		long companyId, String parentCode, boolean primary,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByParentCodeAndIsPrimary_Last(
			long companyId, String parentCode, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByParentCodeAndIsPrimary_Last(
		long companyId, String parentCode, boolean primary,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the agents before and after the current agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	public Agent[] findByParentCodeAndIsPrimary_PrevAndNext(
			String agentId, long companyId, String parentCode, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Removes all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 */
	public void removeByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary);

	/**
	 * Returns the number of agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @return the number of matching agents
	 */
	public int countByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary);

	/**
	 * Returns all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @return the matching agents
	 */
	public java.util.List<Agent> findByParentCode(
		String parentCode, long companyId);

	/**
	 * Returns a range of all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	public java.util.List<Agent> findByParentCode(
		String parentCode, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByParentCode(
		String parentCode, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByParentCode(
		String parentCode, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByParentCode_First(
			String parentCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the first agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByParentCode_First(
		String parentCode, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the last agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByParentCode_Last(
			String parentCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the last agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByParentCode_Last(
		String parentCode, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the agents before and after the current agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	public Agent[] findByParentCode_PrevAndNext(
			String agentId, String parentCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Removes all the agents where parentCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 */
	public void removeByParentCode(String parentCode, long companyId);

	/**
	 * Returns the number of agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @return the number of matching agents
	 */
	public int countByParentCode(String parentCode, long companyId);

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByScreenNameAndParentCode(
			long companyId, String screenName, String parentCode)
		throws NoSuchAgentException;

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByScreenNameAndParentCode(
		long companyId, String screenName, String parentCode);

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByScreenNameAndParentCode(
		long companyId, String screenName, String parentCode,
		boolean retrieveFromCache);

	/**
	 * Removes the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the agent that was removed
	 */
	public Agent removeByScreenNameAndParentCode(
			long companyId, String screenName, String parentCode)
		throws NoSuchAgentException;

	/**
	 * Returns the number of agents where companyId = &#63; and screenName = &#63; and parentCode = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the number of matching agents
	 */
	public int countByScreenNameAndParentCode(
		long companyId, String screenName, String parentCode);

	/**
	 * Returns all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @return the matching agents
	 */
	public java.util.List<Agent> findByPrimaryStatus(
		long companyId, boolean primary);

	/**
	 * Returns a range of all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	public java.util.List<Agent> findByPrimaryStatus(
		long companyId, boolean primary, int start, int end);

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByPrimaryStatus(
		long companyId, boolean primary, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	public java.util.List<Agent> findByPrimaryStatus(
		long companyId, boolean primary, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByPrimaryStatus_First(
			long companyId, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByPrimaryStatus_First(
		long companyId, boolean primary,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	public Agent findByPrimaryStatus_Last(
			long companyId, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	public Agent fetchByPrimaryStatus_Last(
		long companyId, boolean primary,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns the agents before and after the current agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	public Agent[] findByPrimaryStatus_PrevAndNext(
			String agentId, long companyId, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Agent>
				orderByComparator)
		throws NoSuchAgentException;

	/**
	 * Removes all the agents where companyId = &#63; and primary = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 */
	public void removeByPrimaryStatus(long companyId, boolean primary);

	/**
	 * Returns the number of agents where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @return the number of matching agents
	 */
	public int countByPrimaryStatus(long companyId, boolean primary);

	/**
	 * Caches the agent in the entity cache if it is enabled.
	 *
	 * @param agent the agent
	 */
	public void cacheResult(Agent agent);

	/**
	 * Caches the agents in the entity cache if it is enabled.
	 *
	 * @param agents the agents
	 */
	public void cacheResult(java.util.List<Agent> agents);

	/**
	 * Creates a new agent with the primary key. Does not add the agent to the database.
	 *
	 * @param agentId the primary key for the new agent
	 * @return the new agent
	 */
	public Agent create(String agentId);

	/**
	 * Removes the agent with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent that was removed
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	public Agent remove(String agentId) throws NoSuchAgentException;

	public Agent updateImpl(Agent agent);

	/**
	 * Returns the agent with the primary key or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	public Agent findByPrimaryKey(String agentId) throws NoSuchAgentException;

	/**
	 * Returns the agent with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent, or <code>null</code> if a agent with the primary key could not be found
	 */
	public Agent fetchByPrimaryKey(String agentId);

	/**
	 * Returns all the agents.
	 *
	 * @return the agents
	 */
	public java.util.List<Agent> findAll();

	/**
	 * Returns a range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of agents
	 */
	public java.util.List<Agent> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of agents
	 */
	public java.util.List<Agent> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of agents
	 */
	public java.util.List<Agent> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Agent>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the agents from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of agents.
	 *
	 * @return the number of agents
	 */
	public int countAll();

}