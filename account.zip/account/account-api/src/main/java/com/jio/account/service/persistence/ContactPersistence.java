/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence;

import com.jio.account.exception.NoSuchContactException;
import com.jio.account.model.Contact;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the contact service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ContactUtil
 * @generated
 */
@ProviderType
public interface ContactPersistence extends BasePersistence<Contact> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link ContactUtil} to access the contact persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the contact where customerId = &#63; and companyId = &#63; or throws a <code>NoSuchContactException</code> if it could not be found.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findByCustomerId(String customerId, long companyId)
		throws NoSuchContactException;

	/**
	 * Returns the contact where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByCustomerId(String customerId, long companyId);

	/**
	 * Returns the contact where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByCustomerId(
		String customerId, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the contact where customerId = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the contact that was removed
	 */
	public Contact removeByCustomerId(String customerId, long companyId)
		throws NoSuchContactException;

	/**
	 * Returns the number of contacts where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the number of matching contacts
	 */
	public int countByCustomerId(String customerId, long companyId);

	/**
	 * Returns the contact where companyId = &#63; and screenName = &#63; or throws a <code>NoSuchContactException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findByScreenName(long companyId, String screenName)
		throws NoSuchContactException;

	/**
	 * Returns the contact where companyId = &#63; and screenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByScreenName(long companyId, String screenName);

	/**
	 * Returns the contact where companyId = &#63; and screenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByScreenName(
		long companyId, String screenName, boolean retrieveFromCache);

	/**
	 * Removes the contact where companyId = &#63; and screenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the contact that was removed
	 */
	public Contact removeByScreenName(long companyId, String screenName)
		throws NoSuchContactException;

	/**
	 * Returns the number of contacts where companyId = &#63; and screenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the number of matching contacts
	 */
	public int countByScreenName(long companyId, String screenName);

	/**
	 * Returns all the contacts where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching contacts
	 */
	public java.util.List<Contact> findBySN(String screenName, long companyId);

	/**
	 * Returns a range of all the contacts where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @return the range of matching contacts
	 */
	public java.util.List<Contact> findBySN(
		String screenName, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the contacts where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching contacts
	 */
	public java.util.List<Contact> findBySN(
		String screenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns an ordered range of all the contacts where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching contacts
	 */
	public java.util.List<Contact> findBySN(
		String screenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first contact in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findBySN_First(
			String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Contact>
				orderByComparator)
		throws NoSuchContactException;

	/**
	 * Returns the first contact in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchBySN_First(
		String screenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns the last contact in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findBySN_Last(
			String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Contact>
				orderByComparator)
		throws NoSuchContactException;

	/**
	 * Returns the last contact in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchBySN_Last(
		String screenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns the contacts before and after the current contact in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param contactId the primary key of the current contact
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next contact
	 * @throws NoSuchContactException if a contact with the primary key could not be found
	 */
	public Contact[] findBySN_PrevAndNext(
			String contactId, String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Contact>
				orderByComparator)
		throws NoSuchContactException;

	/**
	 * Removes all the contacts where screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	public void removeBySN(String screenName, long companyId);

	/**
	 * Returns the number of contacts where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching contacts
	 */
	public int countBySN(String screenName, long companyId);

	/**
	 * Returns all the contacts where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @return the matching contacts
	 */
	public java.util.List<Contact> findByScreenNameAndIsPrimary(
		long companyId, String screenName, boolean primary);

	/**
	 * Returns a range of all the contacts where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @return the range of matching contacts
	 */
	public java.util.List<Contact> findByScreenNameAndIsPrimary(
		long companyId, String screenName, boolean primary, int start, int end);

	/**
	 * Returns an ordered range of all the contacts where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching contacts
	 */
	public java.util.List<Contact> findByScreenNameAndIsPrimary(
		long companyId, String screenName, boolean primary, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns an ordered range of all the contacts where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching contacts
	 */
	public java.util.List<Contact> findByScreenNameAndIsPrimary(
		long companyId, String screenName, boolean primary, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first contact in the ordered set where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findByScreenNameAndIsPrimary_First(
			long companyId, String screenName, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Contact>
				orderByComparator)
		throws NoSuchContactException;

	/**
	 * Returns the first contact in the ordered set where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByScreenNameAndIsPrimary_First(
		long companyId, String screenName, boolean primary,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns the last contact in the ordered set where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findByScreenNameAndIsPrimary_Last(
			long companyId, String screenName, boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Contact>
				orderByComparator)
		throws NoSuchContactException;

	/**
	 * Returns the last contact in the ordered set where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByScreenNameAndIsPrimary_Last(
		long companyId, String screenName, boolean primary,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns the contacts before and after the current contact in the ordered set where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param contactId the primary key of the current contact
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next contact
	 * @throws NoSuchContactException if a contact with the primary key could not be found
	 */
	public Contact[] findByScreenNameAndIsPrimary_PrevAndNext(
			String contactId, long companyId, String screenName,
			boolean primary,
			com.liferay.portal.kernel.util.OrderByComparator<Contact>
				orderByComparator)
		throws NoSuchContactException;

	/**
	 * Removes all the contacts where companyId = &#63; and screenName = &#63; and primary = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 */
	public void removeByScreenNameAndIsPrimary(
		long companyId, String screenName, boolean primary);

	/**
	 * Returns the number of contacts where companyId = &#63; and screenName = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param primary the primary
	 * @return the number of matching contacts
	 */
	public int countByScreenNameAndIsPrimary(
		long companyId, String screenName, boolean primary);

	/**
	 * Returns the contact where companyId = &#63; and screenName = &#63; and contactId = &#63; or throws a <code>NoSuchContactException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param contactId the contact ID
	 * @return the matching contact
	 * @throws NoSuchContactException if a matching contact could not be found
	 */
	public Contact findByScreenNameAndContactId(
			long companyId, String screenName, String contactId)
		throws NoSuchContactException;

	/**
	 * Returns the contact where companyId = &#63; and screenName = &#63; and contactId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param contactId the contact ID
	 * @return the matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByScreenNameAndContactId(
		long companyId, String screenName, String contactId);

	/**
	 * Returns the contact where companyId = &#63; and screenName = &#63; and contactId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param contactId the contact ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching contact, or <code>null</code> if a matching contact could not be found
	 */
	public Contact fetchByScreenNameAndContactId(
		long companyId, String screenName, String contactId,
		boolean retrieveFromCache);

	/**
	 * Removes the contact where companyId = &#63; and screenName = &#63; and contactId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param contactId the contact ID
	 * @return the contact that was removed
	 */
	public Contact removeByScreenNameAndContactId(
			long companyId, String screenName, String contactId)
		throws NoSuchContactException;

	/**
	 * Returns the number of contacts where companyId = &#63; and screenName = &#63; and contactId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param contactId the contact ID
	 * @return the number of matching contacts
	 */
	public int countByScreenNameAndContactId(
		long companyId, String screenName, String contactId);

	/**
	 * Caches the contact in the entity cache if it is enabled.
	 *
	 * @param contact the contact
	 */
	public void cacheResult(Contact contact);

	/**
	 * Caches the contacts in the entity cache if it is enabled.
	 *
	 * @param contacts the contacts
	 */
	public void cacheResult(java.util.List<Contact> contacts);

	/**
	 * Creates a new contact with the primary key. Does not add the contact to the database.
	 *
	 * @param contactId the primary key for the new contact
	 * @return the new contact
	 */
	public Contact create(String contactId);

	/**
	 * Removes the contact with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param contactId the primary key of the contact
	 * @return the contact that was removed
	 * @throws NoSuchContactException if a contact with the primary key could not be found
	 */
	public Contact remove(String contactId) throws NoSuchContactException;

	public Contact updateImpl(Contact contact);

	/**
	 * Returns the contact with the primary key or throws a <code>NoSuchContactException</code> if it could not be found.
	 *
	 * @param contactId the primary key of the contact
	 * @return the contact
	 * @throws NoSuchContactException if a contact with the primary key could not be found
	 */
	public Contact findByPrimaryKey(String contactId)
		throws NoSuchContactException;

	/**
	 * Returns the contact with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param contactId the primary key of the contact
	 * @return the contact, or <code>null</code> if a contact with the primary key could not be found
	 */
	public Contact fetchByPrimaryKey(String contactId);

	/**
	 * Returns all the contacts.
	 *
	 * @return the contacts
	 */
	public java.util.List<Contact> findAll();

	/**
	 * Returns a range of all the contacts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @return the range of contacts
	 */
	public java.util.List<Contact> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the contacts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of contacts
	 */
	public java.util.List<Contact> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator);

	/**
	 * Returns an ordered range of all the contacts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>ContactModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of contacts
	 * @param end the upper bound of the range of contacts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of contacts
	 */
	public java.util.List<Contact> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Contact>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the contacts from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of contacts.
	 *
	 * @return the number of contacts
	 */
	public int countAll();

}