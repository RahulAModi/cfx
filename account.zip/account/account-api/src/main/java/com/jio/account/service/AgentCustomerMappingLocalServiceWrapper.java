/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides a wrapper for {@link AgentCustomerMappingLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see AgentCustomerMappingLocalService
 * @generated
 */
@ProviderType
public class AgentCustomerMappingLocalServiceWrapper
	implements AgentCustomerMappingLocalService,
			   ServiceWrapper<AgentCustomerMappingLocalService> {

	public AgentCustomerMappingLocalServiceWrapper(
		AgentCustomerMappingLocalService agentCustomerMappingLocalService) {

		_agentCustomerMappingLocalService = agentCustomerMappingLocalService;
	}

	/**
	 * Adds the agent customer mapping to the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 * @return the agent customer mapping that was added
	 */
	@Override
	public com.jio.account.model.AgentCustomerMapping addAgentCustomerMapping(
		com.jio.account.model.AgentCustomerMapping agentCustomerMapping) {

		return _agentCustomerMappingLocalService.addAgentCustomerMapping(
			agentCustomerMapping);
	}

	/**
	 * Creates a new agent customer mapping with the primary key. Does not add the agent customer mapping to the database.
	 *
	 * @param mappingId the primary key for the new agent customer mapping
	 * @return the new agent customer mapping
	 */
	@Override
	public com.jio.account.model.AgentCustomerMapping
		createAgentCustomerMapping(String mappingId) {

		return _agentCustomerMappingLocalService.createAgentCustomerMapping(
			mappingId);
	}

	/**
	 * Deletes the agent customer mapping from the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 * @return the agent customer mapping that was removed
	 */
	@Override
	public com.jio.account.model.AgentCustomerMapping
		deleteAgentCustomerMapping(
			com.jio.account.model.AgentCustomerMapping agentCustomerMapping) {

		return _agentCustomerMappingLocalService.deleteAgentCustomerMapping(
			agentCustomerMapping);
	}

	/**
	 * Deletes the agent customer mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping that was removed
	 * @throws PortalException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public com.jio.account.model.AgentCustomerMapping
			deleteAgentCustomerMapping(String mappingId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _agentCustomerMappingLocalService.deleteAgentCustomerMapping(
			mappingId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _agentCustomerMappingLocalService.deletePersistedModel(
			persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _agentCustomerMappingLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _agentCustomerMappingLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _agentCustomerMappingLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _agentCustomerMappingLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _agentCustomerMappingLocalService.dynamicQueryCount(
			dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _agentCustomerMappingLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.jio.account.model.AgentCustomerMapping fetchAgentCustomerMapping(
		String mappingId) {

		return _agentCustomerMappingLocalService.fetchAgentCustomerMapping(
			mappingId);
	}

	@Override
	public com.jio.account.model.AgentCustomerMapping
			findByAgentAndCustomerScreenName(
				long companyId, String agentScreenName,
				String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return _agentCustomerMappingLocalService.
			findByAgentAndCustomerScreenName(
				companyId, agentScreenName, customerScreenName);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		findByAgentScreenName(long companyId, String agentScreenName) {

		return _agentCustomerMappingLocalService.findByAgentScreenName(
			companyId, agentScreenName);
	}

	@Override
	public com.jio.account.model.AgentCustomerMapping findByCustomerScreenName(
			long companyId, String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return _agentCustomerMappingLocalService.findByCustomerScreenName(
			companyId, customerScreenName);
	}

	/**
	 * Returns the agent customer mapping with the primary key.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping
	 * @throws PortalException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public com.jio.account.model.AgentCustomerMapping getAgentCustomerMapping(
			String mappingId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _agentCustomerMappingLocalService.getAgentCustomerMapping(
			mappingId);
	}

	/**
	 * Returns a range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of agent customer mappings
	 */
	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(int start, int end) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId, int start, int end) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId, String agentScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenName);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String agentScreenName, int start, int end) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenName, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String agentScreenName, String customerScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenName, customerScreenName);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String agentScreenName, String customerScreenName,
			int start, int end) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenName, customerScreenName, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId, String[] agentScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenName);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String[] agentScreenName, int start, int end) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenName, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String[] agentScreenNames,
			String customerScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenNames, customerScreenName);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String[] agentScreenNames,
			String customerScreenName, int start, int end) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappings(
			companyId, agentScreenNames, customerScreenName, start, end);
	}

	/**
	 * Returns the number of agent customer mappings.
	 *
	 * @return the number of agent customer mappings
	 */
	@Override
	public int getAgentCustomerMappingsCount() {
		return _agentCustomerMappingLocalService.
			getAgentCustomerMappingsCount();
	}

	@Override
	public int getAgentCustomerMappingsCount(long companyId) {
		return _agentCustomerMappingLocalService.getAgentCustomerMappingsCount(
			companyId);
	}

	@Override
	public int getAgentCustomerMappingsCount(
		long companyId, String agentScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappingsCount(
			companyId, agentScreenName);
	}

	@Override
	public int getAgentCustomerMappingsCount(
		long companyId, String agentScreenName, String customerScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappingsCount(
			companyId, agentScreenName, customerScreenName);
	}

	@Override
	public int getAgentCustomerMappingsCount(
		long companyId, String[] agentScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappingsCount(
			companyId, agentScreenName);
	}

	@Override
	public int getAgentCustomerMappingsCount(
		long companyId, String[] agentScreenNames, String customerScreenName) {

		return _agentCustomerMappingLocalService.getAgentCustomerMappingsCount(
			companyId, agentScreenNames, customerScreenName);
	}

	@Override
	public java.util.List<com.jio.account.model.AgentCustomerMapping>
		getByCustomerScreenNames(long companyId, String[] customerScreenName) {

		return _agentCustomerMappingLocalService.getByCustomerScreenNames(
			companyId, customerScreenName);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _agentCustomerMappingLocalService.getOSGiServiceIdentifier();
	}

	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _agentCustomerMappingLocalService.getPersistedModel(
			primaryKeyObj);
	}

	@Override
	public com.jio.account.model.AgentCustomerMapping
		saveOrUpdateAgentCustomerMapping(
			long companyId, long groupId, String screenName,
			String agentScreenName, String createBy) {

		return _agentCustomerMappingLocalService.
			saveOrUpdateAgentCustomerMapping(
				companyId, groupId, screenName, agentScreenName, createBy);
	}

	/**
	 * Updates the agent customer mapping in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 * @return the agent customer mapping that was updated
	 */
	@Override
	public com.jio.account.model.AgentCustomerMapping
		updateAgentCustomerMapping(
			com.jio.account.model.AgentCustomerMapping agentCustomerMapping) {

		return _agentCustomerMappingLocalService.updateAgentCustomerMapping(
			agentCustomerMapping);
	}

	@Override
	public AgentCustomerMappingLocalService getWrappedService() {
		return _agentCustomerMappingLocalService;
	}

	@Override
	public void setWrappedService(
		AgentCustomerMappingLocalService agentCustomerMappingLocalService) {

		_agentCustomerMappingLocalService = agentCustomerMappingLocalService;
	}

	private AgentCustomerMappingLocalService _agentCustomerMappingLocalService;

}