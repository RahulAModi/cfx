/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides a wrapper for {@link CustomerLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see CustomerLocalService
 * @generated
 */
@ProviderType
public class CustomerLocalServiceWrapper
	implements CustomerLocalService, ServiceWrapper<CustomerLocalService> {

	public CustomerLocalServiceWrapper(
		CustomerLocalService customerLocalService) {

		_customerLocalService = customerLocalService;
	}

	/**
	 * Adds the customer to the database. Also notifies the appropriate model listeners.
	 *
	 * @param customer the customer
	 * @return the customer that was added
	 */
	@Override
	public com.jio.account.model.Customer addCustomer(
		com.jio.account.model.Customer customer) {

		return _customerLocalService.addCustomer(customer);
	}

	/**
	 * Creates a new customer with the primary key. Does not add the customer to the database.
	 *
	 * @param customerId the primary key for the new customer
	 * @return the new customer
	 */
	@Override
	public com.jio.account.model.Customer createCustomer(String customerId) {
		return _customerLocalService.createCustomer(customerId);
	}

	@Override
	public int customerCountByLogInAgent(String agentScreenName, long companyId)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.customerCountByLogInAgent(
			agentScreenName, companyId);
	}

	@Override
	public int customerCountByMacId(
			String macId, long companyId, String agentScreenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.customerCountByMacId(
			macId, companyId, agentScreenName);
	}

	@Override
	public int customerCountByScreenName(
			String screenName, long companyId, String agentScreenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.customerCountByScreenName(
			screenName, companyId, agentScreenName);
	}

	@Override
	public int customerCountByStatus(
			String status, long companyId, String agentScreenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.customerCountByStatus(
			status, companyId, agentScreenName);
	}

	@Override
	public int customerCountByStbNo(
			String stbNo, long companyId, String agentScreenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.customerCountByStbNo(
			stbNo, companyId, agentScreenName);
	}

	@Override
	public int customerCountByVcId(
			String vcId, long companyId, String agentScreenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.customerCountByVcId(
			vcId, companyId, agentScreenName);
	}

	/**
	 * Deletes the customer from the database. Also notifies the appropriate model listeners.
	 *
	 * @param customer the customer
	 * @return the customer that was removed
	 */
	@Override
	public com.jio.account.model.Customer deleteCustomer(
		com.jio.account.model.Customer customer) {

		return _customerLocalService.deleteCustomer(customer);
	}

	/**
	 * Deletes the customer with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer that was removed
	 * @throws PortalException if a customer with the primary key could not be found
	 */
	@Override
	public com.jio.account.model.Customer deleteCustomer(String customerId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _customerLocalService.deleteCustomer(customerId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _customerLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _customerLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _customerLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _customerLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _customerLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _customerLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _customerLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.jio.account.model.Customer fetchCustomer(String customerId) {
		return _customerLocalService.fetchCustomer(customerId);
	}

	/**
	 * Returns the customer with the primary key.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer
	 * @throws PortalException if a customer with the primary key could not be found
	 */
	@Override
	public com.jio.account.model.Customer getCustomer(String customerId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _customerLocalService.getCustomer(customerId);
	}

	@Override
	public com.jio.account.model.Customer getCustomer(
			String accountNo, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomer(accountNo, companyId);
	}

	@Override
	public com.jio.account.model.Customer getCustomer(
			String accountNo, String screenName, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomer(
			accountNo, screenName, companyId);
	}

	@Override
	public com.jio.account.model.Customer getCustomerByCustomerId(
			String customerId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerByCustomerId(
			customerId, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer>
			getCustomerByLogInAgent(
				String agentScreenName, long companyId, int start, int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.getCustomerByLogInAgent(
			agentScreenName, companyId, start, end);
	}

	@Override
	public com.jio.account.model.Customer getCustomerByMacId(
			String macId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerByMacId(macId, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomerByMacId(
			String macId, long companyId, String agentScreenName, int start,
			int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.getCustomerByMacId(
			macId, companyId, agentScreenName, start, end);
	}

	@Override
	public com.jio.account.model.Customer getCustomerByMacId(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerByMacId(
			accountNo, macId, agentScreenName, companyId);
	}

	@Override
	public com.jio.account.model.Customer getCustomerByScreenName(
			String screenName, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerByScreenName(
			screenName, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer>
			getCustomerByScreenName(
				String screenName, long companyId, String agentScreenName,
				int start, int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.getCustomerByScreenName(
			screenName, companyId, agentScreenName, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomerByStatus(
			String status, long companyId, String agentScreenName, int start,
			int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.getCustomerByStatus(
			status, companyId, agentScreenName, start, end);
	}

	@Override
	public com.jio.account.model.Customer getCustomerBySTBNo(
			String stbNo, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerBySTBNo(stbNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomerByStbNo(
			String stbNo, long companyId, String agentScreenName, int start,
			int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.getCustomerByStbNo(
			stbNo, companyId, agentScreenName, start, end);
	}

	@Override
	public com.jio.account.model.Customer getCustomerBySTBNo(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerBySTBNo(
			accountNo, stbNo, agentScreenName, companyId);
	}

	@Override
	public com.jio.account.model.Customer getCustomerByVcId(
			String vcId, long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerByVcId(vcId, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomerByVcId(
			String vcId, long companyId, String agentScreenName, int start,
			int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return _customerLocalService.getCustomerByVcId(
			vcId, companyId, agentScreenName, start, end);
	}

	@Override
	public com.jio.account.model.Customer getCustomerByVcId(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws com.jio.account.exception.NoSuchCustomerException {

		return _customerLocalService.getCustomerByVcId(
			accountNo, vcId, agentScreenName, companyId);
	}

	/**
	 * Returns a range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of customers
	 */
	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomers(
		int start, int end) {

		return _customerLocalService.getCustomers(start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomers(
		long companyId, int start, int end) {

		return _customerLocalService.getCustomers(companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomers(
		String screenName, boolean primary, long companyId) {

		return _customerLocalService.getCustomers(
			screenName, primary, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomers(
		String screenName, boolean primary, long companyId, int start,
		int end) {

		return _customerLocalService.getCustomers(
			screenName, primary, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomers(
		String screenName, long companyId) {

		return _customerLocalService.getCustomers(screenName, companyId);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer> getCustomers(
		String screenName, long companyId, int start, int end) {

		return _customerLocalService.getCustomers(
			screenName, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.model.Customer>
		getCustomersByCompanyId(long companyId) {

		return _customerLocalService.getCustomersByCompanyId(companyId);
	}

	/**
	 * Returns the number of customers.
	 *
	 * @return the number of customers
	 */
	@Override
	public int getCustomersCount() {
		return _customerLocalService.getCustomersCount();
	}

	@Override
	public int getCustomersCount(long companyId) {
		return _customerLocalService.getCustomersCount(companyId);
	}

	@Override
	public int getCustomersCount(
		String screenName, boolean primary, long companyId) {

		return _customerLocalService.getCustomersCount(
			screenName, primary, companyId);
	}

	@Override
	public int getCustomersCount(String screenName, long companyId) {
		return _customerLocalService.getCustomersCount(screenName, companyId);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _customerLocalService.getOSGiServiceIdentifier();
	}

	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _customerLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the customer in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param customer the customer
	 * @return the customer that was updated
	 */
	@Override
	public com.jio.account.model.Customer updateCustomer(
		com.jio.account.model.Customer customer) {

		return _customerLocalService.updateCustomer(customer);
	}

	@Override
	public CustomerLocalService getWrappedService() {
		return _customerLocalService;
	}

	@Override
	public void setWrappedService(CustomerLocalService customerLocalService) {
		_customerLocalService = customerLocalService;
	}

	private CustomerLocalService _customerLocalService;

}