/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link Customer}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Customer
 * @generated
 */
@ProviderType
public class CustomerWrapper
	extends BaseModelWrapper<Customer>
	implements Customer, ModelWrapper<Customer> {

	public CustomerWrapper(Customer customer) {
		super(customer);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("customerId", getCustomerId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("salutation", getSalutation());
		attributes.put("firstName", getFirstName());
		attributes.put("middleName", getMiddleName());
		attributes.put("lastName", getLastName());
		attributes.put("screenName", getScreenName());
		attributes.put("agentScreenName", getAgentScreenName());
		attributes.put("brmId", getBrmId());
		attributes.put("vcId", getVcId());
		attributes.put("stbNo", getStbNo());
		attributes.put("macId", getMacId());
		attributes.put("accountNo", getAccountNo());
		attributes.put("poId", getPoId());
		attributes.put("connectionType", getConnectionType());
		attributes.put("batId", getBatId());
		attributes.put("serviceType", getServiceType());
		attributes.put("status", getStatus());
		attributes.put("primary", isPrimary());
		attributes.put("remark", getRemark());
		attributes.put("vcPoId", getVcPoId());
		attributes.put("stbPoId", getStbPoId());
		attributes.put("macPoId", getMacPoId());
		attributes.put("servicePoId", getServicePoId());
		attributes.put("autoRenew", isAutoRenew());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String customerId = (String)attributes.get("customerId");

		if (customerId != null) {
			setCustomerId(customerId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String salutation = (String)attributes.get("salutation");

		if (salutation != null) {
			setSalutation(salutation);
		}

		String firstName = (String)attributes.get("firstName");

		if (firstName != null) {
			setFirstName(firstName);
		}

		String middleName = (String)attributes.get("middleName");

		if (middleName != null) {
			setMiddleName(middleName);
		}

		String lastName = (String)attributes.get("lastName");

		if (lastName != null) {
			setLastName(lastName);
		}

		String screenName = (String)attributes.get("screenName");

		if (screenName != null) {
			setScreenName(screenName);
		}

		String agentScreenName = (String)attributes.get("agentScreenName");

		if (agentScreenName != null) {
			setAgentScreenName(agentScreenName);
		}

		String brmId = (String)attributes.get("brmId");

		if (brmId != null) {
			setBrmId(brmId);
		}

		String vcId = (String)attributes.get("vcId");

		if (vcId != null) {
			setVcId(vcId);
		}

		String stbNo = (String)attributes.get("stbNo");

		if (stbNo != null) {
			setStbNo(stbNo);
		}

		String macId = (String)attributes.get("macId");

		if (macId != null) {
			setMacId(macId);
		}

		String accountNo = (String)attributes.get("accountNo");

		if (accountNo != null) {
			setAccountNo(accountNo);
		}

		String poId = (String)attributes.get("poId");

		if (poId != null) {
			setPoId(poId);
		}

		String connectionType = (String)attributes.get("connectionType");

		if (connectionType != null) {
			setConnectionType(connectionType);
		}

		String batId = (String)attributes.get("batId");

		if (batId != null) {
			setBatId(batId);
		}

		String serviceType = (String)attributes.get("serviceType");

		if (serviceType != null) {
			setServiceType(serviceType);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Boolean primary = (Boolean)attributes.get("primary");

		if (primary != null) {
			setPrimary(primary);
		}

		String remark = (String)attributes.get("remark");

		if (remark != null) {
			setRemark(remark);
		}

		String vcPoId = (String)attributes.get("vcPoId");

		if (vcPoId != null) {
			setVcPoId(vcPoId);
		}

		String stbPoId = (String)attributes.get("stbPoId");

		if (stbPoId != null) {
			setStbPoId(stbPoId);
		}

		String macPoId = (String)attributes.get("macPoId");

		if (macPoId != null) {
			setMacPoId(macPoId);
		}

		String servicePoId = (String)attributes.get("servicePoId");

		if (servicePoId != null) {
			setServicePoId(servicePoId);
		}

		Boolean autoRenew = (Boolean)attributes.get("autoRenew");

		if (autoRenew != null) {
			setAutoRenew(autoRenew);
		}
	}

	/**
	 * Returns the account no of this customer.
	 *
	 * @return the account no of this customer
	 */
	@Override
	public String getAccountNo() {
		return model.getAccountNo();
	}

	/**
	 * Returns the agent screen name of this customer.
	 *
	 * @return the agent screen name of this customer
	 */
	@Override
	public String getAgentScreenName() {
		return model.getAgentScreenName();
	}

	/**
	 * Returns the auto renew of this customer.
	 *
	 * @return the auto renew of this customer
	 */
	@Override
	public boolean getAutoRenew() {
		return model.getAutoRenew();
	}

	/**
	 * Returns the bat ID of this customer.
	 *
	 * @return the bat ID of this customer
	 */
	@Override
	public String getBatId() {
		return model.getBatId();
	}

	/**
	 * Returns the brm ID of this customer.
	 *
	 * @return the brm ID of this customer
	 */
	@Override
	public String getBrmId() {
		return model.getBrmId();
	}

	/**
	 * Returns the company ID of this customer.
	 *
	 * @return the company ID of this customer
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the connection type of this customer.
	 *
	 * @return the connection type of this customer
	 */
	@Override
	public String getConnectionType() {
		return model.getConnectionType();
	}

	/**
	 * Returns the create by of this customer.
	 *
	 * @return the create by of this customer
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this customer.
	 *
	 * @return the create date of this customer
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the customer ID of this customer.
	 *
	 * @return the customer ID of this customer
	 */
	@Override
	public String getCustomerId() {
		return model.getCustomerId();
	}

	/**
	 * Returns the first name of this customer.
	 *
	 * @return the first name of this customer
	 */
	@Override
	public String getFirstName() {
		return model.getFirstName();
	}

	/**
	 * Returns the group ID of this customer.
	 *
	 * @return the group ID of this customer
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the last name of this customer.
	 *
	 * @return the last name of this customer
	 */
	@Override
	public String getLastName() {
		return model.getLastName();
	}

	/**
	 * Returns the mac ID of this customer.
	 *
	 * @return the mac ID of this customer
	 */
	@Override
	public String getMacId() {
		return model.getMacId();
	}

	/**
	 * Returns the mac po ID of this customer.
	 *
	 * @return the mac po ID of this customer
	 */
	@Override
	public String getMacPoId() {
		return model.getMacPoId();
	}

	/**
	 * Returns the middle name of this customer.
	 *
	 * @return the middle name of this customer
	 */
	@Override
	public String getMiddleName() {
		return model.getMiddleName();
	}

	/**
	 * Returns the modified date of this customer.
	 *
	 * @return the modified date of this customer
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the po ID of this customer.
	 *
	 * @return the po ID of this customer
	 */
	@Override
	public String getPoId() {
		return model.getPoId();
	}

	/**
	 * Returns the primary of this customer.
	 *
	 * @return the primary of this customer
	 */
	@Override
	public boolean getPrimary() {
		return model.getPrimary();
	}

	/**
	 * Returns the primary key of this customer.
	 *
	 * @return the primary key of this customer
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the remark of this customer.
	 *
	 * @return the remark of this customer
	 */
	@Override
	public String getRemark() {
		return model.getRemark();
	}

	/**
	 * Returns the salutation of this customer.
	 *
	 * @return the salutation of this customer
	 */
	@Override
	public String getSalutation() {
		return model.getSalutation();
	}

	/**
	 * Returns the screen name of this customer.
	 *
	 * @return the screen name of this customer
	 */
	@Override
	public String getScreenName() {
		return model.getScreenName();
	}

	/**
	 * Returns the service po ID of this customer.
	 *
	 * @return the service po ID of this customer
	 */
	@Override
	public String getServicePoId() {
		return model.getServicePoId();
	}

	/**
	 * Returns the service type of this customer.
	 *
	 * @return the service type of this customer
	 */
	@Override
	public String getServiceType() {
		return model.getServiceType();
	}

	/**
	 * Returns the status of this customer.
	 *
	 * @return the status of this customer
	 */
	@Override
	public String getStatus() {
		return model.getStatus();
	}

	/**
	 * Returns the stb no of this customer.
	 *
	 * @return the stb no of this customer
	 */
	@Override
	public String getStbNo() {
		return model.getStbNo();
	}

	/**
	 * Returns the stb po ID of this customer.
	 *
	 * @return the stb po ID of this customer
	 */
	@Override
	public String getStbPoId() {
		return model.getStbPoId();
	}

	/**
	 * Returns the vc ID of this customer.
	 *
	 * @return the vc ID of this customer
	 */
	@Override
	public String getVcId() {
		return model.getVcId();
	}

	/**
	 * Returns the vc po ID of this customer.
	 *
	 * @return the vc po ID of this customer
	 */
	@Override
	public String getVcPoId() {
		return model.getVcPoId();
	}

	/**
	 * Returns <code>true</code> if this customer is auto renew.
	 *
	 * @return <code>true</code> if this customer is auto renew; <code>false</code> otherwise
	 */
	@Override
	public boolean isAutoRenew() {
		return model.isAutoRenew();
	}

	/**
	 * Returns <code>true</code> if this customer is primary.
	 *
	 * @return <code>true</code> if this customer is primary; <code>false</code> otherwise
	 */
	@Override
	public boolean isPrimary() {
		return model.isPrimary();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the account no of this customer.
	 *
	 * @param accountNo the account no of this customer
	 */
	@Override
	public void setAccountNo(String accountNo) {
		model.setAccountNo(accountNo);
	}

	/**
	 * Sets the agent screen name of this customer.
	 *
	 * @param agentScreenName the agent screen name of this customer
	 */
	@Override
	public void setAgentScreenName(String agentScreenName) {
		model.setAgentScreenName(agentScreenName);
	}

	/**
	 * Sets whether this customer is auto renew.
	 *
	 * @param autoRenew the auto renew of this customer
	 */
	@Override
	public void setAutoRenew(boolean autoRenew) {
		model.setAutoRenew(autoRenew);
	}

	/**
	 * Sets the bat ID of this customer.
	 *
	 * @param batId the bat ID of this customer
	 */
	@Override
	public void setBatId(String batId) {
		model.setBatId(batId);
	}

	/**
	 * Sets the brm ID of this customer.
	 *
	 * @param brmId the brm ID of this customer
	 */
	@Override
	public void setBrmId(String brmId) {
		model.setBrmId(brmId);
	}

	/**
	 * Sets the company ID of this customer.
	 *
	 * @param companyId the company ID of this customer
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the connection type of this customer.
	 *
	 * @param connectionType the connection type of this customer
	 */
	@Override
	public void setConnectionType(String connectionType) {
		model.setConnectionType(connectionType);
	}

	/**
	 * Sets the create by of this customer.
	 *
	 * @param createBy the create by of this customer
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this customer.
	 *
	 * @param createDate the create date of this customer
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the customer ID of this customer.
	 *
	 * @param customerId the customer ID of this customer
	 */
	@Override
	public void setCustomerId(String customerId) {
		model.setCustomerId(customerId);
	}

	/**
	 * Sets the first name of this customer.
	 *
	 * @param firstName the first name of this customer
	 */
	@Override
	public void setFirstName(String firstName) {
		model.setFirstName(firstName);
	}

	/**
	 * Sets the group ID of this customer.
	 *
	 * @param groupId the group ID of this customer
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the last name of this customer.
	 *
	 * @param lastName the last name of this customer
	 */
	@Override
	public void setLastName(String lastName) {
		model.setLastName(lastName);
	}

	/**
	 * Sets the mac ID of this customer.
	 *
	 * @param macId the mac ID of this customer
	 */
	@Override
	public void setMacId(String macId) {
		model.setMacId(macId);
	}

	/**
	 * Sets the mac po ID of this customer.
	 *
	 * @param macPoId the mac po ID of this customer
	 */
	@Override
	public void setMacPoId(String macPoId) {
		model.setMacPoId(macPoId);
	}

	/**
	 * Sets the middle name of this customer.
	 *
	 * @param middleName the middle name of this customer
	 */
	@Override
	public void setMiddleName(String middleName) {
		model.setMiddleName(middleName);
	}

	/**
	 * Sets the modified date of this customer.
	 *
	 * @param modifiedDate the modified date of this customer
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the po ID of this customer.
	 *
	 * @param poId the po ID of this customer
	 */
	@Override
	public void setPoId(String poId) {
		model.setPoId(poId);
	}

	/**
	 * Sets whether this customer is primary.
	 *
	 * @param primary the primary of this customer
	 */
	@Override
	public void setPrimary(boolean primary) {
		model.setPrimary(primary);
	}

	/**
	 * Sets the primary key of this customer.
	 *
	 * @param primaryKey the primary key of this customer
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the remark of this customer.
	 *
	 * @param remark the remark of this customer
	 */
	@Override
	public void setRemark(String remark) {
		model.setRemark(remark);
	}

	/**
	 * Sets the salutation of this customer.
	 *
	 * @param salutation the salutation of this customer
	 */
	@Override
	public void setSalutation(String salutation) {
		model.setSalutation(salutation);
	}

	/**
	 * Sets the screen name of this customer.
	 *
	 * @param screenName the screen name of this customer
	 */
	@Override
	public void setScreenName(String screenName) {
		model.setScreenName(screenName);
	}

	/**
	 * Sets the service po ID of this customer.
	 *
	 * @param servicePoId the service po ID of this customer
	 */
	@Override
	public void setServicePoId(String servicePoId) {
		model.setServicePoId(servicePoId);
	}

	/**
	 * Sets the service type of this customer.
	 *
	 * @param serviceType the service type of this customer
	 */
	@Override
	public void setServiceType(String serviceType) {
		model.setServiceType(serviceType);
	}

	/**
	 * Sets the status of this customer.
	 *
	 * @param status the status of this customer
	 */
	@Override
	public void setStatus(String status) {
		model.setStatus(status);
	}

	/**
	 * Sets the stb no of this customer.
	 *
	 * @param stbNo the stb no of this customer
	 */
	@Override
	public void setStbNo(String stbNo) {
		model.setStbNo(stbNo);
	}

	/**
	 * Sets the stb po ID of this customer.
	 *
	 * @param stbPoId the stb po ID of this customer
	 */
	@Override
	public void setStbPoId(String stbPoId) {
		model.setStbPoId(stbPoId);
	}

	/**
	 * Sets the vc ID of this customer.
	 *
	 * @param vcId the vc ID of this customer
	 */
	@Override
	public void setVcId(String vcId) {
		model.setVcId(vcId);
	}

	/**
	 * Sets the vc po ID of this customer.
	 *
	 * @param vcPoId the vc po ID of this customer
	 */
	@Override
	public void setVcPoId(String vcPoId) {
		model.setVcPoId(vcPoId);
	}

	@Override
	protected CustomerWrapper wrap(Customer customer) {
		return new CustomerWrapper(customer);
	}

}