/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence;

import com.jio.account.model.AgentCustomerMapping;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the agent customer mapping service. This utility wraps <code>com.jio.account.service.persistence.impl.AgentCustomerMappingPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AgentCustomerMappingPersistence
 * @generated
 */
@ProviderType
public class AgentCustomerMappingUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(AgentCustomerMapping agentCustomerMapping) {
		getPersistence().clearCache(agentCustomerMapping);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, AgentCustomerMapping> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<AgentCustomerMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<AgentCustomerMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<AgentCustomerMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static AgentCustomerMapping update(
		AgentCustomerMapping agentCustomerMapping) {

		return getPersistence().update(agentCustomerMapping);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static AgentCustomerMapping update(
		AgentCustomerMapping agentCustomerMapping,
		ServiceContext serviceContext) {

		return getPersistence().update(agentCustomerMapping, serviceContext);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCompanyId(long companyId) {
		return getPersistence().findByCompanyId(companyId);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end) {

		return getPersistence().findByCompanyId(companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCompanyId_First(
			long companyId,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCompanyId_First(
		long companyId,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCompanyId_Last(
			long companyId,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCompanyId_Last(
		long companyId,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByCompanyId_PrevAndNext(
			String mappingId, long companyId,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCompanyId_PrevAndNext(
			mappingId, companyId, orderByComparator);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public static void removeByCompanyId(long companyId) {
		getPersistence().removeByCompanyId(companyId);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching agent customer mappings
	 */
	public static int countByCompanyId(long companyId) {
		return getPersistence().countByCompanyId(companyId);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByAgentScreenNames_First(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentScreenNames_First(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByAgentScreenNames_First(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByAgentScreenNames_First(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByAgentScreenNames_Last(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentScreenNames_Last(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByAgentScreenNames_Last(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByAgentScreenNames_Last(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByAgentScreenNames_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentScreenNames_PrevAndNext(
			mappingId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenNames);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenNames, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenNames, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAgentScreenNames(
			companyId, agentScreenNames, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByAgentScreenNames(
		long companyId, String agentScreenName) {

		getPersistence().removeByAgentScreenNames(companyId, agentScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByAgentScreenNames(
		long companyId, String agentScreenName) {

		return getPersistence().countByAgentScreenNames(
			companyId, agentScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @return the number of matching agent customer mappings
	 */
	public static int countByAgentScreenNames(
		long companyId, String[] agentScreenNames) {

		return getPersistence().countByAgentScreenNames(
			companyId, agentScreenNames);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByASCN_CSCN_First(
			long companyId, String agentScreenName, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByASCN_CSCN_First(
			companyId, agentScreenName, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByASCN_CSCN_First(
		long companyId, String agentScreenName, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByASCN_CSCN_First(
			companyId, agentScreenName, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByASCN_CSCN_Last(
			long companyId, String agentScreenName, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByASCN_CSCN_Last(
			companyId, agentScreenName, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByASCN_CSCN_Last(
		long companyId, String agentScreenName, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByASCN_CSCN_Last(
			companyId, agentScreenName, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByASCN_CSCN_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByASCN_CSCN_PrevAndNext(
			mappingId, companyId, agentScreenName, customerScreenName,
			orderByComparator);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 */
	public static void removeByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName) {

		getPersistence().removeByASCN_CSCN(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName) {

		return getPersistence().countByASCN_CSCN(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName) {

		return getPersistence().countByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName) {

		return getPersistence().findByASCN(companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end) {

		return getPersistence().findByASCN(
			companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByASCN(
			companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByASCN(
			companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByASCN_First(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByASCN_First(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByASCN_First(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByASCN_First(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByASCN_Last(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByASCN_Last(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByASCN_Last(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByASCN_Last(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByASCN_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByASCN_PrevAndNext(
			mappingId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByASCN(long companyId, String agentScreenName) {
		getPersistence().removeByASCN(companyId, agentScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByASCN(long companyId, String agentScreenName) {
		return getPersistence().countByASCN(companyId, agentScreenName);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName) {

		return getPersistence().findByCSCN(companyId, customerScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end) {

		return getPersistence().findByCSCN(
			companyId, customerScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByCSCN(
			companyId, customerScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCSCN(
			companyId, customerScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCSCN_First(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCSCN_First(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCSCN_First(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByCSCN_First(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCSCN_Last(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCSCN_Last(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCSCN_Last(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByCSCN_Last(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByCSCN_PrevAndNext(
			String mappingId, long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCSCN_PrevAndNext(
			mappingId, companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 */
	public static void removeByCSCN(long companyId, String customerScreenName) {
		getPersistence().removeByCSCN(companyId, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByCSCN(long companyId, String customerScreenName) {
		return getPersistence().countByCSCN(companyId, customerScreenName);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName) {

		return getPersistence().findByAgentScreenName(
			companyId, agentScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end) {

		return getPersistence().findByAgentScreenName(
			companyId, agentScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByAgentScreenName(
			companyId, agentScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAgentScreenName(
			companyId, agentScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByAgentScreenName_First(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentScreenName_First(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByAgentScreenName_First(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByAgentScreenName_First(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByAgentScreenName_Last(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentScreenName_Last(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByAgentScreenName_Last(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByAgentScreenName_Last(
			companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByAgentScreenName_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentScreenName_PrevAndNext(
			mappingId, companyId, agentScreenName, orderByComparator);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public static void removeByAgentScreenName(
		long companyId, String agentScreenName) {

		getPersistence().removeByAgentScreenName(companyId, agentScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByAgentScreenName(
		long companyId, String agentScreenName) {

		return getPersistence().countByAgentScreenName(
			companyId, agentScreenName);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCustomerScreenName(
			long companyId, String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCustomerScreenName(
			companyId, customerScreenName);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCustomerScreenName(
		long companyId, String customerScreenName) {

		return getPersistence().fetchByCustomerScreenName(
			companyId, customerScreenName);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCustomerScreenName(
		long companyId, String customerScreenName, boolean retrieveFromCache) {

		return getPersistence().fetchByCustomerScreenName(
			companyId, customerScreenName, retrieveFromCache);
	}

	/**
	 * Removes the agent customer mapping where companyId = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the agent customer mapping that was removed
	 */
	public static AgentCustomerMapping removeByCustomerScreenName(
			long companyId, String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().removeByCustomerScreenName(
			companyId, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByCustomerScreenName(
		long companyId, String customerScreenName) {

		return getPersistence().countByCustomerScreenName(
			companyId, customerScreenName);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenName);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenName, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenName, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCustomerScreenNames_First(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCustomerScreenNames_First(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCustomerScreenNames_First(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByCustomerScreenNames_First(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByCustomerScreenNames_Last(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCustomerScreenNames_Last(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByCustomerScreenNames_Last(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().fetchByCustomerScreenNames_Last(
			companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping[] findByCustomerScreenNames_PrevAndNext(
			String mappingId, long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByCustomerScreenNames_PrevAndNext(
			mappingId, companyId, customerScreenName, orderByComparator);
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @return the matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenNames);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenNames, start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenNames, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public static List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCustomerScreenNames(
			companyId, customerScreenNames, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 */
	public static void removeByCustomerScreenNames(
		long companyId, String customerScreenName) {

		getPersistence().removeByCustomerScreenNames(
			companyId, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByCustomerScreenNames(
		long companyId, String customerScreenName) {

		return getPersistence().countByCustomerScreenNames(
			companyId, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @return the number of matching agent customer mappings
	 */
	public static int countByCustomerScreenNames(
		long companyId, String[] customerScreenNames) {

		return getPersistence().countByCustomerScreenNames(
			companyId, customerScreenNames);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping findByAgentAndCustomerScreenName(
			long companyId, String agentScreenName, String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName) {

		return getPersistence().fetchByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public static AgentCustomerMapping fetchByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName,
		boolean retrieveFromCache) {

		return getPersistence().fetchByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName, retrieveFromCache);
	}

	/**
	 * Removes the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the agent customer mapping that was removed
	 */
	public static AgentCustomerMapping removeByAgentAndCustomerScreenName(
			long companyId, String agentScreenName, String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().removeByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public static int countByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName) {

		return getPersistence().countByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName);
	}

	/**
	 * Caches the agent customer mapping in the entity cache if it is enabled.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 */
	public static void cacheResult(AgentCustomerMapping agentCustomerMapping) {
		getPersistence().cacheResult(agentCustomerMapping);
	}

	/**
	 * Caches the agent customer mappings in the entity cache if it is enabled.
	 *
	 * @param agentCustomerMappings the agent customer mappings
	 */
	public static void cacheResult(
		List<AgentCustomerMapping> agentCustomerMappings) {

		getPersistence().cacheResult(agentCustomerMappings);
	}

	/**
	 * Creates a new agent customer mapping with the primary key. Does not add the agent customer mapping to the database.
	 *
	 * @param mappingId the primary key for the new agent customer mapping
	 * @return the new agent customer mapping
	 */
	public static AgentCustomerMapping create(String mappingId) {
		return getPersistence().create(mappingId);
	}

	/**
	 * Removes the agent customer mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping that was removed
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping remove(String mappingId)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().remove(mappingId);
	}

	public static AgentCustomerMapping updateImpl(
		AgentCustomerMapping agentCustomerMapping) {

		return getPersistence().updateImpl(agentCustomerMapping);
	}

	/**
	 * Returns the agent customer mapping with the primary key or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping findByPrimaryKey(String mappingId)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getPersistence().findByPrimaryKey(mappingId);
	}

	/**
	 * Returns the agent customer mapping with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping, or <code>null</code> if a agent customer mapping with the primary key could not be found
	 */
	public static AgentCustomerMapping fetchByPrimaryKey(String mappingId) {
		return getPersistence().fetchByPrimaryKey(mappingId);
	}

	/**
	 * Returns all the agent customer mappings.
	 *
	 * @return the agent customer mappings
	 */
	public static List<AgentCustomerMapping> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of agent customer mappings
	 */
	public static List<AgentCustomerMapping> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of agent customer mappings
	 */
	public static List<AgentCustomerMapping> findAll(
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of agent customer mappings
	 */
	public static List<AgentCustomerMapping> findAll(
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the agent customer mappings from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of agent customer mappings.
	 *
	 * @return the number of agent customer mappings
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static AgentCustomerMappingPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker
		<AgentCustomerMappingPersistence, AgentCustomerMappingPersistence>
			_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(
			AgentCustomerMappingPersistence.class);

		ServiceTracker
			<AgentCustomerMappingPersistence, AgentCustomerMappingPersistence>
				serviceTracker =
					new ServiceTracker
						<AgentCustomerMappingPersistence,
						 AgentCustomerMappingPersistence>(
							 bundle.getBundleContext(),
							 AgentCustomerMappingPersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}