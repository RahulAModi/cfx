/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the local service utility for Agent. This utility wraps
 * <code>com.jio.account.service.impl.AgentLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see AgentLocalService
 * @generated
 */
@ProviderType
public class AgentLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.jio.account.service.impl.AgentLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the agent to the database. Also notifies the appropriate model listeners.
	 *
	 * @param agent the agent
	 * @return the agent that was added
	 */
	public static com.jio.account.model.Agent addAgent(
		com.jio.account.model.Agent agent) {

		return getService().addAgent(agent);
	}

	/**
	 * Creates a new agent with the primary key. Does not add the agent to the database.
	 *
	 * @param agentId the primary key for the new agent
	 * @return the new agent
	 */
	public static com.jio.account.model.Agent createAgent(String agentId) {
		return getService().createAgent(agentId);
	}

	/**
	 * Deletes the agent from the database. Also notifies the appropriate model listeners.
	 *
	 * @param agent the agent
	 * @return the agent that was removed
	 */
	public static com.jio.account.model.Agent deleteAgent(
		com.jio.account.model.Agent agent) {

		return getService().deleteAgent(agent);
	}

	/**
	 * Deletes the agent with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent that was removed
	 * @throws PortalException if a agent with the primary key could not be found
	 */
	public static com.jio.account.model.Agent deleteAgent(String agentId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deleteAgent(agentId);
	}

	/**
	 * @throws PortalException
	 */
	public static com.liferay.portal.kernel.model.PersistedModel
			deletePersistedModel(
				com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery
		dynamicQuery() {

		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.account.model.Agent fetchAgent(String agentId) {
		return getService().fetchAgent(agentId);
	}

	public static com.jio.account.model.Agent getAgent(
			long companyId, String screenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return getService().getAgent(companyId, screenName);
	}

	public static com.jio.account.model.Agent getAgent(
			long companyId, String screenName, String parentCode)
		throws com.jio.account.exception.NoSuchAgentException {

		return getService().getAgent(companyId, screenName, parentCode);
	}

	/**
	 * Returns the agent with the primary key.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent
	 * @throws PortalException if a agent with the primary key could not be found
	 */
	public static com.jio.account.model.Agent getAgent(String agentId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getAgent(agentId);
	}

	public static com.jio.account.model.Agent getAgentByClientCode(
			long companyId, String clientCode)
		throws com.jio.account.exception.NoSuchAgentException {

		return getService().getAgentByClientCode(companyId, clientCode);
	}

	public static com.jio.account.model.Agent getAgentByLegacyCode(
			long companyId, String legacyCode)
		throws com.jio.account.exception.NoSuchAgentException {

		return getService().getAgentByLegacyCode(companyId, legacyCode);
	}

	/**
	 * Returns a range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of agents
	 */
	public static java.util.List<com.jio.account.model.Agent> getAgents(
		int start, int end) {

		return getService().getAgents(start, end);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId) {

		return getService().getAgents(companyId);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId, boolean isPrimary) {

		return getService().getAgents(companyId, isPrimary);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId, boolean isPrimary, int start, int end) {

		return getService().getAgents(companyId, isPrimary, start, end);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId, int start, int end) {

		return getService().getAgents(companyId, start, end);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId, String parentCode) {

		return getService().getAgents(companyId, parentCode);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId, String parentCode, boolean isPrimary) {

		return getService().getAgents(companyId, parentCode, isPrimary);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
		long companyId, String parentCode, boolean isPrimary, int start,
		int end) {

		return getService().getAgents(
			companyId, parentCode, isPrimary, start, end);
	}

	public static java.util.List<com.jio.account.model.Agent> getAgents(
			long companyId, String parentCode, int start, int end)
		throws com.jio.account.exception.NoSuchAgentException {

		return getService().getAgents(companyId, parentCode, start, end);
	}

	/**
	 * Returns the number of agents.
	 *
	 * @return the number of agents
	 */
	public static int getAgentsCount() {
		return getService().getAgentsCount();
	}

	public static int getAgentsCount(long companyId) {
		return getService().getAgentsCount(companyId);
	}

	public static int getAgentsCount(long companyId, boolean isPrimary) {
		return getService().getAgentsCount(companyId, isPrimary);
	}

	public static int getAgentsCount(long companyId, String parentCode) {
		return getService().getAgentsCount(companyId, parentCode);
	}

	public static int getAgentsCount(
		long companyId, String parentCode, boolean isPrimary) {

		return getService().getAgentsCount(companyId, parentCode, isPrimary);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	public static com.jio.account.model.Agent getParentAgent(
			long companyId, String screenName)
		throws com.jio.account.exception.NoSuchAgentException {

		return getService().getParentAgent(companyId, screenName);
	}

	public static com.liferay.portal.kernel.model.PersistedModel
			getPersistedModel(java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the agent in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param agent the agent
	 * @return the agent that was updated
	 */
	public static com.jio.account.model.Agent updateAgent(
		com.jio.account.model.Agent agent) {

		return getService().updateAgent(agent);
	}

	public static AgentLocalService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<AgentLocalService, AgentLocalService>
		_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(AgentLocalService.class);

		ServiceTracker<AgentLocalService, AgentLocalService> serviceTracker =
			new ServiceTracker<AgentLocalService, AgentLocalService>(
				bundle.getBundleContext(), AgentLocalService.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}