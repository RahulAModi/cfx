/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence;

import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the customer service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CustomerUtil
 * @generated
 */
@ProviderType
public interface CustomerPersistence extends BasePersistence<Customer> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link CustomerUtil} to access the customer persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByCustomerId(String customerId, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByCustomerId(String customerId, long companyId);

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByCustomerId(
		String customerId, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the customer where customerId = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByCustomerId(String customerId, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByCustomerId(String customerId, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAN_VCID_ASN(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId,
		boolean retrieveFromCache);

	/**
	 * Removes the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByAN_VCID_ASN(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAN_STBNO_ASN(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName, long companyId,
		boolean retrieveFromCache);

	/**
	 * Removes the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByAN_STBNO_ASN(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAN_MACID_ASN(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName, long companyId,
		boolean retrieveFromCache);

	/**
	 * Removes the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByAN_MACID_ASN(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAccountNo(String accountNo, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAccountNo(String accountNo, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAccountNo(
		String accountNo, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the customer where accountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByAccountNo(String accountNo, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where accountNo = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAccountNo(String accountNo, long companyId);

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByVcId_C(String vcId, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByVcId_C(String vcId, long companyId);

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByVcId_C(
		String vcId, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the customer where vcId = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByVcId_C(String vcId, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where vcId = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByVcId_C(String vcId, long companyId);

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByStbNo_C(String stbNo, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByStbNo_C(String stbNo, long companyId);

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByStbNo_C(
		String stbNo, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the customer where stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByStbNo_C(String stbNo, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where stbNo = &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByStbNo_C(String stbNo, long companyId);

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByMacId_C(String macId, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByMacId_C(String macId, long companyId);

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByMacId_C(
		String macId, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the customer where macId = &#63; and companyId = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByMacId_C(String macId, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where macId = &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByMacId_C(String macId, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAN_SCN(
			String accountNo, String screenName, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_SCN(
		String accountNo, String screenName, long companyId);

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_SCN(
		String accountNo, String screenName, long companyId,
		boolean retrieveFromCache);

	/**
	 * Removes the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	public Customer removeByAN_SCN(
			String accountNo, String screenName, long companyId)
		throws NoSuchCustomerException;

	/**
	 * Returns the number of customers where accountNo = &#63; and screenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAN_SCN(
		String accountNo, String screenName, long companyId);

	/**
	 * Returns all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId);

	/**
	 * Returns a range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findBySCN_P_First(
			String screenName, boolean primary, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchBySCN_P_First(
		String screenName, boolean primary, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findBySCN_P_Last(
			String screenName, boolean primary, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchBySCN_P_Last(
		String screenName, boolean primary, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findBySCN_P_PrevAndNext(
			String customerId, String screenName, boolean primary,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where screenName = &#63; and primary = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 */
	public void removeBySCN_P(
		String screenName, boolean primary, long companyId);

	/**
	 * Returns the number of customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countBySCN_P(String screenName, boolean primary, long companyId);

	/**
	 * Returns all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByScreenName(
		String screenName, long companyId);

	/**
	 * Returns a range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByScreenName_First(
			String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByScreenName_First(
		String screenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByScreenName_Last(
			String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByScreenName_Last(
		String screenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByScreenName_PrevAndNext(
			String customerId, String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	public void removeByScreenName(String screenName, long companyId);

	/**
	 * Returns the number of customers where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByScreenName(String screenName, long companyId);

	/**
	 * Returns all the customers where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByCompanyId_PrevAndNext(
			String customerId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of customers where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Returns all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByAN_C(
		String accountNo, long companyId);

	/**
	 * Returns a range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAN_C_First(
			String accountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_C_First(
		String accountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAN_C_Last(
			String accountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAN_C_Last(
		String accountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByAN_C_PrevAndNext(
			String customerId, String accountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where accountNo LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 */
	public void removeByAN_C(String accountNo, long companyId);

	/**
	 * Returns the number of customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAN_C(String accountNo, long companyId);

	/**
	 * Returns all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findBySN_C(
		String screenName, long companyId);

	/**
	 * Returns a range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findBySN_C_First(
			String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchBySN_C_First(
		String screenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findBySN_C_Last(
			String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchBySN_C_Last(
		String screenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findBySN_C_PrevAndNext(
			String customerId, String screenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where screenName LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	public void removeBySN_C(String screenName, long companyId);

	/**
	 * Returns the number of customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countBySN_C(String screenName, long companyId);

	/**
	 * Returns all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByS_C(String status, long companyId);

	/**
	 * Returns a range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByS_C(
		String status, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByS_C(
		String status, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByS_C(
		String status, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByS_C_First(
			String status, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByS_C_First(
		String status, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByS_C_Last(
			String status, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByS_C_Last(
		String status, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByS_C_PrevAndNext(
			String customerId, String status, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where status LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 */
	public void removeByS_C(String status, long companyId);

	/**
	 * Returns the number of customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByS_C(String status, long companyId);

	/**
	 * Returns all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByVC_C(String vcId, long companyId);

	/**
	 * Returns a range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByVC_C_First(
			String vcId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByVC_C_First(
		String vcId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByVC_C_Last(
			String vcId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByVC_C_Last(
		String vcId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByVC_C_PrevAndNext(
			String customerId, String vcId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where vcId LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 */
	public void removeByVC_C(String vcId, long companyId);

	/**
	 * Returns the number of customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByVC_C(String vcId, long companyId);

	/**
	 * Returns all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findBySTB_C(String stbNo, long companyId);

	/**
	 * Returns a range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findBySTB_C_First(
			String stbNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchBySTB_C_First(
		String stbNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findBySTB_C_Last(
			String stbNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchBySTB_C_Last(
		String stbNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findBySTB_C_PrevAndNext(
			String customerId, String stbNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where stbNo LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 */
	public void removeBySTB_C(String stbNo, long companyId);

	/**
	 * Returns the number of customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countBySTB_C(String stbNo, long companyId);

	/**
	 * Returns all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByMAC_C(String macId, long companyId);

	/**
	 * Returns a range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByMAC_C_First(
			String macId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByMAC_C_First(
		String macId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByMAC_C_Last(
			String macId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByMAC_C_Last(
		String macId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByMAC_C_PrevAndNext(
			String customerId, String macId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where macId LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 */
	public void removeByMAC_C(String macId, long companyId);

	/**
	 * Returns the number of customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByMAC_C(String macId, long companyId);

	/**
	 * Returns all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId);

	/**
	 * Returns a range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAgentScreenName_First(
			String agentScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAgentScreenName_First(
		String agentScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByAgentScreenName_Last(
			String agentScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByAgentScreenName_Last(
		String agentScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByAgentScreenName_PrevAndNext(
			String customerId, String agentScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 */
	public void removeByAgentScreenName(String agentScreenName, long companyId);

	/**
	 * Returns the number of customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	public int countByAgentScreenName(String agentScreenName, long companyId);

	/**
	 * Returns all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName);

	/**
	 * Returns a range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end);

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByScreenNameSearch_First(
			String screenName, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByScreenNameSearch_First(
		String screenName, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByScreenNameSearch_Last(
			String screenName, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByScreenNameSearch_Last(
		String screenName, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByScreenNameSearch_PrevAndNext(
			String customerId, String screenName, long companyId,
			String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByScreenNameSearch(
		String screenName, long companyId, String agentScreenName);

	/**
	 * Returns the number of customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public int countByScreenNameSearch(
		String screenName, long companyId, String agentScreenName);

	/**
	 * Returns all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByStatus(
		String status, long companyId, String agentScreenName);

	/**
	 * Returns a range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end);

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByStatus_First(
			String status, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByStatus_First(
		String status, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByStatus_Last(
			String status, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByStatus_Last(
		String status, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByStatus_PrevAndNext(
			String customerId, String status, long companyId,
			String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByStatus(
		String status, long companyId, String agentScreenName);

	/**
	 * Returns the number of customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public int countByStatus(
		String status, long companyId, String agentScreenName);

	/**
	 * Returns all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName);

	/**
	 * Returns a range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start,
		int end);

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByVcId_First(
			String vcId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByVcId_First(
		String vcId, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByVcId_Last(
			String vcId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByVcId_Last(
		String vcId, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByVcId_PrevAndNext(
			String customerId, String vcId, long companyId,
			String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByVcId(
		String vcId, long companyId, String agentScreenName);

	/**
	 * Returns the number of customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public int countByVcId(String vcId, long companyId, String agentScreenName);

	/**
	 * Returns all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName);

	/**
	 * Returns a range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end);

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByStbNo_First(
			String stbNo, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByStbNo_First(
		String stbNo, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByStbNo_Last(
			String stbNo, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByStbNo_Last(
		String stbNo, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByStbNo_PrevAndNext(
			String customerId, String stbNo, long companyId,
			String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByStbNo(
		String stbNo, long companyId, String agentScreenName);

	/**
	 * Returns the number of customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public int countByStbNo(
		String stbNo, long companyId, String agentScreenName);

	/**
	 * Returns all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	public java.util.List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName);

	/**
	 * Returns a range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	public java.util.List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end);

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	public java.util.List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByMacId_First(
			String macId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByMacId_First(
		String macId, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	public Customer findByMacId_Last(
			String macId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	public Customer fetchByMacId_Last(
		String macId, long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns the customers before and after the current customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer[] findByMacId_PrevAndNext(
			String customerId, String macId, long companyId,
			String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator<Customer>
				orderByComparator)
		throws NoSuchCustomerException;

	/**
	 * Removes all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByMacId(
		String macId, long companyId, String agentScreenName);

	/**
	 * Returns the number of customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	public int countByMacId(
		String macId, long companyId, String agentScreenName);

	/**
	 * Caches the customer in the entity cache if it is enabled.
	 *
	 * @param customer the customer
	 */
	public void cacheResult(Customer customer);

	/**
	 * Caches the customers in the entity cache if it is enabled.
	 *
	 * @param customers the customers
	 */
	public void cacheResult(java.util.List<Customer> customers);

	/**
	 * Creates a new customer with the primary key. Does not add the customer to the database.
	 *
	 * @param customerId the primary key for the new customer
	 * @return the new customer
	 */
	public Customer create(String customerId);

	/**
	 * Removes the customer with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer that was removed
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer remove(String customerId) throws NoSuchCustomerException;

	public Customer updateImpl(Customer customer);

	/**
	 * Returns the customer with the primary key or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	public Customer findByPrimaryKey(String customerId)
		throws NoSuchCustomerException;

	/**
	 * Returns the customer with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer, or <code>null</code> if a customer with the primary key could not be found
	 */
	public Customer fetchByPrimaryKey(String customerId);

	/**
	 * Returns all the customers.
	 *
	 * @return the customers
	 */
	public java.util.List<Customer> findAll();

	/**
	 * Returns a range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of customers
	 */
	public java.util.List<Customer> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of customers
	 */
	public java.util.List<Customer> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator);

	/**
	 * Returns an ordered range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of customers
	 */
	public java.util.List<Customer> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Customer>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the customers from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of customers.
	 *
	 * @return the number of customers
	 */
	public int countAll();

}