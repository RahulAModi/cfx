/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link Address}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Address
 * @generated
 */
@ProviderType
public class AddressWrapper
	extends BaseModelWrapper<Address>
	implements Address, ModelWrapper<Address> {

	public AddressWrapper(Address address) {
		super(address);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("addressId", getAddressId());
		attributes.put("customerId", getCustomerId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("screenName", getScreenName());
		attributes.put("countryCode", getCountryCode());
		attributes.put("regionCode", getRegionCode());
		attributes.put("stateCode", getStateCode());
		attributes.put("cityCode", getCityCode());
		attributes.put("areaCode", getAreaCode());
		attributes.put("pincode", getPincode());
		attributes.put("street", getStreet());
		attributes.put("location", getLocation());
		attributes.put("flatNo", getFlatNo());
		attributes.put("building", getBuilding());
		attributes.put("address", getAddress());
		attributes.put("type", getType());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String addressId = (String)attributes.get("addressId");

		if (addressId != null) {
			setAddressId(addressId);
		}

		String customerId = (String)attributes.get("customerId");

		if (customerId != null) {
			setCustomerId(customerId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String screenName = (String)attributes.get("screenName");

		if (screenName != null) {
			setScreenName(screenName);
		}

		String countryCode = (String)attributes.get("countryCode");

		if (countryCode != null) {
			setCountryCode(countryCode);
		}

		String regionCode = (String)attributes.get("regionCode");

		if (regionCode != null) {
			setRegionCode(regionCode);
		}

		String stateCode = (String)attributes.get("stateCode");

		if (stateCode != null) {
			setStateCode(stateCode);
		}

		String cityCode = (String)attributes.get("cityCode");

		if (cityCode != null) {
			setCityCode(cityCode);
		}

		String areaCode = (String)attributes.get("areaCode");

		if (areaCode != null) {
			setAreaCode(areaCode);
		}

		String pincode = (String)attributes.get("pincode");

		if (pincode != null) {
			setPincode(pincode);
		}

		String street = (String)attributes.get("street");

		if (street != null) {
			setStreet(street);
		}

		String location = (String)attributes.get("location");

		if (location != null) {
			setLocation(location);
		}

		String flatNo = (String)attributes.get("flatNo");

		if (flatNo != null) {
			setFlatNo(flatNo);
		}

		String building = (String)attributes.get("building");

		if (building != null) {
			setBuilding(building);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String type = (String)attributes.get("type");

		if (type != null) {
			setType(type);
		}
	}

	/**
	 * Returns the address of this address.
	 *
	 * @return the address of this address
	 */
	@Override
	public String getAddress() {
		return model.getAddress();
	}

	/**
	 * Returns the address ID of this address.
	 *
	 * @return the address ID of this address
	 */
	@Override
	public String getAddressId() {
		return model.getAddressId();
	}

	/**
	 * Returns the area code of this address.
	 *
	 * @return the area code of this address
	 */
	@Override
	public String getAreaCode() {
		return model.getAreaCode();
	}

	/**
	 * Returns the building of this address.
	 *
	 * @return the building of this address
	 */
	@Override
	public String getBuilding() {
		return model.getBuilding();
	}

	/**
	 * Returns the city code of this address.
	 *
	 * @return the city code of this address
	 */
	@Override
	public String getCityCode() {
		return model.getCityCode();
	}

	/**
	 * Returns the company ID of this address.
	 *
	 * @return the company ID of this address
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the country code of this address.
	 *
	 * @return the country code of this address
	 */
	@Override
	public String getCountryCode() {
		return model.getCountryCode();
	}

	/**
	 * Returns the create by of this address.
	 *
	 * @return the create by of this address
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this address.
	 *
	 * @return the create date of this address
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the customer ID of this address.
	 *
	 * @return the customer ID of this address
	 */
	@Override
	public String getCustomerId() {
		return model.getCustomerId();
	}

	/**
	 * Returns the flat no of this address.
	 *
	 * @return the flat no of this address
	 */
	@Override
	public String getFlatNo() {
		return model.getFlatNo();
	}

	/**
	 * Returns the group ID of this address.
	 *
	 * @return the group ID of this address
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the location of this address.
	 *
	 * @return the location of this address
	 */
	@Override
	public String getLocation() {
		return model.getLocation();
	}

	/**
	 * Returns the modified date of this address.
	 *
	 * @return the modified date of this address
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the pincode of this address.
	 *
	 * @return the pincode of this address
	 */
	@Override
	public String getPincode() {
		return model.getPincode();
	}

	/**
	 * Returns the primary key of this address.
	 *
	 * @return the primary key of this address
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the region code of this address.
	 *
	 * @return the region code of this address
	 */
	@Override
	public String getRegionCode() {
		return model.getRegionCode();
	}

	/**
	 * Returns the screen name of this address.
	 *
	 * @return the screen name of this address
	 */
	@Override
	public String getScreenName() {
		return model.getScreenName();
	}

	/**
	 * Returns the state code of this address.
	 *
	 * @return the state code of this address
	 */
	@Override
	public String getStateCode() {
		return model.getStateCode();
	}

	/**
	 * Returns the street of this address.
	 *
	 * @return the street of this address
	 */
	@Override
	public String getStreet() {
		return model.getStreet();
	}

	/**
	 * Returns the type of this address.
	 *
	 * @return the type of this address
	 */
	@Override
	public String getType() {
		return model.getType();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the address of this address.
	 *
	 * @param address the address of this address
	 */
	@Override
	public void setAddress(String address) {
		model.setAddress(address);
	}

	/**
	 * Sets the address ID of this address.
	 *
	 * @param addressId the address ID of this address
	 */
	@Override
	public void setAddressId(String addressId) {
		model.setAddressId(addressId);
	}

	/**
	 * Sets the area code of this address.
	 *
	 * @param areaCode the area code of this address
	 */
	@Override
	public void setAreaCode(String areaCode) {
		model.setAreaCode(areaCode);
	}

	/**
	 * Sets the building of this address.
	 *
	 * @param building the building of this address
	 */
	@Override
	public void setBuilding(String building) {
		model.setBuilding(building);
	}

	/**
	 * Sets the city code of this address.
	 *
	 * @param cityCode the city code of this address
	 */
	@Override
	public void setCityCode(String cityCode) {
		model.setCityCode(cityCode);
	}

	/**
	 * Sets the company ID of this address.
	 *
	 * @param companyId the company ID of this address
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the country code of this address.
	 *
	 * @param countryCode the country code of this address
	 */
	@Override
	public void setCountryCode(String countryCode) {
		model.setCountryCode(countryCode);
	}

	/**
	 * Sets the create by of this address.
	 *
	 * @param createBy the create by of this address
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this address.
	 *
	 * @param createDate the create date of this address
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the customer ID of this address.
	 *
	 * @param customerId the customer ID of this address
	 */
	@Override
	public void setCustomerId(String customerId) {
		model.setCustomerId(customerId);
	}

	/**
	 * Sets the flat no of this address.
	 *
	 * @param flatNo the flat no of this address
	 */
	@Override
	public void setFlatNo(String flatNo) {
		model.setFlatNo(flatNo);
	}

	/**
	 * Sets the group ID of this address.
	 *
	 * @param groupId the group ID of this address
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the location of this address.
	 *
	 * @param location the location of this address
	 */
	@Override
	public void setLocation(String location) {
		model.setLocation(location);
	}

	/**
	 * Sets the modified date of this address.
	 *
	 * @param modifiedDate the modified date of this address
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the pincode of this address.
	 *
	 * @param pincode the pincode of this address
	 */
	@Override
	public void setPincode(String pincode) {
		model.setPincode(pincode);
	}

	/**
	 * Sets the primary key of this address.
	 *
	 * @param primaryKey the primary key of this address
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the region code of this address.
	 *
	 * @param regionCode the region code of this address
	 */
	@Override
	public void setRegionCode(String regionCode) {
		model.setRegionCode(regionCode);
	}

	/**
	 * Sets the screen name of this address.
	 *
	 * @param screenName the screen name of this address
	 */
	@Override
	public void setScreenName(String screenName) {
		model.setScreenName(screenName);
	}

	/**
	 * Sets the state code of this address.
	 *
	 * @param stateCode the state code of this address
	 */
	@Override
	public void setStateCode(String stateCode) {
		model.setStateCode(stateCode);
	}

	/**
	 * Sets the street of this address.
	 *
	 * @param street the street of this address
	 */
	@Override
	public void setStreet(String street) {
		model.setStreet(street);
	}

	/**
	 * Sets the type of this address.
	 *
	 * @param type the type of this address
	 */
	@Override
	public void setType(String type) {
		model.setType(type);
	}

	@Override
	protected AddressWrapper wrap(Address address) {
		return new AddressWrapper(address);
	}

}