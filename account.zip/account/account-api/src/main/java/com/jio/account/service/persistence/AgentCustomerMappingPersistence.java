/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence;

import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.model.AgentCustomerMapping;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the agent customer mapping service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AgentCustomerMappingUtil
 * @generated
 */
@ProviderType
public interface AgentCustomerMappingPersistence
	extends BasePersistence<AgentCustomerMapping> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link AgentCustomerMappingUtil} to access the agent customer mapping persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the agent customer mappings where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByCompanyId_PrevAndNext(
			String mappingId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Removes all the agent customer mappings where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching agent customer mappings
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByAgentScreenNames_First(
			long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByAgentScreenNames_First(
		long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByAgentScreenNames_Last(
			long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByAgentScreenNames_Last(
		long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByAgentScreenNames_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByAgentScreenNames(
		long companyId, String agentScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByAgentScreenNames(long companyId, String agentScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @return the number of matching agent customer mappings
	 */
	public int countByAgentScreenNames(
		long companyId, String[] agentScreenNames);

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByASCN_CSCN_First(
			long companyId, String agentScreenName, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByASCN_CSCN_First(
		long companyId, String agentScreenName, String customerScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByASCN_CSCN_Last(
			long companyId, String agentScreenName, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByASCN_CSCN_Last(
		long companyId, String agentScreenName, String customerScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByASCN_CSCN_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 */
	public void removeByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName);

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByASCN_First(
			long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByASCN_First(
		long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByASCN_Last(
			long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByASCN_Last(
		long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByASCN_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByASCN(long companyId, String agentScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByASCN(long companyId, String agentScreenName);

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCSCN_First(
			long companyId, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCSCN_First(
		long companyId, String customerScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCSCN_Last(
			long companyId, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCSCN_Last(
		long companyId, String customerScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByCSCN_PrevAndNext(
			String mappingId, long companyId, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 */
	public void removeByCSCN(long companyId, String customerScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByCSCN(long companyId, String customerScreenName);

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByAgentScreenName_First(
			long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByAgentScreenName_First(
		long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByAgentScreenName_Last(
			long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByAgentScreenName_Last(
		long companyId, String agentScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByAgentScreenName_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	public void removeByAgentScreenName(long companyId, String agentScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByAgentScreenName(long companyId, String agentScreenName);

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCustomerScreenName(
			long companyId, String customerScreenName)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCustomerScreenName(
		long companyId, String customerScreenName);

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCustomerScreenName(
		long companyId, String customerScreenName, boolean retrieveFromCache);

	/**
	 * Removes the agent customer mapping where companyId = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the agent customer mapping that was removed
	 */
	public AgentCustomerMapping removeByCustomerScreenName(
			long companyId, String customerScreenName)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByCustomerScreenName(
		long companyId, String customerScreenName);

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCustomerScreenNames_First(
			long companyId, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCustomerScreenNames_First(
		long companyId, String customerScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByCustomerScreenNames_Last(
			long companyId, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByCustomerScreenNames_Last(
		long companyId, String customerScreenName,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping[] findByCustomerScreenNames_PrevAndNext(
			String mappingId, long companyId, String customerScreenName,
			com.liferay.portal.kernel.util.OrderByComparator
				<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @return the matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames);

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 */
	public void removeByCustomerScreenNames(
		long companyId, String customerScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByCustomerScreenNames(
		long companyId, String customerScreenName);

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @return the number of matching agent customer mappings
	 */
	public int countByCustomerScreenNames(
		long companyId, String[] customerScreenNames);

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping findByAgentAndCustomerScreenName(
			long companyId, String agentScreenName, String customerScreenName)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName);

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	public AgentCustomerMapping fetchByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName,
		boolean retrieveFromCache);

	/**
	 * Removes the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the agent customer mapping that was removed
	 */
	public AgentCustomerMapping removeByAgentAndCustomerScreenName(
			long companyId, String agentScreenName, String customerScreenName)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	public int countByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName);

	/**
	 * Caches the agent customer mapping in the entity cache if it is enabled.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 */
	public void cacheResult(AgentCustomerMapping agentCustomerMapping);

	/**
	 * Caches the agent customer mappings in the entity cache if it is enabled.
	 *
	 * @param agentCustomerMappings the agent customer mappings
	 */
	public void cacheResult(
		java.util.List<AgentCustomerMapping> agentCustomerMappings);

	/**
	 * Creates a new agent customer mapping with the primary key. Does not add the agent customer mapping to the database.
	 *
	 * @param mappingId the primary key for the new agent customer mapping
	 * @return the new agent customer mapping
	 */
	public AgentCustomerMapping create(String mappingId);

	/**
	 * Removes the agent customer mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping that was removed
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping remove(String mappingId)
		throws NoSuchAgentCustomerMappingException;

	public AgentCustomerMapping updateImpl(
		AgentCustomerMapping agentCustomerMapping);

	/**
	 * Returns the agent customer mapping with the primary key or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping findByPrimaryKey(String mappingId)
		throws NoSuchAgentCustomerMappingException;

	/**
	 * Returns the agent customer mapping with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping, or <code>null</code> if a agent customer mapping with the primary key could not be found
	 */
	public AgentCustomerMapping fetchByPrimaryKey(String mappingId);

	/**
	 * Returns all the agent customer mappings.
	 *
	 * @return the agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findAll();

	/**
	 * Returns a range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator);

	/**
	 * Returns an ordered range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of agent customer mappings
	 */
	public java.util.List<AgentCustomerMapping> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<AgentCustomerMapping>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the agent customer mappings from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of agent customer mappings.
	 *
	 * @return the number of agent customer mappings
	 */
	public int countAll();

}