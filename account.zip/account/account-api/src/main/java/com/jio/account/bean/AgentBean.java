package com.jio.account.bean;

import com.liferay.portal.kernel.util.Validator;

import java.util.Date;

public class AgentBean {

	private long userId;

	private String screenName;
	private String firstName;
	private String middleName;
	private String lastName;
	private String mobileNo;
	private String email;
	private String name;
	private String gstin;

	private String ppType;
	private String prefDom;
	private String panNo;
	private String stRegNo;
	private String vatTaxNo;
	private Date reportDate;
	private String locator;
	private String distributor;
	private String subDistributor;
	private String distributorPoId;
	private String subDistributorPoId;
	private String distributorName;
	private String subDistributorName;

	private long companyId;
	private long groupId;
	private String parentCode;
	private boolean primary;

	private String jvNo;
	private String jvPoId;
	private String jvName;
	private String directNo;
	private String directPoId;
	private String directName;

	private String poId;
	private String accountNo;
	private int status;

	private String address;
	private String state;
	private String city;
	private String pincode;
	private String area;
	private String region;
	private String country;
	private String street;
	private String location;
	private String building;
	private String flatNo;
	private String createdBy;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		if (Validator.isNotNull(name)) {
			return name;
		} else {
			if (Validator.isNotNull(middleName)) {
				return firstName.concat(" ").concat(middleName).concat(" ").concat(lastName);

			} else {
				return firstName.concat(" ").concat(lastName);
			}
		}
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getPpType() {
		return ppType;
	}

	public void setPpType(String ppType) {
		this.ppType = ppType;
	}

	public String getPrefDom() {
		return prefDom;
	}

	public void setPrefDom(String prefDom) {
		this.prefDom = prefDom;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getStRegNo() {
		return stRegNo;
	}

	public void setStRegNo(String stRegNo) {
		this.stRegNo = stRegNo;
	}

	public String getVatTaxNo() {
		return vatTaxNo;
	}

	public void setVatTaxNo(String vatTaxNo) {
		this.vatTaxNo = vatTaxNo;
	}

	public Date getReportDate() {
		return reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	public String getLocator() {
		return locator;
	}

	public void setLocator(String locator) {
		this.locator = locator;
	}

	public String getDistributor() {
		return distributor;
	}

	public void setDistributor(String distributor) {
		this.distributor = distributor;
	}

	public String getSubDistributor() {
		return subDistributor;
	}

	public void setSubDistributor(String subDistributor) {
		this.subDistributor = subDistributor;
	}

	public String getDistributorPoId() {
		return distributorPoId;
	}

	public void setDistributorPoId(String distributorPoId) {
		this.distributorPoId = distributorPoId;
	}

	public String getSubDistributorPoId() {
		return subDistributorPoId;
	}

	public void setSubDistributorPoId(String subDistributorPoId) {
		this.subDistributorPoId = subDistributorPoId;
	}

	public String getDistributorName() {
		return distributorName;
	}

	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}

	public String getSubDistributorName() {
		return subDistributorName;
	}

	public void setSubDistributorName(String subDistributorName) {
		this.subDistributorName = subDistributorName;
	}

	public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public String getParentCode() {
		return parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean primary) {
		this.primary = primary;
	}

	public String getJvNo() {
		return jvNo;
	}

	public void setJvNo(String jvNo) {
		this.jvNo = jvNo;
	}

	public String getDirectNo() {
		return directNo;
	}

	public void setDirectNo(String directNo) {
		this.directNo = directNo;
	}

	public String getPoId() {
		return poId;
	}

	public void setPoId(String poId) {
		this.poId = poId;
	}

	public String getJvPoId() {
		return jvPoId;
	}

	public void setJvPoId(String jvPoId) {
		this.jvPoId = jvPoId;
	}

	public String getJvName() {
		return jvName;
	}

	public void setJvName(String jvName) {
		this.jvName = jvName;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDirectPoId() {
		return directPoId;
	}

	public void setDirectPoId(String directPoId) {
		this.directPoId = directPoId;
	}

	public String getDirectName() {
		return directName;
	}

	public void setDirectName(String directName) {
		this.directName = directName;
	}

	@Override
	public String toString() {
		return "AgentBean [userId=" + userId + ", screenName=" + screenName + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", mobileNo=" + mobileNo + ", email=" + email + ", name=" + name + ", gstin=" + gstin + ", ppType=" + ppType + ", prefDom=" + prefDom
				+ ", panNo=" + panNo + ", stRegNo=" + stRegNo + ", vatTaxNo=" + vatTaxNo + ", reportDate=" + reportDate + ", locator=" + locator + ", distributor=" + distributor + ", subDistributor=" + subDistributor + ", distributorPoId=" + distributorPoId + ", subDistributorPoId="
				+ subDistributorPoId + ", distributorName=" + distributorName + ", subDistributorName=" + subDistributorName + ", companyId=" + companyId + ", groupId=" + groupId + ", parentCode=" + parentCode + ", primary=" + primary + ", jvNo=" + jvNo + ", jvPoId=" + jvPoId + ", jvName=" + jvName
				+ ", directNo=" + directNo + ", directPoId=" + directPoId + ", directName=" + directName + ", poId=" + poId + ", accountNo=" + accountNo + ", status=" + status + ", address=" + address + ", state=" + state + ", city=" + city + ", pincode=" + pincode + ", area=" + area + ", region="
				+ region + ", country=" + country + ", street=" + street + ", location=" + location + ", building=" + building + ", flatNo=" + flatNo + ", createdBy=" + createdBy + "]";
	}

}