/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the local service utility for AgentCustomerMapping. This utility wraps
 * <code>com.jio.account.service.impl.AgentCustomerMappingLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see AgentCustomerMappingLocalService
 * @generated
 */
@ProviderType
public class AgentCustomerMappingLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.jio.account.service.impl.AgentCustomerMappingLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the agent customer mapping to the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 * @return the agent customer mapping that was added
	 */
	public static com.jio.account.model.AgentCustomerMapping
		addAgentCustomerMapping(
			com.jio.account.model.AgentCustomerMapping agentCustomerMapping) {

		return getService().addAgentCustomerMapping(agentCustomerMapping);
	}

	/**
	 * Creates a new agent customer mapping with the primary key. Does not add the agent customer mapping to the database.
	 *
	 * @param mappingId the primary key for the new agent customer mapping
	 * @return the new agent customer mapping
	 */
	public static com.jio.account.model.AgentCustomerMapping
		createAgentCustomerMapping(String mappingId) {

		return getService().createAgentCustomerMapping(mappingId);
	}

	/**
	 * Deletes the agent customer mapping from the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 * @return the agent customer mapping that was removed
	 */
	public static com.jio.account.model.AgentCustomerMapping
		deleteAgentCustomerMapping(
			com.jio.account.model.AgentCustomerMapping agentCustomerMapping) {

		return getService().deleteAgentCustomerMapping(agentCustomerMapping);
	}

	/**
	 * Deletes the agent customer mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping that was removed
	 * @throws PortalException if a agent customer mapping with the primary key could not be found
	 */
	public static com.jio.account.model.AgentCustomerMapping
			deleteAgentCustomerMapping(String mappingId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deleteAgentCustomerMapping(mappingId);
	}

	/**
	 * @throws PortalException
	 */
	public static com.liferay.portal.kernel.model.PersistedModel
			deletePersistedModel(
				com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery
		dynamicQuery() {

		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.account.model.AgentCustomerMapping
		fetchAgentCustomerMapping(String mappingId) {

		return getService().fetchAgentCustomerMapping(mappingId);
	}

	public static com.jio.account.model.AgentCustomerMapping
			findByAgentAndCustomerScreenName(
				long companyId, String agentScreenName,
				String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getService().findByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		findByAgentScreenName(long companyId, String agentScreenName) {

		return getService().findByAgentScreenName(companyId, agentScreenName);
	}

	public static com.jio.account.model.AgentCustomerMapping
			findByCustomerScreenName(long companyId, String customerScreenName)
		throws com.jio.account.exception.NoSuchAgentCustomerMappingException {

		return getService().findByCustomerScreenName(
			companyId, customerScreenName);
	}

	/**
	 * Returns the agent customer mapping with the primary key.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping
	 * @throws PortalException if a agent customer mapping with the primary key could not be found
	 */
	public static com.jio.account.model.AgentCustomerMapping
			getAgentCustomerMapping(String mappingId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getAgentCustomerMapping(mappingId);
	}

	/**
	 * Returns a range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.model.impl.AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of agent customer mappings
	 */
	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(int start, int end) {

		return getService().getAgentCustomerMappings(start, end);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId) {

		return getService().getAgentCustomerMappings(companyId);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId, int start, int end) {

		return getService().getAgentCustomerMappings(companyId, start, end);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId, String agentScreenName) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenName);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String agentScreenName, int start, int end) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenName, start, end);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String agentScreenName, String customerScreenName) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenName, customerScreenName);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String agentScreenName, String customerScreenName,
			int start, int end) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenName, customerScreenName, start, end);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(long companyId, String[] agentScreenName) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenName);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String[] agentScreenName, int start, int end) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenName, start, end);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String[] agentScreenNames,
			String customerScreenName) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenNames, customerScreenName);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getAgentCustomerMappings(
			long companyId, String[] agentScreenNames,
			String customerScreenName, int start, int end) {

		return getService().getAgentCustomerMappings(
			companyId, agentScreenNames, customerScreenName, start, end);
	}

	/**
	 * Returns the number of agent customer mappings.
	 *
	 * @return the number of agent customer mappings
	 */
	public static int getAgentCustomerMappingsCount() {
		return getService().getAgentCustomerMappingsCount();
	}

	public static int getAgentCustomerMappingsCount(long companyId) {
		return getService().getAgentCustomerMappingsCount(companyId);
	}

	public static int getAgentCustomerMappingsCount(
		long companyId, String agentScreenName) {

		return getService().getAgentCustomerMappingsCount(
			companyId, agentScreenName);
	}

	public static int getAgentCustomerMappingsCount(
		long companyId, String agentScreenName, String customerScreenName) {

		return getService().getAgentCustomerMappingsCount(
			companyId, agentScreenName, customerScreenName);
	}

	public static int getAgentCustomerMappingsCount(
		long companyId, String[] agentScreenName) {

		return getService().getAgentCustomerMappingsCount(
			companyId, agentScreenName);
	}

	public static int getAgentCustomerMappingsCount(
		long companyId, String[] agentScreenNames, String customerScreenName) {

		return getService().getAgentCustomerMappingsCount(
			companyId, agentScreenNames, customerScreenName);
	}

	public static java.util.List<com.jio.account.model.AgentCustomerMapping>
		getByCustomerScreenNames(long companyId, String[] customerScreenName) {

		return getService().getByCustomerScreenNames(
			companyId, customerScreenName);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	public static com.liferay.portal.kernel.model.PersistedModel
			getPersistedModel(java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	public static com.jio.account.model.AgentCustomerMapping
		saveOrUpdateAgentCustomerMapping(
			long companyId, long groupId, String screenName,
			String agentScreenName, String createBy) {

		return getService().saveOrUpdateAgentCustomerMapping(
			companyId, groupId, screenName, agentScreenName, createBy);
	}

	/**
	 * Updates the agent customer mapping in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 * @return the agent customer mapping that was updated
	 */
	public static com.jio.account.model.AgentCustomerMapping
		updateAgentCustomerMapping(
			com.jio.account.model.AgentCustomerMapping agentCustomerMapping) {

		return getService().updateAgentCustomerMapping(agentCustomerMapping);
	}

	public static AgentCustomerMappingLocalService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker
		<AgentCustomerMappingLocalService, AgentCustomerMappingLocalService>
			_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(
			AgentCustomerMappingLocalService.class);

		ServiceTracker
			<AgentCustomerMappingLocalService, AgentCustomerMappingLocalService>
				serviceTracker =
					new ServiceTracker
						<AgentCustomerMappingLocalService,
						 AgentCustomerMappingLocalService>(
							 bundle.getBundleContext(),
							 AgentCustomerMappingLocalService.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}