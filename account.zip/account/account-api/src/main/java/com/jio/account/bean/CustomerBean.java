package com.jio.account.bean;

public class CustomerBean {

	private String customerId;
	private long companyId;
	private long groupId;
	private String brmId;
	private String batId;
	private String screenName;
	private String agentScreenName;
	private String status;
	private String accountNo;
	private String vcId;
	private String stbNo;
	private String macId;
	private String salutation;
	private String firstName;
	private String middleName;
	private String lastName;
	private String mobileNo;
	private String landline;
	private String email;
	private String pincode;
	private String cityCode;
	private String areaCode;
	private String countryCode;
	private String stateCode;
	private String regionCode;
	private String street;
	private String location;
	private String building;
	private String flatNo;
	private String address;
	private String addressType;
	private String serviceType;
	private String connectionType;
	private boolean primary;
	private String createdBy;
	private boolean primaryContact;
	private String poId;
	private String servicePoId;
	private String vcPoId;
	private String stbPoId;
	private String macPoId;
	private String devicePoId;
	private String planPoId;
	private String planName;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public String getBrmId() {
		return brmId;
	}

	public void setBrmId(String brmId) {
		this.brmId = brmId;
	}

	public String getBatId() {
		return batId;
	}

	public void setBatId(String batId) {
		this.batId = batId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getAgentScreenName() {
		return agentScreenName;
	}

	public void setAgentScreenName(String agentScreenName) {
		this.agentScreenName = agentScreenName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getVcId() {
		return vcId;
	}

	public void setVcId(String vcId) {
		this.vcId = vcId;
	}

	public String getStbNo() {
		return stbNo;
	}

	public void setStbNo(String stbNo) {
		this.stbNo = stbNo;
	}

	public String getMacId() {
		return macId;
	}

	public void setMacId(String macId) {
		this.macId = macId;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline = landline;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean primary) {
		this.primary = primary;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public boolean isPrimaryContact() {
		return primaryContact;
	}

	public void setPrimaryContact(boolean primaryContact) {
		this.primaryContact = primaryContact;
	}

	public String getPoId() {
		return poId;
	}

	public void setPoId(String poId) {
		this.poId = poId;
	}

	public String getServicePoId() {
		return servicePoId;
	}

	public void setServicePoId(String servicePoId) {
		this.servicePoId = servicePoId;
	}

	public String getVcPoId() {
		return vcPoId;
	}

	public void setVcPoId(String vcPoId) {
		this.vcPoId = vcPoId;
	}

	public String getStbPoId() {
		return stbPoId;
	}

	public void setStbPoId(String stbPoId) {
		this.stbPoId = stbPoId;
	}

	public String getMacPoId() {
		return macPoId;
	}

	public void setMacPoId(String macPoId) {
		this.macPoId = macPoId;
	}

	public String getDevicePoId() {
		return devicePoId;
	}

	public void setDevicePoId(String devicePoId) {
		this.devicePoId = devicePoId;
	}

	public String getPlanPoId() {
		return planPoId;
	}

	public void setPlanPoId(String planPoId) {
		this.planPoId = planPoId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	@Override
	public String toString() {
		return "CustomerBean [customerId=" + customerId + ", companyId=" + companyId + ", groupId=" + groupId + ", brmId=" + brmId + ", batId=" + batId + ", screenName=" + screenName + ", agentScreenName=" + agentScreenName + ", status=" + status + ", accountNo=" + accountNo + ", vcId=" + vcId
				+ ", stbNo=" + stbNo + ", macId=" + macId + ", salutation=" + salutation + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", mobileNo=" + mobileNo + ", landline=" + landline + ", email=" + email + ", pincode=" + pincode + ", cityCode="
				+ cityCode + ", areaCode=" + areaCode + ", countryCode=" + countryCode + ", stateCode=" + stateCode + ", regionCode=" + regionCode + ", street=" + street + ", location=" + location + ", building=" + building + ", flatNo=" + flatNo + ", address=" + address + ", addressType="
				+ addressType + ", serviceType=" + serviceType + ", connectionType=" + connectionType + ", primary=" + primary + ", createdBy=" + createdBy + ", primaryContact=" + primaryContact + ", poId=" + poId + ", servicePoId=" + servicePoId + ", vcPoId=" + vcPoId + ", stbPoId=" + stbPoId
				+ ", macPoId=" + macPoId + ", devicePoId=" + devicePoId + ", planPoId=" + planPoId + ", planName=" + planName + "]";
	}

}