/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link Agent}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Agent
 * @generated
 */
@ProviderType
public class AgentWrapper
	extends BaseModelWrapper<Agent> implements Agent, ModelWrapper<Agent> {

	public AgentWrapper(Agent agent) {
		super(agent);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("agentId", getAgentId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("screenName", getScreenName());
		attributes.put("name", getName());
		attributes.put("parentCode", getParentCode());
		attributes.put("primary", isPrimary());
		attributes.put("prefDom", getPrefDom());
		attributes.put("poId", getPoId());
		attributes.put("accountNo", getAccountNo());
		attributes.put("gstinNo", getGstinNo());
		attributes.put("status", getStatus());
		attributes.put("autoRenew", isAutoRenew());
		attributes.put("legacyCode", getLegacyCode());
		attributes.put("clientCode", getClientCode());
		attributes.put("bouquetCode", getBouquetCode());
		attributes.put("jvNo", getJvNo());
		attributes.put("directNo", getDirectNo());
		attributes.put("distributor", getDistributor());
		attributes.put("subDistributor", getSubDistributor());
		attributes.put("jvPoId", getJvPoId());
		attributes.put("directPoId", getDirectPoId());
		attributes.put("distributorPoId", getDistributorPoId());
		attributes.put("subDistributorPoId", getSubDistributorPoId());
		attributes.put("jvName", getJvName());
		attributes.put("directName", getDirectName());
		attributes.put("distributorName", getDistributorName());
		attributes.put("subDistributorName", getSubDistributorName());
		attributes.put("panNo", getPanNo());
		attributes.put("reportDate", getReportDate());
		attributes.put("ppType", getPpType());
		attributes.put("locator", getLocator());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String agentId = (String)attributes.get("agentId");

		if (agentId != null) {
			setAgentId(agentId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String screenName = (String)attributes.get("screenName");

		if (screenName != null) {
			setScreenName(screenName);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String parentCode = (String)attributes.get("parentCode");

		if (parentCode != null) {
			setParentCode(parentCode);
		}

		Boolean primary = (Boolean)attributes.get("primary");

		if (primary != null) {
			setPrimary(primary);
		}

		String prefDom = (String)attributes.get("prefDom");

		if (prefDom != null) {
			setPrefDom(prefDom);
		}

		String poId = (String)attributes.get("poId");

		if (poId != null) {
			setPoId(poId);
		}

		String accountNo = (String)attributes.get("accountNo");

		if (accountNo != null) {
			setAccountNo(accountNo);
		}

		String gstinNo = (String)attributes.get("gstinNo");

		if (gstinNo != null) {
			setGstinNo(gstinNo);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Boolean autoRenew = (Boolean)attributes.get("autoRenew");

		if (autoRenew != null) {
			setAutoRenew(autoRenew);
		}

		String legacyCode = (String)attributes.get("legacyCode");

		if (legacyCode != null) {
			setLegacyCode(legacyCode);
		}

		String clientCode = (String)attributes.get("clientCode");

		if (clientCode != null) {
			setClientCode(clientCode);
		}

		String bouquetCode = (String)attributes.get("bouquetCode");

		if (bouquetCode != null) {
			setBouquetCode(bouquetCode);
		}

		String jvNo = (String)attributes.get("jvNo");

		if (jvNo != null) {
			setJvNo(jvNo);
		}

		String directNo = (String)attributes.get("directNo");

		if (directNo != null) {
			setDirectNo(directNo);
		}

		String distributor = (String)attributes.get("distributor");

		if (distributor != null) {
			setDistributor(distributor);
		}

		String subDistributor = (String)attributes.get("subDistributor");

		if (subDistributor != null) {
			setSubDistributor(subDistributor);
		}

		String jvPoId = (String)attributes.get("jvPoId");

		if (jvPoId != null) {
			setJvPoId(jvPoId);
		}

		String directPoId = (String)attributes.get("directPoId");

		if (directPoId != null) {
			setDirectPoId(directPoId);
		}

		String distributorPoId = (String)attributes.get("distributorPoId");

		if (distributorPoId != null) {
			setDistributorPoId(distributorPoId);
		}

		String subDistributorPoId = (String)attributes.get(
			"subDistributorPoId");

		if (subDistributorPoId != null) {
			setSubDistributorPoId(subDistributorPoId);
		}

		String jvName = (String)attributes.get("jvName");

		if (jvName != null) {
			setJvName(jvName);
		}

		String directName = (String)attributes.get("directName");

		if (directName != null) {
			setDirectName(directName);
		}

		String distributorName = (String)attributes.get("distributorName");

		if (distributorName != null) {
			setDistributorName(distributorName);
		}

		String subDistributorName = (String)attributes.get(
			"subDistributorName");

		if (subDistributorName != null) {
			setSubDistributorName(subDistributorName);
		}

		String panNo = (String)attributes.get("panNo");

		if (panNo != null) {
			setPanNo(panNo);
		}

		Date reportDate = (Date)attributes.get("reportDate");

		if (reportDate != null) {
			setReportDate(reportDate);
		}

		String ppType = (String)attributes.get("ppType");

		if (ppType != null) {
			setPpType(ppType);
		}

		String locator = (String)attributes.get("locator");

		if (locator != null) {
			setLocator(locator);
		}
	}

	/**
	 * Returns the account no of this agent.
	 *
	 * @return the account no of this agent
	 */
	@Override
	public String getAccountNo() {
		return model.getAccountNo();
	}

	/**
	 * Returns the agent ID of this agent.
	 *
	 * @return the agent ID of this agent
	 */
	@Override
	public String getAgentId() {
		return model.getAgentId();
	}

	/**
	 * Returns the auto renew of this agent.
	 *
	 * @return the auto renew of this agent
	 */
	@Override
	public boolean getAutoRenew() {
		return model.getAutoRenew();
	}

	/**
	 * Returns the bouquet code of this agent.
	 *
	 * @return the bouquet code of this agent
	 */
	@Override
	public String getBouquetCode() {
		return model.getBouquetCode();
	}

	/**
	 * Returns the client code of this agent.
	 *
	 * @return the client code of this agent
	 */
	@Override
	public String getClientCode() {
		return model.getClientCode();
	}

	/**
	 * Returns the company ID of this agent.
	 *
	 * @return the company ID of this agent
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the create by of this agent.
	 *
	 * @return the create by of this agent
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this agent.
	 *
	 * @return the create date of this agent
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the direct name of this agent.
	 *
	 * @return the direct name of this agent
	 */
	@Override
	public String getDirectName() {
		return model.getDirectName();
	}

	/**
	 * Returns the direct no of this agent.
	 *
	 * @return the direct no of this agent
	 */
	@Override
	public String getDirectNo() {
		return model.getDirectNo();
	}

	/**
	 * Returns the direct po ID of this agent.
	 *
	 * @return the direct po ID of this agent
	 */
	@Override
	public String getDirectPoId() {
		return model.getDirectPoId();
	}

	/**
	 * Returns the distributor of this agent.
	 *
	 * @return the distributor of this agent
	 */
	@Override
	public String getDistributor() {
		return model.getDistributor();
	}

	/**
	 * Returns the distributor name of this agent.
	 *
	 * @return the distributor name of this agent
	 */
	@Override
	public String getDistributorName() {
		return model.getDistributorName();
	}

	/**
	 * Returns the distributor po ID of this agent.
	 *
	 * @return the distributor po ID of this agent
	 */
	@Override
	public String getDistributorPoId() {
		return model.getDistributorPoId();
	}

	/**
	 * Returns the group ID of this agent.
	 *
	 * @return the group ID of this agent
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the gstin no of this agent.
	 *
	 * @return the gstin no of this agent
	 */
	@Override
	public String getGstinNo() {
		return model.getGstinNo();
	}

	/**
	 * Returns the jv name of this agent.
	 *
	 * @return the jv name of this agent
	 */
	@Override
	public String getJvName() {
		return model.getJvName();
	}

	/**
	 * Returns the jv no of this agent.
	 *
	 * @return the jv no of this agent
	 */
	@Override
	public String getJvNo() {
		return model.getJvNo();
	}

	/**
	 * Returns the jv po ID of this agent.
	 *
	 * @return the jv po ID of this agent
	 */
	@Override
	public String getJvPoId() {
		return model.getJvPoId();
	}

	/**
	 * Returns the legacy code of this agent.
	 *
	 * @return the legacy code of this agent
	 */
	@Override
	public String getLegacyCode() {
		return model.getLegacyCode();
	}

	/**
	 * Returns the locator of this agent.
	 *
	 * @return the locator of this agent
	 */
	@Override
	public String getLocator() {
		return model.getLocator();
	}

	/**
	 * Returns the modified date of this agent.
	 *
	 * @return the modified date of this agent
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the name of this agent.
	 *
	 * @return the name of this agent
	 */
	@Override
	public String getName() {
		return model.getName();
	}

	/**
	 * Returns the pan no of this agent.
	 *
	 * @return the pan no of this agent
	 */
	@Override
	public String getPanNo() {
		return model.getPanNo();
	}

	/**
	 * Returns the parent code of this agent.
	 *
	 * @return the parent code of this agent
	 */
	@Override
	public String getParentCode() {
		return model.getParentCode();
	}

	/**
	 * Returns the po ID of this agent.
	 *
	 * @return the po ID of this agent
	 */
	@Override
	public String getPoId() {
		return model.getPoId();
	}

	/**
	 * Returns the pp type of this agent.
	 *
	 * @return the pp type of this agent
	 */
	@Override
	public String getPpType() {
		return model.getPpType();
	}

	/**
	 * Returns the pref dom of this agent.
	 *
	 * @return the pref dom of this agent
	 */
	@Override
	public String getPrefDom() {
		return model.getPrefDom();
	}

	/**
	 * Returns the primary of this agent.
	 *
	 * @return the primary of this agent
	 */
	@Override
	public boolean getPrimary() {
		return model.getPrimary();
	}

	/**
	 * Returns the primary key of this agent.
	 *
	 * @return the primary key of this agent
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the report date of this agent.
	 *
	 * @return the report date of this agent
	 */
	@Override
	public Date getReportDate() {
		return model.getReportDate();
	}

	/**
	 * Returns the screen name of this agent.
	 *
	 * @return the screen name of this agent
	 */
	@Override
	public String getScreenName() {
		return model.getScreenName();
	}

	/**
	 * Returns the status of this agent.
	 *
	 * @return the status of this agent
	 */
	@Override
	public int getStatus() {
		return model.getStatus();
	}

	/**
	 * Returns the sub distributor of this agent.
	 *
	 * @return the sub distributor of this agent
	 */
	@Override
	public String getSubDistributor() {
		return model.getSubDistributor();
	}

	/**
	 * Returns the sub distributor name of this agent.
	 *
	 * @return the sub distributor name of this agent
	 */
	@Override
	public String getSubDistributorName() {
		return model.getSubDistributorName();
	}

	/**
	 * Returns the sub distributor po ID of this agent.
	 *
	 * @return the sub distributor po ID of this agent
	 */
	@Override
	public String getSubDistributorPoId() {
		return model.getSubDistributorPoId();
	}

	/**
	 * Returns <code>true</code> if this agent is auto renew.
	 *
	 * @return <code>true</code> if this agent is auto renew; <code>false</code> otherwise
	 */
	@Override
	public boolean isAutoRenew() {
		return model.isAutoRenew();
	}

	/**
	 * Returns <code>true</code> if this agent is primary.
	 *
	 * @return <code>true</code> if this agent is primary; <code>false</code> otherwise
	 */
	@Override
	public boolean isPrimary() {
		return model.isPrimary();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the account no of this agent.
	 *
	 * @param accountNo the account no of this agent
	 */
	@Override
	public void setAccountNo(String accountNo) {
		model.setAccountNo(accountNo);
	}

	/**
	 * Sets the agent ID of this agent.
	 *
	 * @param agentId the agent ID of this agent
	 */
	@Override
	public void setAgentId(String agentId) {
		model.setAgentId(agentId);
	}

	/**
	 * Sets whether this agent is auto renew.
	 *
	 * @param autoRenew the auto renew of this agent
	 */
	@Override
	public void setAutoRenew(boolean autoRenew) {
		model.setAutoRenew(autoRenew);
	}

	/**
	 * Sets the bouquet code of this agent.
	 *
	 * @param bouquetCode the bouquet code of this agent
	 */
	@Override
	public void setBouquetCode(String bouquetCode) {
		model.setBouquetCode(bouquetCode);
	}

	/**
	 * Sets the client code of this agent.
	 *
	 * @param clientCode the client code of this agent
	 */
	@Override
	public void setClientCode(String clientCode) {
		model.setClientCode(clientCode);
	}

	/**
	 * Sets the company ID of this agent.
	 *
	 * @param companyId the company ID of this agent
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the create by of this agent.
	 *
	 * @param createBy the create by of this agent
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this agent.
	 *
	 * @param createDate the create date of this agent
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the direct name of this agent.
	 *
	 * @param directName the direct name of this agent
	 */
	@Override
	public void setDirectName(String directName) {
		model.setDirectName(directName);
	}

	/**
	 * Sets the direct no of this agent.
	 *
	 * @param directNo the direct no of this agent
	 */
	@Override
	public void setDirectNo(String directNo) {
		model.setDirectNo(directNo);
	}

	/**
	 * Sets the direct po ID of this agent.
	 *
	 * @param directPoId the direct po ID of this agent
	 */
	@Override
	public void setDirectPoId(String directPoId) {
		model.setDirectPoId(directPoId);
	}

	/**
	 * Sets the distributor of this agent.
	 *
	 * @param distributor the distributor of this agent
	 */
	@Override
	public void setDistributor(String distributor) {
		model.setDistributor(distributor);
	}

	/**
	 * Sets the distributor name of this agent.
	 *
	 * @param distributorName the distributor name of this agent
	 */
	@Override
	public void setDistributorName(String distributorName) {
		model.setDistributorName(distributorName);
	}

	/**
	 * Sets the distributor po ID of this agent.
	 *
	 * @param distributorPoId the distributor po ID of this agent
	 */
	@Override
	public void setDistributorPoId(String distributorPoId) {
		model.setDistributorPoId(distributorPoId);
	}

	/**
	 * Sets the group ID of this agent.
	 *
	 * @param groupId the group ID of this agent
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the gstin no of this agent.
	 *
	 * @param gstinNo the gstin no of this agent
	 */
	@Override
	public void setGstinNo(String gstinNo) {
		model.setGstinNo(gstinNo);
	}

	/**
	 * Sets the jv name of this agent.
	 *
	 * @param jvName the jv name of this agent
	 */
	@Override
	public void setJvName(String jvName) {
		model.setJvName(jvName);
	}

	/**
	 * Sets the jv no of this agent.
	 *
	 * @param jvNo the jv no of this agent
	 */
	@Override
	public void setJvNo(String jvNo) {
		model.setJvNo(jvNo);
	}

	/**
	 * Sets the jv po ID of this agent.
	 *
	 * @param jvPoId the jv po ID of this agent
	 */
	@Override
	public void setJvPoId(String jvPoId) {
		model.setJvPoId(jvPoId);
	}

	/**
	 * Sets the legacy code of this agent.
	 *
	 * @param legacyCode the legacy code of this agent
	 */
	@Override
	public void setLegacyCode(String legacyCode) {
		model.setLegacyCode(legacyCode);
	}

	/**
	 * Sets the locator of this agent.
	 *
	 * @param locator the locator of this agent
	 */
	@Override
	public void setLocator(String locator) {
		model.setLocator(locator);
	}

	/**
	 * Sets the modified date of this agent.
	 *
	 * @param modifiedDate the modified date of this agent
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the name of this agent.
	 *
	 * @param name the name of this agent
	 */
	@Override
	public void setName(String name) {
		model.setName(name);
	}

	/**
	 * Sets the pan no of this agent.
	 *
	 * @param panNo the pan no of this agent
	 */
	@Override
	public void setPanNo(String panNo) {
		model.setPanNo(panNo);
	}

	/**
	 * Sets the parent code of this agent.
	 *
	 * @param parentCode the parent code of this agent
	 */
	@Override
	public void setParentCode(String parentCode) {
		model.setParentCode(parentCode);
	}

	/**
	 * Sets the po ID of this agent.
	 *
	 * @param poId the po ID of this agent
	 */
	@Override
	public void setPoId(String poId) {
		model.setPoId(poId);
	}

	/**
	 * Sets the pp type of this agent.
	 *
	 * @param ppType the pp type of this agent
	 */
	@Override
	public void setPpType(String ppType) {
		model.setPpType(ppType);
	}

	/**
	 * Sets the pref dom of this agent.
	 *
	 * @param prefDom the pref dom of this agent
	 */
	@Override
	public void setPrefDom(String prefDom) {
		model.setPrefDom(prefDom);
	}

	/**
	 * Sets whether this agent is primary.
	 *
	 * @param primary the primary of this agent
	 */
	@Override
	public void setPrimary(boolean primary) {
		model.setPrimary(primary);
	}

	/**
	 * Sets the primary key of this agent.
	 *
	 * @param primaryKey the primary key of this agent
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the report date of this agent.
	 *
	 * @param reportDate the report date of this agent
	 */
	@Override
	public void setReportDate(Date reportDate) {
		model.setReportDate(reportDate);
	}

	/**
	 * Sets the screen name of this agent.
	 *
	 * @param screenName the screen name of this agent
	 */
	@Override
	public void setScreenName(String screenName) {
		model.setScreenName(screenName);
	}

	/**
	 * Sets the status of this agent.
	 *
	 * @param status the status of this agent
	 */
	@Override
	public void setStatus(int status) {
		model.setStatus(status);
	}

	/**
	 * Sets the sub distributor of this agent.
	 *
	 * @param subDistributor the sub distributor of this agent
	 */
	@Override
	public void setSubDistributor(String subDistributor) {
		model.setSubDistributor(subDistributor);
	}

	/**
	 * Sets the sub distributor name of this agent.
	 *
	 * @param subDistributorName the sub distributor name of this agent
	 */
	@Override
	public void setSubDistributorName(String subDistributorName) {
		model.setSubDistributorName(subDistributorName);
	}

	/**
	 * Sets the sub distributor po ID of this agent.
	 *
	 * @param subDistributorPoId the sub distributor po ID of this agent
	 */
	@Override
	public void setSubDistributorPoId(String subDistributorPoId) {
		model.setSubDistributorPoId(subDistributorPoId);
	}

	@Override
	protected AgentWrapper wrap(Agent agent) {
		return new AgentWrapper(agent);
	}

}