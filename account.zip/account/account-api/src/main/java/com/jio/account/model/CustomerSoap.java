/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class CustomerSoap implements Serializable {

	public static CustomerSoap toSoapModel(Customer model) {
		CustomerSoap soapModel = new CustomerSoap();

		soapModel.setCustomerId(model.getCustomerId());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateBy(model.getCreateBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setSalutation(model.getSalutation());
		soapModel.setFirstName(model.getFirstName());
		soapModel.setMiddleName(model.getMiddleName());
		soapModel.setLastName(model.getLastName());
		soapModel.setScreenName(model.getScreenName());
		soapModel.setAgentScreenName(model.getAgentScreenName());
		soapModel.setBrmId(model.getBrmId());
		soapModel.setVcId(model.getVcId());
		soapModel.setStbNo(model.getStbNo());
		soapModel.setMacId(model.getMacId());
		soapModel.setAccountNo(model.getAccountNo());
		soapModel.setPoId(model.getPoId());
		soapModel.setConnectionType(model.getConnectionType());
		soapModel.setBatId(model.getBatId());
		soapModel.setServiceType(model.getServiceType());
		soapModel.setStatus(model.getStatus());
		soapModel.setPrimary(model.isPrimary());
		soapModel.setRemark(model.getRemark());
		soapModel.setVcPoId(model.getVcPoId());
		soapModel.setStbPoId(model.getStbPoId());
		soapModel.setMacPoId(model.getMacPoId());
		soapModel.setServicePoId(model.getServicePoId());
		soapModel.setAutoRenew(model.isAutoRenew());

		return soapModel;
	}

	public static CustomerSoap[] toSoapModels(Customer[] models) {
		CustomerSoap[] soapModels = new CustomerSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static CustomerSoap[][] toSoapModels(Customer[][] models) {
		CustomerSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new CustomerSoap[models.length][models[0].length];
		}
		else {
			soapModels = new CustomerSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static CustomerSoap[] toSoapModels(List<Customer> models) {
		List<CustomerSoap> soapModels = new ArrayList<CustomerSoap>(
			models.size());

		for (Customer model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new CustomerSoap[soapModels.size()]);
	}

	public CustomerSoap() {
	}

	public String getPrimaryKey() {
		return _customerId;
	}

	public void setPrimaryKey(String pk) {
		setCustomerId(pk);
	}

	public String getCustomerId() {
		return _customerId;
	}

	public void setCustomerId(String customerId) {
		_customerId = customerId;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public String getCreateBy() {
		return _createBy;
	}

	public void setCreateBy(String createBy) {
		_createBy = createBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public String getSalutation() {
		return _salutation;
	}

	public void setSalutation(String salutation) {
		_salutation = salutation;
	}

	public String getFirstName() {
		return _firstName;
	}

	public void setFirstName(String firstName) {
		_firstName = firstName;
	}

	public String getMiddleName() {
		return _middleName;
	}

	public void setMiddleName(String middleName) {
		_middleName = middleName;
	}

	public String getLastName() {
		return _lastName;
	}

	public void setLastName(String lastName) {
		_lastName = lastName;
	}

	public String getScreenName() {
		return _screenName;
	}

	public void setScreenName(String screenName) {
		_screenName = screenName;
	}

	public String getAgentScreenName() {
		return _agentScreenName;
	}

	public void setAgentScreenName(String agentScreenName) {
		_agentScreenName = agentScreenName;
	}

	public String getBrmId() {
		return _brmId;
	}

	public void setBrmId(String brmId) {
		_brmId = brmId;
	}

	public String getVcId() {
		return _vcId;
	}

	public void setVcId(String vcId) {
		_vcId = vcId;
	}

	public String getStbNo() {
		return _stbNo;
	}

	public void setStbNo(String stbNo) {
		_stbNo = stbNo;
	}

	public String getMacId() {
		return _macId;
	}

	public void setMacId(String macId) {
		_macId = macId;
	}

	public String getAccountNo() {
		return _accountNo;
	}

	public void setAccountNo(String accountNo) {
		_accountNo = accountNo;
	}

	public String getPoId() {
		return _poId;
	}

	public void setPoId(String poId) {
		_poId = poId;
	}

	public String getConnectionType() {
		return _connectionType;
	}

	public void setConnectionType(String connectionType) {
		_connectionType = connectionType;
	}

	public String getBatId() {
		return _batId;
	}

	public void setBatId(String batId) {
		_batId = batId;
	}

	public String getServiceType() {
		return _serviceType;
	}

	public void setServiceType(String serviceType) {
		_serviceType = serviceType;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public boolean getPrimary() {
		return _primary;
	}

	public boolean isPrimary() {
		return _primary;
	}

	public void setPrimary(boolean primary) {
		_primary = primary;
	}

	public String getRemark() {
		return _remark;
	}

	public void setRemark(String remark) {
		_remark = remark;
	}

	public String getVcPoId() {
		return _vcPoId;
	}

	public void setVcPoId(String vcPoId) {
		_vcPoId = vcPoId;
	}

	public String getStbPoId() {
		return _stbPoId;
	}

	public void setStbPoId(String stbPoId) {
		_stbPoId = stbPoId;
	}

	public String getMacPoId() {
		return _macPoId;
	}

	public void setMacPoId(String macPoId) {
		_macPoId = macPoId;
	}

	public String getServicePoId() {
		return _servicePoId;
	}

	public void setServicePoId(String servicePoId) {
		_servicePoId = servicePoId;
	}

	public boolean getAutoRenew() {
		return _autoRenew;
	}

	public boolean isAutoRenew() {
		return _autoRenew;
	}

	public void setAutoRenew(boolean autoRenew) {
		_autoRenew = autoRenew;
	}

	private String _customerId;
	private long _groupId;
	private long _companyId;
	private String _createBy;
	private Date _createDate;
	private Date _modifiedDate;
	private String _salutation;
	private String _firstName;
	private String _middleName;
	private String _lastName;
	private String _screenName;
	private String _agentScreenName;
	private String _brmId;
	private String _vcId;
	private String _stbNo;
	private String _macId;
	private String _accountNo;
	private String _poId;
	private String _connectionType;
	private String _batId;
	private String _serviceType;
	private String _status;
	private boolean _primary;
	private String _remark;
	private String _vcPoId;
	private String _stbPoId;
	private String _macPoId;
	private String _servicePoId;
	private boolean _autoRenew;

}