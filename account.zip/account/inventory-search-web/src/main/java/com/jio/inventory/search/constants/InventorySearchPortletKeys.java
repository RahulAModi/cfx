package com.jio.inventory.search.constants;

/**
 * @author Vishal7.Shah
 */
public class InventorySearchPortletKeys {

	public static final String PORTLET_NAME = "com_jio_inventory_search_portlet_InventorySearchPortlet";

	public static final String CONFIGURATION_NAME = "com_jio_inventory_search_configuration_InventoryConfiguration";

}