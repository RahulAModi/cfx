package com.jio.inventory.search.configuration;

import com.jio.inventory.search.constants.InventorySearchPortletKeys;

import aQute.bnd.annotation.metatype.Meta;

@Meta.OCD(id = InventorySearchPortletKeys.CONFIGURATION_NAME)
public interface InventoryConfiguration {

	@Meta.AD(required = false)
	public String global();

}
