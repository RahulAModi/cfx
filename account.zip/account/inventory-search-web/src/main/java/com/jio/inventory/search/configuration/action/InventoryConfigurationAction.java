package com.jio.inventory.search.configuration.action;

import com.jio.inventory.search.configuration.InventoryConfiguration;
import com.jio.inventory.search.constants.InventorySearchPortletKeys;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.ConfigurationAction;
import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;

@Component(configurationPid = InventorySearchPortletKeys.CONFIGURATION_NAME, configurationPolicy = ConfigurationPolicy.OPTIONAL, immediate = true, property = { "javax.portlet.name=" + InventorySearchPortletKeys.PORTLET_NAME }, service = ConfigurationAction.class)
public class InventoryConfigurationAction extends DefaultConfigurationAction {

	@Override
	public void include(PortletConfig portletConfig, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {

		long companyId = PortalUtil.getCompanyId(httpServletRequest);

		httpServletRequest.setAttribute(InventoryConfiguration.class.getName(), inventoryConfiguration);

		super.include(portletConfig, httpServletRequest, httpServletResponse);
	}

	@Override
	public void processAction(PortletConfig portletConfig, ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		String global = ParamUtil.getString(actionRequest, "global");

		setPreference(actionRequest, "global", global);

		super.processAction(portletConfig, actionRequest, actionResponse);
	}

	@Activate
	@Modified
	protected void activate(Map<Object, Object> properties) {

		inventoryConfiguration = ConfigurableUtil.createConfigurable(InventoryConfiguration.class, properties);
	}

	private static final Log LOGGER = LogFactoryUtil.getLog(InventoryConfigurationAction.class);

	private volatile InventoryConfiguration inventoryConfiguration;

}
