package com.jio.inventory.search.portlet.action;

import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.customer.service.CustomerService;
import com.jio.inventory.search.constants.InventorySearchPortletKeys;
import com.jio.inventory.search.constants.MVCCommandNames;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + InventorySearchPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(renderRequest);
		boolean isSuperAdmin = false;

		String vcId = ParamUtil.getString(renderRequest, "vcId");
		String stbNo = ParamUtil.getString(renderRequest, "stbNo");
		String macId = ParamUtil.getString(renderRequest, "macId");

		PortletPreferences portletPreferences = renderRequest.getPreferences();
		boolean global = GetterUtil.getBoolean(portletPreferences.getValue("global", StringPool.BLANK));
		Map<String, String> map = null;
		String status = StringPool.BLANK;
		String message = StringPool.BLANK;
		try {
			long groupId = PortalUtil.getScopeGroupId(renderRequest);
			User userAgent = PortalUtil.getUser(renderRequest);
			String txRefNo = AccountUtil.getTxRefNo();
			String screenName = "2975299";
			if (Validator.isNotNull(userAgent)) {
				isSuperAdmin = AccountUtil.isAdmin(userAgent.getUserId());
				if (isSuperAdmin) {
					global = isSuperAdmin;
				} else {
					screenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());
				}
				if (Validator.isNotNull(vcId) || Validator.isNotNull(stbNo) || Validator.isNotNull(macId)) {
					map = customerService.getInventory(vcId, stbNo, macId, screenName, txRefNo, userAgent, companyId, groupId, global);
					if (map.containsKey("status")) {
						status = map.get("status");
						map.remove("status");
					}
					if (map.containsKey("message")) {
						message = map.get("message");
						map.remove("message");
					}
				}
			}
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}
		if ("FAIL".equalsIgnoreCase(status)) {
			renderRequest.setAttribute("errorMessage", message);
			SessionErrors.add(renderRequest, "error-message");
		}
		renderRequest.setAttribute("vcId", vcId);
		renderRequest.setAttribute("stbNo", stbNo);
		renderRequest.setAttribute("macId", macId);
		renderRequest.setAttribute("map", map);
		renderRequest.setAttribute("isSuperAdmin", isSuperAdmin);

		return "/inventory/view.jsp";
	}

	@Reference
	private CustomerService customerService;

	@Reference
	private AgentService agentService;
}