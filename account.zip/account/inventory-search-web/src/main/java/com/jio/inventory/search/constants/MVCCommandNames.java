package com.jio.inventory.search.constants;

public class MVCCommandNames {

	public static final String SEARCH = "/inventory/search";

	public static final String VIEW = "/inventory/view";
	
	public static final String DOWNLOAD = "/inventory/download";

}
