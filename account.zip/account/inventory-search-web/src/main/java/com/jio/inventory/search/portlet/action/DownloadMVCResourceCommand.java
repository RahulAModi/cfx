package com.jio.inventory.search.portlet.action;

import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.customer.service.CustomerService;
import com.jio.inventory.search.constants.InventorySearchPortletKeys;
import com.jio.inventory.search.constants.MVCCommandNames;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + InventorySearchPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD }, service = MVCResourceCommand.class)
public class DownloadMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadMVCResourceCommand.class);

	@Reference
	private CustomerService customerService;

	@Reference
	private AgentService agentService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean resource = true;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		boolean isSuperAdmin = false;
		String vcId = ParamUtil.getString(resourceRequest, "vcId");
		String stbNo = ParamUtil.getString(resourceRequest, "stbNo");
		String macId = ParamUtil.getString(resourceRequest, "macId");

		PortletPreferences portletPreferences = resourceRequest.getPreferences();
		boolean global = GetterUtil.getBoolean(portletPreferences.getValue("global", StringPool.BLANK));
		Map<String, String> map = new HashMap<String, String>();

		try {
			long groupId = PortalUtil.getScopeGroupId(resourceRequest);

			User userAgent = PortalUtil.getUser(resourceRequest);
			String txRefNo = AccountUtil.getTxRefNo();
			String screenName = "2975299";
			if (Validator.isNotNull(userAgent)) {
				isSuperAdmin = AccountUtil.isAdmin(userAgent.getUserId());
				if (isSuperAdmin) {
					global = isSuperAdmin;
				} else {
					screenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());
				}
				if (Validator.isNotNull(vcId) || Validator.isNotNull(stbNo) || Validator.isNotNull(macId)) {
					map = customerService.getInventory(vcId, stbNo, macId, screenName, txRefNo, userAgent, companyId, groupId, global);
					if (map.containsKey("status")) {
						map.remove("status");
					}
					if (map.containsKey("message")) {
						map.remove("message");
					}
				}
			}

			StringBundler sb = new StringBundler();

			map.entrySet().forEach(entry -> {
				sb.append(entry.getKey().toUpperCase());
				sb.append(CharPool.COMMA);
				sb.append(entry.getValue());
				sb.append(CharPool.COMMA);

				sb.setIndex(sb.index() - 1);
				sb.append(CharPool.NEW_LINE);
			});

			String fileName = "Inventory".concat(StringPool.UNDERLINE).concat(screenName).concat(StringPool.PERIOD).concat("csv");
			byte[] bytes = sb.toString().getBytes();
			String contentType = ContentTypes.APPLICATION_TEXT;
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, bytes, contentType);
			} catch (IOException e) {
				LOGGER.error("IOException :: " + e.toString());
				resource = false;
			}

		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		return resource;
	}

}
