package com.jio.agent.service.impl;

import com.jio.account.bean.AgentBean;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Contact;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.balance.constant.BalanceConstant;
import com.jio.balance.model.AgentBalance;
import com.jio.balance.service.AgentBalanceLocalService;
import com.jio.balance.service.BalanceLocalService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.RoleLocalService;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.Date;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, service = AgentService.class)
public class AgentServiceImpl implements AgentService {

	@Override
	public String getPrimaryAgentScreenName(long companyId, String screenName) throws NoSuchAgentException {
		LOGGER.info("AgentServiceImpl::getPrimaryAgentScreenName");
		String primaryAgentScreenName = screenName;
		Agent agent = agentLocalService.getAgent(companyId, screenName);
		if (!agent.isPrimary()) {
			primaryAgentScreenName = agent.getParentCode();
		}
		return primaryAgentScreenName;
	}

	@Override
	public Agent saveAgent(long creatorUserId, AgentBean agentBean, ServiceContext serviceContext) throws PortalException {
		LOGGER.info("AgentServiceImpl::saveAgent");
		Agent agent = saveOrUpdateAgent(agentBean.getCompanyId(), agentBean.getGroupId(), agentBean.getCreatedBy(), agentBean.getScreenName(), agentBean.getName(), agentBean.getParentCode(), agentBean.isPrimary(), agentBean.getJvNo(), agentBean.getDirectNo(), agentBean.getPoId(),
				agentBean.getAccountNo(), agentBean.getGstin(), agentBean.getStatus(), agentBean.getDistributor(), agentBean.getSubDistributor(), agentBean.getPrefDom(), agentBean.getJvPoId(), agentBean.getDirectPoId(), agentBean.getDistributorPoId(), agentBean.getDistributorPoId(),
				agentBean.getDirectName(), agentBean.getDistributorName(), agentBean.getSubDistributorName(), agentBean.getPanNo(), agentBean.getReportDate(), agentBean.getPpType(), agentBean.getLocator());

		saveOrUpdateBalance(agent);

		saveOrUpdateAddress(agentBean.getCompanyId(), agentBean.getGroupId(), agentBean.getScreenName(), StringPool.BLANK, StringPool.BLANK, agentBean.getState(), agentBean.getCity(), StringPool.BLANK, agentBean.getPincode(), agentBean.getStreet(), agentBean.getLocation(), agentBean.getBuilding(),
				agentBean.getFlatNo(), agentBean.getAddress(), StringPool.BLANK, agentBean.getParentCode());

		saveOrUpdateContact(agentBean.getCompanyId(), agentBean.getGroupId(), agentBean.getScreenName(), agentBean.getMobileNo(), StringPool.BLANK, agentBean.getEmail(), Boolean.FALSE, agentBean.getParentCode());

		saveOrUpdateUser(creatorUserId, agentBean, serviceContext);

		return agent;
	}

	@Override
	public User saveOrUpdateUser(long creatorUserId, AgentBean agentBean, ServiceContext serviceContext) throws PortalException {
		LOGGER.info("AgentServiceImpl::saveOrUpdateUser");
		User user = null;
		try {
			if (Validator.isNotNull(agentBean.getScreenName())) {
				user = userLocalService.getUserByScreenName(agentBean.getCompanyId(), agentBean.getScreenName());
			}
		} catch (PortalException e) {
			LOGGER.warn("PortalException :: " + e.toString());
		}
		if (Validator.isNotNull(user)) {
			// Update
			user.setFirstName(agentBean.getFirstName());
			user.setMiddleName(agentBean.getMiddleName());
			user.setLastName(agentBean.getLastName());
			user = userLocalService.updateUser(user);
		} else {
			// Add
			String jobTitle = "Agent";
			if (agentBean.isPrimary()) {
				jobTitle = "LCO Agent";
			}
			long[] roles = getAgentRoleIds(agentBean.getCompanyId());
			user = userLocalService.addUserWithWorkflow(creatorUserId, agentBean.getCompanyId(), false, "test", "test", false, agentBean.getScreenName(), agentBean.getEmail(), 0L, "", serviceContext.getLocale(), agentBean.getFirstName(), agentBean.getMiddleName(), agentBean.getLastName(), 0L, 0L,
					true, 0, 15, 1991, jobTitle, new long[] {}, new long[] {}, roles, new long[] {}, false, serviceContext);
		}
		LOGGER.info("User :" + user.toString());
		return user;
	}

	private long[] getAgentRoleIds(long companyId) {
		long roleId = getAgentRoleId(companyId);
		if (roleId != 0L) {
			return new long[] { roleId };
		}
		return new long[] {};
	}

	public long getAgentRoleId(long companyId) {
		String name = GetterUtil.getString(JioPropsUtil.get(ConfigConstant.AGENT_ROLE, companyId));
		if (Validator.isNotNull(name)) {
			try {
				Role role = roleLocalService.getRole(companyId, name);
				return role.getRoleId();
			} catch (PortalException e) {
				LOGGER.error("PortalException : " + e.toString());
			}
		}
		return 0L;
	}

	@Override
	public Agent saveOrUpdateAgent(long comapnyId, long groupId, String createBy, String screenName, String name, String parentCode, boolean primary, String jvNo, String directNo, String poId, String accountNo, String gstinNo, int status, String distributor, String subDistributor, String prefDom,
			String jvPoId, String directPoId, String distributorPoId, String subDistributorPoId, String directName, String distributorName, String subDistributorName, String panNo, Date reportDate, String ppType, String locator) {
		LOGGER.info("AgentServiceImpl::saveOrUpdateAgent");
		Agent agent = null;
		if (Validator.isNotNull(screenName)) {
			try {
				agent = agentLocalService.getAgent(comapnyId, screenName);
			} catch (NoSuchAgentException e) {
				LOGGER.warn("NoSuchAgentException :: " + e.toString());
			}
		}

		if (Validator.isNull(agent)) {
			String refernceNumber = primary ? AccountUtil.getRefNo("L") : AccountUtil.getRefNo("AL");
			agent = agentLocalService.createAgent(refernceNumber);
		}

		agent.setCompanyId(comapnyId);
		agent.setGroupId(groupId);
		agent.setCreateBy(createBy);
		agent.setScreenName(screenName);
		agent.setName(name);
		agent.setParentCode(parentCode);
		agent.setPrimary(primary);
		agent.setJvNo(jvNo);
		agent.setDirectNo(directNo);
		agent.setPoId(poId);
		agent.setAccountNo(accountNo);
		agent.setGstinNo(gstinNo);
		agent.setStatus(status);
		agent.setDistributor(distributor);
		agent.setSubDistributor(subDistributor);
		agent.setPrefDom(prefDom);
		agent.setJvPoId(jvPoId);
		agent.setDistributorPoId(distributorPoId);
		agent.setSubDistributorPoId(subDistributorPoId);
		agent.setDistributorName(distributorName);
		agent.setSubDistributorName(subDistributorName);
		agent.setPanNo(panNo);
		agent.setReportDate(reportDate);
		agent.setPpType(ppType);
		agent.setLocator(locator);

		if (agent.isNew()) {
			agent = agentLocalService.addAgent(agent);
		} else {
			agent = agentLocalService.updateAgent(agent);
		}
		LOGGER.info("Agent : " + agent.toString());
		return agent;
	}

	@Override
	public Address saveOrUpdateAddress(long companyId, long groupId, String screenName, String countryCode, String regionCode, String stateCode, String cityCode, String areaCode, String pinCode, String street, String location, String building, String flatNo, String addressLine, String type,
			String createdBy) {
		LOGGER.info("AgentServiceImpl::saveOrUpdateAddress");
		Address address = null;

		if (Validator.isNotNull(screenName)) {
			try {
				address = addressLocalService.getAddress(companyId, screenName);
			} catch (NoSuchAddressException e) {
				LOGGER.warn("NoSuchAddressException :: " + e.toString());
			}
		}

		if (Validator.isNull(address)) {
			address = addressLocalService.createAddress(AccountUtil.getRefNo("A"));
		}

		address.setCompanyId(companyId);
		address.setGroupId(groupId);
		address.setScreenName(screenName);
		address.setCountryCode(countryCode);
		address.setRegionCode(regionCode);
		address.setStateCode(stateCode);
		address.setCityCode(cityCode);
		address.setAreaCode(areaCode);
		address.setPincode(pinCode);
		address.setStreet(street);
		address.setLocation(location);
		address.setBuilding(building);
		address.setFlatNo(flatNo);
		address.setAddress(addressLine);
		address.setType(type);
		address.setCreateBy(createdBy);

		if (address.isNew()) {
			address = addressLocalService.addAddress(address);
		} else {
			address = addressLocalService.updateAddress(address);
		}
		LOGGER.info("Address : " + address.toString());
		return address;
	}

	@Override
	public Contact saveOrUpdateContact(long companyId, long groupId, String screenName, String mobileNo, String landLineNo, String email, boolean primary, String createdBy) {
		LOGGER.info("AgentServiceImpl::saveOrUpdateContact");
		Contact contact = null;

		if (Validator.isNotNull(screenName)) {
			try {
				contact = contactLocalService.getContact(companyId, screenName);
			} catch (NoSuchContactException e) {
				LOGGER.warn("NoSuchContactException :: " + e.toString());
			}
		}

		if (Validator.isNull(contact)) {
			contact = contactLocalService.createContact(AccountUtil.getRefNo("CC"));
		}

		contact.setCompanyId(companyId);
		contact.setGroupId(groupId);
		contact.setScreenName(screenName);
		contact.setMobileNo(mobileNo);
		contact.setLandLineNo(landLineNo);
		contact.setEmail(email);
		contact.setPrimary(primary);
		contact.setCreateBy(createdBy);

		if (contact.isNew()) {
			contact = contactLocalService.addContact(contact);
		} else {
			contact = contactLocalService.updateContact(contact);
		}
		LOGGER.info("Contact : " + contact.toString());
		return contact;
	}

	public boolean validUser(long companyId, String screenName, String emailAddress) {
		LOGGER.info("AgentServiceImpl::validUser");
		boolean validUser = true;
		User user = null;
		try {
			if (Validator.isNotNull(screenName)) {
				user = userLocalService.getUserByScreenName(companyId, screenName);
				if (Validator.isNotNull(user)) {
					validUser = false;
				}
			} else {
				validUser = false;
			}

		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		try {
			if (Validator.isNotNull(emailAddress)) {
				user = userLocalService.getUserByEmailAddress(companyId, emailAddress);
				if (Validator.isNotNull(user)) {
					validUser = true;
				}
			} else {
				validUser = false;
			}
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		return validUser;
	}

	@Override
	public AgentBalance saveOrUpdateBalance(Agent agent) {
		LOGGER.info("AgentServiceImpl::saveOrUpdateBalance");
		balanceLocalService.saveBalance(0L, agent.getCompanyId(), agent.getGroupId(), BalanceConstant.CREATE, 0.0, true, "Create LCO Entry", StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, null, agent.getAgentId(), agent.getParentCode(), BalanceConstant.CREATE, StringPool.BLANK,
				agent.getParentCode(), agent.getParentCode(), StringPool.BLANK, BalanceConstant.CREATE, BalanceConstant.CREATE, agent.getParentCode(), null, 0, StringPool.BLANK);

		AgentBalance agentBalance = agentBalanceLocalService.saveAgentBalance(agent.getGroupId(), agent.getCompanyId(), agent.getParentCode(), 0.0, true, agent.getAgentId(), "Create LCO Entry", BalanceConstant.CREATE, StringPool.BLANK, agent.getParentCode(), agent.getParentCode());

		return agentBalance;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private CounterLocalService counterLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private BalanceLocalService balanceLocalService;

	@Reference
	private AgentBalanceLocalService agentBalanceLocalService;

	@Reference
	private RoleLocalService roleLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(AgentServiceImpl.class);
}
