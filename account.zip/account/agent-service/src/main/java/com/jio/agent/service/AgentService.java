package com.jio.agent.service;

import com.jio.account.bean.AgentBean;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Contact;
import com.jio.balance.model.AgentBalance;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;

import java.util.Date;

public interface AgentService {

	/**
	 * 
	 * @param companyId
	 * @param screenName
	 * @return
	 * @throws NoSuchAgentException
	 */
	String getPrimaryAgentScreenName(long companyId, String screenName) throws NoSuchAgentException;

	/**
	 * 
	 * @param creatorUserId
	 * @param agentBean
	 * @param serviceContext
	 * @return
	 * @throws PortalException
	 */
	User saveOrUpdateUser(long creatorUserId, AgentBean agentBean, ServiceContext serviceContext) throws PortalException;

	/**
	 * 
	 * @param creatorUserId
	 * @param agentBean
	 * @param serviceContext
	 * @return
	 * @throws PortalException
	 */
	Agent saveAgent(long creatorUserId, AgentBean agentBean, ServiceContext serviceContext) throws PortalException;

	/**
	 * 
	 * @param comapnyId
	 * @param groupId
	 * @param createBy
	 * @param screenName
	 * @param name
	 * @param parentCode
	 * @param primary
	 * @param jvNo
	 * @param directNo
	 * @param poId
	 * @param accountNo
	 * @param gstinNo
	 * @param status
	 * @param distributor
	 * @param subDistributor
	 * @param prefDom
	 * @param jvPoId
	 * @param directPoId
	 * @param distributorPoId
	 * @param subDistributorPoId
	 * @param directName
	 * @param distributorName
	 * @param subDistributorName
	 * @param panNo
	 * @param reportDate
	 * @param ppType
	 * @param locator
	 * @return
	 */
	Agent saveOrUpdateAgent(long comapnyId, long groupId, String createBy, String screenName, String name, String parentCode, boolean primary, String jvNo, String directNo, String poId, String accountNo, String gstinNo, int status, String distributor, String subDistributor, String prefDom,
			String jvPoId, String directPoId, String distributorPoId, String subDistributorPoId, String directName, String distributorName, String subDistributorName, String panNo, Date reportDate, String ppType, String locator);

	/**
	 * 
	 * @param companyId
	 * @param groupId
	 * @param screenName
	 * @param countryCode
	 * @param regionCode
	 * @param stateCode
	 * @param cityCode
	 * @param areaCode
	 * @param pinCode
	 * @param street
	 * @param location
	 * @param building
	 * @param flatNo
	 * @param addressLine
	 * @param type
	 * @param createdBy
	 * @return
	 */
	Address saveOrUpdateAddress(long companyId, long groupId, String screenName, String countryCode, String regionCode, String stateCode, String cityCode, String areaCode, String pinCode, String street, String location, String building, String flatNo, String addressLine, String type,
			String createdBy);

	/**
	 * 
	 * @param companyId
	 * @param groupId
	 * @param screenName
	 * @param mobileNo
	 * @param landLineNo
	 * @param email
	 * @param primary
	 * @param createdBy
	 * @return
	 */
	Contact saveOrUpdateContact(long companyId, long groupId, String screenName, String mobileNo, String landLineNo, String email, boolean primary, String createdBy);

	/**
	 * 
	 * @param companyId
	 * @param screenName
	 * @param emailAddress
	 * @return
	 */
	boolean validUser(long companyId, String screenName, String emailAddress);

	/**
	 * 
	 * @param agent
	 * @return
	 */
	AgentBalance saveOrUpdateBalance(Agent agent);

	/**
	 * 
	 * @param companyId
	 * @return
	 */
	long getAgentRoleId(long companyId);

}
