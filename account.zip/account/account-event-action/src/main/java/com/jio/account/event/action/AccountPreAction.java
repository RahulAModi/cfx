package com.jio.account.event.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.balance.model.AgentBalance;
import com.jio.balance.service.AgentBalanceLocalService;
import com.liferay.portal.kernel.events.ActionException;
import com.liferay.portal.kernel.events.LifecycleAction;
import com.liferay.portal.kernel.events.LifecycleEvent;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Vishal7.Shah
 */
@Component(immediate = true, property = { "key=servlet.service.events.pre" }, service = LifecycleAction.class)
public class AccountPreAction implements LifecycleAction {

	private static final Log LOGGER = LogFactoryUtil.getLog(AccountPreAction.class);

	@Override
	public void processLifecycleEvent(LifecycleEvent lifecycleEvent) throws ActionException {
		HttpServletRequest httpServletRequest = lifecycleEvent.getRequest();
		try {
			User user = PortalUtil.getUser(httpServletRequest);
			long companyId = PortalUtil.getCompanyId(httpServletRequest);
			if (Validator.isNotNull(user) && AccountUtil.isNotAdmin(user.getUserId())) {
				Agent agent = agentLocalService.getParentAgent(companyId, user.getScreenName());
				double balance = 0.0d;
				try {
					AgentBalance agentBalance = agentBalanceLocalService.getAgentBalance(agent.getScreenName(), companyId);
					balance = agentBalance.getAmount();
				} catch (NoSuchAgentBalanceException e) {
					LOGGER.warn("NoSuchAgentBalanceException : " + e.toString());
				}
				Map<String, String> ftlVariables = new HashMap<String, String>();
				ftlVariables.put("agentName", agent.getName());
				ftlVariables.put("agentCode", agent.getScreenName());
				ftlVariables.put("agentBalance", String.format("%.2f", balance));
				httpServletRequest.setAttribute(WebKeys.FTL_VARIABLES, ftlVariables);
			}

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

	}

	@Reference
	AgentLocalService agentLocalService;

	@Reference
	AgentBalanceLocalService agentBalanceLocalService;

}