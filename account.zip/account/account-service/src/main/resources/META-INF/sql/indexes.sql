create index IX_6F213D34 on ACCOUNT_Address (companyId, screenName[$COLUMN_LENGTH:75$], addressId[$COLUMN_LENGTH:75$]);
create index IX_78B19C53 on ACCOUNT_Address (customerId[$COLUMN_LENGTH:75$], companyId);
create index IX_DFFA995 on ACCOUNT_Address (screenName[$COLUMN_LENGTH:75$], companyId);

create index IX_204E5B9B on ACCOUNT_Agent (companyId, clientCode[$COLUMN_LENGTH:75$]);
create index IX_AB79E519 on ACCOUNT_Agent (companyId, legacyCode[$COLUMN_LENGTH:75$]);
create index IX_8EB1E70B on ACCOUNT_Agent (companyId, parentCode[$COLUMN_LENGTH:75$], primary_);
create index IX_ABE728E0 on ACCOUNT_Agent (companyId, primary_);
create index IX_98FD5805 on ACCOUNT_Agent (companyId, screenName[$COLUMN_LENGTH:75$], parentCode[$COLUMN_LENGTH:75$]);
create index IX_1AD69B84 on ACCOUNT_Agent (parentCode[$COLUMN_LENGTH:75$], companyId);

create index IX_3DA95CB0 on ACCOUNT_AgentCustomerMapping (companyId, agentScreenName[$COLUMN_LENGTH:75$], customerScreenName[$COLUMN_LENGTH:75$]);
create index IX_9F8581AE on ACCOUNT_AgentCustomerMapping (companyId, customerScreenName[$COLUMN_LENGTH:75$]);

create index IX_E67CB18C on ACCOUNT_Contact (companyId, screenName[$COLUMN_LENGTH:75$], contactId[$COLUMN_LENGTH:75$]);
create index IX_B31BDEF0 on ACCOUNT_Contact (companyId, screenName[$COLUMN_LENGTH:75$], primary_);
create index IX_71F55DA7 on ACCOUNT_Contact (customerId[$COLUMN_LENGTH:75$], companyId);
create index IX_7436AE9 on ACCOUNT_Contact (screenName[$COLUMN_LENGTH:75$], companyId);

create index IX_235FA9A0 on ACCOUNT_Customer (accountNo[$COLUMN_LENGTH:75$], companyId);
create index IX_139CBDEE on ACCOUNT_Customer (accountNo[$COLUMN_LENGTH:75$], macId[$COLUMN_LENGTH:75$], agentScreenName[$COLUMN_LENGTH:75$], companyId);
create index IX_4A056F5 on ACCOUNT_Customer (accountNo[$COLUMN_LENGTH:75$], screenName[$COLUMN_LENGTH:75$], companyId);
create index IX_1726E8E6 on ACCOUNT_Customer (accountNo[$COLUMN_LENGTH:75$], stbNo[$COLUMN_LENGTH:75$], agentScreenName[$COLUMN_LENGTH:75$], companyId);
create index IX_A3A40CA0 on ACCOUNT_Customer (accountNo[$COLUMN_LENGTH:75$], vcId[$COLUMN_LENGTH:75$], agentScreenName[$COLUMN_LENGTH:75$], companyId);
create index IX_B473F132 on ACCOUNT_Customer (agentScreenName[$COLUMN_LENGTH:75$], companyId);
create index IX_983AB0B2 on ACCOUNT_Customer (companyId);
create index IX_CE1145C5 on ACCOUNT_Customer (customerId[$COLUMN_LENGTH:75$], companyId);
create index IX_1C7AFF88 on ACCOUNT_Customer (macId[$COLUMN_LENGTH:75$], companyId, agentScreenName[$COLUMN_LENGTH:75$]);
create index IX_C2DA7405 on ACCOUNT_Customer (screenName[$COLUMN_LENGTH:75$], companyId, agentScreenName[$COLUMN_LENGTH:75$]);
create index IX_15860156 on ACCOUNT_Customer (screenName[$COLUMN_LENGTH:75$], primary_, companyId);
create index IX_EAC235A0 on ACCOUNT_Customer (status[$COLUMN_LENGTH:75$], companyId, agentScreenName[$COLUMN_LENGTH:75$]);
create index IX_20052A80 on ACCOUNT_Customer (stbNo[$COLUMN_LENGTH:75$], companyId, agentScreenName[$COLUMN_LENGTH:75$]);
create index IX_C2F001D6 on ACCOUNT_Customer (vcId[$COLUMN_LENGTH:75$], companyId, agentScreenName[$COLUMN_LENGTH:75$]);

create index IX_B596881 on ACCOUNT_Document (companyId, customerId[$COLUMN_LENGTH:75$], category[$COLUMN_LENGTH:75$], type_[$COLUMN_LENGTH:75$]);
create index IX_ACA16E6C on ACCOUNT_Document (companyId, customerId[$COLUMN_LENGTH:75$], documentId[$COLUMN_LENGTH:75$]);
create index IX_F6B62B21 on ACCOUNT_Document (companyId, customerId[$COLUMN_LENGTH:75$], name[$COLUMN_LENGTH:75$]);
create index IX_4284FC43 on ACCOUNT_Document (companyId, screenName[$COLUMN_LENGTH:75$], category[$COLUMN_LENGTH:75$], type_[$COLUMN_LENGTH:75$]);
create index IX_C115096A on ACCOUNT_Document (companyId, screenName[$COLUMN_LENGTH:75$], documentId[$COLUMN_LENGTH:75$]);
create index IX_E4C15C9F on ACCOUNT_Document (companyId, screenName[$COLUMN_LENGTH:75$], name[$COLUMN_LENGTH:75$]);
create index IX_FB4BE328 on ACCOUNT_Document (customerId[$COLUMN_LENGTH:75$], companyId);
create index IX_9099F06A on ACCOUNT_Document (screenName[$COLUMN_LENGTH:75$], companyId);