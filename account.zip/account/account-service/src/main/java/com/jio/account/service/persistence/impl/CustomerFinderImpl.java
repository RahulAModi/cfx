package com.jio.account.service.persistence.impl;

import com.jio.account.model.Customer;
import com.jio.account.model.impl.CustomerImpl;
import com.jio.account.service.persistence.CustomerFinder;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.dao.orm.custom.sql.CustomSQL;
import com.liferay.portal.kernel.dao.orm.ORMException;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.Type;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(service = CustomerFinder.class)
public class CustomerFinderImpl extends CustomerFinderBaseImpl implements CustomerFinder {

	private static final Log LOGGER = LogFactoryUtil.getLog(CustomerFinderImpl.class.getName());

	@Reference
	private CustomSQL _customSQL;

	public static final String GET_AGENTS = CustomerFinder.class.getName() + ".getCustomers";
	public static final String COUNT_AGENTS = CustomerFinder.class.getName() + ".countCustomers";

	@SuppressWarnings("unchecked")
	public List<Customer> getCustomers(String agentScreenName, long companyId, int start, int end) {
		Session session = null;
		SQLQuery queryObject = null;
		try {
			session = openSession();

			queryObject = createCustomerSQL(session, GET_AGENTS, false, agentScreenName, companyId, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK);

			return (List<Customer>) QueryUtil.list(queryObject, getDialect(), start, end);
		} catch (ORMException e) {
			throw new ORMException(e);
		} finally {
			if (session != null) {
				closeSession(session);
			}
		}
	}

	public int countCustomers(String agentScreenName, long companyId) {
		Session session = null;
		SQLQuery queryObject = null;
		try {
			session = openSession();

			queryObject = createCustomerSQL(session, COUNT_AGENTS, true, agentScreenName, companyId, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK);

			return (Integer) queryObject.list().get(0);
		} catch (ORMException e) {
			throw new ORMException(e);
		} finally {
			if (session != null) {
				closeSession(session);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Customer> getCustomers(String screenName, String status, String vcId, String stbNo, String macId, String agentScreenName, long companyId, int start, int end) {
		Session session = null;
		SQLQuery queryObject = null;
		try {
			session = openSession();

			queryObject = createCustomerSQL(session, GET_AGENTS, false, agentScreenName, companyId, screenName, status, vcId, stbNo, macId);

			return (List<Customer>) QueryUtil.list(queryObject, getDialect(), start, end);
		} catch (ORMException e) {
			throw new ORMException(e);
		} finally {
			if (session != null) {
				closeSession(session);
			}
		}
	}

	public int countCustomers(String screenName, String status, String vcId, String stbNo, String macId, String agentScreenName, long companyId) {
		Session session = null;
		SQLQuery queryObject = null;
		try {
			session = openSession();

			queryObject = createCustomerSQL(session, COUNT_AGENTS, true, agentScreenName, companyId, screenName, status, vcId, stbNo, macId);

			return (Integer) queryObject.list().get(0);
		} catch (ORMException e) {
			throw new ORMException(e);
		} finally {
			if (session != null) {
				closeSession(session);
			}
		}
	}

	protected SQLQuery createCustomerSQL(Session session, String query, boolean count, String agentScreenName, long companyId, String screenName, String status, String vcId, String stbNo, String macId) {
		String sql = _customSQL.get(getClass(), query);

		if (Validator.isNotNull(screenName)) {
			sql = StringUtil.replace(sql, "[$WHERE_CLAUSE$]", "AND AC.SCREENNAME LIKE ?");
		} else if (Validator.isNotNull(status)) {
			sql = StringUtil.replace(sql, "[$WHERE_CLAUSE$]", "AND AC.STATUS LIKE ?");
		} else if (Validator.isNotNull(vcId)) {
			sql = StringUtil.replace(sql, "[$WHERE_CLAUSE$]", "AND AC.VCID LIKE ?");
		} else if (Validator.isNotNull(stbNo)) {
			sql = StringUtil.replace(sql, "[$WHERE_CLAUSE$]", "AND AC.STBNO LIKE ?");
		} else if (Validator.isNotNull(macId)) {
			sql = StringUtil.replace(sql, "[$WHERE_CLAUSE$]", "AND AC.MACID LIKE ?");
		} else {
			sql = StringUtil.replace(sql, "[$WHERE_CLAUSE$]", "");
		}

		SQLQuery queryObject = session.createSQLQuery(sql);
		queryObject.setCacheable(false);

		if (count) {
			queryObject.addScalar("TOTALCOUNT", Type.INTEGER);
		} else {
			queryObject.addEntity("AC", CustomerImpl.class);
		}

		QueryPos queryPos = QueryPos.getInstance(queryObject);
		queryPos.add(agentScreenName);
		queryPos.add(companyId);

		if (Validator.isNotNull(screenName)) {
			queryPos.add(screenName);
		} else if (Validator.isNotNull(status)) {
			queryPos.add(status);
		} else if (Validator.isNotNull(vcId)) {
			queryPos.add(vcId);
		} else if (Validator.isNotNull(stbNo)) {
			queryPos.add(stbNo);
		} else if (Validator.isNotNull(macId)) {
			queryPos.add(macId);
		} else {

		}
		return queryObject;
	}

}
