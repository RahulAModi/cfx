/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.impl;

import com.jio.account.exception.NoSuchDocumentException;
import com.jio.account.model.Document;
import com.jio.account.service.base.DocumentLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the document local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.service.DocumentLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DocumentLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.model.Document", service = AopService.class)
public class DocumentLocalServiceImpl extends DocumentLocalServiceBaseImpl {

	@Override
	public Document addDocument(Document document) {
		document.setCreateDate(new Date());
		document.setModifiedDate(document.getCreateDate());
		document = super.addDocument(document);
		AuditUtil.audit(document, AuditConstants.SAVE);
		return document;
	}

	@Override
	public Document updateDocument(Document document) {
		document.setModifiedDate(new Date());
		document = super.updateDocument(document);
		AuditUtil.audit(document, AuditConstants.UPDATE);
		return document;
	}

	@Override
	public Document deleteDocument(Document document) {
		document.setModifiedDate(new Date());
		document = super.deleteDocument(document);
		AuditUtil.audit(document, AuditConstants.DELETE);
		return document;
	}

	@Override
	public Document deleteDocument(String documentId) throws PortalException {
		return deleteDocument(getDocument(documentId));
	}

	public List<Document> getDocuments(String customerId, long companyId) {
		return this.documentPersistence.findByCustomerId(customerId, companyId);
	}

	public List<Document> findByScreenName(String screenName, long companyId) {
		return this.documentPersistence.findByScreenName(screenName, companyId);
	}

	public Document findByScreenNameAndDocumentId(long companyId, String customerId, String documentId) throws NoSuchDocumentException {
		return this.documentPersistence.findByC_C_D(companyId, customerId, documentId);
	}

	public Document findBySN_NAME(long companyId, String customerId, String name) throws NoSuchDocumentException {
		return this.documentPersistence.findByC_C_N(companyId, customerId, name);
	}

	public Document getDocumentByC_S_C_T(long companyId, String customerId, String category, String type) throws NoSuchDocumentException {
		return this.documentPersistence.findByC_C_C_T(companyId, customerId, category, type);
	}

	public Document getDocumentByC_S_C(long companyId, String customerId, String category) throws NoSuchDocumentException {
		return this.documentPersistence.findByC_C_C(companyId, customerId, category);
	}

}