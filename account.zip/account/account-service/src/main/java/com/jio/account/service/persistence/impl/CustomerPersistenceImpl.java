/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence.impl;

import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.model.impl.CustomerImpl;
import com.jio.account.model.impl.CustomerModelImpl;
import com.jio.account.service.persistence.CustomerPersistence;
import com.jio.account.service.persistence.impl.constants.ACCOUNTPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the customer service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = CustomerPersistence.class)
@ProviderType
public class CustomerPersistenceImpl
	extends BasePersistenceImpl<Customer> implements CustomerPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>CustomerUtil</code> to access the customer persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		CustomerImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathFetchByCustomerId;
	private FinderPath _finderPathCountByCustomerId;

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByCustomerId(String customerId, long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByCustomerId(customerId, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("customerId=");
			msg.append(customerId);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByCustomerId(String customerId, long companyId) {
		return fetchByCustomerId(customerId, companyId, true);
	}

	/**
	 * Returns the customer where customerId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByCustomerId(
		String customerId, long companyId, boolean retrieveFromCache) {

		customerId = Objects.toString(customerId, "");

		Object[] finderArgs = new Object[] {customerId, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByCustomerId, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(customerId, customer.getCustomerId()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2);
			}

			query.append(_FINDER_COLUMN_CUSTOMERID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByCustomerId, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByCustomerId(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByCustomerId, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where customerId = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByCustomerId(String customerId, long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByCustomerId(customerId, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByCustomerId(String customerId, long companyId) {
		customerId = Objects.toString(customerId, "");

		FinderPath finderPath = _finderPathCountByCustomerId;

		Object[] finderArgs = new Object[] {customerId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2);
			}

			query.append(_FINDER_COLUMN_CUSTOMERID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2 =
		"customer.customerId = ? AND ";

	private static final String _FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3 =
		"(customer.customerId IS NULL OR customer.customerId = '') AND ";

	private static final String _FINDER_COLUMN_CUSTOMERID_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByAN_VCID_ASN;
	private FinderPath _finderPathCountByAN_VCID_ASN;

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAN_VCID_ASN(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(10);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", vcId=");
			msg.append(vcId);

			msg.append(", agentScreenName=");
			msg.append(agentScreenName);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId) {

		return fetchByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId, true);
	}

	/**
	 * Returns the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		vcId = Objects.toString(vcId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Object[] finderArgs = new Object[] {
			accountNo, vcId, agentScreenName, companyId
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAN_VCID_ASN, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(accountNo, customer.getAccountNo()) ||
				!Objects.equals(vcId, customer.getVcId()) ||
				!Objects.equals(
					agentScreenName, customer.getAgentScreenName()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_VCID_ASN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_VCID_ASN_ACCOUNTNO_2);
			}

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_VCID_ASN_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_AN_VCID_ASN_VCID_2);
			}

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_VCID_ASN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AN_VCID_ASN_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_VCID_ASN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindVcId) {
					qPos.add(vcId);
				}

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAN_VCID_ASN, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByAN_VCID_ASN(String, String, String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAN_VCID_ASN, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByAN_VCID_ASN(
			String accountNo, String vcId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByAN_VCID_ASN(
			accountNo, vcId, agentScreenName, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and vcId = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param vcId the vc ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAN_VCID_ASN(
		String accountNo, String vcId, String agentScreenName, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		vcId = Objects.toString(vcId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_VCID_ASN;

		Object[] finderArgs = new Object[] {
			accountNo, vcId, agentScreenName, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_VCID_ASN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_VCID_ASN_ACCOUNTNO_2);
			}

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_VCID_ASN_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_AN_VCID_ASN_VCID_2);
			}

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_VCID_ASN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AN_VCID_ASN_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_VCID_ASN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindVcId) {
					qPos.add(vcId);
				}

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_VCID_ASN_ACCOUNTNO_2 =
		"customer.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_VCID_ASN_ACCOUNTNO_3 =
		"(customer.accountNo IS NULL OR customer.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_VCID_ASN_VCID_2 =
		"customer.vcId = ? AND ";

	private static final String _FINDER_COLUMN_AN_VCID_ASN_VCID_3 =
		"(customer.vcId IS NULL OR customer.vcId = '') AND ";

	private static final String _FINDER_COLUMN_AN_VCID_ASN_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_VCID_ASN_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_VCID_ASN_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByAN_STBNO_ASN;
	private FinderPath _finderPathCountByAN_STBNO_ASN;

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAN_STBNO_ASN(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(10);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", stbNo=");
			msg.append(stbNo);

			msg.append(", agentScreenName=");
			msg.append(agentScreenName);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName,
		long companyId) {

		return fetchByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId, true);
	}

	/**
	 * Returns the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName, long companyId,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		stbNo = Objects.toString(stbNo, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Object[] finderArgs = new Object[] {
			accountNo, stbNo, agentScreenName, companyId
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAN_STBNO_ASN, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(accountNo, customer.getAccountNo()) ||
				!Objects.equals(stbNo, customer.getStbNo()) ||
				!Objects.equals(
					agentScreenName, customer.getAgentScreenName()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_STBNO_ASN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_STBNO_ASN_ACCOUNTNO_2);
			}

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_STBNO_ASN_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_AN_STBNO_ASN_STBNO_2);
			}

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_STBNO_ASN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AN_STBNO_ASN_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_STBNO_ASN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAN_STBNO_ASN, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByAN_STBNO_ASN(String, String, String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAN_STBNO_ASN, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByAN_STBNO_ASN(
			String accountNo, String stbNo, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByAN_STBNO_ASN(
			accountNo, stbNo, agentScreenName, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and stbNo = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param stbNo the stb no
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAN_STBNO_ASN(
		String accountNo, String stbNo, String agentScreenName,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		stbNo = Objects.toString(stbNo, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_STBNO_ASN;

		Object[] finderArgs = new Object[] {
			accountNo, stbNo, agentScreenName, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_STBNO_ASN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_STBNO_ASN_ACCOUNTNO_2);
			}

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_STBNO_ASN_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_AN_STBNO_ASN_STBNO_2);
			}

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_STBNO_ASN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AN_STBNO_ASN_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_STBNO_ASN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_ACCOUNTNO_2 =
		"customer.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_ACCOUNTNO_3 =
		"(customer.accountNo IS NULL OR customer.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_STBNO_2 =
		"customer.stbNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_STBNO_3 =
		"(customer.stbNo IS NULL OR customer.stbNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_STBNO_ASN_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByAN_MACID_ASN;
	private FinderPath _finderPathCountByAN_MACID_ASN;

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAN_MACID_ASN(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(10);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", macId=");
			msg.append(macId);

			msg.append(", agentScreenName=");
			msg.append(agentScreenName);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName,
		long companyId) {

		return fetchByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId, true);
	}

	/**
	 * Returns the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName, long companyId,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		macId = Objects.toString(macId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Object[] finderArgs = new Object[] {
			accountNo, macId, agentScreenName, companyId
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAN_MACID_ASN, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(accountNo, customer.getAccountNo()) ||
				!Objects.equals(macId, customer.getMacId()) ||
				!Objects.equals(
					agentScreenName, customer.getAgentScreenName()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_MACID_ASN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_MACID_ASN_ACCOUNTNO_2);
			}

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_MACID_ASN_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_AN_MACID_ASN_MACID_2);
			}

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_MACID_ASN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AN_MACID_ASN_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_MACID_ASN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindMacId) {
					qPos.add(macId);
				}

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAN_MACID_ASN, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByAN_MACID_ASN(String, String, String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAN_MACID_ASN, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByAN_MACID_ASN(
			String accountNo, String macId, String agentScreenName,
			long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByAN_MACID_ASN(
			accountNo, macId, agentScreenName, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and macId = &#63; and agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param macId the mac ID
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAN_MACID_ASN(
		String accountNo, String macId, String agentScreenName,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		macId = Objects.toString(macId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_MACID_ASN;

		Object[] finderArgs = new Object[] {
			accountNo, macId, agentScreenName, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_MACID_ASN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_MACID_ASN_ACCOUNTNO_2);
			}

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_MACID_ASN_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_AN_MACID_ASN_MACID_2);
			}

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_MACID_ASN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AN_MACID_ASN_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_MACID_ASN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindMacId) {
					qPos.add(macId);
				}

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_MACID_ASN_ACCOUNTNO_2 =
		"customer.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_MACID_ASN_ACCOUNTNO_3 =
		"(customer.accountNo IS NULL OR customer.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_MACID_ASN_MACID_2 =
		"customer.macId = ? AND ";

	private static final String _FINDER_COLUMN_AN_MACID_ASN_MACID_3 =
		"(customer.macId IS NULL OR customer.macId = '') AND ";

	private static final String _FINDER_COLUMN_AN_MACID_ASN_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_MACID_ASN_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_MACID_ASN_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByAccountNo;
	private FinderPath _finderPathCountByAccountNo;

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAccountNo(String accountNo, long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByAccountNo(accountNo, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAccountNo(String accountNo, long companyId) {
		return fetchByAccountNo(accountNo, companyId, true);
	}

	/**
	 * Returns the customer where accountNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAccountNo(
		String accountNo, long companyId, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");

		Object[] finderArgs = new Object[] {accountNo, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAccountNo, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(accountNo, customer.getAccountNo()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_ACCOUNTNO_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_ACCOUNTNO_ACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_ACCOUNTNO_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAccountNo, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByAccountNo(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAccountNo, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where accountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByAccountNo(String accountNo, long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByAccountNo(accountNo, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAccountNo(String accountNo, long companyId) {
		accountNo = Objects.toString(accountNo, "");

		FinderPath finderPath = _finderPathCountByAccountNo;

		Object[] finderArgs = new Object[] {accountNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_ACCOUNTNO_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_ACCOUNTNO_ACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_ACCOUNTNO_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ACCOUNTNO_ACCOUNTNO_2 =
		"customer.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_ACCOUNTNO_ACCOUNTNO_3 =
		"(customer.accountNo IS NULL OR customer.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_ACCOUNTNO_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByVcId_C;
	private FinderPath _finderPathCountByVcId_C;

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByVcId_C(String vcId, long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByVcId_C(vcId, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("vcId=");
			msg.append(vcId);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByVcId_C(String vcId, long companyId) {
		return fetchByVcId_C(vcId, companyId, true);
	}

	/**
	 * Returns the customer where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByVcId_C(
		String vcId, long companyId, boolean retrieveFromCache) {

		vcId = Objects.toString(vcId, "");

		Object[] finderArgs = new Object[] {vcId, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByVcId_C, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(vcId, customer.getVcId()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_C_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_C_VCID_2);
			}

			query.append(_FINDER_COLUMN_VCID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByVcId_C, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByVcId_C(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByVcId_C, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where vcId = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByVcId_C(String vcId, long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByVcId_C(vcId, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where vcId = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByVcId_C(String vcId, long companyId) {
		vcId = Objects.toString(vcId, "");

		FinderPath finderPath = _finderPathCountByVcId_C;

		Object[] finderArgs = new Object[] {vcId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_C_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_C_VCID_2);
			}

			query.append(_FINDER_COLUMN_VCID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VCID_C_VCID_2 =
		"customer.vcId = ? AND ";

	private static final String _FINDER_COLUMN_VCID_C_VCID_3 =
		"(customer.vcId IS NULL OR customer.vcId = '') AND ";

	private static final String _FINDER_COLUMN_VCID_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByStbNo_C;
	private FinderPath _finderPathCountByStbNo_C;

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByStbNo_C(String stbNo, long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByStbNo_C(stbNo, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("stbNo=");
			msg.append(stbNo);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByStbNo_C(String stbNo, long companyId) {
		return fetchByStbNo_C(stbNo, companyId, true);
	}

	/**
	 * Returns the customer where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByStbNo_C(
		String stbNo, long companyId, boolean retrieveFromCache) {

		stbNo = Objects.toString(stbNo, "");

		Object[] finderArgs = new Object[] {stbNo, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByStbNo_C, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(stbNo, customer.getStbNo()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_C_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STBNO_C_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STBNO_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByStbNo_C, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByStbNo_C(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByStbNo_C, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByStbNo_C(String stbNo, long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByStbNo_C(stbNo, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where stbNo = &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByStbNo_C(String stbNo, long companyId) {
		stbNo = Objects.toString(stbNo, "");

		FinderPath finderPath = _finderPathCountByStbNo_C;

		Object[] finderArgs = new Object[] {stbNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_C_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STBNO_C_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STBNO_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STBNO_C_STBNO_2 =
		"customer.stbNo = ? AND ";

	private static final String _FINDER_COLUMN_STBNO_C_STBNO_3 =
		"(customer.stbNo IS NULL OR customer.stbNo = '') AND ";

	private static final String _FINDER_COLUMN_STBNO_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByMacId_C;
	private FinderPath _finderPathCountByMacId_C;

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByMacId_C(String macId, long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByMacId_C(macId, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("macId=");
			msg.append(macId);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByMacId_C(String macId, long companyId) {
		return fetchByMacId_C(macId, companyId, true);
	}

	/**
	 * Returns the customer where macId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByMacId_C(
		String macId, long companyId, boolean retrieveFromCache) {

		macId = Objects.toString(macId, "");

		Object[] finderArgs = new Object[] {macId, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByMacId_C, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(macId, customer.getMacId()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_MACID_C_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_MACID_C_MACID_2);
			}

			query.append(_FINDER_COLUMN_MACID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMacId) {
					qPos.add(macId);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByMacId_C, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByMacId_C(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByMacId_C, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where macId = &#63; and companyId = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByMacId_C(String macId, long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByMacId_C(macId, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where macId = &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByMacId_C(String macId, long companyId) {
		macId = Objects.toString(macId, "");

		FinderPath finderPath = _finderPathCountByMacId_C;

		Object[] finderArgs = new Object[] {macId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_MACID_C_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_MACID_C_MACID_2);
			}

			query.append(_FINDER_COLUMN_MACID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMacId) {
					qPos.add(macId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MACID_C_MACID_2 =
		"customer.macId = ? AND ";

	private static final String _FINDER_COLUMN_MACID_C_MACID_3 =
		"(customer.macId IS NULL OR customer.macId = '') AND ";

	private static final String _FINDER_COLUMN_MACID_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathFetchByAN_SCN;
	private FinderPath _finderPathCountByAN_SCN;

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAN_SCN(
			String accountNo, String screenName, long companyId)
		throws NoSuchCustomerException {

		Customer customer = fetchByAN_SCN(accountNo, screenName, companyId);

		if (customer == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", screenName=");
			msg.append(screenName);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCustomerException(msg.toString());
		}

		return customer;
	}

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_SCN(
		String accountNo, String screenName, long companyId) {

		return fetchByAN_SCN(accountNo, screenName, companyId, true);
	}

	/**
	 * Returns the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_SCN(
		String accountNo, String screenName, long companyId,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		screenName = Objects.toString(screenName, "");

		Object[] finderArgs = new Object[] {accountNo, screenName, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAN_SCN, finderArgs, this);
		}

		if (result instanceof Customer) {
			Customer customer = (Customer)result;

			if (!Objects.equals(accountNo, customer.getAccountNo()) ||
				!Objects.equals(screenName, customer.getScreenName()) ||
				(companyId != customer.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_SCN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_SCN_ACCOUNTNO_2);
			}

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_SCN_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_AN_SCN_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_SCN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				List<Customer> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAN_SCN, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CustomerPersistenceImpl.fetchByAN_SCN(String, String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Customer customer = list.get(0);

					result = customer;

					cacheResult(customer);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByAN_SCN, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Customer)result;
		}
	}

	/**
	 * Removes the customer where accountNo = &#63; and screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the customer that was removed
	 */
	@Override
	public Customer removeByAN_SCN(
			String accountNo, String screenName, long companyId)
		throws NoSuchCustomerException {

		Customer customer = findByAN_SCN(accountNo, screenName, companyId);

		return remove(customer);
	}

	/**
	 * Returns the number of customers where accountNo = &#63; and screenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAN_SCN(
		String accountNo, String screenName, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		screenName = Objects.toString(screenName, "");

		FinderPath finderPath = _finderPathCountByAN_SCN;

		Object[] finderArgs = new Object[] {accountNo, screenName, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_SCN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_SCN_ACCOUNTNO_2);
			}

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_SCN_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_AN_SCN_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_SCN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_SCN_ACCOUNTNO_2 =
		"customer.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_SCN_ACCOUNTNO_3 =
		"(customer.accountNo IS NULL OR customer.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_SCN_SCREENNAME_2 =
		"customer.screenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_SCN_SCREENNAME_3 =
		"(customer.screenName IS NULL OR customer.screenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_SCN_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindBySCN_P;
	private FinderPath _finderPathWithoutPaginationFindBySCN_P;
	private FinderPath _finderPathCountBySCN_P;

	/**
	 * Returns all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId) {

		return findBySCN_P(
			screenName, primary, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start,
		int end) {

		return findBySCN_P(screenName, primary, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findBySCN_P(
			screenName, primary, companyId, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findBySCN_P(
		String screenName, boolean primary, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindBySCN_P;
			finderArgs = new Object[] {screenName, primary, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindBySCN_P;
			finderArgs = new Object[] {
				screenName, primary, companyId, start, end, orderByComparator
			};
		}

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!screenName.equals(customer.getScreenName()) ||
						(primary != customer.isPrimary()) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCN_P_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCN_P_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCN_P_PRIMARY_2);

			query.append(_FINDER_COLUMN_SCN_P_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(primary);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findBySCN_P_First(
			String screenName, boolean primary, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchBySCN_P_First(
			screenName, primary, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", primary=");
		msg.append(primary);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchBySCN_P_First(
		String screenName, boolean primary, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findBySCN_P(
			screenName, primary, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findBySCN_P_Last(
			String screenName, boolean primary, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchBySCN_P_Last(
			screenName, primary, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", primary=");
		msg.append(primary);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchBySCN_P_Last(
		String screenName, boolean primary, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countBySCN_P(screenName, primary, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findBySCN_P(
			screenName, primary, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findBySCN_P_PrevAndNext(
			String customerId, String screenName, boolean primary,
			long companyId, OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		screenName = Objects.toString(screenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getBySCN_P_PrevAndNext(
				session, customer, screenName, primary, companyId,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getBySCN_P_PrevAndNext(
				session, customer, screenName, primary, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getBySCN_P_PrevAndNext(
		Session session, Customer customer, String screenName, boolean primary,
		long companyId, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindScreenName = false;

		if (screenName.isEmpty()) {
			query.append(_FINDER_COLUMN_SCN_P_SCREENNAME_3);
		}
		else {
			bindScreenName = true;

			query.append(_FINDER_COLUMN_SCN_P_SCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_SCN_P_PRIMARY_2);

		query.append(_FINDER_COLUMN_SCN_P_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindScreenName) {
			qPos.add(screenName);
		}

		qPos.add(primary);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where screenName = &#63; and primary = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 */
	@Override
	public void removeBySCN_P(
		String screenName, boolean primary, long companyId) {

		for (Customer customer :
				findBySCN_P(
					screenName, primary, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where screenName = &#63; and primary = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param primary the primary
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countBySCN_P(
		String screenName, boolean primary, long companyId) {

		screenName = Objects.toString(screenName, "");

		FinderPath finderPath = _finderPathCountBySCN_P;

		Object[] finderArgs = new Object[] {screenName, primary, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCN_P_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCN_P_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCN_P_PRIMARY_2);

			query.append(_FINDER_COLUMN_SCN_P_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(primary);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SCN_P_SCREENNAME_2 =
		"customer.screenName = ? AND ";

	private static final String _FINDER_COLUMN_SCN_P_SCREENNAME_3 =
		"(customer.screenName IS NULL OR customer.screenName = '') AND ";

	private static final String _FINDER_COLUMN_SCN_P_PRIMARY_2 =
		"customer.primary = ? AND ";

	private static final String _FINDER_COLUMN_SCN_P_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByScreenName;
	private FinderPath _finderPathWithoutPaginationFindByScreenName;
	private FinderPath _finderPathCountByScreenName;

	/**
	 * Returns all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByScreenName(String screenName, long companyId) {
		return findByScreenName(
			screenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end) {

		return findByScreenName(screenName, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByScreenName(
			screenName, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByScreenName(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByScreenName;
			finderArgs = new Object[] {screenName, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByScreenName;
			finderArgs = new Object[] {
				screenName, companyId, start, end, orderByComparator
			};
		}

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!screenName.equals(customer.getScreenName()) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByScreenName_First(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByScreenName_First(
			screenName, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByScreenName_First(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByScreenName(
			screenName, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByScreenName_Last(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByScreenName_Last(
			screenName, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByScreenName_Last(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByScreenName(screenName, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByScreenName(
			screenName, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByScreenName_PrevAndNext(
			String customerId, String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		screenName = Objects.toString(screenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByScreenName_PrevAndNext(
				session, customer, screenName, companyId, orderByComparator,
				true);

			array[1] = customer;

			array[2] = getByScreenName_PrevAndNext(
				session, customer, screenName, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByScreenName_PrevAndNext(
		Session session, Customer customer, String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindScreenName = false;

		if (screenName.isEmpty()) {
			query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
		}
		else {
			bindScreenName = true;

			query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindScreenName) {
			qPos.add(screenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByScreenName(String screenName, long companyId) {
		for (Customer customer :
				findByScreenName(
					screenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByScreenName(String screenName, long companyId) {
		screenName = Objects.toString(screenName, "");

		FinderPath finderPath = _finderPathCountByScreenName;

		Object[] finderArgs = new Object[] {screenName, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SCREENNAME_SCREENNAME_2 =
		"customer.screenName = ? AND ";

	private static final String _FINDER_COLUMN_SCREENNAME_SCREENNAME_3 =
		"(customer.screenName IS NULL OR customer.screenName = '') AND ";

	private static final String _FINDER_COLUMN_SCREENNAME_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the customers where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByCompanyId(long companyId, int start, int end) {
		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if ((companyId != customer.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByCompanyId_First(
			long companyId, OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByCompanyId_First(
			companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByCompanyId_First(
		long companyId, OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByCompanyId(
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByCompanyId_Last(
			long companyId, OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByCompanyId_Last(companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByCompanyId_Last(
		long companyId, OrderByComparator<Customer> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByCompanyId_PrevAndNext(
			String customerId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, customer, companyId, orderByComparator, true);

			array[1] = customer;

			array[2] = getByCompanyId_PrevAndNext(
				session, customer, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByCompanyId_PrevAndNext(
		Session session, Customer customer, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (Customer customer :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_C;
	private FinderPath _finderPathWithPaginationCountByAN_C;

	/**
	 * Returns all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByAN_C(String accountNo, long companyId) {
		return findByAN_C(
			accountNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end) {

		return findByAN_C(accountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByAN_C(
			accountNo, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByAN_C(
		String accountNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByAN_C;
		finderArgs = new Object[] {
			accountNo, companyId, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getAccountNo(), accountNo, '_', '%', '\\',
							true) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_C_ACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_AN_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAN_C_First(
			String accountNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByAN_C_First(
			accountNo, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_C_First(
		String accountNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByAN_C(
			accountNo, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAN_C_Last(
			String accountNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByAN_C_Last(
			accountNo, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAN_C_Last(
		String accountNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByAN_C(accountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByAN_C(
			accountNo, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByAN_C_PrevAndNext(
			String customerId, String accountNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		accountNo = Objects.toString(accountNo, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByAN_C_PrevAndNext(
				session, customer, accountNo, companyId, orderByComparator,
				true);

			array[1] = customer;

			array[2] = getByAN_C_PrevAndNext(
				session, customer, accountNo, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByAN_C_PrevAndNext(
		Session session, Customer customer, String accountNo, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_C_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_C_ACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_AN_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where accountNo LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_C(String accountNo, long companyId) {
		for (Customer customer :
				findByAN_C(
					accountNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where accountNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAN_C(String accountNo, long companyId) {
		accountNo = Objects.toString(accountNo, "");

		FinderPath finderPath = _finderPathWithPaginationCountByAN_C;

		Object[] finderArgs = new Object[] {accountNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_C_ACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_AN_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_C_ACCOUNTNO_2 =
		"customer.accountNo LIKE ? AND ";

	private static final String _FINDER_COLUMN_AN_C_ACCOUNTNO_3 =
		"(customer.accountNo IS NULL OR customer.accountNo LIKE '') AND ";

	private static final String _FINDER_COLUMN_AN_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindBySN_C;
	private FinderPath _finderPathWithPaginationCountBySN_C;

	/**
	 * Returns all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findBySN_C(String screenName, long companyId) {
		return findBySN_C(
			screenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end) {

		return findBySN_C(screenName, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findBySN_C(
			screenName, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findBySN_C(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindBySN_C;
		finderArgs = new Object[] {
			screenName, companyId, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getScreenName(), screenName, '_', '%',
							'\\', true) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SN_C_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SN_C_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SN_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findBySN_C_First(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchBySN_C_First(
			screenName, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchBySN_C_First(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findBySN_C(
			screenName, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findBySN_C_Last(
			String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchBySN_C_Last(
			screenName, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchBySN_C_Last(
		String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countBySN_C(screenName, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findBySN_C(
			screenName, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findBySN_C_PrevAndNext(
			String customerId, String screenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		screenName = Objects.toString(screenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getBySN_C_PrevAndNext(
				session, customer, screenName, companyId, orderByComparator,
				true);

			array[1] = customer;

			array[2] = getBySN_C_PrevAndNext(
				session, customer, screenName, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getBySN_C_PrevAndNext(
		Session session, Customer customer, String screenName, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindScreenName = false;

		if (screenName.isEmpty()) {
			query.append(_FINDER_COLUMN_SN_C_SCREENNAME_3);
		}
		else {
			bindScreenName = true;

			query.append(_FINDER_COLUMN_SN_C_SCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_SN_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindScreenName) {
			qPos.add(screenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where screenName LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeBySN_C(String screenName, long companyId) {
		for (Customer customer :
				findBySN_C(
					screenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where screenName LIKE &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countBySN_C(String screenName, long companyId) {
		screenName = Objects.toString(screenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountBySN_C;

		Object[] finderArgs = new Object[] {screenName, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SN_C_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SN_C_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SN_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SN_C_SCREENNAME_2 =
		"customer.screenName LIKE ? AND ";

	private static final String _FINDER_COLUMN_SN_C_SCREENNAME_3 =
		"(customer.screenName IS NULL OR customer.screenName LIKE '') AND ";

	private static final String _FINDER_COLUMN_SN_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByS_C;
	private FinderPath _finderPathWithPaginationCountByS_C;

	/**
	 * Returns all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByS_C(String status, long companyId) {
		return findByS_C(
			status, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByS_C(
		String status, long companyId, int start, int end) {

		return findByS_C(status, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByS_C(
		String status, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByS_C(
			status, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByS_C(
		String status, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		status = Objects.toString(status, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByS_C;
		finderArgs = new Object[] {
			status, companyId, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getStatus(), status, '_', '%', '\\',
							true) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindStatus = false;

			if (status.isEmpty()) {
				query.append(_FINDER_COLUMN_S_C_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_S_C_STATUS_2);
			}

			query.append(_FINDER_COLUMN_S_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStatus) {
					qPos.add(status);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByS_C_First(
			String status, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByS_C_First(
			status, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByS_C_First(
		String status, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByS_C(
			status, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByS_C_Last(
			String status, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByS_C_Last(
			status, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByS_C_Last(
		String status, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByS_C(status, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByS_C(
			status, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param status the status
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByS_C_PrevAndNext(
			String customerId, String status, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		status = Objects.toString(status, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByS_C_PrevAndNext(
				session, customer, status, companyId, orderByComparator, true);

			array[1] = customer;

			array[2] = getByS_C_PrevAndNext(
				session, customer, status, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByS_C_PrevAndNext(
		Session session, Customer customer, String status, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindStatus = false;

		if (status.isEmpty()) {
			query.append(_FINDER_COLUMN_S_C_STATUS_3);
		}
		else {
			bindStatus = true;

			query.append(_FINDER_COLUMN_S_C_STATUS_2);
		}

		query.append(_FINDER_COLUMN_S_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindStatus) {
			qPos.add(status);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where status LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 */
	@Override
	public void removeByS_C(String status, long companyId) {
		for (Customer customer :
				findByS_C(
					status, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where status LIKE &#63; and companyId = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByS_C(String status, long companyId) {
		status = Objects.toString(status, "");

		FinderPath finderPath = _finderPathWithPaginationCountByS_C;

		Object[] finderArgs = new Object[] {status, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindStatus = false;

			if (status.isEmpty()) {
				query.append(_FINDER_COLUMN_S_C_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_S_C_STATUS_2);
			}

			query.append(_FINDER_COLUMN_S_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStatus) {
					qPos.add(status);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_S_C_STATUS_2 =
		"customer.status LIKE ? AND ";

	private static final String _FINDER_COLUMN_S_C_STATUS_3 =
		"(customer.status IS NULL OR customer.status LIKE '') AND ";

	private static final String _FINDER_COLUMN_S_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByVC_C;
	private FinderPath _finderPathWithPaginationCountByVC_C;

	/**
	 * Returns all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByVC_C(String vcId, long companyId) {
		return findByVC_C(
			vcId, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end) {

		return findByVC_C(vcId, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByVC_C(vcId, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByVC_C(
		String vcId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		vcId = Objects.toString(vcId, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByVC_C;
		finderArgs = new Object[] {
			vcId, companyId, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getVcId(), vcId, '_', '%', '\\', true) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VC_C_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VC_C_VCID_2);
			}

			query.append(_FINDER_COLUMN_VC_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByVC_C_First(
			String vcId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByVC_C_First(
			vcId, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vcId=");
		msg.append(vcId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByVC_C_First(
		String vcId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByVC_C(
			vcId, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByVC_C_Last(
			String vcId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByVC_C_Last(
			vcId, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vcId=");
		msg.append(vcId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByVC_C_Last(
		String vcId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByVC_C(vcId, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByVC_C(
			vcId, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByVC_C_PrevAndNext(
			String customerId, String vcId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		vcId = Objects.toString(vcId, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByVC_C_PrevAndNext(
				session, customer, vcId, companyId, orderByComparator, true);

			array[1] = customer;

			array[2] = getByVC_C_PrevAndNext(
				session, customer, vcId, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByVC_C_PrevAndNext(
		Session session, Customer customer, String vcId, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindVcId = false;

		if (vcId.isEmpty()) {
			query.append(_FINDER_COLUMN_VC_C_VCID_3);
		}
		else {
			bindVcId = true;

			query.append(_FINDER_COLUMN_VC_C_VCID_2);
		}

		query.append(_FINDER_COLUMN_VC_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindVcId) {
			qPos.add(vcId);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where vcId LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 */
	@Override
	public void removeByVC_C(String vcId, long companyId) {
		for (Customer customer :
				findByVC_C(
					vcId, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where vcId LIKE &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByVC_C(String vcId, long companyId) {
		vcId = Objects.toString(vcId, "");

		FinderPath finderPath = _finderPathWithPaginationCountByVC_C;

		Object[] finderArgs = new Object[] {vcId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VC_C_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VC_C_VCID_2);
			}

			query.append(_FINDER_COLUMN_VC_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VC_C_VCID_2 =
		"customer.vcId LIKE ? AND ";

	private static final String _FINDER_COLUMN_VC_C_VCID_3 =
		"(customer.vcId IS NULL OR customer.vcId LIKE '') AND ";

	private static final String _FINDER_COLUMN_VC_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindBySTB_C;
	private FinderPath _finderPathWithPaginationCountBySTB_C;

	/**
	 * Returns all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findBySTB_C(String stbNo, long companyId) {
		return findBySTB_C(
			stbNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end) {

		return findBySTB_C(stbNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findBySTB_C(
			stbNo, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findBySTB_C(
		String stbNo, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		stbNo = Objects.toString(stbNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindBySTB_C;
		finderArgs = new Object[] {
			stbNo, companyId, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getStbNo(), stbNo, '_', '%', '\\', true) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STB_C_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STB_C_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STB_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findBySTB_C_First(
			String stbNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchBySTB_C_First(
			stbNo, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("stbNo=");
		msg.append(stbNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchBySTB_C_First(
		String stbNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findBySTB_C(
			stbNo, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findBySTB_C_Last(
			String stbNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchBySTB_C_Last(
			stbNo, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("stbNo=");
		msg.append(stbNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchBySTB_C_Last(
		String stbNo, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countBySTB_C(stbNo, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findBySTB_C(
			stbNo, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findBySTB_C_PrevAndNext(
			String customerId, String stbNo, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		stbNo = Objects.toString(stbNo, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getBySTB_C_PrevAndNext(
				session, customer, stbNo, companyId, orderByComparator, true);

			array[1] = customer;

			array[2] = getBySTB_C_PrevAndNext(
				session, customer, stbNo, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getBySTB_C_PrevAndNext(
		Session session, Customer customer, String stbNo, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindStbNo = false;

		if (stbNo.isEmpty()) {
			query.append(_FINDER_COLUMN_STB_C_STBNO_3);
		}
		else {
			bindStbNo = true;

			query.append(_FINDER_COLUMN_STB_C_STBNO_2);
		}

		query.append(_FINDER_COLUMN_STB_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindStbNo) {
			qPos.add(stbNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where stbNo LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 */
	@Override
	public void removeBySTB_C(String stbNo, long companyId) {
		for (Customer customer :
				findBySTB_C(
					stbNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where stbNo LIKE &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countBySTB_C(String stbNo, long companyId) {
		stbNo = Objects.toString(stbNo, "");

		FinderPath finderPath = _finderPathWithPaginationCountBySTB_C;

		Object[] finderArgs = new Object[] {stbNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STB_C_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STB_C_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STB_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STB_C_STBNO_2 =
		"customer.stbNo LIKE ? AND ";

	private static final String _FINDER_COLUMN_STB_C_STBNO_3 =
		"(customer.stbNo IS NULL OR customer.stbNo LIKE '') AND ";

	private static final String _FINDER_COLUMN_STB_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMAC_C;
	private FinderPath _finderPathWithPaginationCountByMAC_C;

	/**
	 * Returns all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByMAC_C(String macId, long companyId) {
		return findByMAC_C(
			macId, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end) {

		return findByMAC_C(macId, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByMAC_C(
			macId, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByMAC_C(
		String macId, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		macId = Objects.toString(macId, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByMAC_C;
		finderArgs = new Object[] {
			macId, companyId, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getMacId(), macId, '_', '%', '\\', true) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_MAC_C_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_MAC_C_MACID_2);
			}

			query.append(_FINDER_COLUMN_MAC_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMacId) {
					qPos.add(macId);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByMAC_C_First(
			String macId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByMAC_C_First(
			macId, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("macId=");
		msg.append(macId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByMAC_C_First(
		String macId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByMAC_C(
			macId, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByMAC_C_Last(
			String macId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByMAC_C_Last(
			macId, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("macId=");
		msg.append(macId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByMAC_C_Last(
		String macId, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByMAC_C(macId, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByMAC_C(
			macId, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByMAC_C_PrevAndNext(
			String customerId, String macId, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		macId = Objects.toString(macId, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByMAC_C_PrevAndNext(
				session, customer, macId, companyId, orderByComparator, true);

			array[1] = customer;

			array[2] = getByMAC_C_PrevAndNext(
				session, customer, macId, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByMAC_C_PrevAndNext(
		Session session, Customer customer, String macId, long companyId,
		OrderByComparator<Customer> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindMacId = false;

		if (macId.isEmpty()) {
			query.append(_FINDER_COLUMN_MAC_C_MACID_3);
		}
		else {
			bindMacId = true;

			query.append(_FINDER_COLUMN_MAC_C_MACID_2);
		}

		query.append(_FINDER_COLUMN_MAC_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMacId) {
			qPos.add(macId);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where macId LIKE &#63; and companyId = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMAC_C(String macId, long companyId) {
		for (Customer customer :
				findByMAC_C(
					macId, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where macId LIKE &#63; and companyId = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByMAC_C(String macId, long companyId) {
		macId = Objects.toString(macId, "");

		FinderPath finderPath = _finderPathWithPaginationCountByMAC_C;

		Object[] finderArgs = new Object[] {macId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_MAC_C_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_MAC_C_MACID_2);
			}

			query.append(_FINDER_COLUMN_MAC_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMacId) {
					qPos.add(macId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MAC_C_MACID_2 =
		"customer.macId LIKE ? AND ";

	private static final String _FINDER_COLUMN_MAC_C_MACID_3 =
		"(customer.macId IS NULL OR customer.macId LIKE '') AND ";

	private static final String _FINDER_COLUMN_MAC_C_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAgentScreenName;
	private FinderPath _finderPathWithoutPaginationFindByAgentScreenName;
	private FinderPath _finderPathCountByAgentScreenName;

	/**
	 * Returns all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId) {

		return findByAgentScreenName(
			agentScreenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end) {

		return findByAgentScreenName(
			agentScreenName, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByAgentScreenName(
			agentScreenName, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByAgentScreenName(
		String agentScreenName, long companyId, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAgentScreenName;
			finderArgs = new Object[] {agentScreenName, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAgentScreenName;
			finderArgs = new Object[] {
				agentScreenName, companyId, start, end, orderByComparator
			};
		}

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!agentScreenName.equals(
							customer.getAgentScreenName()) ||
						(companyId != customer.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAgentScreenName_First(
			String agentScreenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByAgentScreenName_First(
			agentScreenName, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("agentScreenName=");
		msg.append(agentScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAgentScreenName_First(
		String agentScreenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByAgentScreenName(
			agentScreenName, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByAgentScreenName_Last(
			String agentScreenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByAgentScreenName_Last(
			agentScreenName, companyId, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("agentScreenName=");
		msg.append(agentScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByAgentScreenName_Last(
		String agentScreenName, long companyId,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByAgentScreenName(agentScreenName, companyId);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByAgentScreenName(
			agentScreenName, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByAgentScreenName_PrevAndNext(
			String customerId, String agentScreenName, long companyId,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		agentScreenName = Objects.toString(agentScreenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByAgentScreenName_PrevAndNext(
				session, customer, agentScreenName, companyId,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getByAgentScreenName_PrevAndNext(
				session, customer, agentScreenName, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByAgentScreenName_PrevAndNext(
		Session session, Customer customer, String agentScreenName,
		long companyId, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where agentScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAgentScreenName(
		String agentScreenName, long companyId) {

		for (Customer customer :
				findByAgentScreenName(
					agentScreenName, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where agentScreenName = &#63; and companyId = &#63;.
	 *
	 * @param agentScreenName the agent screen name
	 * @param companyId the company ID
	 * @return the number of matching customers
	 */
	@Override
	public int countByAgentScreenName(String agentScreenName, long companyId) {
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathCountByAgentScreenName;

		Object[] finderArgs = new Object[] {agentScreenName, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2 =
			"customer.agentScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3 =
			"(customer.agentScreenName IS NULL OR customer.agentScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2 =
		"customer.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByScreenNameSearch;
	private FinderPath _finderPathWithPaginationCountByScreenNameSearch;

	/**
	 * Returns all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName) {

		return findByScreenNameSearch(
			screenName, companyId, agentScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end) {

		return findByScreenNameSearch(
			screenName, companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return findByScreenNameSearch(
			screenName, companyId, agentScreenName, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByScreenNameSearch(
		String screenName, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByScreenNameSearch;
		finderArgs = new Object[] {
			screenName, companyId, agentScreenName, start, end,
			orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getScreenName(), screenName, '_', '%',
							'\\', true) ||
						(companyId != customer.getCompanyId()) ||
						!agentScreenName.equals(
							customer.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCREENNAMESEARCH_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByScreenNameSearch_First(
			String screenName, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByScreenNameSearch_First(
			screenName, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByScreenNameSearch_First(
		String screenName, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByScreenNameSearch(
			screenName, companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByScreenNameSearch_Last(
			String screenName, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByScreenNameSearch_Last(
			screenName, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByScreenNameSearch_Last(
		String screenName, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByScreenNameSearch(
			screenName, companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByScreenNameSearch(
			screenName, companyId, agentScreenName, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByScreenNameSearch_PrevAndNext(
			String customerId, String screenName, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		screenName = Objects.toString(screenName, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByScreenNameSearch_PrevAndNext(
				session, customer, screenName, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getByScreenNameSearch_PrevAndNext(
				session, customer, screenName, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByScreenNameSearch_PrevAndNext(
		Session session, Customer customer, String screenName, long companyId,
		String agentScreenName, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindScreenName = false;

		if (screenName.isEmpty()) {
			query.append(_FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_3);
		}
		else {
			bindScreenName = true;

			query.append(_FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_SCREENNAMESEARCH_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindScreenName) {
			qPos.add(screenName);
		}

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByScreenNameSearch(
		String screenName, long companyId, String agentScreenName) {

		for (Customer customer :
				findByScreenNameSearch(
					screenName, companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where screenName LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	@Override
	public int countByScreenNameSearch(
		String screenName, long companyId, String agentScreenName) {

		screenName = Objects.toString(screenName, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath =
			_finderPathWithPaginationCountByScreenNameSearch;

		Object[] finderArgs = new Object[] {
			screenName, companyId, agentScreenName
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCREENNAMESEARCH_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_2 =
		"customer.screenName LIKE ? AND ";

	private static final String _FINDER_COLUMN_SCREENNAMESEARCH_SCREENNAME_3 =
		"(customer.screenName IS NULL OR customer.screenName LIKE '') AND ";

	private static final String _FINDER_COLUMN_SCREENNAMESEARCH_COMPANYID_2 =
		"customer.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_2 =
			"customer.agentScreenName = ?";

	private static final String
		_FINDER_COLUMN_SCREENNAMESEARCH_AGENTSCREENNAME_3 =
			"(customer.agentScreenName IS NULL OR customer.agentScreenName = '')";

	private FinderPath _finderPathWithPaginationFindByStatus;
	private FinderPath _finderPathWithPaginationCountByStatus;

	/**
	 * Returns all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByStatus(
		String status, long companyId, String agentScreenName) {

		return findByStatus(
			status, companyId, agentScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end) {

		return findByStatus(
			status, companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return findByStatus(
			status, companyId, agentScreenName, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByStatus(
		String status, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		status = Objects.toString(status, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByStatus;
		finderArgs = new Object[] {
			status, companyId, agentScreenName, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getStatus(), status, '_', '%', '\\',
							true) ||
						(companyId != customer.getCompanyId()) ||
						!agentScreenName.equals(
							customer.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindStatus = false;

			if (status.isEmpty()) {
				query.append(_FINDER_COLUMN_STATUS_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_STATUS_STATUS_2);
			}

			query.append(_FINDER_COLUMN_STATUS_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_STATUS_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_STATUS_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStatus) {
					qPos.add(status);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByStatus_First(
			String status, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByStatus_First(
			status, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByStatus_First(
		String status, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByStatus(
			status, companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByStatus_Last(
			String status, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByStatus_Last(
			status, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("status=");
		msg.append(status);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByStatus_Last(
		String status, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByStatus(status, companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByStatus(
			status, companyId, agentScreenName, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByStatus_PrevAndNext(
			String customerId, String status, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		status = Objects.toString(status, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByStatus_PrevAndNext(
				session, customer, status, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getByStatus_PrevAndNext(
				session, customer, status, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByStatus_PrevAndNext(
		Session session, Customer customer, String status, long companyId,
		String agentScreenName, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindStatus = false;

		if (status.isEmpty()) {
			query.append(_FINDER_COLUMN_STATUS_STATUS_3);
		}
		else {
			bindStatus = true;

			query.append(_FINDER_COLUMN_STATUS_STATUS_2);
		}

		query.append(_FINDER_COLUMN_STATUS_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_STATUS_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_STATUS_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindStatus) {
			qPos.add(status);
		}

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByStatus(
		String status, long companyId, String agentScreenName) {

		for (Customer customer :
				findByStatus(
					status, companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where status LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param status the status
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	@Override
	public int countByStatus(
		String status, long companyId, String agentScreenName) {

		status = Objects.toString(status, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByStatus;

		Object[] finderArgs = new Object[] {status, companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindStatus = false;

			if (status.isEmpty()) {
				query.append(_FINDER_COLUMN_STATUS_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_STATUS_STATUS_2);
			}

			query.append(_FINDER_COLUMN_STATUS_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_STATUS_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_STATUS_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStatus) {
					qPos.add(status);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATUS_STATUS_2 =
		"customer.status LIKE ? AND ";

	private static final String _FINDER_COLUMN_STATUS_STATUS_3 =
		"(customer.status IS NULL OR customer.status LIKE '') AND ";

	private static final String _FINDER_COLUMN_STATUS_COMPANYID_2 =
		"customer.companyId = ? AND ";

	private static final String _FINDER_COLUMN_STATUS_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ?";

	private static final String _FINDER_COLUMN_STATUS_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '')";

	private FinderPath _finderPathWithPaginationFindByVcId;
	private FinderPath _finderPathWithPaginationCountByVcId;

	/**
	 * Returns all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName) {

		return findByVcId(
			vcId, companyId, agentScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start,
		int end) {

		return findByVcId(vcId, companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start, int end,
		OrderByComparator<Customer> orderByComparator) {

		return findByVcId(
			vcId, companyId, agentScreenName, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByVcId(
		String vcId, long companyId, String agentScreenName, int start, int end,
		OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		vcId = Objects.toString(vcId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByVcId;
		finderArgs = new Object[] {
			vcId, companyId, agentScreenName, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getVcId(), vcId, '_', '%', '\\', true) ||
						(companyId != customer.getCompanyId()) ||
						!agentScreenName.equals(
							customer.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_VCID_2);
			}

			query.append(_FINDER_COLUMN_VCID_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_VCID_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByVcId_First(
			String vcId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByVcId_First(
			vcId, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vcId=");
		msg.append(vcId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByVcId_First(
		String vcId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByVcId(
			vcId, companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByVcId_Last(
			String vcId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByVcId_Last(
			vcId, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vcId=");
		msg.append(vcId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByVcId_Last(
		String vcId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByVcId(vcId, companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByVcId(
			vcId, companyId, agentScreenName, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByVcId_PrevAndNext(
			String customerId, String vcId, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		vcId = Objects.toString(vcId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByVcId_PrevAndNext(
				session, customer, vcId, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getByVcId_PrevAndNext(
				session, customer, vcId, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByVcId_PrevAndNext(
		Session session, Customer customer, String vcId, long companyId,
		String agentScreenName, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindVcId = false;

		if (vcId.isEmpty()) {
			query.append(_FINDER_COLUMN_VCID_VCID_3);
		}
		else {
			bindVcId = true;

			query.append(_FINDER_COLUMN_VCID_VCID_2);
		}

		query.append(_FINDER_COLUMN_VCID_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_VCID_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_VCID_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindVcId) {
			qPos.add(vcId);
		}

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByVcId(
		String vcId, long companyId, String agentScreenName) {

		for (Customer customer :
				findByVcId(
					vcId, companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where vcId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	@Override
	public int countByVcId(
		String vcId, long companyId, String agentScreenName) {

		vcId = Objects.toString(vcId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByVcId;

		Object[] finderArgs = new Object[] {vcId, companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_VCID_2);
			}

			query.append(_FINDER_COLUMN_VCID_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_VCID_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VCID_VCID_2 =
		"customer.vcId LIKE ? AND ";

	private static final String _FINDER_COLUMN_VCID_VCID_3 =
		"(customer.vcId IS NULL OR customer.vcId LIKE '') AND ";

	private static final String _FINDER_COLUMN_VCID_COMPANYID_2 =
		"customer.companyId = ? AND ";

	private static final String _FINDER_COLUMN_VCID_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ?";

	private static final String _FINDER_COLUMN_VCID_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '')";

	private FinderPath _finderPathWithPaginationFindByStbNo;
	private FinderPath _finderPathWithPaginationCountByStbNo;

	/**
	 * Returns all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName) {

		return findByStbNo(
			stbNo, companyId, agentScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end) {

		return findByStbNo(stbNo, companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return findByStbNo(
			stbNo, companyId, agentScreenName, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByStbNo(
		String stbNo, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		stbNo = Objects.toString(stbNo, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByStbNo;
		finderArgs = new Object[] {
			stbNo, companyId, agentScreenName, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getStbNo(), stbNo, '_', '%', '\\', true) ||
						(companyId != customer.getCompanyId()) ||
						!agentScreenName.equals(
							customer.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STBNO_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STBNO_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_STBNO_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByStbNo_First(
			String stbNo, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByStbNo_First(
			stbNo, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("stbNo=");
		msg.append(stbNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByStbNo_First(
		String stbNo, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByStbNo(
			stbNo, companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByStbNo_Last(
			String stbNo, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByStbNo_Last(
			stbNo, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("stbNo=");
		msg.append(stbNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByStbNo_Last(
		String stbNo, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByStbNo(stbNo, companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByStbNo(
			stbNo, companyId, agentScreenName, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByStbNo_PrevAndNext(
			String customerId, String stbNo, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		stbNo = Objects.toString(stbNo, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByStbNo_PrevAndNext(
				session, customer, stbNo, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getByStbNo_PrevAndNext(
				session, customer, stbNo, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByStbNo_PrevAndNext(
		Session session, Customer customer, String stbNo, long companyId,
		String agentScreenName, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindStbNo = false;

		if (stbNo.isEmpty()) {
			query.append(_FINDER_COLUMN_STBNO_STBNO_3);
		}
		else {
			bindStbNo = true;

			query.append(_FINDER_COLUMN_STBNO_STBNO_2);
		}

		query.append(_FINDER_COLUMN_STBNO_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_STBNO_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_STBNO_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindStbNo) {
			qPos.add(stbNo);
		}

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByStbNo(
		String stbNo, long companyId, String agentScreenName) {

		for (Customer customer :
				findByStbNo(
					stbNo, companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where stbNo LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	@Override
	public int countByStbNo(
		String stbNo, long companyId, String agentScreenName) {

		stbNo = Objects.toString(stbNo, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByStbNo;

		Object[] finderArgs = new Object[] {stbNo, companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STBNO_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STBNO_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_STBNO_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STBNO_STBNO_2 =
		"customer.stbNo LIKE ? AND ";

	private static final String _FINDER_COLUMN_STBNO_STBNO_3 =
		"(customer.stbNo IS NULL OR customer.stbNo LIKE '') AND ";

	private static final String _FINDER_COLUMN_STBNO_COMPANYID_2 =
		"customer.companyId = ? AND ";

	private static final String _FINDER_COLUMN_STBNO_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ?";

	private static final String _FINDER_COLUMN_STBNO_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '')";

	private FinderPath _finderPathWithPaginationFindByMacId;
	private FinderPath _finderPathWithPaginationCountByMacId;

	/**
	 * Returns all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching customers
	 */
	@Override
	public List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName) {

		return findByMacId(
			macId, companyId, agentScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of matching customers
	 */
	@Override
	public List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end) {

		return findByMacId(macId, companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator) {

		return findByMacId(
			macId, companyId, agentScreenName, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching customers
	 */
	@Override
	public List<Customer> findByMacId(
		String macId, long companyId, String agentScreenName, int start,
		int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		macId = Objects.toString(macId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByMacId;
		finderArgs = new Object[] {
			macId, companyId, agentScreenName, start, end, orderByComparator
		};

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Customer customer : list) {
					if (!StringUtil.wildcardMatches(
							customer.getMacId(), macId, '_', '%', '\\', true) ||
						(companyId != customer.getCompanyId()) ||
						!agentScreenName.equals(
							customer.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CUSTOMER_WHERE);

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_MACID_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_MACID_MACID_2);
			}

			query.append(_FINDER_COLUMN_MACID_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_MACID_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_MACID_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CustomerModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMacId) {
					qPos.add(macId);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByMacId_First(
			String macId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByMacId_First(
			macId, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("macId=");
		msg.append(macId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the first customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByMacId_First(
		String macId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		List<Customer> list = findByMacId(
			macId, companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer
	 * @throws NoSuchCustomerException if a matching customer could not be found
	 */
	@Override
	public Customer findByMacId_Last(
			String macId, long companyId, String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		Customer customer = fetchByMacId_Last(
			macId, companyId, agentScreenName, orderByComparator);

		if (customer != null) {
			return customer;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("macId=");
		msg.append(macId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchCustomerException(msg.toString());
	}

	/**
	 * Returns the last customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching customer, or <code>null</code> if a matching customer could not be found
	 */
	@Override
	public Customer fetchByMacId_Last(
		String macId, long companyId, String agentScreenName,
		OrderByComparator<Customer> orderByComparator) {

		int count = countByMacId(macId, companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<Customer> list = findByMacId(
			macId, companyId, agentScreenName, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the customers before and after the current customer in the ordered set where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param customerId the primary key of the current customer
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer[] findByMacId_PrevAndNext(
			String customerId, String macId, long companyId,
			String agentScreenName,
			OrderByComparator<Customer> orderByComparator)
		throws NoSuchCustomerException {

		macId = Objects.toString(macId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		Customer customer = findByPrimaryKey(customerId);

		Session session = null;

		try {
			session = openSession();

			Customer[] array = new CustomerImpl[3];

			array[0] = getByMacId_PrevAndNext(
				session, customer, macId, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = customer;

			array[2] = getByMacId_PrevAndNext(
				session, customer, macId, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Customer getByMacId_PrevAndNext(
		Session session, Customer customer, String macId, long companyId,
		String agentScreenName, OrderByComparator<Customer> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CUSTOMER_WHERE);

		boolean bindMacId = false;

		if (macId.isEmpty()) {
			query.append(_FINDER_COLUMN_MACID_MACID_3);
		}
		else {
			bindMacId = true;

			query.append(_FINDER_COLUMN_MACID_MACID_2);
		}

		query.append(_FINDER_COLUMN_MACID_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_MACID_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_MACID_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CustomerModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMacId) {
			qPos.add(macId);
		}

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(customer)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Customer> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByMacId(
		String macId, long companyId, String agentScreenName) {

		for (Customer customer :
				findByMacId(
					macId, companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(customer);
		}
	}

	/**
	 * Returns the number of customers where macId LIKE &#63; and companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param macId the mac ID
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching customers
	 */
	@Override
	public int countByMacId(
		String macId, long companyId, String agentScreenName) {

		macId = Objects.toString(macId, "");
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByMacId;

		Object[] finderArgs = new Object[] {macId, companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CUSTOMER_WHERE);

			boolean bindMacId = false;

			if (macId.isEmpty()) {
				query.append(_FINDER_COLUMN_MACID_MACID_3);
			}
			else {
				bindMacId = true;

				query.append(_FINDER_COLUMN_MACID_MACID_2);
			}

			query.append(_FINDER_COLUMN_MACID_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_MACID_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_MACID_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMacId) {
					qPos.add(macId);
				}

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MACID_MACID_2 =
		"customer.macId LIKE ? AND ";

	private static final String _FINDER_COLUMN_MACID_MACID_3 =
		"(customer.macId IS NULL OR customer.macId LIKE '') AND ";

	private static final String _FINDER_COLUMN_MACID_COMPANYID_2 =
		"customer.companyId = ? AND ";

	private static final String _FINDER_COLUMN_MACID_AGENTSCREENNAME_2 =
		"customer.agentScreenName = ?";

	private static final String _FINDER_COLUMN_MACID_AGENTSCREENNAME_3 =
		"(customer.agentScreenName IS NULL OR customer.agentScreenName = '')";

	public CustomerPersistenceImpl() {
		setModelClass(Customer.class);

		setModelImplClass(CustomerImpl.class);
		setModelPKClass(String.class);

		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("primary", "primary_");

		setDBColumnNames(dbColumnNames);
	}

	/**
	 * Caches the customer in the entity cache if it is enabled.
	 *
	 * @param customer the customer
	 */
	@Override
	public void cacheResult(Customer customer) {
		entityCache.putResult(
			entityCacheEnabled, CustomerImpl.class, customer.getPrimaryKey(),
			customer);

		finderCache.putResult(
			_finderPathFetchByCustomerId,
			new Object[] {customer.getCustomerId(), customer.getCompanyId()},
			customer);

		finderCache.putResult(
			_finderPathFetchByAN_VCID_ASN,
			new Object[] {
				customer.getAccountNo(), customer.getVcId(),
				customer.getAgentScreenName(), customer.getCompanyId()
			},
			customer);

		finderCache.putResult(
			_finderPathFetchByAN_STBNO_ASN,
			new Object[] {
				customer.getAccountNo(), customer.getStbNo(),
				customer.getAgentScreenName(), customer.getCompanyId()
			},
			customer);

		finderCache.putResult(
			_finderPathFetchByAN_MACID_ASN,
			new Object[] {
				customer.getAccountNo(), customer.getMacId(),
				customer.getAgentScreenName(), customer.getCompanyId()
			},
			customer);

		finderCache.putResult(
			_finderPathFetchByAccountNo,
			new Object[] {customer.getAccountNo(), customer.getCompanyId()},
			customer);

		finderCache.putResult(
			_finderPathFetchByVcId_C,
			new Object[] {customer.getVcId(), customer.getCompanyId()},
			customer);

		finderCache.putResult(
			_finderPathFetchByStbNo_C,
			new Object[] {customer.getStbNo(), customer.getCompanyId()},
			customer);

		finderCache.putResult(
			_finderPathFetchByMacId_C,
			new Object[] {customer.getMacId(), customer.getCompanyId()},
			customer);

		finderCache.putResult(
			_finderPathFetchByAN_SCN,
			new Object[] {
				customer.getAccountNo(), customer.getScreenName(),
				customer.getCompanyId()
			},
			customer);

		customer.resetOriginalValues();
	}

	/**
	 * Caches the customers in the entity cache if it is enabled.
	 *
	 * @param customers the customers
	 */
	@Override
	public void cacheResult(List<Customer> customers) {
		for (Customer customer : customers) {
			if (entityCache.getResult(
					entityCacheEnabled, CustomerImpl.class,
					customer.getPrimaryKey()) == null) {

				cacheResult(customer);
			}
			else {
				customer.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all customers.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(CustomerImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the customer.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Customer customer) {
		entityCache.removeResult(
			entityCacheEnabled, CustomerImpl.class, customer.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache((CustomerModelImpl)customer, true);
	}

	@Override
	public void clearCache(List<Customer> customers) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Customer customer : customers) {
			entityCache.removeResult(
				entityCacheEnabled, CustomerImpl.class,
				customer.getPrimaryKey());

			clearUniqueFindersCache((CustomerModelImpl)customer, true);
		}
	}

	protected void cacheUniqueFindersCache(
		CustomerModelImpl customerModelImpl) {

		Object[] args = new Object[] {
			customerModelImpl.getCustomerId(), customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByCustomerId, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByCustomerId, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getAccountNo(), customerModelImpl.getVcId(),
			customerModelImpl.getAgentScreenName(),
			customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAN_VCID_ASN, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAN_VCID_ASN, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getAccountNo(), customerModelImpl.getStbNo(),
			customerModelImpl.getAgentScreenName(),
			customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAN_STBNO_ASN, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAN_STBNO_ASN, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getAccountNo(), customerModelImpl.getMacId(),
			customerModelImpl.getAgentScreenName(),
			customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAN_MACID_ASN, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAN_MACID_ASN, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getAccountNo(), customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAccountNo, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAccountNo, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getVcId(), customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByVcId_C, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByVcId_C, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getStbNo(), customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByStbNo_C, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByStbNo_C, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getMacId(), customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByMacId_C, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByMacId_C, args, customerModelImpl, false);

		args = new Object[] {
			customerModelImpl.getAccountNo(), customerModelImpl.getScreenName(),
			customerModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAN_SCN, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAN_SCN, args, customerModelImpl, false);
	}

	protected void clearUniqueFindersCache(
		CustomerModelImpl customerModelImpl, boolean clearCurrent) {

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getCustomerId(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCustomerId, args);
			finderCache.removeResult(_finderPathFetchByCustomerId, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByCustomerId.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalCustomerId(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCustomerId, args);
			finderCache.removeResult(_finderPathFetchByCustomerId, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getAccountNo(), customerModelImpl.getVcId(),
				customerModelImpl.getAgentScreenName(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_VCID_ASN, args);
			finderCache.removeResult(_finderPathFetchByAN_VCID_ASN, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByAN_VCID_ASN.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalAccountNo(),
				customerModelImpl.getOriginalVcId(),
				customerModelImpl.getOriginalAgentScreenName(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_VCID_ASN, args);
			finderCache.removeResult(_finderPathFetchByAN_VCID_ASN, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getAccountNo(), customerModelImpl.getStbNo(),
				customerModelImpl.getAgentScreenName(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_STBNO_ASN, args);
			finderCache.removeResult(_finderPathFetchByAN_STBNO_ASN, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByAN_STBNO_ASN.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalAccountNo(),
				customerModelImpl.getOriginalStbNo(),
				customerModelImpl.getOriginalAgentScreenName(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_STBNO_ASN, args);
			finderCache.removeResult(_finderPathFetchByAN_STBNO_ASN, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getAccountNo(), customerModelImpl.getMacId(),
				customerModelImpl.getAgentScreenName(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_MACID_ASN, args);
			finderCache.removeResult(_finderPathFetchByAN_MACID_ASN, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByAN_MACID_ASN.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalAccountNo(),
				customerModelImpl.getOriginalMacId(),
				customerModelImpl.getOriginalAgentScreenName(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_MACID_ASN, args);
			finderCache.removeResult(_finderPathFetchByAN_MACID_ASN, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getAccountNo(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAccountNo, args);
			finderCache.removeResult(_finderPathFetchByAccountNo, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByAccountNo.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalAccountNo(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAccountNo, args);
			finderCache.removeResult(_finderPathFetchByAccountNo, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getVcId(), customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByVcId_C, args);
			finderCache.removeResult(_finderPathFetchByVcId_C, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByVcId_C.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalVcId(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByVcId_C, args);
			finderCache.removeResult(_finderPathFetchByVcId_C, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getStbNo(), customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByStbNo_C, args);
			finderCache.removeResult(_finderPathFetchByStbNo_C, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByStbNo_C.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalStbNo(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByStbNo_C, args);
			finderCache.removeResult(_finderPathFetchByStbNo_C, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getMacId(), customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMacId_C, args);
			finderCache.removeResult(_finderPathFetchByMacId_C, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByMacId_C.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalMacId(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMacId_C, args);
			finderCache.removeResult(_finderPathFetchByMacId_C, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				customerModelImpl.getAccountNo(),
				customerModelImpl.getScreenName(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_SCN, args);
			finderCache.removeResult(_finderPathFetchByAN_SCN, args);
		}

		if ((customerModelImpl.getColumnBitmask() &
			 _finderPathFetchByAN_SCN.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				customerModelImpl.getOriginalAccountNo(),
				customerModelImpl.getOriginalScreenName(),
				customerModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_SCN, args);
			finderCache.removeResult(_finderPathFetchByAN_SCN, args);
		}
	}

	/**
	 * Creates a new customer with the primary key. Does not add the customer to the database.
	 *
	 * @param customerId the primary key for the new customer
	 * @return the new customer
	 */
	@Override
	public Customer create(String customerId) {
		Customer customer = new CustomerImpl();

		customer.setNew(true);
		customer.setPrimaryKey(customerId);

		customer.setCompanyId(companyProvider.getCompanyId());

		return customer;
	}

	/**
	 * Removes the customer with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer that was removed
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer remove(String customerId) throws NoSuchCustomerException {
		return remove((Serializable)customerId);
	}

	/**
	 * Removes the customer with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the customer
	 * @return the customer that was removed
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer remove(Serializable primaryKey)
		throws NoSuchCustomerException {

		Session session = null;

		try {
			session = openSession();

			Customer customer = (Customer)session.get(
				CustomerImpl.class, primaryKey);

			if (customer == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchCustomerException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(customer);
		}
		catch (NoSuchCustomerException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Customer removeImpl(Customer customer) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(customer)) {
				customer = (Customer)session.get(
					CustomerImpl.class, customer.getPrimaryKeyObj());
			}

			if (customer != null) {
				session.delete(customer);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (customer != null) {
			clearCache(customer);
		}

		return customer;
	}

	@Override
	public Customer updateImpl(Customer customer) {
		boolean isNew = customer.isNew();

		if (!(customer instanceof CustomerModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(customer.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(customer);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in customer proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom Customer implementation " +
					customer.getClass());
		}

		CustomerModelImpl customerModelImpl = (CustomerModelImpl)customer;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (customer.getCreateDate() == null)) {
			if (serviceContext == null) {
				customer.setCreateDate(now);
			}
			else {
				customer.setCreateDate(serviceContext.getCreateDate(now));
			}
		}

		if (!customerModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				customer.setModifiedDate(now);
			}
			else {
				customer.setModifiedDate(serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (customer.isNew()) {
				session.save(customer);

				customer.setNew(false);
			}
			else {
				customer = (Customer)session.merge(customer);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {
				customerModelImpl.getScreenName(),
				customerModelImpl.isPrimary(), customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountBySCN_P, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindBySCN_P, args);

			args = new Object[] {
				customerModelImpl.getScreenName(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByScreenName, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByScreenName, args);

			args = new Object[] {customerModelImpl.getCompanyId()};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			args = new Object[] {
				customerModelImpl.getAgentScreenName(),
				customerModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAgentScreenName, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAgentScreenName, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((customerModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindBySCN_P.getColumnBitmask()) !=
					 0) {

				Object[] args = new Object[] {
					customerModelImpl.getOriginalScreenName(),
					customerModelImpl.getOriginalPrimary(),
					customerModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountBySCN_P, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindBySCN_P, args);

				args = new Object[] {
					customerModelImpl.getScreenName(),
					customerModelImpl.isPrimary(),
					customerModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountBySCN_P, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindBySCN_P, args);
			}

			if ((customerModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByScreenName.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					customerModelImpl.getOriginalScreenName(),
					customerModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByScreenName, args);

				args = new Object[] {
					customerModelImpl.getScreenName(),
					customerModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByScreenName, args);
			}

			if ((customerModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					customerModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {customerModelImpl.getCompanyId()};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}

			if ((customerModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAgentScreenName.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					customerModelImpl.getOriginalAgentScreenName(),
					customerModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByAgentScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAgentScreenName, args);

				args = new Object[] {
					customerModelImpl.getAgentScreenName(),
					customerModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByAgentScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAgentScreenName, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, CustomerImpl.class, customer.getPrimaryKey(),
			customer, false);

		clearUniqueFindersCache(customerModelImpl, false);
		cacheUniqueFindersCache(customerModelImpl);

		customer.resetOriginalValues();

		return customer;
	}

	/**
	 * Returns the customer with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the customer
	 * @return the customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer findByPrimaryKey(Serializable primaryKey)
		throws NoSuchCustomerException {

		Customer customer = fetchByPrimaryKey(primaryKey);

		if (customer == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchCustomerException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return customer;
	}

	/**
	 * Returns the customer with the primary key or throws a <code>NoSuchCustomerException</code> if it could not be found.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer
	 * @throws NoSuchCustomerException if a customer with the primary key could not be found
	 */
	@Override
	public Customer findByPrimaryKey(String customerId)
		throws NoSuchCustomerException {

		return findByPrimaryKey((Serializable)customerId);
	}

	/**
	 * Returns the customer with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param customerId the primary key of the customer
	 * @return the customer, or <code>null</code> if a customer with the primary key could not be found
	 */
	@Override
	public Customer fetchByPrimaryKey(String customerId) {
		return fetchByPrimaryKey((Serializable)customerId);
	}

	/**
	 * Returns all the customers.
	 *
	 * @return the customers
	 */
	@Override
	public List<Customer> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @return the range of customers
	 */
	@Override
	public List<Customer> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of customers
	 */
	@Override
	public List<Customer> findAll(
		int start, int end, OrderByComparator<Customer> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CustomerModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of customers
	 * @param end the upper bound of the range of customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of customers
	 */
	@Override
	public List<Customer> findAll(
		int start, int end, OrderByComparator<Customer> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<Customer> list = null;

		if (retrieveFromCache) {
			list = (List<Customer>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_CUSTOMER);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_CUSTOMER;

				if (pagination) {
					sql = sql.concat(CustomerModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Customer>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the customers from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (Customer customer : findAll()) {
			remove(customer);
		}
	}

	/**
	 * Returns the number of customers.
	 *
	 * @return the number of customers
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_CUSTOMER);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "customerId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_CUSTOMER;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return CustomerModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the customer persistence.
	 */
	@Activate
	public void activate() {
		CustomerModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		CustomerModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathFetchByCustomerId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByCustomerId",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.CUSTOMERID_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByCustomerId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCustomerId",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByAN_VCID_ASN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAN_VCID_ASN",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			CustomerModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CustomerModelImpl.VCID_COLUMN_BITMASK |
			CustomerModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAN_VCID_ASN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_VCID_ASN",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathFetchByAN_STBNO_ASN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAN_STBNO_ASN",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			CustomerModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CustomerModelImpl.STBNO_COLUMN_BITMASK |
			CustomerModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAN_STBNO_ASN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_STBNO_ASN",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathFetchByAN_MACID_ASN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAN_MACID_ASN",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			CustomerModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CustomerModelImpl.MACID_COLUMN_BITMASK |
			CustomerModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAN_MACID_ASN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_MACID_ASN",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathFetchByAccountNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAccountNo",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAccountNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAccountNo",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByVcId_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByVcId_C",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.VCID_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByVcId_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByVcId_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByStbNo_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByStbNo_C",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.STBNO_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByStbNo_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByStbNo_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByMacId_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByMacId_C",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.MACID_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByMacId_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMacId_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByAN_SCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAN_SCN",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			CustomerModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CustomerModelImpl.SCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAN_SCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_SCN",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindBySCN_P = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBySCN_P",
			new String[] {
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindBySCN_P = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBySCN_P",
			new String[] {
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			},
			CustomerModelImpl.SCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.PRIMARY_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK |
			CustomerModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountBySCN_P = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBySCN_P",
			new String[] {
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByScreenName",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByScreenName",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.SCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK |
			CustomerModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByScreenName",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK |
			CustomerModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});

		_finderPathWithPaginationFindByAN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByAN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByAN_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindBySN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBySN_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountBySN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countBySN_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByS_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByS_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByS_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByS_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByVC_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByVC_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByVC_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByVC_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindBySTB_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBySTB_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountBySTB_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countBySTB_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByMAC_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMAC_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByMAC_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByMAC_C",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByAgentScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAgentScreenName",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAgentScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAgentScreenName",
			new String[] {String.class.getName(), Long.class.getName()},
			CustomerModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			CustomerModelImpl.COMPANYID_COLUMN_BITMASK |
			CustomerModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAgentScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAgentScreenName",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByScreenNameSearch = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByScreenNameSearch",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByScreenNameSearch = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByScreenNameSearch",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName()
			});

		_finderPathWithPaginationFindByStatus = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByStatus",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByStatus = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByStatus",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName()
			});

		_finderPathWithPaginationFindByVcId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByVcId",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByVcId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByVcId",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName()
			});

		_finderPathWithPaginationFindByStbNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByStbNo",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByStbNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByStbNo",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName()
			});

		_finderPathWithPaginationFindByMacId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CustomerImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMacId",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByMacId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByMacId",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName()
			});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(CustomerImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.model.Customer"),
			true);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_CUSTOMER =
		"SELECT customer FROM Customer customer";

	private static final String _SQL_SELECT_CUSTOMER_WHERE =
		"SELECT customer FROM Customer customer WHERE ";

	private static final String _SQL_COUNT_CUSTOMER =
		"SELECT COUNT(customer) FROM Customer customer";

	private static final String _SQL_COUNT_CUSTOMER_WHERE =
		"SELECT COUNT(customer) FROM Customer customer WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "customer.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No Customer exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No Customer exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		CustomerPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"primary"});

}