/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model.impl;

import com.jio.account.model.Address;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The cache model class for representing Address in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class AddressCacheModel implements CacheModel<Address>, Externalizable {

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AddressCacheModel)) {
			return false;
		}

		AddressCacheModel addressCacheModel = (AddressCacheModel)obj;

		if (addressId.equals(addressCacheModel.addressId)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, addressId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(41);

		sb.append("{addressId=");
		sb.append(addressId);
		sb.append(", customerId=");
		sb.append(customerId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createBy=");
		sb.append(createBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", screenName=");
		sb.append(screenName);
		sb.append(", countryCode=");
		sb.append(countryCode);
		sb.append(", regionCode=");
		sb.append(regionCode);
		sb.append(", stateCode=");
		sb.append(stateCode);
		sb.append(", cityCode=");
		sb.append(cityCode);
		sb.append(", areaCode=");
		sb.append(areaCode);
		sb.append(", pincode=");
		sb.append(pincode);
		sb.append(", street=");
		sb.append(street);
		sb.append(", location=");
		sb.append(location);
		sb.append(", flatNo=");
		sb.append(flatNo);
		sb.append(", building=");
		sb.append(building);
		sb.append(", address=");
		sb.append(address);
		sb.append(", type=");
		sb.append(type);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Address toEntityModel() {
		AddressImpl addressImpl = new AddressImpl();

		if (addressId == null) {
			addressImpl.setAddressId("");
		}
		else {
			addressImpl.setAddressId(addressId);
		}

		if (customerId == null) {
			addressImpl.setCustomerId("");
		}
		else {
			addressImpl.setCustomerId(customerId);
		}

		addressImpl.setGroupId(groupId);
		addressImpl.setCompanyId(companyId);

		if (createBy == null) {
			addressImpl.setCreateBy("");
		}
		else {
			addressImpl.setCreateBy(createBy);
		}

		if (createDate == Long.MIN_VALUE) {
			addressImpl.setCreateDate(null);
		}
		else {
			addressImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			addressImpl.setModifiedDate(null);
		}
		else {
			addressImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (screenName == null) {
			addressImpl.setScreenName("");
		}
		else {
			addressImpl.setScreenName(screenName);
		}

		if (countryCode == null) {
			addressImpl.setCountryCode("");
		}
		else {
			addressImpl.setCountryCode(countryCode);
		}

		if (regionCode == null) {
			addressImpl.setRegionCode("");
		}
		else {
			addressImpl.setRegionCode(regionCode);
		}

		if (stateCode == null) {
			addressImpl.setStateCode("");
		}
		else {
			addressImpl.setStateCode(stateCode);
		}

		if (cityCode == null) {
			addressImpl.setCityCode("");
		}
		else {
			addressImpl.setCityCode(cityCode);
		}

		if (areaCode == null) {
			addressImpl.setAreaCode("");
		}
		else {
			addressImpl.setAreaCode(areaCode);
		}

		if (pincode == null) {
			addressImpl.setPincode("");
		}
		else {
			addressImpl.setPincode(pincode);
		}

		if (street == null) {
			addressImpl.setStreet("");
		}
		else {
			addressImpl.setStreet(street);
		}

		if (location == null) {
			addressImpl.setLocation("");
		}
		else {
			addressImpl.setLocation(location);
		}

		if (flatNo == null) {
			addressImpl.setFlatNo("");
		}
		else {
			addressImpl.setFlatNo(flatNo);
		}

		if (building == null) {
			addressImpl.setBuilding("");
		}
		else {
			addressImpl.setBuilding(building);
		}

		if (address == null) {
			addressImpl.setAddress("");
		}
		else {
			addressImpl.setAddress(address);
		}

		if (type == null) {
			addressImpl.setType("");
		}
		else {
			addressImpl.setType(type);
		}

		addressImpl.resetOriginalValues();

		return addressImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		addressId = objectInput.readUTF();
		customerId = objectInput.readUTF();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();
		createBy = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		screenName = objectInput.readUTF();
		countryCode = objectInput.readUTF();
		regionCode = objectInput.readUTF();
		stateCode = objectInput.readUTF();
		cityCode = objectInput.readUTF();
		areaCode = objectInput.readUTF();
		pincode = objectInput.readUTF();
		street = objectInput.readUTF();
		location = objectInput.readUTF();
		flatNo = objectInput.readUTF();
		building = objectInput.readUTF();
		address = objectInput.readUTF();
		type = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (addressId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(addressId);
		}

		if (customerId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerId);
		}

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		if (createBy == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(createBy);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (screenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(screenName);
		}

		if (countryCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(countryCode);
		}

		if (regionCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(regionCode);
		}

		if (stateCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(stateCode);
		}

		if (cityCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(cityCode);
		}

		if (areaCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(areaCode);
		}

		if (pincode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(pincode);
		}

		if (street == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(street);
		}

		if (location == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(location);
		}

		if (flatNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(flatNo);
		}

		if (building == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(building);
		}

		if (address == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(address);
		}

		if (type == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(type);
		}
	}

	public String addressId;
	public String customerId;
	public long groupId;
	public long companyId;
	public String createBy;
	public long createDate;
	public long modifiedDate;
	public String screenName;
	public String countryCode;
	public String regionCode;
	public String stateCode;
	public String cityCode;
	public String areaCode;
	public String pincode;
	public String street;
	public String location;
	public String flatNo;
	public String building;
	public String address;
	public String type;

}