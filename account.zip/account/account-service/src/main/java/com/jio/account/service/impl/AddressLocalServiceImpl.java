/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.impl;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.model.Address;
import com.jio.account.service.base.AddressLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.portal.aop.AopService;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the address local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.service.AddressLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AddressLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.model.Address", service = AopService.class)
public class AddressLocalServiceImpl extends AddressLocalServiceBaseImpl {

	@Override
	public Address addAddress(Address address) {
		address.setCreateDate(new Date());
		address.setModifiedDate(new Date());
		address = super.addAddress(address);
		AuditUtil.audit(address, AuditConstants.SAVE);
		return address;
	}

	@Override
	public Address updateAddress(Address address) {
		address.setModifiedDate(new Date());
		address = super.updateAddress(address);
		AuditUtil.audit(address, AuditConstants.UPDATE);
		return address;
	}

	@Override
	public Address deleteAddress(Address address) {
		address.setModifiedDate(new Date());
		address = super.deleteAddress(address);
		AuditUtil.audit(address, AuditConstants.UPDATE);
		return address;
	}

	public Address getAddress(String customerId, long companyId) throws NoSuchAddressException {
		return this.addressPersistence.findByCustomerId(customerId, companyId);
	}

	public Address getAddress(long companyId, String screenName) throws NoSuchAddressException {
		return this.addressPersistence.findByScreenName(companyId, screenName);
	}

	public List<Address> getAddresses(String screenName, long companyId) {
		return this.addressPersistence.findBySN(screenName, companyId);
	}

}