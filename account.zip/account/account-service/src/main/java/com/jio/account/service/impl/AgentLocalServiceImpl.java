/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.impl;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.base.AgentLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the agent local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.service.AgentLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AgentLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.model.Agent", service = AopService.class)
public class AgentLocalServiceImpl extends AgentLocalServiceBaseImpl {

	@Override
	public Agent addAgent(Agent agent) {
		agent.setCreateDate(new Date());
		agent.setModifiedDate(new Date());
		agent = super.addAgent(agent);
		AuditUtil.audit(agent, AuditConstants.SAVE);
		return agent;
	}

	@Override
	public Agent updateAgent(Agent agent) {
		agent.setModifiedDate(new Date());
		agent = super.updateAgent(agent);
		AuditUtil.audit(agent, AuditConstants.UPDATE);
		return agent;
	}

	@Override
	public Agent deleteAgent(Agent agent) {
		agent = super.deleteAgent(agent);
		AuditUtil.audit(agent, AuditConstants.DELETE);
		return agent;
	}

	@Override
	public Agent deleteAgent(String agentId) throws PortalException {
		return deleteAgent(getAgent(agentId));
	}

	public Agent getParentAgent(long companyId, String screenName) throws NoSuchAgentException {
		Agent agent = agentLocalService.getAgent(companyId, screenName);
		if (!agent.isPrimary()) {
			agent = agentLocalService.getAgent(companyId, agent.getParentCode());
		}
		return agent;
	}
	
	public Agent getAgentByLegacyCode(long companyId, String legacyCode) throws NoSuchAgentException {
		return agentPersistence.findByLegacyCode(companyId, legacyCode);
	}
	
	public Agent getAgentByClientCode(long companyId, String clientCode) throws NoSuchAgentException {
		return agentPersistence.findByClientCode(companyId, clientCode);
	}

	public Agent getAgent(long companyId, String screenName) throws NoSuchAgentException {
		return agentPersistence.findByScreenName(companyId, screenName);
	}

	public Agent getAgent(long companyId, String screenName, String parentCode) throws NoSuchAgentException {
		return agentPersistence.findByScreenNameAndParentCode(companyId, screenName, parentCode);
	}

	public List<Agent> getAgents(long companyId, String parentCode, int start, int end) throws NoSuchAgentException {
		return agentPersistence.findByParentCode(parentCode, companyId, start, end);
	}

	public List<Agent> getAgents(long companyId, String parentCode) {
		return agentPersistence.findByParentCode(parentCode, companyId);
	}

	public int getAgentsCount(long companyId, String parentCode) {
		return agentPersistence.countByParentCode(parentCode, companyId);
	}

	public List<Agent> getAgents(long companyId, String parentCode, boolean isPrimary, int start, int end) {
		return agentPersistence.findByParentCodeAndIsPrimary(companyId, parentCode, isPrimary, start, end);
	}

	public List<Agent> getAgents(long companyId, String parentCode, boolean isPrimary) {
		return agentPersistence.findByParentCodeAndIsPrimary(companyId, parentCode, isPrimary);
	}

	public int getAgentsCount(long companyId, String parentCode, boolean isPrimary) {
		return agentPersistence.countByParentCodeAndIsPrimary(companyId, parentCode, isPrimary);
	}

	public List<Agent> getAgents(long companyId, boolean isPrimary, int start, int end) {
		return agentPersistence.findByPrimaryStatus(companyId, isPrimary, start, end);
	}

	public List<Agent> getAgents(long companyId, boolean isPrimary) {
		return agentPersistence.findByPrimaryStatus(companyId, isPrimary);
	}

	public int getAgentsCount(long companyId, boolean isPrimary) {
		return agentPersistence.countByPrimaryStatus(companyId, isPrimary);
	}

	public List<Agent> getAgents(long companyId, int start, int end) {
		return agentPersistence.findByCompanyId(companyId, start, end);
	}

	public List<Agent> getAgents(long companyId) {
		return agentPersistence.findByCompanyId(companyId);
	}

	public int getAgentsCount(long companyId) {
		return agentPersistence.countByCompanyId(companyId);
	}

}