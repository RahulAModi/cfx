/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.impl;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.base.CustomerLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.util.Validator;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * The implementation of the customer local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.service.CustomerLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CustomerLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.model.Customer", service = AopService.class)
public class CustomerLocalServiceImpl extends CustomerLocalServiceBaseImpl {

	@Override
	public Customer addCustomer(Customer customer) {
		customer.setCreateDate(new Date());
		customer.setModifiedDate(new Date());
		customer = super.addCustomer(customer);
		AuditUtil.audit(customer, AuditConstants.SAVE);
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		customer.setModifiedDate(new Date());
		customer = super.updateCustomer(customer);
		AuditUtil.audit(customer, AuditConstants.UPDATE);
		return customer;
	}

	@Override
	public Customer deleteCustomer(Customer customer) {
		customer.setModifiedDate(new Date());
		customer = super.deleteCustomer(customer);
		AuditUtil.audit(customer, AuditConstants.DELETE);
		return customer;
	}

	public Customer getCustomerByCustomerId(String customerId, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByCustomerId(customerId, companyId);
	}

	public Customer getCustomerByVcId(String accountNo, String vcId, String agentScreenName, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByAN_VCID_ASN(accountNo, vcId, agentScreenName, companyId);
	}

	public Customer getCustomerBySTBNo(String accountNo, String stbNo, String agentScreenName, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByAN_STBNO_ASN(accountNo, stbNo, agentScreenName, companyId);
	}

	public Customer getCustomerByMacId(String accountNo, String macId, String agentScreenName, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByAN_MACID_ASN(accountNo, macId, agentScreenName, companyId);
	}

	public Customer getCustomerByVcId(String vcId, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByVcId_C(vcId, companyId);
	}

	public Customer getCustomerBySTBNo(String stbNo, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByStbNo_C(stbNo, companyId);
	}

	public Customer getCustomerByMacId(String macId, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByMacId_C(macId, companyId);
	}

	@Override
	public Customer deleteCustomer(String customerId) throws PortalException {
		return deleteCustomer(getCustomer(customerId));
	}

	public Customer getCustomer(String accountNo, long companyId) throws NoSuchCustomerException {
		return this.customerPersistence.findByAccountNo(accountNo, companyId);
	}

	public Customer getCustomer(String accountNo, String screenName, long companyId) throws NoSuchCustomerException {
		if (Validator.isNotNull(screenName)) {
			return this.customerPersistence.findByAN_SCN(accountNo, screenName, companyId);
		} else {
			return getCustomer(accountNo, companyId);
		}
	}

	public Customer getCustomerByScreenName(String screenName, long companyId) throws NoSuchCustomerException {
		Customer customer = null;
		List<Customer> customers = getCustomers(screenName, true, companyId);
		if (!customers.isEmpty()) {
			customer = customers.get(0);
		} else {
			throw new NoSuchCustomerException(screenName);
		}
		return customer;
	}

	public List<Customer> getCustomers(String screenName, boolean primary, long companyId) {
		return this.customerPersistence.findBySCN_P(screenName, primary, companyId);
	}

	public List<Customer> getCustomers(String screenName, boolean primary, long companyId, int start, int end) {
		return this.customerPersistence.findBySCN_P(screenName, primary, companyId, start, end);
	}

	public int getCustomersCount(String screenName, boolean primary, long companyId) {
		return this.customerPersistence.countBySCN_P(screenName, primary, companyId);
	}

	public List<Customer> getCustomers(String screenName, long companyId) {
		return this.customerPersistence.findByScreenName(screenName, companyId);
	}

	public List<Customer> getCustomers(String screenName, long companyId, int start, int end) {
		return this.customerPersistence.findByScreenName(screenName, companyId, start, end);
	}

	public int getCustomersCount(String screenName, long companyId) {
		return this.customerPersistence.countByScreenName(screenName, companyId);
	}

	public List<Customer> getCustomerByScreenName(String screenName, long companyId, String agentScreenName, int start, int end) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {

			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.findByScreenNameSearch(StringPool.PERCENT.concat(screenName).concat(StringPool.PERCENT), companyId, agentScreenName, start, end);
			} else {
				return this.customerFinder.getCustomers(StringPool.PERCENT.concat(screenName).concat(StringPool.PERCENT), StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, agentScreenName, companyId, start, end);
			}
		} else {
			return this.customerPersistence.findBySN_C(StringPool.PERCENT.concat(screenName).concat(StringPool.PERCENT), companyId, start, end);
		}
	}

	public int customerCountByScreenName(String screenName, long companyId, String agentScreenName) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.countByScreenNameSearch(StringPool.PERCENT.concat(screenName).concat(StringPool.PERCENT), companyId, agentScreenName);
			} else {
				return this.customerFinder.countCustomers(StringPool.PERCENT.concat(screenName).concat(StringPool.PERCENT), StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, agentScreenName, companyId);
			}
		} else {
			return this.customerPersistence.countBySN_C(screenName, companyId);
		}
	}

	public List<Customer> getCustomerByStatus(String status, long companyId, String agentScreenName, int start, int end) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.findByStatus(StringPool.PERCENT.concat(status).concat(StringPool.PERCENT), companyId, agentScreenName, start, end);
			} else {
				return this.customerFinder.getCustomers(StringPool.BLANK, StringPool.PERCENT.concat(status).concat(StringPool.PERCENT), StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, agentScreenName, companyId, start, end);
			}
		} else {
			return this.customerPersistence.findByS_C(StringPool.PERCENT.concat(status).concat(StringPool.PERCENT), companyId, start, end);
		}
	}

	public int customerCountByStatus(String status, long companyId, String agentScreenName) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.countByStatus(StringPool.PERCENT.concat(status).concat(StringPool.PERCENT), companyId, agentScreenName);
			} else {
				return this.customerFinder.countCustomers(StringPool.BLANK, StringPool.PERCENT.concat(status).concat(StringPool.PERCENT), StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, agentScreenName, companyId);
			}
		} else {
			return this.customerPersistence.countByS_C(StringPool.PERCENT.concat(status).concat(StringPool.PERCENT), companyId);
		}
	}

	public List<Customer> getCustomerByVcId(String vcId, long companyId, String agentScreenName, int start, int end) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.findByVcId(StringPool.PERCENT.concat(vcId).concat(StringPool.PERCENT), companyId, agentScreenName, start, end);
			} else {
				return this.customerFinder.getCustomers(StringPool.BLANK, StringPool.BLANK, StringPool.PERCENT.concat(vcId).concat(StringPool.PERCENT), StringPool.BLANK, StringPool.BLANK, agentScreenName, companyId, start, end);
			}
		} else {
			return this.customerPersistence.findByVC_C(StringPool.PERCENT.concat(vcId).concat(StringPool.PERCENT), companyId, start, end);
		}
	}

	public int customerCountByVcId(String vcId, long companyId, String agentScreenName) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.countByVcId(StringPool.PERCENT.concat(vcId).concat(StringPool.PERCENT), companyId, agentScreenName);
			} else {
				return this.customerFinder.countCustomers(StringPool.BLANK, StringPool.BLANK, StringPool.PERCENT.concat(vcId).concat(StringPool.PERCENT), StringPool.BLANK, StringPool.BLANK, agentScreenName, companyId);
			}
		} else {
			return this.customerPersistence.countByVC_C(StringPool.PERCENT.concat(vcId).concat(StringPool.PERCENT), companyId);
		}
	}

	public List<Customer> getCustomerByStbNo(String stbNo, long companyId, String agentScreenName, int start, int end) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.findByStbNo(StringPool.PERCENT.concat(stbNo).concat(StringPool.PERCENT), companyId, agentScreenName, start, end);
			} else {
				return this.customerFinder.getCustomers(StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.PERCENT.concat(stbNo).concat(StringPool.PERCENT), StringPool.BLANK, agentScreenName, companyId, start, end);
			}
		} else {
			return this.customerPersistence.findBySTB_C(StringPool.PERCENT.concat(stbNo).concat(StringPool.PERCENT), companyId, start, end);
		}
	}

	public int customerCountByStbNo(String stbNo, long companyId, String agentScreenName) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.countByStbNo(StringPool.PERCENT.concat(stbNo).concat(StringPool.PERCENT), companyId, agentScreenName);
			} else {
				return this.customerFinder.countCustomers(StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.PERCENT.concat(stbNo).concat(StringPool.PERCENT), StringPool.BLANK, agentScreenName, companyId);
			}
		} else {
			return this.customerPersistence.countBySTB_C(StringPool.PERCENT.concat(stbNo).concat(StringPool.PERCENT), companyId);
		}
	}

	public List<Customer> getCustomerByMacId(String macId, long companyId, String agentScreenName, int start, int end) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.findByMacId(StringPool.PERCENT.concat(macId).concat(StringPool.PERCENT), companyId, agentScreenName, start, end);
			} else {
				return this.customerFinder.getCustomers(StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.PERCENT.concat(macId).concat(StringPool.PERCENT), agentScreenName, companyId, start, end);
			}
		} else {
			return this.customerPersistence.findByMAC_C(StringPool.PERCENT.concat(macId).concat(StringPool.PERCENT), companyId, start, end);
		}
	}

	public int customerCountByMacId(String macId, long companyId, String agentScreenName) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.countByMacId(StringPool.PERCENT.concat(macId).concat(StringPool.PERCENT), companyId, agentScreenName);
			} else {
				return this.customerFinder.countCustomers(StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.PERCENT.concat(macId).concat(StringPool.PERCENT), agentScreenName, companyId);
			}
		} else {
			return this.customerPersistence.countByMAC_C(StringPool.PERCENT.concat(macId).concat(StringPool.PERCENT), companyId);
		}
	}

	public List<Customer> getCustomerByLogInAgent(String agentScreenName, long companyId, int start, int end) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.findByAgentScreenName(agentScreenName, companyId, start, end);
			} else {
				return this.customerFinder.getCustomers(agentScreenName, companyId, start, end);
			}

		} else {
			return this.customerPersistence.findByCompanyId(companyId, start, end);
		}
	}

	public int customerCountByLogInAgent(String agentScreenName, long companyId) throws NoSuchAgentException {
		if (Validator.isNotNull(agentScreenName)) {

			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
			if (agent.isPrimary()) {
				return this.customerPersistence.countByAgentScreenName(agentScreenName, companyId);
			} else {
				return this.customerFinder.countCustomers(agentScreenName, companyId);
			}

		} else {
			return this.customerPersistence.countByCompanyId(companyId);
		}
	}

	public List<Customer> getCustomers(long companyId, int start, int end) {
		return this.customerPersistence.findByCompanyId(companyId, start, end);
	}

	public List<Customer> getCustomersByCompanyId(long companyId) {
		return this.customerPersistence.findByCompanyId(companyId);
	}

	public int getCustomersCount(long companyId) {
		return this.customerPersistence.countByCompanyId(companyId);
	}

	@Reference
	private AgentLocalService agentLocalService;

}