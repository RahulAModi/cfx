/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.impl;

import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.service.base.AgentCustomerMappingLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the agent customer mapping local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.service.AgentCustomerMappingLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see AgentCustomerMappingLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.model.AgentCustomerMapping", service = AopService.class)
public class AgentCustomerMappingLocalServiceImpl extends AgentCustomerMappingLocalServiceBaseImpl {

	private static final Log LOGGER = LogFactoryUtil.getLog(AgentCustomerMappingLocalServiceImpl.class);

	public AgentCustomerMapping saveOrUpdateAgentCustomerMapping(long companyId, long groupId, String screenName, String agentScreenName, String createBy) {
		AgentCustomerMapping agentCustomerMapping = null;
		if (Validator.isNotNull(screenName)) {
			try {
				agentCustomerMapping = agentCustomerMappingLocalService.findByCustomerScreenName(companyId, screenName);
			} catch (NoSuchAgentCustomerMappingException e) {
				LOGGER.error("NoSuchAgentCustomerMappingException :: " + e.toString());
			}
		}

		if (Validator.isNull(agentCustomerMapping)) {
			AgentCustomerMapping acm = agentCustomerMappingLocalService.createAgentCustomerMapping(String.valueOf(counterLocalService.increment(AgentCustomerMapping.class.getName())));
			acm.setCompanyId(companyId);
			acm.setGroupId(groupId);
			acm.setCustomerScreenName(screenName);
			acm.setAgentScreenName(agentScreenName);
			acm.setCreateBy(createBy);
			return agentCustomerMappingLocalService.addAgentCustomerMapping(acm);
		}

		return agentCustomerMapping;
	}

	@Override
	public AgentCustomerMapping addAgentCustomerMapping(AgentCustomerMapping agentCustomerMapping) {
		agentCustomerMapping.setCreateDate(new Date());
		agentCustomerMapping.setModifiedDate(agentCustomerMapping.getCreateDate());
		agentCustomerMapping = super.addAgentCustomerMapping(agentCustomerMapping);
		AuditUtil.audit(agentCustomerMapping, AuditConstants.SAVE);
		return agentCustomerMapping;
	}

	@Override
	public AgentCustomerMapping updateAgentCustomerMapping(AgentCustomerMapping agentCustomerMapping) {
		agentCustomerMapping.setModifiedDate(new Date());
		agentCustomerMapping = super.updateAgentCustomerMapping(agentCustomerMapping);
		AuditUtil.audit(agentCustomerMapping, AuditConstants.UPDATE);
		return agentCustomerMapping;
	}

	@Override
	public AgentCustomerMapping deleteAgentCustomerMapping(AgentCustomerMapping agentCustomerMapping) {
		agentCustomerMapping = super.deleteAgentCustomerMapping(agentCustomerMapping);
		AuditUtil.audit(agentCustomerMapping, AuditConstants.DELETE);
		return agentCustomerMapping;
	}

	@Override
	public AgentCustomerMapping deleteAgentCustomerMapping(String mappingId) throws PortalException {
		return deleteAgentCustomerMapping(getAgentCustomerMapping(mappingId));
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, int start, int end) {
		return this.agentCustomerMappingPersistence.findByCompanyId(companyId, start, end);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId) {
		return this.agentCustomerMappingPersistence.findByCompanyId(companyId);
	}

	public int getAgentCustomerMappingsCount(long companyId) {
		return this.agentCustomerMappingPersistence.countByCompanyId(companyId);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String agentScreenName, int start, int end) {
		return this.agentCustomerMappingPersistence.findByAgentScreenName(companyId, agentScreenName, start, end);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String agentScreenName) {
		return this.agentCustomerMappingPersistence.findByAgentScreenName(companyId, agentScreenName);
	}

	public int getAgentCustomerMappingsCount(long companyId, String agentScreenName) {
		return this.agentCustomerMappingPersistence.countByAgentScreenName(companyId, agentScreenName);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String[] agentScreenName, int start, int end) {
		return this.agentCustomerMappingPersistence.findByAgentScreenNames(companyId, agentScreenName, start, end);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String[] agentScreenName) {
		return this.agentCustomerMappingPersistence.findByAgentScreenNames(companyId, agentScreenName);
	}

	public int getAgentCustomerMappingsCount(long companyId, String[] agentScreenName) {
		return this.agentCustomerMappingPersistence.countByAgentScreenNames(companyId, agentScreenName);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String agentScreenName, String customerScreenName, int start, int end) {
		return this.agentCustomerMappingPersistence.findByASCN_CSCN(companyId, agentScreenName, StringPool.PERCENT.concat(customerScreenName).concat(StringPool.PERCENT), start, end);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String agentScreenName, String customerScreenName) {
		return this.agentCustomerMappingPersistence.findByASCN_CSCN(companyId, agentScreenName, StringPool.PERCENT.concat(customerScreenName).concat(StringPool.PERCENT));
	}

	public int getAgentCustomerMappingsCount(long companyId, String agentScreenName, String customerScreenName) {
		return this.agentCustomerMappingPersistence.countByASCN_CSCN(companyId, agentScreenName, StringPool.PERCENT.concat(customerScreenName).concat(StringPool.PERCENT));
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String[] agentScreenNames, String customerScreenName, int start, int end) {
		return this.agentCustomerMappingPersistence.findByASCN_CSCN(companyId, agentScreenNames, StringPool.PERCENT.concat(customerScreenName).concat(StringPool.PERCENT), start, end);
	}

	public List<AgentCustomerMapping> getAgentCustomerMappings(long companyId, String[] agentScreenNames, String customerScreenName) {
		return this.agentCustomerMappingPersistence.findByASCN_CSCN(companyId, agentScreenNames, StringPool.PERCENT.concat(customerScreenName).concat(StringPool.PERCENT));
	}

	public int getAgentCustomerMappingsCount(long companyId, String[] agentScreenNames, String customerScreenName) {
		return this.agentCustomerMappingPersistence.countByASCN_CSCN(companyId, agentScreenNames, StringPool.PERCENT.concat(customerScreenName).concat(StringPool.PERCENT));
	}

	public List<AgentCustomerMapping> findByAgentScreenName(long companyId, String agentScreenName) {
		return this.agentCustomerMappingPersistence.findByAgentScreenName(companyId, agentScreenName);
	}

	public AgentCustomerMapping findByAgentAndCustomerScreenName(long companyId, String agentScreenName, String customerScreenName) throws NoSuchAgentCustomerMappingException {
		return this.agentCustomerMappingPersistence.findByAgentAndCustomerScreenName(companyId, agentScreenName, customerScreenName);
	}

	public AgentCustomerMapping findByCustomerScreenName(long companyId, String customerScreenName) throws NoSuchAgentCustomerMappingException {
		return this.agentCustomerMappingPersistence.findByCustomerScreenName(companyId, customerScreenName);
	}

	public List<AgentCustomerMapping> getByCustomerScreenNames(long companyId, String[] customerScreenName) {
		return this.agentCustomerMappingPersistence.findByCustomerScreenNames(companyId, customerScreenName);
	}
}