/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model.impl;

import com.jio.account.model.Agent;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The cache model class for representing Agent in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class AgentCacheModel implements CacheModel<Agent>, Externalizable {

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AgentCacheModel)) {
			return false;
		}

		AgentCacheModel agentCacheModel = (AgentCacheModel)obj;

		if (agentId.equals(agentCacheModel.agentId)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, agentId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(71);

		sb.append("{agentId=");
		sb.append(agentId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createBy=");
		sb.append(createBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", screenName=");
		sb.append(screenName);
		sb.append(", name=");
		sb.append(name);
		sb.append(", parentCode=");
		sb.append(parentCode);
		sb.append(", primary=");
		sb.append(primary);
		sb.append(", prefDom=");
		sb.append(prefDom);
		sb.append(", poId=");
		sb.append(poId);
		sb.append(", accountNo=");
		sb.append(accountNo);
		sb.append(", gstinNo=");
		sb.append(gstinNo);
		sb.append(", status=");
		sb.append(status);
		sb.append(", autoRenew=");
		sb.append(autoRenew);
		sb.append(", legacyCode=");
		sb.append(legacyCode);
		sb.append(", clientCode=");
		sb.append(clientCode);
		sb.append(", bouquetCode=");
		sb.append(bouquetCode);
		sb.append(", jvNo=");
		sb.append(jvNo);
		sb.append(", directNo=");
		sb.append(directNo);
		sb.append(", distributor=");
		sb.append(distributor);
		sb.append(", subDistributor=");
		sb.append(subDistributor);
		sb.append(", jvPoId=");
		sb.append(jvPoId);
		sb.append(", directPoId=");
		sb.append(directPoId);
		sb.append(", distributorPoId=");
		sb.append(distributorPoId);
		sb.append(", subDistributorPoId=");
		sb.append(subDistributorPoId);
		sb.append(", jvName=");
		sb.append(jvName);
		sb.append(", directName=");
		sb.append(directName);
		sb.append(", distributorName=");
		sb.append(distributorName);
		sb.append(", subDistributorName=");
		sb.append(subDistributorName);
		sb.append(", panNo=");
		sb.append(panNo);
		sb.append(", reportDate=");
		sb.append(reportDate);
		sb.append(", ppType=");
		sb.append(ppType);
		sb.append(", locator=");
		sb.append(locator);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Agent toEntityModel() {
		AgentImpl agentImpl = new AgentImpl();

		if (agentId == null) {
			agentImpl.setAgentId("");
		}
		else {
			agentImpl.setAgentId(agentId);
		}

		agentImpl.setGroupId(groupId);
		agentImpl.setCompanyId(companyId);

		if (createBy == null) {
			agentImpl.setCreateBy("");
		}
		else {
			agentImpl.setCreateBy(createBy);
		}

		if (createDate == Long.MIN_VALUE) {
			agentImpl.setCreateDate(null);
		}
		else {
			agentImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			agentImpl.setModifiedDate(null);
		}
		else {
			agentImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (screenName == null) {
			agentImpl.setScreenName("");
		}
		else {
			agentImpl.setScreenName(screenName);
		}

		if (name == null) {
			agentImpl.setName("");
		}
		else {
			agentImpl.setName(name);
		}

		if (parentCode == null) {
			agentImpl.setParentCode("");
		}
		else {
			agentImpl.setParentCode(parentCode);
		}

		agentImpl.setPrimary(primary);

		if (prefDom == null) {
			agentImpl.setPrefDom("");
		}
		else {
			agentImpl.setPrefDom(prefDom);
		}

		if (poId == null) {
			agentImpl.setPoId("");
		}
		else {
			agentImpl.setPoId(poId);
		}

		if (accountNo == null) {
			agentImpl.setAccountNo("");
		}
		else {
			agentImpl.setAccountNo(accountNo);
		}

		if (gstinNo == null) {
			agentImpl.setGstinNo("");
		}
		else {
			agentImpl.setGstinNo(gstinNo);
		}

		agentImpl.setStatus(status);
		agentImpl.setAutoRenew(autoRenew);

		if (legacyCode == null) {
			agentImpl.setLegacyCode("");
		}
		else {
			agentImpl.setLegacyCode(legacyCode);
		}

		if (clientCode == null) {
			agentImpl.setClientCode("");
		}
		else {
			agentImpl.setClientCode(clientCode);
		}

		if (bouquetCode == null) {
			agentImpl.setBouquetCode("");
		}
		else {
			agentImpl.setBouquetCode(bouquetCode);
		}

		if (jvNo == null) {
			agentImpl.setJvNo("");
		}
		else {
			agentImpl.setJvNo(jvNo);
		}

		if (directNo == null) {
			agentImpl.setDirectNo("");
		}
		else {
			agentImpl.setDirectNo(directNo);
		}

		if (distributor == null) {
			agentImpl.setDistributor("");
		}
		else {
			agentImpl.setDistributor(distributor);
		}

		if (subDistributor == null) {
			agentImpl.setSubDistributor("");
		}
		else {
			agentImpl.setSubDistributor(subDistributor);
		}

		if (jvPoId == null) {
			agentImpl.setJvPoId("");
		}
		else {
			agentImpl.setJvPoId(jvPoId);
		}

		if (directPoId == null) {
			agentImpl.setDirectPoId("");
		}
		else {
			agentImpl.setDirectPoId(directPoId);
		}

		if (distributorPoId == null) {
			agentImpl.setDistributorPoId("");
		}
		else {
			agentImpl.setDistributorPoId(distributorPoId);
		}

		if (subDistributorPoId == null) {
			agentImpl.setSubDistributorPoId("");
		}
		else {
			agentImpl.setSubDistributorPoId(subDistributorPoId);
		}

		if (jvName == null) {
			agentImpl.setJvName("");
		}
		else {
			agentImpl.setJvName(jvName);
		}

		if (directName == null) {
			agentImpl.setDirectName("");
		}
		else {
			agentImpl.setDirectName(directName);
		}

		if (distributorName == null) {
			agentImpl.setDistributorName("");
		}
		else {
			agentImpl.setDistributorName(distributorName);
		}

		if (subDistributorName == null) {
			agentImpl.setSubDistributorName("");
		}
		else {
			agentImpl.setSubDistributorName(subDistributorName);
		}

		if (panNo == null) {
			agentImpl.setPanNo("");
		}
		else {
			agentImpl.setPanNo(panNo);
		}

		if (reportDate == Long.MIN_VALUE) {
			agentImpl.setReportDate(null);
		}
		else {
			agentImpl.setReportDate(new Date(reportDate));
		}

		if (ppType == null) {
			agentImpl.setPpType("");
		}
		else {
			agentImpl.setPpType(ppType);
		}

		if (locator == null) {
			agentImpl.setLocator("");
		}
		else {
			agentImpl.setLocator(locator);
		}

		agentImpl.resetOriginalValues();

		return agentImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		agentId = objectInput.readUTF();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();
		createBy = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		screenName = objectInput.readUTF();
		name = objectInput.readUTF();
		parentCode = objectInput.readUTF();

		primary = objectInput.readBoolean();
		prefDom = objectInput.readUTF();
		poId = objectInput.readUTF();
		accountNo = objectInput.readUTF();
		gstinNo = objectInput.readUTF();

		status = objectInput.readInt();

		autoRenew = objectInput.readBoolean();
		legacyCode = objectInput.readUTF();
		clientCode = objectInput.readUTF();
		bouquetCode = objectInput.readUTF();
		jvNo = objectInput.readUTF();
		directNo = objectInput.readUTF();
		distributor = objectInput.readUTF();
		subDistributor = objectInput.readUTF();
		jvPoId = objectInput.readUTF();
		directPoId = objectInput.readUTF();
		distributorPoId = objectInput.readUTF();
		subDistributorPoId = objectInput.readUTF();
		jvName = objectInput.readUTF();
		directName = objectInput.readUTF();
		distributorName = objectInput.readUTF();
		subDistributorName = objectInput.readUTF();
		panNo = objectInput.readUTF();
		reportDate = objectInput.readLong();
		ppType = objectInput.readUTF();
		locator = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (agentId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(agentId);
		}

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		if (createBy == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(createBy);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (screenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(screenName);
		}

		if (name == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (parentCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(parentCode);
		}

		objectOutput.writeBoolean(primary);

		if (prefDom == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(prefDom);
		}

		if (poId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(poId);
		}

		if (accountNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(accountNo);
		}

		if (gstinNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(gstinNo);
		}

		objectOutput.writeInt(status);

		objectOutput.writeBoolean(autoRenew);

		if (legacyCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(legacyCode);
		}

		if (clientCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(clientCode);
		}

		if (bouquetCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(bouquetCode);
		}

		if (jvNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(jvNo);
		}

		if (directNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(directNo);
		}

		if (distributor == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(distributor);
		}

		if (subDistributor == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(subDistributor);
		}

		if (jvPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(jvPoId);
		}

		if (directPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(directPoId);
		}

		if (distributorPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(distributorPoId);
		}

		if (subDistributorPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(subDistributorPoId);
		}

		if (jvName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(jvName);
		}

		if (directName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(directName);
		}

		if (distributorName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(distributorName);
		}

		if (subDistributorName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(subDistributorName);
		}

		if (panNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(panNo);
		}

		objectOutput.writeLong(reportDate);

		if (ppType == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(ppType);
		}

		if (locator == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(locator);
		}
	}

	public String agentId;
	public long groupId;
	public long companyId;
	public String createBy;
	public long createDate;
	public long modifiedDate;
	public String screenName;
	public String name;
	public String parentCode;
	public boolean primary;
	public String prefDom;
	public String poId;
	public String accountNo;
	public String gstinNo;
	public int status;
	public boolean autoRenew;
	public String legacyCode;
	public String clientCode;
	public String bouquetCode;
	public String jvNo;
	public String directNo;
	public String distributor;
	public String subDistributor;
	public String jvPoId;
	public String directPoId;
	public String distributorPoId;
	public String subDistributorPoId;
	public String jvName;
	public String directName;
	public String distributorName;
	public String subDistributorName;
	public String panNo;
	public long reportDate;
	public String ppType;
	public String locator;

}