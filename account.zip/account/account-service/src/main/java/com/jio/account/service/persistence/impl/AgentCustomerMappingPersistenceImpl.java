/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence.impl;

import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.model.impl.AgentCustomerMappingImpl;
import com.jio.account.model.impl.AgentCustomerMappingModelImpl;
import com.jio.account.service.persistence.AgentCustomerMappingPersistence;
import com.jio.account.service.persistence.impl.constants.ACCOUNTPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the agent customer mapping service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = AgentCustomerMappingPersistence.class)
@ProviderType
public class AgentCustomerMappingPersistenceImpl
	extends BasePersistenceImpl<AgentCustomerMapping>
	implements AgentCustomerMappingPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>AgentCustomerMappingUtil</code> to access the agent customer mapping persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		AgentCustomerMappingImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the agent customer mappings where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end) {

		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCompanyId_First(
			long companyId,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByCompanyId_First(
			companyId, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCompanyId_First(
		long companyId,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByCompanyId(
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCompanyId_Last(
			long companyId,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByCompanyId_Last(
			companyId, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCompanyId_Last(
		long companyId,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByCompanyId_PrevAndNext(
			String mappingId, long companyId,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, agentCustomerMapping, companyId, orderByComparator,
				true);

			array[1] = agentCustomerMapping;

			array[2] = getByCompanyId_PrevAndNext(
				session, agentCustomerMapping, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByCompanyId_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (AgentCustomerMapping agentCustomerMapping :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"agentCustomerMapping.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAgentScreenNames;
	private FinderPath _finderPathWithoutPaginationFindByAgentScreenNames;
	private FinderPath _finderPathCountByAgentScreenNames;
	private FinderPath _finderPathWithPaginationCountByAgentScreenNames;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName) {

		return findByAgentScreenNames(
			companyId, agentScreenName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end) {

		return findByAgentScreenNames(
			companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByAgentScreenNames(
			companyId, agentScreenName, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAgentScreenNames;
			finderArgs = new Object[] {companyId, agentScreenName};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAgentScreenNames;
			finderArgs = new Object[] {
				companyId, agentScreenName, start, end, orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!agentScreenName.equals(
							agentCustomerMapping.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTSCREENNAMES_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByAgentScreenNames_First(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			fetchByAgentScreenNames_First(
				companyId, agentScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByAgentScreenNames_First(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByAgentScreenNames(
			companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByAgentScreenNames_Last(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			fetchByAgentScreenNames_Last(
				companyId, agentScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByAgentScreenNames_Last(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByAgentScreenNames(companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByAgentScreenNames(
			companyId, agentScreenName, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByAgentScreenNames_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		agentScreenName = Objects.toString(agentScreenName, "");

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByAgentScreenNames_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = agentCustomerMapping;

			array[2] = getByAgentScreenNames_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByAgentScreenNames_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_AGENTSCREENNAMES_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames) {

		return findByAgentScreenNames(
			companyId, agentScreenNames, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end) {

		return findByAgentScreenNames(
			companyId, agentScreenNames, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByAgentScreenNames(
			companyId, agentScreenNames, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenNames(
		long companyId, String[] agentScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		if (agentScreenNames == null) {
			agentScreenNames = new String[0];
		}
		else if (agentScreenNames.length > 1) {
			for (int i = 0; i < agentScreenNames.length; i++) {
				agentScreenNames[i] = Objects.toString(agentScreenNames[i], "");
			}

			agentScreenNames = ArrayUtil.sortedUnique(agentScreenNames);
		}

		if (agentScreenNames.length == 1) {
			return findByAgentScreenNames(
				companyId, agentScreenNames[0], start, end, orderByComparator);
		}

		boolean pagination = true;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderArgs = new Object[] {
				companyId, StringUtil.merge(agentScreenNames)
			};
		}
		else {
			finderArgs = new Object[] {
				companyId, StringUtil.merge(agentScreenNames), start, end,
				orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				_finderPathWithPaginationFindByAgentScreenNames, finderArgs,
				this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!ArrayUtil.contains(
							agentScreenNames,
							agentCustomerMapping.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTSCREENNAMES_COMPANYID_2);

			if (agentScreenNames.length > 0) {
				query.append("(");

				for (int i = 0; i < agentScreenNames.length; i++) {
					String agentScreenName = agentScreenNames[i];

					if (agentScreenName.isEmpty()) {
						query.append(
							_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_3);
					}
					else {
						query.append(
							_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_2);
					}

					if ((i + 1) < agentScreenNames.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");
			}

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				for (String agentScreenName : agentScreenNames) {
					if (agentScreenName != null && !agentScreenName.isEmpty()) {
						qPos.add(agentScreenName);
					}
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(
					_finderPathWithPaginationFindByAgentScreenNames, finderArgs,
					list);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationFindByAgentScreenNames,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByAgentScreenNames(
		long companyId, String agentScreenName) {

		for (AgentCustomerMapping agentCustomerMapping :
				findByAgentScreenNames(
					companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByAgentScreenNames(long companyId, String agentScreenName) {
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathCountByAgentScreenNames;

		Object[] finderArgs = new Object[] {companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTSCREENNAMES_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = any &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByAgentScreenNames(
		long companyId, String[] agentScreenNames) {

		if (agentScreenNames == null) {
			agentScreenNames = new String[0];
		}
		else if (agentScreenNames.length > 1) {
			for (int i = 0; i < agentScreenNames.length; i++) {
				agentScreenNames[i] = Objects.toString(agentScreenNames[i], "");
			}

			agentScreenNames = ArrayUtil.sortedUnique(agentScreenNames);
		}

		Object[] finderArgs = new Object[] {
			companyId, StringUtil.merge(agentScreenNames)
		};

		Long count = (Long)finderCache.getResult(
			_finderPathWithPaginationCountByAgentScreenNames, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTSCREENNAMES_COMPANYID_2);

			if (agentScreenNames.length > 0) {
				query.append("(");

				for (int i = 0; i < agentScreenNames.length; i++) {
					String agentScreenName = agentScreenNames[i];

					if (agentScreenName.isEmpty()) {
						query.append(
							_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_3);
					}
					else {
						query.append(
							_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_2);
					}

					if ((i + 1) < agentScreenNames.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");
			}

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				for (String agentScreenName : agentScreenNames) {
					if (agentScreenName != null && !agentScreenName.isEmpty()) {
						qPos.add(agentScreenName);
					}
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathWithPaginationCountByAgentScreenNames,
					finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationCountByAgentScreenNames,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AGENTSCREENNAMES_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_2 =
			"agentCustomerMapping.agentScreenName = ?";

	private static final String
		_FINDER_COLUMN_AGENTSCREENNAMES_AGENTSCREENNAME_3 =
			"(agentCustomerMapping.agentScreenName IS NULL OR agentCustomerMapping.agentScreenName = '')";

	private FinderPath _finderPathWithPaginationFindByASCN_CSCN;
	private FinderPath _finderPathWithPaginationCountByASCN_CSCN;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName) {

		return findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end) {

		return findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		agentScreenName = Objects.toString(agentScreenName, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByASCN_CSCN;
		finderArgs = new Object[] {
			companyId, agentScreenName, customerScreenName, start, end,
			orderByComparator
		};

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!agentScreenName.equals(
							agentCustomerMapping.getAgentScreenName()) ||
						!StringUtil.wildcardMatches(
							agentCustomerMapping.getCustomerScreenName(),
							customerScreenName, '_', '%', '\\', false)) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_ASCN_CSCN_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (bindCustomerScreenName) {
					qPos.add(StringUtil.toLowerCase(customerScreenName));
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByASCN_CSCN_First(
			long companyId, String agentScreenName, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByASCN_CSCN_First(
			companyId, agentScreenName, customerScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByASCN_CSCN_First(
		long companyId, String agentScreenName, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByASCN_CSCN_Last(
			long companyId, String agentScreenName, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByASCN_CSCN_Last(
			companyId, agentScreenName, customerScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByASCN_CSCN_Last(
		long companyId, String agentScreenName, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByASCN_CSCN(
			companyId, agentScreenName, customerScreenName);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByASCN_CSCN(
			companyId, agentScreenName, customerScreenName, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByASCN_CSCN_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		agentScreenName = Objects.toString(agentScreenName, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByASCN_CSCN_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				customerScreenName, orderByComparator, true);

			array[1] = agentCustomerMapping;

			array[2] = getByASCN_CSCN_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				customerScreenName, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByASCN_CSCN_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId, String agentScreenName, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_ASCN_CSCN_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (bindCustomerScreenName) {
			qPos.add(StringUtil.toLowerCase(customerScreenName));
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName) {

		return findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end) {

		return findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByASCN_CSCN(
			companyId, agentScreenNames, customerScreenName, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName,
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		if (agentScreenNames == null) {
			agentScreenNames = new String[0];
		}
		else if (agentScreenNames.length > 1) {
			for (int i = 0; i < agentScreenNames.length; i++) {
				agentScreenNames[i] = Objects.toString(agentScreenNames[i], "");
			}

			agentScreenNames = ArrayUtil.sortedUnique(agentScreenNames);
		}

		customerScreenName = Objects.toString(customerScreenName, "");

		if (agentScreenNames.length == 1) {
			return findByASCN_CSCN(
				companyId, agentScreenNames[0], customerScreenName, start, end,
				orderByComparator);
		}

		boolean pagination = true;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderArgs = new Object[] {
				companyId, StringUtil.merge(agentScreenNames),
				customerScreenName
			};
		}
		else {
			finderArgs = new Object[] {
				companyId, StringUtil.merge(agentScreenNames),
				customerScreenName, start, end, orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				_finderPathWithPaginationFindByASCN_CSCN, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!ArrayUtil.contains(
							agentScreenNames,
							agentCustomerMapping.getAgentScreenName()) ||
						!StringUtil.wildcardMatches(
							agentCustomerMapping.getCustomerScreenName(),
							customerScreenName, '_', '%', '\\', false)) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_ASCN_CSCN_COMPANYID_2);

			if (agentScreenNames.length > 0) {
				query.append("(");

				for (int i = 0; i < agentScreenNames.length; i++) {
					String agentScreenName = agentScreenNames[i];

					if (agentScreenName.isEmpty()) {
						query.append(
							_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_6);
					}
					else {
						query.append(
							_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_5);
					}

					if ((i + 1) < agentScreenNames.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");

				query.append(WHERE_AND);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_2);
			}

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				for (String agentScreenName : agentScreenNames) {
					if (agentScreenName != null && !agentScreenName.isEmpty()) {
						qPos.add(agentScreenName);
					}
				}

				if (bindCustomerScreenName) {
					qPos.add(StringUtil.toLowerCase(customerScreenName));
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(
					_finderPathWithPaginationFindByASCN_CSCN, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationFindByASCN_CSCN, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 */
	@Override
	public void removeByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName) {

		for (AgentCustomerMapping agentCustomerMapping :
				findByASCN_CSCN(
					companyId, agentScreenName, customerScreenName,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByASCN_CSCN(
		long companyId, String agentScreenName, String customerScreenName) {

		agentScreenName = Objects.toString(agentScreenName, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByASCN_CSCN;

		Object[] finderArgs = new Object[] {
			companyId, agentScreenName, customerScreenName
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_ASCN_CSCN_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (bindCustomerScreenName) {
					qPos.add(StringUtil.toLowerCase(customerScreenName));
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = any &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenNames the agent screen names
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByASCN_CSCN(
		long companyId, String[] agentScreenNames, String customerScreenName) {

		if (agentScreenNames == null) {
			agentScreenNames = new String[0];
		}
		else if (agentScreenNames.length > 1) {
			for (int i = 0; i < agentScreenNames.length; i++) {
				agentScreenNames[i] = Objects.toString(agentScreenNames[i], "");
			}

			agentScreenNames = ArrayUtil.sortedUnique(agentScreenNames);
		}

		customerScreenName = Objects.toString(customerScreenName, "");

		Object[] finderArgs = new Object[] {
			companyId, StringUtil.merge(agentScreenNames), customerScreenName
		};

		Long count = (Long)finderCache.getResult(
			_finderPathWithPaginationCountByASCN_CSCN, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_ASCN_CSCN_COMPANYID_2);

			if (agentScreenNames.length > 0) {
				query.append("(");

				for (int i = 0; i < agentScreenNames.length; i++) {
					String agentScreenName = agentScreenNames[i];

					if (agentScreenName.isEmpty()) {
						query.append(
							_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_6);
					}
					else {
						query.append(
							_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_5);
					}

					if ((i + 1) < agentScreenNames.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");

				query.append(WHERE_AND);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_2);
			}

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				for (String agentScreenName : agentScreenNames) {
					if (agentScreenName != null && !agentScreenName.isEmpty()) {
						qPos.add(agentScreenName);
					}
				}

				if (bindCustomerScreenName) {
					qPos.add(StringUtil.toLowerCase(customerScreenName));
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathWithPaginationCountByASCN_CSCN, finderArgs,
					count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationCountByASCN_CSCN, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASCN_CSCN_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String _FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_2 =
		"agentCustomerMapping.agentScreenName = ? AND ";

	private static final String _FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_3 =
		"(agentCustomerMapping.agentScreenName IS NULL OR agentCustomerMapping.agentScreenName = '') AND ";

	private static final String _FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_5 =
		"(" + removeConjunction(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_2) +
			")";

	private static final String _FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_6 =
		"(" + removeConjunction(_FINDER_COLUMN_ASCN_CSCN_AGENTSCREENNAME_3) +
			")";

	private static final String _FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_2 =
		"lower(agentCustomerMapping.customerScreenName) LIKE ?";

	private static final String _FINDER_COLUMN_ASCN_CSCN_CUSTOMERSCREENNAME_3 =
		"(agentCustomerMapping.customerScreenName IS NULL OR agentCustomerMapping.customerScreenName LIKE '')";

	private FinderPath _finderPathWithPaginationFindByASCN;
	private FinderPath _finderPathWithPaginationCountByASCN;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName) {

		return findByASCN(
			companyId, agentScreenName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end) {

		return findByASCN(companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByASCN(
			companyId, agentScreenName, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByASCN(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByASCN;
		finderArgs = new Object[] {
			companyId, agentScreenName, start, end, orderByComparator
		};

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!StringUtil.wildcardMatches(
							agentCustomerMapping.getAgentScreenName(),
							agentScreenName, '_', '%', '\\', false)) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_ASCN_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(StringUtil.toLowerCase(agentScreenName));
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByASCN_First(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByASCN_First(
			companyId, agentScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByASCN_First(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByASCN(
			companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByASCN_Last(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByASCN_Last(
			companyId, agentScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByASCN_Last(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByASCN(companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByASCN(
			companyId, agentScreenName, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByASCN_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		agentScreenName = Objects.toString(agentScreenName, "");

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByASCN_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = agentCustomerMapping;

			array[2] = getByASCN_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByASCN_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_ASCN_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_ASCN_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_ASCN_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(StringUtil.toLowerCase(agentScreenName));
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByASCN(long companyId, String agentScreenName) {
		for (AgentCustomerMapping agentCustomerMapping :
				findByASCN(
					companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByASCN(long companyId, String agentScreenName) {
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByASCN;

		Object[] finderArgs = new Object[] {companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_ASCN_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_ASCN_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_ASCN_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(StringUtil.toLowerCase(agentScreenName));
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASCN_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String _FINDER_COLUMN_ASCN_AGENTSCREENNAME_2 =
		"lower(agentCustomerMapping.agentScreenName) LIKE ?";

	private static final String _FINDER_COLUMN_ASCN_AGENTSCREENNAME_3 =
		"(agentCustomerMapping.agentScreenName IS NULL OR agentCustomerMapping.agentScreenName LIKE '')";

	private FinderPath _finderPathWithPaginationFindByCSCN;
	private FinderPath _finderPathWithPaginationCountByCSCN;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName) {

		return findByCSCN(
			companyId, customerScreenName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end) {

		return findByCSCN(companyId, customerScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByCSCN(
			companyId, customerScreenName, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCSCN(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		finderPath = _finderPathWithPaginationFindByCSCN;
		finderArgs = new Object[] {
			companyId, customerScreenName, start, end, orderByComparator
		};

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!StringUtil.wildcardMatches(
							agentCustomerMapping.getCustomerScreenName(),
							customerScreenName, '_', '%', '\\', false)) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CSCN_COMPANYID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerScreenName) {
					qPos.add(StringUtil.toLowerCase(customerScreenName));
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCSCN_First(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByCSCN_First(
			companyId, customerScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCSCN_First(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByCSCN(
			companyId, customerScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCSCN_Last(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByCSCN_Last(
			companyId, customerScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCSCN_Last(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByCSCN(companyId, customerScreenName);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByCSCN(
			companyId, customerScreenName, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByCSCN_PrevAndNext(
			String mappingId, long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		customerScreenName = Objects.toString(customerScreenName, "");

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByCSCN_PrevAndNext(
				session, agentCustomerMapping, companyId, customerScreenName,
				orderByComparator, true);

			array[1] = agentCustomerMapping;

			array[2] = getByCSCN_PrevAndNext(
				session, agentCustomerMapping, companyId, customerScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByCSCN_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_CSCN_COMPANYID_2);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindCustomerScreenName) {
			qPos.add(StringUtil.toLowerCase(customerScreenName));
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 */
	@Override
	public void removeByCSCN(long companyId, String customerScreenName) {
		for (AgentCustomerMapping agentCustomerMapping :
				findByCSCN(
					companyId, customerScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName LIKE &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByCSCN(long companyId, String customerScreenName) {
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathWithPaginationCountByCSCN;

		Object[] finderArgs = new Object[] {companyId, customerScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CSCN_COMPANYID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerScreenName) {
					qPos.add(StringUtil.toLowerCase(customerScreenName));
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CSCN_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String _FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_2 =
		"lower(agentCustomerMapping.customerScreenName) LIKE ?";

	private static final String _FINDER_COLUMN_CSCN_CUSTOMERSCREENNAME_3 =
		"(agentCustomerMapping.customerScreenName IS NULL OR agentCustomerMapping.customerScreenName LIKE '')";

	private FinderPath _finderPathWithPaginationFindByAgentScreenName;
	private FinderPath _finderPathWithoutPaginationFindByAgentScreenName;
	private FinderPath _finderPathCountByAgentScreenName;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName) {

		return findByAgentScreenName(
			companyId, agentScreenName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end) {

		return findByAgentScreenName(
			companyId, agentScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByAgentScreenName(
			companyId, agentScreenName, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByAgentScreenName(
		long companyId, String agentScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		agentScreenName = Objects.toString(agentScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAgentScreenName;
			finderArgs = new Object[] {companyId, agentScreenName};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAgentScreenName;
			finderArgs = new Object[] {
				companyId, agentScreenName, start, end, orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!agentScreenName.equals(
							agentCustomerMapping.getAgentScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByAgentScreenName_First(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			fetchByAgentScreenName_First(
				companyId, agentScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByAgentScreenName_First(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByAgentScreenName(
			companyId, agentScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByAgentScreenName_Last(
			long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByAgentScreenName_Last(
			companyId, agentScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", agentScreenName=");
		msg.append(agentScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByAgentScreenName_Last(
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByAgentScreenName(companyId, agentScreenName);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByAgentScreenName(
			companyId, agentScreenName, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByAgentScreenName_PrevAndNext(
			String mappingId, long companyId, String agentScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		agentScreenName = Objects.toString(agentScreenName, "");

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByAgentScreenName_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				orderByComparator, true);

			array[1] = agentCustomerMapping;

			array[2] = getByAgentScreenName_PrevAndNext(
				session, agentCustomerMapping, companyId, agentScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByAgentScreenName_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId, String agentScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2);

		boolean bindAgentScreenName = false;

		if (agentScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3);
		}
		else {
			bindAgentScreenName = true;

			query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindAgentScreenName) {
			qPos.add(agentScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and agentScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 */
	@Override
	public void removeByAgentScreenName(
		long companyId, String agentScreenName) {

		for (AgentCustomerMapping agentCustomerMapping :
				findByAgentScreenName(
					companyId, agentScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByAgentScreenName(long companyId, String agentScreenName) {
		agentScreenName = Objects.toString(agentScreenName, "");

		FinderPath finderPath = _finderPathCountByAgentScreenName;

		Object[] finderArgs = new Object[] {companyId, agentScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AGENTSCREENNAME_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_2 =
			"agentCustomerMapping.agentScreenName = ?";

	private static final String
		_FINDER_COLUMN_AGENTSCREENNAME_AGENTSCREENNAME_3 =
			"(agentCustomerMapping.agentScreenName IS NULL OR agentCustomerMapping.agentScreenName = '')";

	private FinderPath _finderPathFetchByCustomerScreenName;
	private FinderPath _finderPathCountByCustomerScreenName;

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCustomerScreenName(
			long companyId, String customerScreenName)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByCustomerScreenName(
			companyId, customerScreenName);

		if (agentCustomerMapping == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", customerScreenName=");
			msg.append(customerScreenName);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchAgentCustomerMappingException(msg.toString());
		}

		return agentCustomerMapping;
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCustomerScreenName(
		long companyId, String customerScreenName) {

		return fetchByCustomerScreenName(companyId, customerScreenName, true);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCustomerScreenName(
		long companyId, String customerScreenName, boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");

		Object[] finderArgs = new Object[] {companyId, customerScreenName};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByCustomerScreenName, finderArgs, this);
		}

		if (result instanceof AgentCustomerMapping) {
			AgentCustomerMapping agentCustomerMapping =
				(AgentCustomerMapping)result;

			if ((companyId != agentCustomerMapping.getCompanyId()) ||
				!Objects.equals(
					customerScreenName,
					agentCustomerMapping.getCustomerScreenName())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CUSTOMERSCREENNAME_COMPANYID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAME_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAME_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				List<AgentCustomerMapping> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByCustomerScreenName, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"AgentCustomerMappingPersistenceImpl.fetchByCustomerScreenName(long, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					AgentCustomerMapping agentCustomerMapping = list.get(0);

					result = agentCustomerMapping;

					cacheResult(agentCustomerMapping);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByCustomerScreenName, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (AgentCustomerMapping)result;
		}
	}

	/**
	 * Removes the agent customer mapping where companyId = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the agent customer mapping that was removed
	 */
	@Override
	public AgentCustomerMapping removeByCustomerScreenName(
			long companyId, String customerScreenName)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = findByCustomerScreenName(
			companyId, customerScreenName);

		return remove(agentCustomerMapping);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByCustomerScreenName(
		long companyId, String customerScreenName) {

		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByCustomerScreenName;

		Object[] finderArgs = new Object[] {companyId, customerScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CUSTOMERSCREENNAME_COMPANYID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAME_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAME_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CUSTOMERSCREENNAME_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_CUSTOMERSCREENNAME_CUSTOMERSCREENNAME_2 =
			"agentCustomerMapping.customerScreenName = ?";

	private static final String
		_FINDER_COLUMN_CUSTOMERSCREENNAME_CUSTOMERSCREENNAME_3 =
			"(agentCustomerMapping.customerScreenName IS NULL OR agentCustomerMapping.customerScreenName = '')";

	private FinderPath _finderPathWithPaginationFindByCustomerScreenNames;
	private FinderPath _finderPathWithoutPaginationFindByCustomerScreenNames;
	private FinderPath _finderPathCountByCustomerScreenNames;
	private FinderPath _finderPathWithPaginationCountByCustomerScreenNames;

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName) {

		return findByCustomerScreenNames(
			companyId, customerScreenName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end) {

		return findByCustomerScreenNames(
			companyId, customerScreenName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByCustomerScreenNames(
			companyId, customerScreenName, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String customerScreenName, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCustomerScreenNames;
			finderArgs = new Object[] {companyId, customerScreenName};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCustomerScreenNames;
			finderArgs = new Object[] {
				companyId, customerScreenName, start, end, orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!customerScreenName.equals(
							agentCustomerMapping.getCustomerScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CUSTOMERSCREENNAMES_COMPANYID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCustomerScreenNames_First(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			fetchByCustomerScreenNames_First(
				companyId, customerScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the first agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCustomerScreenNames_First(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		List<AgentCustomerMapping> list = findByCustomerScreenNames(
			companyId, customerScreenName, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByCustomerScreenNames_Last(
			long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			fetchByCustomerScreenNames_Last(
				companyId, customerScreenName, orderByComparator);

		if (agentCustomerMapping != null) {
			return agentCustomerMapping;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append("}");

		throw new NoSuchAgentCustomerMappingException(msg.toString());
	}

	/**
	 * Returns the last agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByCustomerScreenNames_Last(
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		int count = countByCustomerScreenNames(companyId, customerScreenName);

		if (count == 0) {
			return null;
		}

		List<AgentCustomerMapping> list = findByCustomerScreenNames(
			companyId, customerScreenName, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agent customer mappings before and after the current agent customer mapping in the ordered set where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param mappingId the primary key of the current agent customer mapping
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping[] findByCustomerScreenNames_PrevAndNext(
			String mappingId, long companyId, String customerScreenName,
			OrderByComparator<AgentCustomerMapping> orderByComparator)
		throws NoSuchAgentCustomerMappingException {

		customerScreenName = Objects.toString(customerScreenName, "");

		AgentCustomerMapping agentCustomerMapping = findByPrimaryKey(mappingId);

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping[] array = new AgentCustomerMappingImpl[3];

			array[0] = getByCustomerScreenNames_PrevAndNext(
				session, agentCustomerMapping, companyId, customerScreenName,
				orderByComparator, true);

			array[1] = agentCustomerMapping;

			array[2] = getByCustomerScreenNames_PrevAndNext(
				session, agentCustomerMapping, companyId, customerScreenName,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AgentCustomerMapping getByCustomerScreenNames_PrevAndNext(
		Session session, AgentCustomerMapping agentCustomerMapping,
		long companyId, String customerScreenName,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

		query.append(_FINDER_COLUMN_CUSTOMERSCREENNAMES_COMPANYID_2);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(
				_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(
				_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						agentCustomerMapping)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<AgentCustomerMapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @return the matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames) {

		return findByCustomerScreenNames(
			companyId, customerScreenNames, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end) {

		return findByCustomerScreenNames(
			companyId, customerScreenNames, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findByCustomerScreenNames(
			companyId, customerScreenNames, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings where companyId = &#63; and customerScreenName = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findByCustomerScreenNames(
		long companyId, String[] customerScreenNames, int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		if (customerScreenNames == null) {
			customerScreenNames = new String[0];
		}
		else if (customerScreenNames.length > 1) {
			for (int i = 0; i < customerScreenNames.length; i++) {
				customerScreenNames[i] = Objects.toString(
					customerScreenNames[i], "");
			}

			customerScreenNames = ArrayUtil.sortedUnique(customerScreenNames);
		}

		if (customerScreenNames.length == 1) {
			return findByCustomerScreenNames(
				companyId, customerScreenNames[0], start, end,
				orderByComparator);
		}

		boolean pagination = true;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderArgs = new Object[] {
				companyId, StringUtil.merge(customerScreenNames)
			};
		}
		else {
			finderArgs = new Object[] {
				companyId, StringUtil.merge(customerScreenNames), start, end,
				orderByComparator
			};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				_finderPathWithPaginationFindByCustomerScreenNames, finderArgs,
				this);

			if ((list != null) && !list.isEmpty()) {
				for (AgentCustomerMapping agentCustomerMapping : list) {
					if ((companyId != agentCustomerMapping.getCompanyId()) ||
						!ArrayUtil.contains(
							customerScreenNames,
							agentCustomerMapping.getCustomerScreenName())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CUSTOMERSCREENNAMES_COMPANYID_2);

			if (customerScreenNames.length > 0) {
				query.append("(");

				for (int i = 0; i < customerScreenNames.length; i++) {
					String customerScreenName = customerScreenNames[i];

					if (customerScreenName.isEmpty()) {
						query.append(
							_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_3);
					}
					else {
						query.append(
							_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_2);
					}

					if ((i + 1) < customerScreenNames.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");
			}

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				for (String customerScreenName : customerScreenNames) {
					if (customerScreenName != null &&
						!customerScreenName.isEmpty()) {

						qPos.add(customerScreenName);
					}
				}

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(
					_finderPathWithPaginationFindByCustomerScreenNames,
					finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationFindByCustomerScreenNames,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the agent customer mappings where companyId = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 */
	@Override
	public void removeByCustomerScreenNames(
		long companyId, String customerScreenName) {

		for (AgentCustomerMapping agentCustomerMapping :
				findByCustomerScreenNames(
					companyId, customerScreenName, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByCustomerScreenNames(
		long companyId, String customerScreenName) {

		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByCustomerScreenNames;

		Object[] finderArgs = new Object[] {companyId, customerScreenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CUSTOMERSCREENNAMES_COMPANYID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and customerScreenName = any &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerScreenNames the customer screen names
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByCustomerScreenNames(
		long companyId, String[] customerScreenNames) {

		if (customerScreenNames == null) {
			customerScreenNames = new String[0];
		}
		else if (customerScreenNames.length > 1) {
			for (int i = 0; i < customerScreenNames.length; i++) {
				customerScreenNames[i] = Objects.toString(
					customerScreenNames[i], "");
			}

			customerScreenNames = ArrayUtil.sortedUnique(customerScreenNames);
		}

		Object[] finderArgs = new Object[] {
			companyId, StringUtil.merge(customerScreenNames)
		};

		Long count = (Long)finderCache.getResult(
			_finderPathWithPaginationCountByCustomerScreenNames, finderArgs,
			this);

		if (count == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_CUSTOMERSCREENNAMES_COMPANYID_2);

			if (customerScreenNames.length > 0) {
				query.append("(");

				for (int i = 0; i < customerScreenNames.length; i++) {
					String customerScreenName = customerScreenNames[i];

					if (customerScreenName.isEmpty()) {
						query.append(
							_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_3);
					}
					else {
						query.append(
							_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_2);
					}

					if ((i + 1) < customerScreenNames.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");
			}

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				for (String customerScreenName : customerScreenNames) {
					if (customerScreenName != null &&
						!customerScreenName.isEmpty()) {

						qPos.add(customerScreenName);
					}
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathWithPaginationCountByCustomerScreenNames,
					finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationCountByCustomerScreenNames,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CUSTOMERSCREENNAMES_COMPANYID_2 =
		"agentCustomerMapping.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_2 =
			"agentCustomerMapping.customerScreenName = ?";

	private static final String
		_FINDER_COLUMN_CUSTOMERSCREENNAMES_CUSTOMERSCREENNAME_3 =
			"(agentCustomerMapping.customerScreenName IS NULL OR agentCustomerMapping.customerScreenName = '')";

	private FinderPath _finderPathFetchByAgentAndCustomerScreenName;
	private FinderPath _finderPathCountByAgentAndCustomerScreenName;

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping findByAgentAndCustomerScreenName(
			long companyId, String agentScreenName, String customerScreenName)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			fetchByAgentAndCustomerScreenName(
				companyId, agentScreenName, customerScreenName);

		if (agentCustomerMapping == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", agentScreenName=");
			msg.append(agentScreenName);

			msg.append(", customerScreenName=");
			msg.append(customerScreenName);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchAgentCustomerMappingException(msg.toString());
		}

		return agentCustomerMapping;
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName) {

		return fetchByAgentAndCustomerScreenName(
			companyId, agentScreenName, customerScreenName, true);
	}

	/**
	 * Returns the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent customer mapping, or <code>null</code> if a matching agent customer mapping could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName,
		boolean retrieveFromCache) {

		agentScreenName = Objects.toString(agentScreenName, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		Object[] finderArgs = new Object[] {
			companyId, agentScreenName, customerScreenName
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAgentAndCustomerScreenName, finderArgs, this);
		}

		if (result instanceof AgentCustomerMapping) {
			AgentCustomerMapping agentCustomerMapping =
				(AgentCustomerMapping)result;

			if ((companyId != agentCustomerMapping.getCompanyId()) ||
				!Objects.equals(
					agentScreenName,
					agentCustomerMapping.getAgentScreenName()) ||
				!Objects.equals(
					customerScreenName,
					agentCustomerMapping.getCustomerScreenName())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_AGENTSCREENNAME_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				List<AgentCustomerMapping> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAgentAndCustomerScreenName,
						finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"AgentCustomerMappingPersistenceImpl.fetchByAgentAndCustomerScreenName(long, String, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					AgentCustomerMapping agentCustomerMapping = list.get(0);

					result = agentCustomerMapping;

					cacheResult(agentCustomerMapping);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAgentAndCustomerScreenName, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (AgentCustomerMapping)result;
		}
	}

	/**
	 * Removes the agent customer mapping where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the agent customer mapping that was removed
	 */
	@Override
	public AgentCustomerMapping removeByAgentAndCustomerScreenName(
			long companyId, String agentScreenName, String customerScreenName)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping =
			findByAgentAndCustomerScreenName(
				companyId, agentScreenName, customerScreenName);

		return remove(agentCustomerMapping);
	}

	/**
	 * Returns the number of agent customer mappings where companyId = &#63; and agentScreenName = &#63; and customerScreenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param agentScreenName the agent screen name
	 * @param customerScreenName the customer screen name
	 * @return the number of matching agent customer mappings
	 */
	@Override
	public int countByAgentAndCustomerScreenName(
		long companyId, String agentScreenName, String customerScreenName) {

		agentScreenName = Objects.toString(agentScreenName, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByAgentAndCustomerScreenName;

		Object[] finderArgs = new Object[] {
			companyId, agentScreenName, customerScreenName
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE);

			query.append(_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_COMPANYID_2);

			boolean bindAgentScreenName = false;

			if (agentScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_AGENTSCREENNAME_3);
			}
			else {
				bindAgentScreenName = true;

				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_AGENTSCREENNAME_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_CUSTOMERSCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindAgentScreenName) {
					qPos.add(agentScreenName);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_COMPANYID_2 =
			"agentCustomerMapping.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_AGENTSCREENNAME_2 =
			"agentCustomerMapping.agentScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_AGENTSCREENNAME_3 =
			"(agentCustomerMapping.agentScreenName IS NULL OR agentCustomerMapping.agentScreenName = '') AND ";

	private static final String
		_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_CUSTOMERSCREENNAME_2 =
			"agentCustomerMapping.customerScreenName = ?";

	private static final String
		_FINDER_COLUMN_AGENTANDCUSTOMERSCREENNAME_CUSTOMERSCREENNAME_3 =
			"(agentCustomerMapping.customerScreenName IS NULL OR agentCustomerMapping.customerScreenName = '')";

	public AgentCustomerMappingPersistenceImpl() {
		setModelClass(AgentCustomerMapping.class);

		setModelImplClass(AgentCustomerMappingImpl.class);
		setModelPKClass(String.class);
	}

	/**
	 * Caches the agent customer mapping in the entity cache if it is enabled.
	 *
	 * @param agentCustomerMapping the agent customer mapping
	 */
	@Override
	public void cacheResult(AgentCustomerMapping agentCustomerMapping) {
		entityCache.putResult(
			entityCacheEnabled, AgentCustomerMappingImpl.class,
			agentCustomerMapping.getPrimaryKey(), agentCustomerMapping);

		finderCache.putResult(
			_finderPathFetchByCustomerScreenName,
			new Object[] {
				agentCustomerMapping.getCompanyId(),
				agentCustomerMapping.getCustomerScreenName()
			},
			agentCustomerMapping);

		finderCache.putResult(
			_finderPathFetchByAgentAndCustomerScreenName,
			new Object[] {
				agentCustomerMapping.getCompanyId(),
				agentCustomerMapping.getAgentScreenName(),
				agentCustomerMapping.getCustomerScreenName()
			},
			agentCustomerMapping);

		agentCustomerMapping.resetOriginalValues();
	}

	/**
	 * Caches the agent customer mappings in the entity cache if it is enabled.
	 *
	 * @param agentCustomerMappings the agent customer mappings
	 */
	@Override
	public void cacheResult(List<AgentCustomerMapping> agentCustomerMappings) {
		for (AgentCustomerMapping agentCustomerMapping :
				agentCustomerMappings) {

			if (entityCache.getResult(
					entityCacheEnabled, AgentCustomerMappingImpl.class,
					agentCustomerMapping.getPrimaryKey()) == null) {

				cacheResult(agentCustomerMapping);
			}
			else {
				agentCustomerMapping.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all agent customer mappings.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(AgentCustomerMappingImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the agent customer mapping.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(AgentCustomerMapping agentCustomerMapping) {
		entityCache.removeResult(
			entityCacheEnabled, AgentCustomerMappingImpl.class,
			agentCustomerMapping.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(
			(AgentCustomerMappingModelImpl)agentCustomerMapping, true);
	}

	@Override
	public void clearCache(List<AgentCustomerMapping> agentCustomerMappings) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (AgentCustomerMapping agentCustomerMapping :
				agentCustomerMappings) {

			entityCache.removeResult(
				entityCacheEnabled, AgentCustomerMappingImpl.class,
				agentCustomerMapping.getPrimaryKey());

			clearUniqueFindersCache(
				(AgentCustomerMappingModelImpl)agentCustomerMapping, true);
		}
	}

	protected void cacheUniqueFindersCache(
		AgentCustomerMappingModelImpl agentCustomerMappingModelImpl) {

		Object[] args = new Object[] {
			agentCustomerMappingModelImpl.getCompanyId(),
			agentCustomerMappingModelImpl.getCustomerScreenName()
		};

		finderCache.putResult(
			_finderPathCountByCustomerScreenName, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByCustomerScreenName, args,
			agentCustomerMappingModelImpl, false);

		args = new Object[] {
			agentCustomerMappingModelImpl.getCompanyId(),
			agentCustomerMappingModelImpl.getAgentScreenName(),
			agentCustomerMappingModelImpl.getCustomerScreenName()
		};

		finderCache.putResult(
			_finderPathCountByAgentAndCustomerScreenName, args, Long.valueOf(1),
			false);
		finderCache.putResult(
			_finderPathFetchByAgentAndCustomerScreenName, args,
			agentCustomerMappingModelImpl, false);
	}

	protected void clearUniqueFindersCache(
		AgentCustomerMappingModelImpl agentCustomerMappingModelImpl,
		boolean clearCurrent) {

		if (clearCurrent) {
			Object[] args = new Object[] {
				agentCustomerMappingModelImpl.getCompanyId(),
				agentCustomerMappingModelImpl.getCustomerScreenName()
			};

			finderCache.removeResult(
				_finderPathCountByCustomerScreenName, args);
			finderCache.removeResult(
				_finderPathFetchByCustomerScreenName, args);
		}

		if ((agentCustomerMappingModelImpl.getColumnBitmask() &
			 _finderPathFetchByCustomerScreenName.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				agentCustomerMappingModelImpl.getOriginalCompanyId(),
				agentCustomerMappingModelImpl.getOriginalCustomerScreenName()
			};

			finderCache.removeResult(
				_finderPathCountByCustomerScreenName, args);
			finderCache.removeResult(
				_finderPathFetchByCustomerScreenName, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				agentCustomerMappingModelImpl.getCompanyId(),
				agentCustomerMappingModelImpl.getAgentScreenName(),
				agentCustomerMappingModelImpl.getCustomerScreenName()
			};

			finderCache.removeResult(
				_finderPathCountByAgentAndCustomerScreenName, args);
			finderCache.removeResult(
				_finderPathFetchByAgentAndCustomerScreenName, args);
		}

		if ((agentCustomerMappingModelImpl.getColumnBitmask() &
			 _finderPathFetchByAgentAndCustomerScreenName.getColumnBitmask()) !=
				 0) {

			Object[] args = new Object[] {
				agentCustomerMappingModelImpl.getOriginalCompanyId(),
				agentCustomerMappingModelImpl.getOriginalAgentScreenName(),
				agentCustomerMappingModelImpl.getOriginalCustomerScreenName()
			};

			finderCache.removeResult(
				_finderPathCountByAgentAndCustomerScreenName, args);
			finderCache.removeResult(
				_finderPathFetchByAgentAndCustomerScreenName, args);
		}
	}

	/**
	 * Creates a new agent customer mapping with the primary key. Does not add the agent customer mapping to the database.
	 *
	 * @param mappingId the primary key for the new agent customer mapping
	 * @return the new agent customer mapping
	 */
	@Override
	public AgentCustomerMapping create(String mappingId) {
		AgentCustomerMapping agentCustomerMapping =
			new AgentCustomerMappingImpl();

		agentCustomerMapping.setNew(true);
		agentCustomerMapping.setPrimaryKey(mappingId);

		agentCustomerMapping.setCompanyId(companyProvider.getCompanyId());

		return agentCustomerMapping;
	}

	/**
	 * Removes the agent customer mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping that was removed
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping remove(String mappingId)
		throws NoSuchAgentCustomerMappingException {

		return remove((Serializable)mappingId);
	}

	/**
	 * Removes the agent customer mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the agent customer mapping
	 * @return the agent customer mapping that was removed
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping remove(Serializable primaryKey)
		throws NoSuchAgentCustomerMappingException {

		Session session = null;

		try {
			session = openSession();

			AgentCustomerMapping agentCustomerMapping =
				(AgentCustomerMapping)session.get(
					AgentCustomerMappingImpl.class, primaryKey);

			if (agentCustomerMapping == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchAgentCustomerMappingException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(agentCustomerMapping);
		}
		catch (NoSuchAgentCustomerMappingException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected AgentCustomerMapping removeImpl(
		AgentCustomerMapping agentCustomerMapping) {

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(agentCustomerMapping)) {
				agentCustomerMapping = (AgentCustomerMapping)session.get(
					AgentCustomerMappingImpl.class,
					agentCustomerMapping.getPrimaryKeyObj());
			}

			if (agentCustomerMapping != null) {
				session.delete(agentCustomerMapping);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (agentCustomerMapping != null) {
			clearCache(agentCustomerMapping);
		}

		return agentCustomerMapping;
	}

	@Override
	public AgentCustomerMapping updateImpl(
		AgentCustomerMapping agentCustomerMapping) {

		boolean isNew = agentCustomerMapping.isNew();

		if (!(agentCustomerMapping instanceof AgentCustomerMappingModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(agentCustomerMapping.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					agentCustomerMapping);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in agentCustomerMapping proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom AgentCustomerMapping implementation " +
					agentCustomerMapping.getClass());
		}

		AgentCustomerMappingModelImpl agentCustomerMappingModelImpl =
			(AgentCustomerMappingModelImpl)agentCustomerMapping;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (agentCustomerMapping.getCreateDate() == null)) {
			if (serviceContext == null) {
				agentCustomerMapping.setCreateDate(now);
			}
			else {
				agentCustomerMapping.setCreateDate(
					serviceContext.getCreateDate(now));
			}
		}

		if (!agentCustomerMappingModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				agentCustomerMapping.setModifiedDate(now);
			}
			else {
				agentCustomerMapping.setModifiedDate(
					serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (agentCustomerMapping.isNew()) {
				session.save(agentCustomerMapping);

				agentCustomerMapping.setNew(false);
			}
			else {
				agentCustomerMapping = (AgentCustomerMapping)session.merge(
					agentCustomerMapping);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {
				agentCustomerMappingModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			args = new Object[] {
				agentCustomerMappingModelImpl.getCompanyId(),
				agentCustomerMappingModelImpl.getAgentScreenName()
			};

			finderCache.removeResult(_finderPathCountByAgentScreenNames, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAgentScreenNames, args);

			args = new Object[] {
				agentCustomerMappingModelImpl.getCompanyId(),
				agentCustomerMappingModelImpl.getAgentScreenName()
			};

			finderCache.removeResult(_finderPathCountByAgentScreenName, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAgentScreenName, args);

			args = new Object[] {
				agentCustomerMappingModelImpl.getCompanyId(),
				agentCustomerMappingModelImpl.getCustomerScreenName()
			};

			finderCache.removeResult(
				_finderPathCountByCustomerScreenNames, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCustomerScreenNames, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((agentCustomerMappingModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentCustomerMappingModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {
					agentCustomerMappingModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}

			if ((agentCustomerMappingModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAgentScreenNames.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentCustomerMappingModelImpl.getOriginalCompanyId(),
					agentCustomerMappingModelImpl.getOriginalAgentScreenName()
				};

				finderCache.removeResult(
					_finderPathCountByAgentScreenNames, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAgentScreenNames, args);

				args = new Object[] {
					agentCustomerMappingModelImpl.getCompanyId(),
					agentCustomerMappingModelImpl.getAgentScreenName()
				};

				finderCache.removeResult(
					_finderPathCountByAgentScreenNames, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAgentScreenNames, args);
			}

			if ((agentCustomerMappingModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAgentScreenName.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentCustomerMappingModelImpl.getOriginalCompanyId(),
					agentCustomerMappingModelImpl.getOriginalAgentScreenName()
				};

				finderCache.removeResult(
					_finderPathCountByAgentScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAgentScreenName, args);

				args = new Object[] {
					agentCustomerMappingModelImpl.getCompanyId(),
					agentCustomerMappingModelImpl.getAgentScreenName()
				};

				finderCache.removeResult(
					_finderPathCountByAgentScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAgentScreenName, args);
			}

			if ((agentCustomerMappingModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCustomerScreenNames.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentCustomerMappingModelImpl.getOriginalCompanyId(),
					agentCustomerMappingModelImpl.
						getOriginalCustomerScreenName()
				};

				finderCache.removeResult(
					_finderPathCountByCustomerScreenNames, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCustomerScreenNames,
					args);

				args = new Object[] {
					agentCustomerMappingModelImpl.getCompanyId(),
					agentCustomerMappingModelImpl.getCustomerScreenName()
				};

				finderCache.removeResult(
					_finderPathCountByCustomerScreenNames, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCustomerScreenNames,
					args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, AgentCustomerMappingImpl.class,
			agentCustomerMapping.getPrimaryKey(), agentCustomerMapping, false);

		clearUniqueFindersCache(agentCustomerMappingModelImpl, false);
		cacheUniqueFindersCache(agentCustomerMappingModelImpl);

		agentCustomerMapping.resetOriginalValues();

		return agentCustomerMapping;
	}

	/**
	 * Returns the agent customer mapping with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the agent customer mapping
	 * @return the agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping findByPrimaryKey(Serializable primaryKey)
		throws NoSuchAgentCustomerMappingException {

		AgentCustomerMapping agentCustomerMapping = fetchByPrimaryKey(
			primaryKey);

		if (agentCustomerMapping == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchAgentCustomerMappingException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return agentCustomerMapping;
	}

	/**
	 * Returns the agent customer mapping with the primary key or throws a <code>NoSuchAgentCustomerMappingException</code> if it could not be found.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping
	 * @throws NoSuchAgentCustomerMappingException if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping findByPrimaryKey(String mappingId)
		throws NoSuchAgentCustomerMappingException {

		return findByPrimaryKey((Serializable)mappingId);
	}

	/**
	 * Returns the agent customer mapping with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param mappingId the primary key of the agent customer mapping
	 * @return the agent customer mapping, or <code>null</code> if a agent customer mapping with the primary key could not be found
	 */
	@Override
	public AgentCustomerMapping fetchByPrimaryKey(String mappingId) {
		return fetchByPrimaryKey((Serializable)mappingId);
	}

	/**
	 * Returns all the agent customer mappings.
	 *
	 * @return the agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @return the range of agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findAll(
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agent customer mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentCustomerMappingModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agent customer mappings
	 * @param end the upper bound of the range of agent customer mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of agent customer mappings
	 */
	@Override
	public List<AgentCustomerMapping> findAll(
		int start, int end,
		OrderByComparator<AgentCustomerMapping> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<AgentCustomerMapping> list = null;

		if (retrieveFromCache) {
			list = (List<AgentCustomerMapping>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_AGENTCUSTOMERMAPPING);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_AGENTCUSTOMERMAPPING;

				if (pagination) {
					sql = sql.concat(
						AgentCustomerMappingModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<AgentCustomerMapping>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the agent customer mappings from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (AgentCustomerMapping agentCustomerMapping : findAll()) {
			remove(agentCustomerMapping);
		}
	}

	/**
	 * Returns the number of agent customer mappings.
	 *
	 * @return the number of agent customer mappings
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_AGENTCUSTOMERMAPPING);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "mappingId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_AGENTCUSTOMERMAPPING;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return AgentCustomerMappingModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the agent customer mapping persistence.
	 */
	@Activate
	public void activate() {
		AgentCustomerMappingModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		AgentCustomerMappingModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			AgentCustomerMappingModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});

		_finderPathWithPaginationFindByAgentScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAgentScreenNames",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAgentScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAgentScreenNames",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentCustomerMappingModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAgentScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAgentScreenNames",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationCountByAgentScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByAgentScreenNames",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationFindByASCN_CSCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByASCN_CSCN",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByASCN_CSCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByASCN_CSCN",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			});

		_finderPathWithPaginationFindByASCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByASCN",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByASCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByASCN",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationFindByCSCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCSCN",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithPaginationCountByCSCN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByCSCN",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationFindByAgentScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAgentScreenName",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAgentScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAgentScreenName",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentCustomerMappingModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAgentScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAgentScreenName",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathFetchByCustomerScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByCustomerScreenName",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentCustomerMappingModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK);

		_finderPathCountByCustomerScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByCustomerScreenName",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationFindByCustomerScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCustomerScreenNames",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCustomerScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByCustomerScreenNames",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentCustomerMappingModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCustomerScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByCustomerScreenNames",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationCountByCustomerScreenNames = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"countByCustomerScreenNames",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathFetchByAgentAndCustomerScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled,
			AgentCustomerMappingImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByAgentAndCustomerScreenName",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			},
			AgentCustomerMappingModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.AGENTSCREENNAME_COLUMN_BITMASK |
			AgentCustomerMappingModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK);

		_finderPathCountByAgentAndCustomerScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAgentAndCustomerScreenName",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(AgentCustomerMappingImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.model.AgentCustomerMapping"),
			true);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_AGENTCUSTOMERMAPPING =
		"SELECT agentCustomerMapping FROM AgentCustomerMapping agentCustomerMapping";

	private static final String _SQL_SELECT_AGENTCUSTOMERMAPPING_WHERE =
		"SELECT agentCustomerMapping FROM AgentCustomerMapping agentCustomerMapping WHERE ";

	private static final String _SQL_COUNT_AGENTCUSTOMERMAPPING =
		"SELECT COUNT(agentCustomerMapping) FROM AgentCustomerMapping agentCustomerMapping";

	private static final String _SQL_COUNT_AGENTCUSTOMERMAPPING_WHERE =
		"SELECT COUNT(agentCustomerMapping) FROM AgentCustomerMapping agentCustomerMapping WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS =
		"agentCustomerMapping.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No AgentCustomerMapping exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No AgentCustomerMapping exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		AgentCustomerMappingPersistenceImpl.class);

}