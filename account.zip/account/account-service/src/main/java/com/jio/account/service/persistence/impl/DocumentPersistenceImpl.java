/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence.impl;

import com.jio.account.exception.NoSuchDocumentException;
import com.jio.account.model.Document;
import com.jio.account.model.impl.DocumentImpl;
import com.jio.account.model.impl.DocumentModelImpl;
import com.jio.account.service.persistence.DocumentPersistence;
import com.jio.account.service.persistence.impl.constants.ACCOUNTPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the document service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = DocumentPersistence.class)
@ProviderType
public class DocumentPersistenceImpl
	extends BasePersistenceImpl<Document> implements DocumentPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>DocumentUtil</code> to access the document persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		DocumentImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByCustomerId;
	private FinderPath _finderPathWithoutPaginationFindByCustomerId;
	private FinderPath _finderPathCountByCustomerId;

	/**
	 * Returns all the documents where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the matching documents
	 */
	@Override
	public List<Document> findByCustomerId(String customerId, long companyId) {
		return findByCustomerId(
			customerId, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the documents where customerId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @return the range of matching documents
	 */
	@Override
	public List<Document> findByCustomerId(
		String customerId, long companyId, int start, int end) {

		return findByCustomerId(customerId, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the documents where customerId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching documents
	 */
	@Override
	public List<Document> findByCustomerId(
		String customerId, long companyId, int start, int end,
		OrderByComparator<Document> orderByComparator) {

		return findByCustomerId(
			customerId, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the documents where customerId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching documents
	 */
	@Override
	public List<Document> findByCustomerId(
		String customerId, long companyId, int start, int end,
		OrderByComparator<Document> orderByComparator,
		boolean retrieveFromCache) {

		customerId = Objects.toString(customerId, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCustomerId;
			finderArgs = new Object[] {customerId, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCustomerId;
			finderArgs = new Object[] {
				customerId, companyId, start, end, orderByComparator
			};
		}

		List<Document> list = null;

		if (retrieveFromCache) {
			list = (List<Document>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Document document : list) {
					if (!customerId.equals(document.getCustomerId()) ||
						(companyId != document.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_DOCUMENT_WHERE);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2);
			}

			query.append(_FINDER_COLUMN_CUSTOMERID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(DocumentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Document>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Document>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first document in the ordered set where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByCustomerId_First(
			String customerId, long companyId,
			OrderByComparator<Document> orderByComparator)
		throws NoSuchDocumentException {

		Document document = fetchByCustomerId_First(
			customerId, companyId, orderByComparator);

		if (document != null) {
			return document;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerId=");
		msg.append(customerId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchDocumentException(msg.toString());
	}

	/**
	 * Returns the first document in the ordered set where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByCustomerId_First(
		String customerId, long companyId,
		OrderByComparator<Document> orderByComparator) {

		List<Document> list = findByCustomerId(
			customerId, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last document in the ordered set where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByCustomerId_Last(
			String customerId, long companyId,
			OrderByComparator<Document> orderByComparator)
		throws NoSuchDocumentException {

		Document document = fetchByCustomerId_Last(
			customerId, companyId, orderByComparator);

		if (document != null) {
			return document;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerId=");
		msg.append(customerId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchDocumentException(msg.toString());
	}

	/**
	 * Returns the last document in the ordered set where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByCustomerId_Last(
		String customerId, long companyId,
		OrderByComparator<Document> orderByComparator) {

		int count = countByCustomerId(customerId, companyId);

		if (count == 0) {
			return null;
		}

		List<Document> list = findByCustomerId(
			customerId, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the documents before and after the current document in the ordered set where customerId = &#63; and companyId = &#63;.
	 *
	 * @param documentId the primary key of the current document
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next document
	 * @throws NoSuchDocumentException if a document with the primary key could not be found
	 */
	@Override
	public Document[] findByCustomerId_PrevAndNext(
			String documentId, String customerId, long companyId,
			OrderByComparator<Document> orderByComparator)
		throws NoSuchDocumentException {

		customerId = Objects.toString(customerId, "");

		Document document = findByPrimaryKey(documentId);

		Session session = null;

		try {
			session = openSession();

			Document[] array = new DocumentImpl[3];

			array[0] = getByCustomerId_PrevAndNext(
				session, document, customerId, companyId, orderByComparator,
				true);

			array[1] = document;

			array[2] = getByCustomerId_PrevAndNext(
				session, document, customerId, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Document getByCustomerId_PrevAndNext(
		Session session, Document document, String customerId, long companyId,
		OrderByComparator<Document> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_DOCUMENT_WHERE);

		boolean bindCustomerId = false;

		if (customerId.isEmpty()) {
			query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3);
		}
		else {
			bindCustomerId = true;

			query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2);
		}

		query.append(_FINDER_COLUMN_CUSTOMERID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DocumentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCustomerId) {
			qPos.add(customerId);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(document)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Document> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the documents where customerId = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCustomerId(String customerId, long companyId) {
		for (Document document :
				findByCustomerId(
					customerId, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(document);
		}
	}

	/**
	 * Returns the number of documents where customerId = &#63; and companyId = &#63;.
	 *
	 * @param customerId the customer ID
	 * @param companyId the company ID
	 * @return the number of matching documents
	 */
	@Override
	public int countByCustomerId(String customerId, long companyId) {
		customerId = Objects.toString(customerId, "");

		FinderPath finderPath = _finderPathCountByCustomerId;

		Object[] finderArgs = new Object[] {customerId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DOCUMENT_WHERE);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2);
			}

			query.append(_FINDER_COLUMN_CUSTOMERID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CUSTOMERID_CUSTOMERID_2 =
		"document.customerId = ? AND ";

	private static final String _FINDER_COLUMN_CUSTOMERID_CUSTOMERID_3 =
		"(document.customerId IS NULL OR document.customerId = '') AND ";

	private static final String _FINDER_COLUMN_CUSTOMERID_COMPANYID_2 =
		"document.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByScreenName;
	private FinderPath _finderPathWithoutPaginationFindByScreenName;
	private FinderPath _finderPathCountByScreenName;

	/**
	 * Returns all the documents where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the matching documents
	 */
	@Override
	public List<Document> findByScreenName(String screenName, long companyId) {
		return findByScreenName(
			screenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the documents where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @return the range of matching documents
	 */
	@Override
	public List<Document> findByScreenName(
		String screenName, long companyId, int start, int end) {

		return findByScreenName(screenName, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the documents where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching documents
	 */
	@Override
	public List<Document> findByScreenName(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Document> orderByComparator) {

		return findByScreenName(
			screenName, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the documents where screenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching documents
	 */
	@Override
	public List<Document> findByScreenName(
		String screenName, long companyId, int start, int end,
		OrderByComparator<Document> orderByComparator,
		boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByScreenName;
			finderArgs = new Object[] {screenName, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByScreenName;
			finderArgs = new Object[] {
				screenName, companyId, start, end, orderByComparator
			};
		}

		List<Document> list = null;

		if (retrieveFromCache) {
			list = (List<Document>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Document document : list) {
					if (!screenName.equals(document.getScreenName()) ||
						(companyId != document.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_DOCUMENT_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(DocumentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Document>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Document>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first document in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByScreenName_First(
			String screenName, long companyId,
			OrderByComparator<Document> orderByComparator)
		throws NoSuchDocumentException {

		Document document = fetchByScreenName_First(
			screenName, companyId, orderByComparator);

		if (document != null) {
			return document;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchDocumentException(msg.toString());
	}

	/**
	 * Returns the first document in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByScreenName_First(
		String screenName, long companyId,
		OrderByComparator<Document> orderByComparator) {

		List<Document> list = findByScreenName(
			screenName, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last document in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByScreenName_Last(
			String screenName, long companyId,
			OrderByComparator<Document> orderByComparator)
		throws NoSuchDocumentException {

		Document document = fetchByScreenName_Last(
			screenName, companyId, orderByComparator);

		if (document != null) {
			return document;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("screenName=");
		msg.append(screenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchDocumentException(msg.toString());
	}

	/**
	 * Returns the last document in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByScreenName_Last(
		String screenName, long companyId,
		OrderByComparator<Document> orderByComparator) {

		int count = countByScreenName(screenName, companyId);

		if (count == 0) {
			return null;
		}

		List<Document> list = findByScreenName(
			screenName, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the documents before and after the current document in the ordered set where screenName = &#63; and companyId = &#63;.
	 *
	 * @param documentId the primary key of the current document
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next document
	 * @throws NoSuchDocumentException if a document with the primary key could not be found
	 */
	@Override
	public Document[] findByScreenName_PrevAndNext(
			String documentId, String screenName, long companyId,
			OrderByComparator<Document> orderByComparator)
		throws NoSuchDocumentException {

		screenName = Objects.toString(screenName, "");

		Document document = findByPrimaryKey(documentId);

		Session session = null;

		try {
			session = openSession();

			Document[] array = new DocumentImpl[3];

			array[0] = getByScreenName_PrevAndNext(
				session, document, screenName, companyId, orderByComparator,
				true);

			array[1] = document;

			array[2] = getByScreenName_PrevAndNext(
				session, document, screenName, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Document getByScreenName_PrevAndNext(
		Session session, Document document, String screenName, long companyId,
		OrderByComparator<Document> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_DOCUMENT_WHERE);

		boolean bindScreenName = false;

		if (screenName.isEmpty()) {
			query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
		}
		else {
			bindScreenName = true;

			query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DocumentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindScreenName) {
			qPos.add(screenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(document)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Document> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the documents where screenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByScreenName(String screenName, long companyId) {
		for (Document document :
				findByScreenName(
					screenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(document);
		}
	}

	/**
	 * Returns the number of documents where screenName = &#63; and companyId = &#63;.
	 *
	 * @param screenName the screen name
	 * @param companyId the company ID
	 * @return the number of matching documents
	 */
	@Override
	public int countByScreenName(String screenName, long companyId) {
		screenName = Objects.toString(screenName, "");

		FinderPath finderPath = _finderPathCountByScreenName;

		Object[] finderArgs = new Object[] {screenName, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DOCUMENT_WHERE);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SCREENNAME_SCREENNAME_2 =
		"document.screenName = ? AND ";

	private static final String _FINDER_COLUMN_SCREENNAME_SCREENNAME_3 =
		"(document.screenName IS NULL OR document.screenName = '') AND ";

	private static final String _FINDER_COLUMN_SCREENNAME_COMPANYID_2 =
		"document.companyId = ?";

	private FinderPath _finderPathFetchByC_C_C_T;
	private FinderPath _finderPathCountByC_C_C_T;

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and category = &#63; and type = &#63; or throws a <code>NoSuchDocumentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @param type the type
	 * @return the matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByC_C_C_T(
			long companyId, String customerId, String category, String type)
		throws NoSuchDocumentException {

		Document document = fetchByC_C_C_T(
			companyId, customerId, category, type);

		if (document == null) {
			StringBundler msg = new StringBundler(10);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", customerId=");
			msg.append(customerId);

			msg.append(", category=");
			msg.append(category);

			msg.append(", type=");
			msg.append(type);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDocumentException(msg.toString());
		}

		return document;
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and category = &#63; and type = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @param type the type
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_C_T(
		long companyId, String customerId, String category, String type) {

		return fetchByC_C_C_T(companyId, customerId, category, type, true);
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and category = &#63; and type = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @param type the type
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_C_T(
		long companyId, String customerId, String category, String type,
		boolean retrieveFromCache) {

		customerId = Objects.toString(customerId, "");
		category = Objects.toString(category, "");
		type = Objects.toString(type, "");

		Object[] finderArgs = new Object[] {
			companyId, customerId, category, type
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByC_C_C_T, finderArgs, this);
		}

		if (result instanceof Document) {
			Document document = (Document)result;

			if ((companyId != document.getCompanyId()) ||
				!Objects.equals(customerId, document.getCustomerId()) ||
				!Objects.equals(category, document.getCategory()) ||
				!Objects.equals(type, document.getType())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_SELECT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_C_T_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_T_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_C_T_CUSTOMERID_2);
			}

			boolean bindCategory = false;

			if (category.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_T_CATEGORY_3);
			}
			else {
				bindCategory = true;

				query.append(_FINDER_COLUMN_C_C_C_T_CATEGORY_2);
			}

			boolean bindType = false;

			if (type.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_T_TYPE_3);
			}
			else {
				bindType = true;

				query.append(_FINDER_COLUMN_C_C_C_T_TYPE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindCategory) {
					qPos.add(category);
				}

				if (bindType) {
					qPos.add(type);
				}

				List<Document> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByC_C_C_T, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DocumentPersistenceImpl.fetchByC_C_C_T(long, String, String, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Document document = list.get(0);

					result = document;

					cacheResult(document);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByC_C_C_T, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Document)result;
		}
	}

	/**
	 * Removes the document where companyId = &#63; and customerId = &#63; and category = &#63; and type = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @param type the type
	 * @return the document that was removed
	 */
	@Override
	public Document removeByC_C_C_T(
			long companyId, String customerId, String category, String type)
		throws NoSuchDocumentException {

		Document document = findByC_C_C_T(
			companyId, customerId, category, type);

		return remove(document);
	}

	/**
	 * Returns the number of documents where companyId = &#63; and customerId = &#63; and category = &#63; and type = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @param type the type
	 * @return the number of matching documents
	 */
	@Override
	public int countByC_C_C_T(
		long companyId, String customerId, String category, String type) {

		customerId = Objects.toString(customerId, "");
		category = Objects.toString(category, "");
		type = Objects.toString(type, "");

		FinderPath finderPath = _finderPathCountByC_C_C_T;

		Object[] finderArgs = new Object[] {
			companyId, customerId, category, type
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_C_T_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_T_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_C_T_CUSTOMERID_2);
			}

			boolean bindCategory = false;

			if (category.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_T_CATEGORY_3);
			}
			else {
				bindCategory = true;

				query.append(_FINDER_COLUMN_C_C_C_T_CATEGORY_2);
			}

			boolean bindType = false;

			if (type.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_T_TYPE_3);
			}
			else {
				bindType = true;

				query.append(_FINDER_COLUMN_C_C_C_T_TYPE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindCategory) {
					qPos.add(category);
				}

				if (bindType) {
					qPos.add(type);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_C_C_C_T_COMPANYID_2 =
		"document.companyId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_C_T_CUSTOMERID_2 =
		"document.customerId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_C_T_CUSTOMERID_3 =
		"(document.customerId IS NULL OR document.customerId = '') AND ";

	private static final String _FINDER_COLUMN_C_C_C_T_CATEGORY_2 =
		"document.category = ? AND ";

	private static final String _FINDER_COLUMN_C_C_C_T_CATEGORY_3 =
		"(document.category IS NULL OR document.category = '') AND ";

	private static final String _FINDER_COLUMN_C_C_C_T_TYPE_2 =
		"document.type = ?";

	private static final String _FINDER_COLUMN_C_C_C_T_TYPE_3 =
		"(document.type IS NULL OR document.type = '')";

	private FinderPath _finderPathFetchByC_C_C;
	private FinderPath _finderPathCountByC_C_C;

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and category = &#63; or throws a <code>NoSuchDocumentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @return the matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByC_C_C(
			long companyId, String customerId, String category)
		throws NoSuchDocumentException {

		Document document = fetchByC_C_C(companyId, customerId, category);

		if (document == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", customerId=");
			msg.append(customerId);

			msg.append(", category=");
			msg.append(category);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDocumentException(msg.toString());
		}

		return document;
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and category = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_C(
		long companyId, String customerId, String category) {

		return fetchByC_C_C(companyId, customerId, category, true);
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and category = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_C(
		long companyId, String customerId, String category,
		boolean retrieveFromCache) {

		customerId = Objects.toString(customerId, "");
		category = Objects.toString(category, "");

		Object[] finderArgs = new Object[] {companyId, customerId, category};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByC_C_C, finderArgs, this);
		}

		if (result instanceof Document) {
			Document document = (Document)result;

			if ((companyId != document.getCompanyId()) ||
				!Objects.equals(customerId, document.getCustomerId()) ||
				!Objects.equals(category, document.getCategory())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_C_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_C_CUSTOMERID_2);
			}

			boolean bindCategory = false;

			if (category.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_CATEGORY_3);
			}
			else {
				bindCategory = true;

				query.append(_FINDER_COLUMN_C_C_C_CATEGORY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindCategory) {
					qPos.add(category);
				}

				List<Document> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByC_C_C, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DocumentPersistenceImpl.fetchByC_C_C(long, String, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Document document = list.get(0);

					result = document;

					cacheResult(document);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByC_C_C, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Document)result;
		}
	}

	/**
	 * Removes the document where companyId = &#63; and customerId = &#63; and category = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @return the document that was removed
	 */
	@Override
	public Document removeByC_C_C(
			long companyId, String customerId, String category)
		throws NoSuchDocumentException {

		Document document = findByC_C_C(companyId, customerId, category);

		return remove(document);
	}

	/**
	 * Returns the number of documents where companyId = &#63; and customerId = &#63; and category = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param category the category
	 * @return the number of matching documents
	 */
	@Override
	public int countByC_C_C(
		long companyId, String customerId, String category) {

		customerId = Objects.toString(customerId, "");
		category = Objects.toString(category, "");

		FinderPath finderPath = _finderPathCountByC_C_C;

		Object[] finderArgs = new Object[] {companyId, customerId, category};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_C_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_C_CUSTOMERID_2);
			}

			boolean bindCategory = false;

			if (category.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_C_CATEGORY_3);
			}
			else {
				bindCategory = true;

				query.append(_FINDER_COLUMN_C_C_C_CATEGORY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindCategory) {
					qPos.add(category);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_C_C_C_COMPANYID_2 =
		"document.companyId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_C_CUSTOMERID_2 =
		"document.customerId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_C_CUSTOMERID_3 =
		"(document.customerId IS NULL OR document.customerId = '') AND ";

	private static final String _FINDER_COLUMN_C_C_C_CATEGORY_2 =
		"document.category = ?";

	private static final String _FINDER_COLUMN_C_C_C_CATEGORY_3 =
		"(document.category IS NULL OR document.category = '')";

	private FinderPath _finderPathFetchByC_C_D;
	private FinderPath _finderPathCountByC_C_D;

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and documentId = &#63; or throws a <code>NoSuchDocumentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param documentId the document ID
	 * @return the matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByC_C_D(
			long companyId, String customerId, String documentId)
		throws NoSuchDocumentException {

		Document document = fetchByC_C_D(companyId, customerId, documentId);

		if (document == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", customerId=");
			msg.append(customerId);

			msg.append(", documentId=");
			msg.append(documentId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDocumentException(msg.toString());
		}

		return document;
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and documentId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param documentId the document ID
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_D(
		long companyId, String customerId, String documentId) {

		return fetchByC_C_D(companyId, customerId, documentId, true);
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and documentId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param documentId the document ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_D(
		long companyId, String customerId, String documentId,
		boolean retrieveFromCache) {

		customerId = Objects.toString(customerId, "");
		documentId = Objects.toString(documentId, "");

		Object[] finderArgs = new Object[] {companyId, customerId, documentId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByC_C_D, finderArgs, this);
		}

		if (result instanceof Document) {
			Document document = (Document)result;

			if ((companyId != document.getCompanyId()) ||
				!Objects.equals(customerId, document.getCustomerId()) ||
				!Objects.equals(documentId, document.getDocumentId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_D_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_D_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_D_CUSTOMERID_2);
			}

			boolean bindDocumentId = false;

			if (documentId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_D_DOCUMENTID_3);
			}
			else {
				bindDocumentId = true;

				query.append(_FINDER_COLUMN_C_C_D_DOCUMENTID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindDocumentId) {
					qPos.add(documentId);
				}

				List<Document> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByC_C_D, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DocumentPersistenceImpl.fetchByC_C_D(long, String, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Document document = list.get(0);

					result = document;

					cacheResult(document);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByC_C_D, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Document)result;
		}
	}

	/**
	 * Removes the document where companyId = &#63; and customerId = &#63; and documentId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param documentId the document ID
	 * @return the document that was removed
	 */
	@Override
	public Document removeByC_C_D(
			long companyId, String customerId, String documentId)
		throws NoSuchDocumentException {

		Document document = findByC_C_D(companyId, customerId, documentId);

		return remove(document);
	}

	/**
	 * Returns the number of documents where companyId = &#63; and customerId = &#63; and documentId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param documentId the document ID
	 * @return the number of matching documents
	 */
	@Override
	public int countByC_C_D(
		long companyId, String customerId, String documentId) {

		customerId = Objects.toString(customerId, "");
		documentId = Objects.toString(documentId, "");

		FinderPath finderPath = _finderPathCountByC_C_D;

		Object[] finderArgs = new Object[] {companyId, customerId, documentId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_D_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_D_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_D_CUSTOMERID_2);
			}

			boolean bindDocumentId = false;

			if (documentId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_D_DOCUMENTID_3);
			}
			else {
				bindDocumentId = true;

				query.append(_FINDER_COLUMN_C_C_D_DOCUMENTID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindDocumentId) {
					qPos.add(documentId);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_C_C_D_COMPANYID_2 =
		"document.companyId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_D_CUSTOMERID_2 =
		"document.customerId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_D_CUSTOMERID_3 =
		"(document.customerId IS NULL OR document.customerId = '') AND ";

	private static final String _FINDER_COLUMN_C_C_D_DOCUMENTID_2 =
		"document.documentId = ?";

	private static final String _FINDER_COLUMN_C_C_D_DOCUMENTID_3 =
		"(document.documentId IS NULL OR document.documentId = '')";

	private FinderPath _finderPathFetchByC_C_N;
	private FinderPath _finderPathCountByC_C_N;

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and name = &#63; or throws a <code>NoSuchDocumentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param name the name
	 * @return the matching document
	 * @throws NoSuchDocumentException if a matching document could not be found
	 */
	@Override
	public Document findByC_C_N(long companyId, String customerId, String name)
		throws NoSuchDocumentException {

		Document document = fetchByC_C_N(companyId, customerId, name);

		if (document == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", customerId=");
			msg.append(customerId);

			msg.append(", name=");
			msg.append(name);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDocumentException(msg.toString());
		}

		return document;
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and name = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param name the name
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_N(
		long companyId, String customerId, String name) {

		return fetchByC_C_N(companyId, customerId, name, true);
	}

	/**
	 * Returns the document where companyId = &#63; and customerId = &#63; and name = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param name the name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching document, or <code>null</code> if a matching document could not be found
	 */
	@Override
	public Document fetchByC_C_N(
		long companyId, String customerId, String name,
		boolean retrieveFromCache) {

		customerId = Objects.toString(customerId, "");
		name = Objects.toString(name, "");

		Object[] finderArgs = new Object[] {companyId, customerId, name};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByC_C_N, finderArgs, this);
		}

		if (result instanceof Document) {
			Document document = (Document)result;

			if ((companyId != document.getCompanyId()) ||
				!Objects.equals(customerId, document.getCustomerId()) ||
				!Objects.equals(name, document.getName())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_N_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_N_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_N_CUSTOMERID_2);
			}

			boolean bindName = false;

			if (name.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_N_NAME_3);
			}
			else {
				bindName = true;

				query.append(_FINDER_COLUMN_C_C_N_NAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindName) {
					qPos.add(name);
				}

				List<Document> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByC_C_N, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DocumentPersistenceImpl.fetchByC_C_N(long, String, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Document document = list.get(0);

					result = document;

					cacheResult(document);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByC_C_N, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Document)result;
		}
	}

	/**
	 * Removes the document where companyId = &#63; and customerId = &#63; and name = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param name the name
	 * @return the document that was removed
	 */
	@Override
	public Document removeByC_C_N(
			long companyId, String customerId, String name)
		throws NoSuchDocumentException {

		Document document = findByC_C_N(companyId, customerId, name);

		return remove(document);
	}

	/**
	 * Returns the number of documents where companyId = &#63; and customerId = &#63; and name = &#63;.
	 *
	 * @param companyId the company ID
	 * @param customerId the customer ID
	 * @param name the name
	 * @return the number of matching documents
	 */
	@Override
	public int countByC_C_N(long companyId, String customerId, String name) {
		customerId = Objects.toString(customerId, "");
		name = Objects.toString(name, "");

		FinderPath finderPath = _finderPathCountByC_C_N;

		Object[] finderArgs = new Object[] {companyId, customerId, name};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_DOCUMENT_WHERE);

			query.append(_FINDER_COLUMN_C_C_N_COMPANYID_2);

			boolean bindCustomerId = false;

			if (customerId.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_N_CUSTOMERID_3);
			}
			else {
				bindCustomerId = true;

				query.append(_FINDER_COLUMN_C_C_N_CUSTOMERID_2);
			}

			boolean bindName = false;

			if (name.isEmpty()) {
				query.append(_FINDER_COLUMN_C_C_N_NAME_3);
			}
			else {
				bindName = true;

				query.append(_FINDER_COLUMN_C_C_N_NAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindCustomerId) {
					qPos.add(customerId);
				}

				if (bindName) {
					qPos.add(name);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_C_C_N_COMPANYID_2 =
		"document.companyId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_N_CUSTOMERID_2 =
		"document.customerId = ? AND ";

	private static final String _FINDER_COLUMN_C_C_N_CUSTOMERID_3 =
		"(document.customerId IS NULL OR document.customerId = '') AND ";

	private static final String _FINDER_COLUMN_C_C_N_NAME_2 =
		"document.name = ?";

	private static final String _FINDER_COLUMN_C_C_N_NAME_3 =
		"(document.name IS NULL OR document.name = '')";

	public DocumentPersistenceImpl() {
		setModelClass(Document.class);

		setModelImplClass(DocumentImpl.class);
		setModelPKClass(String.class);

		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("type", "type_");

		setDBColumnNames(dbColumnNames);
	}

	/**
	 * Caches the document in the entity cache if it is enabled.
	 *
	 * @param document the document
	 */
	@Override
	public void cacheResult(Document document) {
		entityCache.putResult(
			entityCacheEnabled, DocumentImpl.class, document.getPrimaryKey(),
			document);

		finderCache.putResult(
			_finderPathFetchByC_C_C_T,
			new Object[] {
				document.getCompanyId(), document.getCustomerId(),
				document.getCategory(), document.getType()
			},
			document);

		finderCache.putResult(
			_finderPathFetchByC_C_C,
			new Object[] {
				document.getCompanyId(), document.getCustomerId(),
				document.getCategory()
			},
			document);

		finderCache.putResult(
			_finderPathFetchByC_C_D,
			new Object[] {
				document.getCompanyId(), document.getCustomerId(),
				document.getDocumentId()
			},
			document);

		finderCache.putResult(
			_finderPathFetchByC_C_N,
			new Object[] {
				document.getCompanyId(), document.getCustomerId(),
				document.getName()
			},
			document);

		document.resetOriginalValues();
	}

	/**
	 * Caches the documents in the entity cache if it is enabled.
	 *
	 * @param documents the documents
	 */
	@Override
	public void cacheResult(List<Document> documents) {
		for (Document document : documents) {
			if (entityCache.getResult(
					entityCacheEnabled, DocumentImpl.class,
					document.getPrimaryKey()) == null) {

				cacheResult(document);
			}
			else {
				document.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all documents.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(DocumentImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the document.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Document document) {
		entityCache.removeResult(
			entityCacheEnabled, DocumentImpl.class, document.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache((DocumentModelImpl)document, true);
	}

	@Override
	public void clearCache(List<Document> documents) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Document document : documents) {
			entityCache.removeResult(
				entityCacheEnabled, DocumentImpl.class,
				document.getPrimaryKey());

			clearUniqueFindersCache((DocumentModelImpl)document, true);
		}
	}

	protected void cacheUniqueFindersCache(
		DocumentModelImpl documentModelImpl) {

		Object[] args = new Object[] {
			documentModelImpl.getCompanyId(), documentModelImpl.getCustomerId(),
			documentModelImpl.getCategory(), documentModelImpl.getType()
		};

		finderCache.putResult(
			_finderPathCountByC_C_C_T, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByC_C_C_T, args, documentModelImpl, false);

		args = new Object[] {
			documentModelImpl.getCompanyId(), documentModelImpl.getCustomerId(),
			documentModelImpl.getCategory()
		};

		finderCache.putResult(
			_finderPathCountByC_C_C, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByC_C_C, args, documentModelImpl, false);

		args = new Object[] {
			documentModelImpl.getCompanyId(), documentModelImpl.getCustomerId(),
			documentModelImpl.getDocumentId()
		};

		finderCache.putResult(
			_finderPathCountByC_C_D, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByC_C_D, args, documentModelImpl, false);

		args = new Object[] {
			documentModelImpl.getCompanyId(), documentModelImpl.getCustomerId(),
			documentModelImpl.getName()
		};

		finderCache.putResult(
			_finderPathCountByC_C_N, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByC_C_N, args, documentModelImpl, false);
	}

	protected void clearUniqueFindersCache(
		DocumentModelImpl documentModelImpl, boolean clearCurrent) {

		if (clearCurrent) {
			Object[] args = new Object[] {
				documentModelImpl.getCompanyId(),
				documentModelImpl.getCustomerId(),
				documentModelImpl.getCategory(), documentModelImpl.getType()
			};

			finderCache.removeResult(_finderPathCountByC_C_C_T, args);
			finderCache.removeResult(_finderPathFetchByC_C_C_T, args);
		}

		if ((documentModelImpl.getColumnBitmask() &
			 _finderPathFetchByC_C_C_T.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				documentModelImpl.getOriginalCompanyId(),
				documentModelImpl.getOriginalCustomerId(),
				documentModelImpl.getOriginalCategory(),
				documentModelImpl.getOriginalType()
			};

			finderCache.removeResult(_finderPathCountByC_C_C_T, args);
			finderCache.removeResult(_finderPathFetchByC_C_C_T, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				documentModelImpl.getCompanyId(),
				documentModelImpl.getCustomerId(),
				documentModelImpl.getCategory()
			};

			finderCache.removeResult(_finderPathCountByC_C_C, args);
			finderCache.removeResult(_finderPathFetchByC_C_C, args);
		}

		if ((documentModelImpl.getColumnBitmask() &
			 _finderPathFetchByC_C_C.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				documentModelImpl.getOriginalCompanyId(),
				documentModelImpl.getOriginalCustomerId(),
				documentModelImpl.getOriginalCategory()
			};

			finderCache.removeResult(_finderPathCountByC_C_C, args);
			finderCache.removeResult(_finderPathFetchByC_C_C, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				documentModelImpl.getCompanyId(),
				documentModelImpl.getCustomerId(),
				documentModelImpl.getDocumentId()
			};

			finderCache.removeResult(_finderPathCountByC_C_D, args);
			finderCache.removeResult(_finderPathFetchByC_C_D, args);
		}

		if ((documentModelImpl.getColumnBitmask() &
			 _finderPathFetchByC_C_D.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				documentModelImpl.getOriginalCompanyId(),
				documentModelImpl.getOriginalCustomerId(),
				documentModelImpl.getOriginalDocumentId()
			};

			finderCache.removeResult(_finderPathCountByC_C_D, args);
			finderCache.removeResult(_finderPathFetchByC_C_D, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				documentModelImpl.getCompanyId(),
				documentModelImpl.getCustomerId(), documentModelImpl.getName()
			};

			finderCache.removeResult(_finderPathCountByC_C_N, args);
			finderCache.removeResult(_finderPathFetchByC_C_N, args);
		}

		if ((documentModelImpl.getColumnBitmask() &
			 _finderPathFetchByC_C_N.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				documentModelImpl.getOriginalCompanyId(),
				documentModelImpl.getOriginalCustomerId(),
				documentModelImpl.getOriginalName()
			};

			finderCache.removeResult(_finderPathCountByC_C_N, args);
			finderCache.removeResult(_finderPathFetchByC_C_N, args);
		}
	}

	/**
	 * Creates a new document with the primary key. Does not add the document to the database.
	 *
	 * @param documentId the primary key for the new document
	 * @return the new document
	 */
	@Override
	public Document create(String documentId) {
		Document document = new DocumentImpl();

		document.setNew(true);
		document.setPrimaryKey(documentId);

		document.setCompanyId(companyProvider.getCompanyId());

		return document;
	}

	/**
	 * Removes the document with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param documentId the primary key of the document
	 * @return the document that was removed
	 * @throws NoSuchDocumentException if a document with the primary key could not be found
	 */
	@Override
	public Document remove(String documentId) throws NoSuchDocumentException {
		return remove((Serializable)documentId);
	}

	/**
	 * Removes the document with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the document
	 * @return the document that was removed
	 * @throws NoSuchDocumentException if a document with the primary key could not be found
	 */
	@Override
	public Document remove(Serializable primaryKey)
		throws NoSuchDocumentException {

		Session session = null;

		try {
			session = openSession();

			Document document = (Document)session.get(
				DocumentImpl.class, primaryKey);

			if (document == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDocumentException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(document);
		}
		catch (NoSuchDocumentException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Document removeImpl(Document document) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(document)) {
				document = (Document)session.get(
					DocumentImpl.class, document.getPrimaryKeyObj());
			}

			if (document != null) {
				session.delete(document);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (document != null) {
			clearCache(document);
		}

		return document;
	}

	@Override
	public Document updateImpl(Document document) {
		boolean isNew = document.isNew();

		if (!(document instanceof DocumentModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(document.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(document);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in document proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom Document implementation " +
					document.getClass());
		}

		DocumentModelImpl documentModelImpl = (DocumentModelImpl)document;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (document.getCreateDate() == null)) {
			if (serviceContext == null) {
				document.setCreateDate(now);
			}
			else {
				document.setCreateDate(serviceContext.getCreateDate(now));
			}
		}

		if (!documentModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				document.setModifiedDate(now);
			}
			else {
				document.setModifiedDate(serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (document.isNew()) {
				session.save(document);

				document.setNew(false);
			}
			else {
				document = (Document)session.merge(document);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {
				documentModelImpl.getCustomerId(),
				documentModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCustomerId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCustomerId, args);

			args = new Object[] {
				documentModelImpl.getScreenName(),
				documentModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByScreenName, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByScreenName, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((documentModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCustomerId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					documentModelImpl.getOriginalCustomerId(),
					documentModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCustomerId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCustomerId, args);

				args = new Object[] {
					documentModelImpl.getCustomerId(),
					documentModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCustomerId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCustomerId, args);
			}

			if ((documentModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByScreenName.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					documentModelImpl.getOriginalScreenName(),
					documentModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByScreenName, args);

				args = new Object[] {
					documentModelImpl.getScreenName(),
					documentModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByScreenName, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByScreenName, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, DocumentImpl.class, document.getPrimaryKey(),
			document, false);

		clearUniqueFindersCache(documentModelImpl, false);
		cacheUniqueFindersCache(documentModelImpl);

		document.resetOriginalValues();

		return document;
	}

	/**
	 * Returns the document with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the document
	 * @return the document
	 * @throws NoSuchDocumentException if a document with the primary key could not be found
	 */
	@Override
	public Document findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDocumentException {

		Document document = fetchByPrimaryKey(primaryKey);

		if (document == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDocumentException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return document;
	}

	/**
	 * Returns the document with the primary key or throws a <code>NoSuchDocumentException</code> if it could not be found.
	 *
	 * @param documentId the primary key of the document
	 * @return the document
	 * @throws NoSuchDocumentException if a document with the primary key could not be found
	 */
	@Override
	public Document findByPrimaryKey(String documentId)
		throws NoSuchDocumentException {

		return findByPrimaryKey((Serializable)documentId);
	}

	/**
	 * Returns the document with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param documentId the primary key of the document
	 * @return the document, or <code>null</code> if a document with the primary key could not be found
	 */
	@Override
	public Document fetchByPrimaryKey(String documentId) {
		return fetchByPrimaryKey((Serializable)documentId);
	}

	/**
	 * Returns all the documents.
	 *
	 * @return the documents
	 */
	@Override
	public List<Document> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the documents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @return the range of documents
	 */
	@Override
	public List<Document> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the documents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of documents
	 */
	@Override
	public List<Document> findAll(
		int start, int end, OrderByComparator<Document> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the documents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DocumentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of documents
	 * @param end the upper bound of the range of documents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of documents
	 */
	@Override
	public List<Document> findAll(
		int start, int end, OrderByComparator<Document> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<Document> list = null;

		if (retrieveFromCache) {
			list = (List<Document>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_DOCUMENT);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DOCUMENT;

				if (pagination) {
					sql = sql.concat(DocumentModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Document>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Document>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the documents from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (Document document : findAll()) {
			remove(document);
		}
	}

	/**
	 * Returns the number of documents.
	 *
	 * @return the number of documents
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DOCUMENT);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "documentId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_DOCUMENT;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return DocumentModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the document persistence.
	 */
	@Activate
	public void activate() {
		DocumentModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		DocumentModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathWithPaginationFindByCustomerId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCustomerId",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCustomerId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCustomerId",
			new String[] {String.class.getName(), Long.class.getName()},
			DocumentModelImpl.CUSTOMERID_COLUMN_BITMASK |
			DocumentModelImpl.COMPANYID_COLUMN_BITMASK |
			DocumentModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCustomerId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCustomerId",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByScreenName",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByScreenName",
			new String[] {String.class.getName(), Long.class.getName()},
			DocumentModelImpl.SCREENNAME_COLUMN_BITMASK |
			DocumentModelImpl.COMPANYID_COLUMN_BITMASK |
			DocumentModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByScreenName",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByC_C_C_T = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByC_C_C_T",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName()
			},
			DocumentModelImpl.COMPANYID_COLUMN_BITMASK |
			DocumentModelImpl.CUSTOMERID_COLUMN_BITMASK |
			DocumentModelImpl.CATEGORY_COLUMN_BITMASK |
			DocumentModelImpl.TYPE_COLUMN_BITMASK);

		_finderPathCountByC_C_C_T = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByC_C_C_T",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName()
			});

		_finderPathFetchByC_C_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByC_C_C",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			},
			DocumentModelImpl.COMPANYID_COLUMN_BITMASK |
			DocumentModelImpl.CUSTOMERID_COLUMN_BITMASK |
			DocumentModelImpl.CATEGORY_COLUMN_BITMASK);

		_finderPathCountByC_C_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByC_C_C",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			});

		_finderPathFetchByC_C_D = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByC_C_D",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			},
			DocumentModelImpl.COMPANYID_COLUMN_BITMASK |
			DocumentModelImpl.CUSTOMERID_COLUMN_BITMASK |
			DocumentModelImpl.DOCUMENTID_COLUMN_BITMASK);

		_finderPathCountByC_C_D = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByC_C_D",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			});

		_finderPathFetchByC_C_N = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DocumentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByC_C_N",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			},
			DocumentModelImpl.COMPANYID_COLUMN_BITMASK |
			DocumentModelImpl.CUSTOMERID_COLUMN_BITMASK |
			DocumentModelImpl.NAME_COLUMN_BITMASK);

		_finderPathCountByC_C_N = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByC_C_N",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(DocumentImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.model.Document"),
			true);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_DOCUMENT =
		"SELECT document FROM Document document";

	private static final String _SQL_SELECT_DOCUMENT_WHERE =
		"SELECT document FROM Document document WHERE ";

	private static final String _SQL_COUNT_DOCUMENT =
		"SELECT COUNT(document) FROM Document document";

	private static final String _SQL_COUNT_DOCUMENT_WHERE =
		"SELECT COUNT(document) FROM Document document WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "document.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No Document exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No Document exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		DocumentPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"type"});

}