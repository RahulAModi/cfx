/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.service.persistence.impl;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.model.impl.AgentImpl;
import com.jio.account.model.impl.AgentModelImpl;
import com.jio.account.service.persistence.AgentPersistence;
import com.jio.account.service.persistence.impl.constants.ACCOUNTPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the agent service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = AgentPersistence.class)
@ProviderType
public class AgentPersistenceImpl
	extends BasePersistenceImpl<Agent> implements AgentPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>AgentUtil</code> to access the agent persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		AgentImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the agents where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching agents
	 */
	@Override
	public List<Agent> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agents where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	@Override
	public List<Agent> findByCompanyId(long companyId, int start, int end) {
		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agents where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Agent> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agents where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Agent> orderByComparator, boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<Agent> list = null;

		if (retrieveFromCache) {
			list = (List<Agent>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Agent agent : list) {
					if ((companyId != agent.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByCompanyId_First(
			long companyId, OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByCompanyId_First(companyId, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the first agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByCompanyId_First(
		long companyId, OrderByComparator<Agent> orderByComparator) {

		List<Agent> list = findByCompanyId(companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByCompanyId_Last(
			long companyId, OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByCompanyId_Last(companyId, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the last agent in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByCompanyId_Last(
		long companyId, OrderByComparator<Agent> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<Agent> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agents before and after the current agent in the ordered set where companyId = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent[] findByCompanyId_PrevAndNext(
			String agentId, long companyId,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = findByPrimaryKey(agentId);

		Session session = null;

		try {
			session = openSession();

			Agent[] array = new AgentImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, agent, companyId, orderByComparator, true);

			array[1] = agent;

			array[2] = getByCompanyId_PrevAndNext(
				session, agent, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Agent getByCompanyId_PrevAndNext(
		Session session, Agent agent, long companyId,
		OrderByComparator<Agent> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_AGENT_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(agent)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Agent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agents where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (Agent agent :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(agent);
		}
	}

	/**
	 * Returns the number of agents where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching agents
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"agent.companyId = ?";

	private FinderPath _finderPathFetchByScreenName;
	private FinderPath _finderPathCountByScreenName;

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByScreenName(long companyId, String screenName)
		throws NoSuchAgentException {

		Agent agent = fetchByScreenName(companyId, screenName);

		if (agent == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", screenName=");
			msg.append(screenName);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchAgentException(msg.toString());
		}

		return agent;
	}

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByScreenName(long companyId, String screenName) {
		return fetchByScreenName(companyId, screenName, true);
	}

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByScreenName(
		long companyId, String screenName, boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");

		Object[] finderArgs = new Object[] {companyId, screenName};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByScreenName, finderArgs, this);
		}

		if (result instanceof Agent) {
			Agent agent = (Agent)result;

			if ((companyId != agent.getCompanyId()) ||
				!Objects.equals(screenName, agent.getScreenName())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				List<Agent> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByScreenName, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"AgentPersistenceImpl.fetchByScreenName(long, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Agent agent = list.get(0);

					result = agent;

					cacheResult(agent);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByScreenName, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Agent)result;
		}
	}

	/**
	 * Removes the agent where companyId = &#63; and screenName = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the agent that was removed
	 */
	@Override
	public Agent removeByScreenName(long companyId, String screenName)
		throws NoSuchAgentException {

		Agent agent = findByScreenName(companyId, screenName);

		return remove(agent);
	}

	/**
	 * Returns the number of agents where companyId = &#63; and screenName = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @return the number of matching agents
	 */
	@Override
	public int countByScreenName(long companyId, String screenName) {
		screenName = Objects.toString(screenName, "");

		FinderPath finderPath = _finderPathCountByScreenName;

		Object[] finderArgs = new Object[] {companyId, screenName};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_SCREENNAME_COMPANYID_2);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(_FINDER_COLUMN_SCREENNAME_SCREENNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SCREENNAME_COMPANYID_2 =
		"agent.companyId = ? AND ";

	private static final String _FINDER_COLUMN_SCREENNAME_SCREENNAME_2 =
		"agent.screenName = ?";

	private static final String _FINDER_COLUMN_SCREENNAME_SCREENNAME_3 =
		"(agent.screenName IS NULL OR agent.screenName = '')";

	private FinderPath _finderPathFetchByLegacyCode;
	private FinderPath _finderPathCountByLegacyCode;

	/**
	 * Returns the agent where companyId = &#63; and legacyCode = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByLegacyCode(long companyId, String legacyCode)
		throws NoSuchAgentException {

		Agent agent = fetchByLegacyCode(companyId, legacyCode);

		if (agent == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", legacyCode=");
			msg.append(legacyCode);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchAgentException(msg.toString());
		}

		return agent;
	}

	/**
	 * Returns the agent where companyId = &#63; and legacyCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByLegacyCode(long companyId, String legacyCode) {
		return fetchByLegacyCode(companyId, legacyCode, true);
	}

	/**
	 * Returns the agent where companyId = &#63; and legacyCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByLegacyCode(
		long companyId, String legacyCode, boolean retrieveFromCache) {

		legacyCode = Objects.toString(legacyCode, "");

		Object[] finderArgs = new Object[] {companyId, legacyCode};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByLegacyCode, finderArgs, this);
		}

		if (result instanceof Agent) {
			Agent agent = (Agent)result;

			if ((companyId != agent.getCompanyId()) ||
				!Objects.equals(legacyCode, agent.getLegacyCode())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_LEGACYCODE_COMPANYID_2);

			boolean bindLegacyCode = false;

			if (legacyCode.isEmpty()) {
				query.append(_FINDER_COLUMN_LEGACYCODE_LEGACYCODE_3);
			}
			else {
				bindLegacyCode = true;

				query.append(_FINDER_COLUMN_LEGACYCODE_LEGACYCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindLegacyCode) {
					qPos.add(legacyCode);
				}

				List<Agent> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByLegacyCode, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"AgentPersistenceImpl.fetchByLegacyCode(long, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Agent agent = list.get(0);

					result = agent;

					cacheResult(agent);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByLegacyCode, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Agent)result;
		}
	}

	/**
	 * Removes the agent where companyId = &#63; and legacyCode = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the agent that was removed
	 */
	@Override
	public Agent removeByLegacyCode(long companyId, String legacyCode)
		throws NoSuchAgentException {

		Agent agent = findByLegacyCode(companyId, legacyCode);

		return remove(agent);
	}

	/**
	 * Returns the number of agents where companyId = &#63; and legacyCode = &#63;.
	 *
	 * @param companyId the company ID
	 * @param legacyCode the legacy code
	 * @return the number of matching agents
	 */
	@Override
	public int countByLegacyCode(long companyId, String legacyCode) {
		legacyCode = Objects.toString(legacyCode, "");

		FinderPath finderPath = _finderPathCountByLegacyCode;

		Object[] finderArgs = new Object[] {companyId, legacyCode};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_LEGACYCODE_COMPANYID_2);

			boolean bindLegacyCode = false;

			if (legacyCode.isEmpty()) {
				query.append(_FINDER_COLUMN_LEGACYCODE_LEGACYCODE_3);
			}
			else {
				bindLegacyCode = true;

				query.append(_FINDER_COLUMN_LEGACYCODE_LEGACYCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindLegacyCode) {
					qPos.add(legacyCode);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_LEGACYCODE_COMPANYID_2 =
		"agent.companyId = ? AND ";

	private static final String _FINDER_COLUMN_LEGACYCODE_LEGACYCODE_2 =
		"agent.legacyCode = ?";

	private static final String _FINDER_COLUMN_LEGACYCODE_LEGACYCODE_3 =
		"(agent.legacyCode IS NULL OR agent.legacyCode = '')";

	private FinderPath _finderPathFetchByClientCode;
	private FinderPath _finderPathCountByClientCode;

	/**
	 * Returns the agent where companyId = &#63; and clientCode = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByClientCode(long companyId, String clientCode)
		throws NoSuchAgentException {

		Agent agent = fetchByClientCode(companyId, clientCode);

		if (agent == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", clientCode=");
			msg.append(clientCode);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchAgentException(msg.toString());
		}

		return agent;
	}

	/**
	 * Returns the agent where companyId = &#63; and clientCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByClientCode(long companyId, String clientCode) {
		return fetchByClientCode(companyId, clientCode, true);
	}

	/**
	 * Returns the agent where companyId = &#63; and clientCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByClientCode(
		long companyId, String clientCode, boolean retrieveFromCache) {

		clientCode = Objects.toString(clientCode, "");

		Object[] finderArgs = new Object[] {companyId, clientCode};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByClientCode, finderArgs, this);
		}

		if (result instanceof Agent) {
			Agent agent = (Agent)result;

			if ((companyId != agent.getCompanyId()) ||
				!Objects.equals(clientCode, agent.getClientCode())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_CLIENTCODE_COMPANYID_2);

			boolean bindClientCode = false;

			if (clientCode.isEmpty()) {
				query.append(_FINDER_COLUMN_CLIENTCODE_CLIENTCODE_3);
			}
			else {
				bindClientCode = true;

				query.append(_FINDER_COLUMN_CLIENTCODE_CLIENTCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindClientCode) {
					qPos.add(clientCode);
				}

				List<Agent> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByClientCode, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"AgentPersistenceImpl.fetchByClientCode(long, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Agent agent = list.get(0);

					result = agent;

					cacheResult(agent);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByClientCode, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Agent)result;
		}
	}

	/**
	 * Removes the agent where companyId = &#63; and clientCode = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the agent that was removed
	 */
	@Override
	public Agent removeByClientCode(long companyId, String clientCode)
		throws NoSuchAgentException {

		Agent agent = findByClientCode(companyId, clientCode);

		return remove(agent);
	}

	/**
	 * Returns the number of agents where companyId = &#63; and clientCode = &#63;.
	 *
	 * @param companyId the company ID
	 * @param clientCode the client code
	 * @return the number of matching agents
	 */
	@Override
	public int countByClientCode(long companyId, String clientCode) {
		clientCode = Objects.toString(clientCode, "");

		FinderPath finderPath = _finderPathCountByClientCode;

		Object[] finderArgs = new Object[] {companyId, clientCode};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_CLIENTCODE_COMPANYID_2);

			boolean bindClientCode = false;

			if (clientCode.isEmpty()) {
				query.append(_FINDER_COLUMN_CLIENTCODE_CLIENTCODE_3);
			}
			else {
				bindClientCode = true;

				query.append(_FINDER_COLUMN_CLIENTCODE_CLIENTCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindClientCode) {
					qPos.add(clientCode);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CLIENTCODE_COMPANYID_2 =
		"agent.companyId = ? AND ";

	private static final String _FINDER_COLUMN_CLIENTCODE_CLIENTCODE_2 =
		"agent.clientCode = ?";

	private static final String _FINDER_COLUMN_CLIENTCODE_CLIENTCODE_3 =
		"(agent.clientCode IS NULL OR agent.clientCode = '')";

	private FinderPath _finderPathWithPaginationFindByParentCodeAndIsPrimary;
	private FinderPath _finderPathWithoutPaginationFindByParentCodeAndIsPrimary;
	private FinderPath _finderPathCountByParentCodeAndIsPrimary;

	/**
	 * Returns all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @return the matching agents
	 */
	@Override
	public List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary) {

		return findByParentCodeAndIsPrimary(
			companyId, parentCode, primary, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	@Override
	public List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary, int start,
		int end) {

		return findByParentCodeAndIsPrimary(
			companyId, parentCode, primary, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary, int start, int end,
		OrderByComparator<Agent> orderByComparator) {

		return findByParentCodeAndIsPrimary(
			companyId, parentCode, primary, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary, int start, int end,
		OrderByComparator<Agent> orderByComparator, boolean retrieveFromCache) {

		parentCode = Objects.toString(parentCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath =
				_finderPathWithoutPaginationFindByParentCodeAndIsPrimary;
			finderArgs = new Object[] {companyId, parentCode, primary};
		}
		else {
			finderPath = _finderPathWithPaginationFindByParentCodeAndIsPrimary;
			finderArgs = new Object[] {
				companyId, parentCode, primary, start, end, orderByComparator
			};
		}

		List<Agent> list = null;

		if (retrieveFromCache) {
			list = (List<Agent>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Agent agent : list) {
					if ((companyId != agent.getCompanyId()) ||
						!parentCode.equals(agent.getParentCode()) ||
						(primary != agent.isPrimary())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_COMPANYID_2);

			boolean bindParentCode = false;

			if (parentCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_3);
			}
			else {
				bindParentCode = true;

				query.append(
					_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_2);
			}

			query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PRIMARY_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindParentCode) {
					qPos.add(parentCode);
				}

				qPos.add(primary);

				if (!pagination) {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByParentCodeAndIsPrimary_First(
			long companyId, String parentCode, boolean primary,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByParentCodeAndIsPrimary_First(
			companyId, parentCode, primary, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", parentCode=");
		msg.append(parentCode);

		msg.append(", primary=");
		msg.append(primary);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByParentCodeAndIsPrimary_First(
		long companyId, String parentCode, boolean primary,
		OrderByComparator<Agent> orderByComparator) {

		List<Agent> list = findByParentCodeAndIsPrimary(
			companyId, parentCode, primary, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByParentCodeAndIsPrimary_Last(
			long companyId, String parentCode, boolean primary,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByParentCodeAndIsPrimary_Last(
			companyId, parentCode, primary, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", parentCode=");
		msg.append(parentCode);

		msg.append(", primary=");
		msg.append(primary);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByParentCodeAndIsPrimary_Last(
		long companyId, String parentCode, boolean primary,
		OrderByComparator<Agent> orderByComparator) {

		int count = countByParentCodeAndIsPrimary(
			companyId, parentCode, primary);

		if (count == 0) {
			return null;
		}

		List<Agent> list = findByParentCodeAndIsPrimary(
			companyId, parentCode, primary, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agents before and after the current agent in the ordered set where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent[] findByParentCodeAndIsPrimary_PrevAndNext(
			String agentId, long companyId, String parentCode, boolean primary,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		parentCode = Objects.toString(parentCode, "");

		Agent agent = findByPrimaryKey(agentId);

		Session session = null;

		try {
			session = openSession();

			Agent[] array = new AgentImpl[3];

			array[0] = getByParentCodeAndIsPrimary_PrevAndNext(
				session, agent, companyId, parentCode, primary,
				orderByComparator, true);

			array[1] = agent;

			array[2] = getByParentCodeAndIsPrimary_PrevAndNext(
				session, agent, companyId, parentCode, primary,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Agent getByParentCodeAndIsPrimary_PrevAndNext(
		Session session, Agent agent, long companyId, String parentCode,
		boolean primary, OrderByComparator<Agent> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_AGENT_WHERE);

		query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_COMPANYID_2);

		boolean bindParentCode = false;

		if (parentCode.isEmpty()) {
			query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_3);
		}
		else {
			bindParentCode = true;

			query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_2);
		}

		query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PRIMARY_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (bindParentCode) {
			qPos.add(parentCode);
		}

		qPos.add(primary);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(agent)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Agent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agents where companyId = &#63; and parentCode = &#63; and primary = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 */
	@Override
	public void removeByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary) {

		for (Agent agent :
				findByParentCodeAndIsPrimary(
					companyId, parentCode, primary, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(agent);
		}
	}

	/**
	 * Returns the number of agents where companyId = &#63; and parentCode = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param parentCode the parent code
	 * @param primary the primary
	 * @return the number of matching agents
	 */
	@Override
	public int countByParentCodeAndIsPrimary(
		long companyId, String parentCode, boolean primary) {

		parentCode = Objects.toString(parentCode, "");

		FinderPath finderPath = _finderPathCountByParentCodeAndIsPrimary;

		Object[] finderArgs = new Object[] {companyId, parentCode, primary};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_COMPANYID_2);

			boolean bindParentCode = false;

			if (parentCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_3);
			}
			else {
				bindParentCode = true;

				query.append(
					_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_2);
			}

			query.append(_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PRIMARY_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindParentCode) {
					qPos.add(parentCode);
				}

				qPos.add(primary);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_PARENTCODEANDISPRIMARY_COMPANYID_2 =
			"agent.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_2 =
			"agent.parentCode = ? AND ";

	private static final String
		_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PARENTCODE_3 =
			"(agent.parentCode IS NULL OR agent.parentCode = '') AND ";

	private static final String
		_FINDER_COLUMN_PARENTCODEANDISPRIMARY_PRIMARY_2 = "agent.primary = ?";

	private FinderPath _finderPathWithPaginationFindByParentCode;
	private FinderPath _finderPathWithoutPaginationFindByParentCode;
	private FinderPath _finderPathCountByParentCode;

	/**
	 * Returns all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @return the matching agents
	 */
	@Override
	public List<Agent> findByParentCode(String parentCode, long companyId) {
		return findByParentCode(
			parentCode, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	@Override
	public List<Agent> findByParentCode(
		String parentCode, long companyId, int start, int end) {

		return findByParentCode(parentCode, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByParentCode(
		String parentCode, long companyId, int start, int end,
		OrderByComparator<Agent> orderByComparator) {

		return findByParentCode(
			parentCode, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByParentCode(
		String parentCode, long companyId, int start, int end,
		OrderByComparator<Agent> orderByComparator, boolean retrieveFromCache) {

		parentCode = Objects.toString(parentCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByParentCode;
			finderArgs = new Object[] {parentCode, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByParentCode;
			finderArgs = new Object[] {
				parentCode, companyId, start, end, orderByComparator
			};
		}

		List<Agent> list = null;

		if (retrieveFromCache) {
			list = (List<Agent>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Agent agent : list) {
					if (!parentCode.equals(agent.getParentCode()) ||
						(companyId != agent.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENT_WHERE);

			boolean bindParentCode = false;

			if (parentCode.isEmpty()) {
				query.append(_FINDER_COLUMN_PARENTCODE_PARENTCODE_3);
			}
			else {
				bindParentCode = true;

				query.append(_FINDER_COLUMN_PARENTCODE_PARENTCODE_2);
			}

			query.append(_FINDER_COLUMN_PARENTCODE_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindParentCode) {
					qPos.add(parentCode);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByParentCode_First(
			String parentCode, long companyId,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByParentCode_First(
			parentCode, companyId, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("parentCode=");
		msg.append(parentCode);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the first agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByParentCode_First(
		String parentCode, long companyId,
		OrderByComparator<Agent> orderByComparator) {

		List<Agent> list = findByParentCode(
			parentCode, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByParentCode_Last(
			String parentCode, long companyId,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByParentCode_Last(
			parentCode, companyId, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("parentCode=");
		msg.append(parentCode);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the last agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByParentCode_Last(
		String parentCode, long companyId,
		OrderByComparator<Agent> orderByComparator) {

		int count = countByParentCode(parentCode, companyId);

		if (count == 0) {
			return null;
		}

		List<Agent> list = findByParentCode(
			parentCode, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agents before and after the current agent in the ordered set where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent[] findByParentCode_PrevAndNext(
			String agentId, String parentCode, long companyId,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		parentCode = Objects.toString(parentCode, "");

		Agent agent = findByPrimaryKey(agentId);

		Session session = null;

		try {
			session = openSession();

			Agent[] array = new AgentImpl[3];

			array[0] = getByParentCode_PrevAndNext(
				session, agent, parentCode, companyId, orderByComparator, true);

			array[1] = agent;

			array[2] = getByParentCode_PrevAndNext(
				session, agent, parentCode, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Agent getByParentCode_PrevAndNext(
		Session session, Agent agent, String parentCode, long companyId,
		OrderByComparator<Agent> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENT_WHERE);

		boolean bindParentCode = false;

		if (parentCode.isEmpty()) {
			query.append(_FINDER_COLUMN_PARENTCODE_PARENTCODE_3);
		}
		else {
			bindParentCode = true;

			query.append(_FINDER_COLUMN_PARENTCODE_PARENTCODE_2);
		}

		query.append(_FINDER_COLUMN_PARENTCODE_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindParentCode) {
			qPos.add(parentCode);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(agent)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Agent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agents where parentCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 */
	@Override
	public void removeByParentCode(String parentCode, long companyId) {
		for (Agent agent :
				findByParentCode(
					parentCode, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(agent);
		}
	}

	/**
	 * Returns the number of agents where parentCode = &#63; and companyId = &#63;.
	 *
	 * @param parentCode the parent code
	 * @param companyId the company ID
	 * @return the number of matching agents
	 */
	@Override
	public int countByParentCode(String parentCode, long companyId) {
		parentCode = Objects.toString(parentCode, "");

		FinderPath finderPath = _finderPathCountByParentCode;

		Object[] finderArgs = new Object[] {parentCode, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENT_WHERE);

			boolean bindParentCode = false;

			if (parentCode.isEmpty()) {
				query.append(_FINDER_COLUMN_PARENTCODE_PARENTCODE_3);
			}
			else {
				bindParentCode = true;

				query.append(_FINDER_COLUMN_PARENTCODE_PARENTCODE_2);
			}

			query.append(_FINDER_COLUMN_PARENTCODE_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindParentCode) {
					qPos.add(parentCode);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PARENTCODE_PARENTCODE_2 =
		"agent.parentCode = ? AND ";

	private static final String _FINDER_COLUMN_PARENTCODE_PARENTCODE_3 =
		"(agent.parentCode IS NULL OR agent.parentCode = '') AND ";

	private static final String _FINDER_COLUMN_PARENTCODE_COMPANYID_2 =
		"agent.companyId = ?";

	private FinderPath _finderPathFetchByScreenNameAndParentCode;
	private FinderPath _finderPathCountByScreenNameAndParentCode;

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByScreenNameAndParentCode(
			long companyId, String screenName, String parentCode)
		throws NoSuchAgentException {

		Agent agent = fetchByScreenNameAndParentCode(
			companyId, screenName, parentCode);

		if (agent == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", screenName=");
			msg.append(screenName);

			msg.append(", parentCode=");
			msg.append(parentCode);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchAgentException(msg.toString());
		}

		return agent;
	}

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByScreenNameAndParentCode(
		long companyId, String screenName, String parentCode) {

		return fetchByScreenNameAndParentCode(
			companyId, screenName, parentCode, true);
	}

	/**
	 * Returns the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByScreenNameAndParentCode(
		long companyId, String screenName, String parentCode,
		boolean retrieveFromCache) {

		screenName = Objects.toString(screenName, "");
		parentCode = Objects.toString(parentCode, "");

		Object[] finderArgs = new Object[] {companyId, screenName, parentCode};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByScreenNameAndParentCode, finderArgs, this);
		}

		if (result instanceof Agent) {
			Agent agent = (Agent)result;

			if ((companyId != agent.getCompanyId()) ||
				!Objects.equals(screenName, agent.getScreenName()) ||
				!Objects.equals(parentCode, agent.getParentCode())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_COMPANYID_2);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_SCREENNAME_2);
			}

			boolean bindParentCode = false;

			if (parentCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_PARENTCODE_3);
			}
			else {
				bindParentCode = true;

				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_PARENTCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				if (bindParentCode) {
					qPos.add(parentCode);
				}

				List<Agent> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByScreenNameAndParentCode, finderArgs,
						list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"AgentPersistenceImpl.fetchByScreenNameAndParentCode(long, String, String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Agent agent = list.get(0);

					result = agent;

					cacheResult(agent);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByScreenNameAndParentCode, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Agent)result;
		}
	}

	/**
	 * Removes the agent where companyId = &#63; and screenName = &#63; and parentCode = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the agent that was removed
	 */
	@Override
	public Agent removeByScreenNameAndParentCode(
			long companyId, String screenName, String parentCode)
		throws NoSuchAgentException {

		Agent agent = findByScreenNameAndParentCode(
			companyId, screenName, parentCode);

		return remove(agent);
	}

	/**
	 * Returns the number of agents where companyId = &#63; and screenName = &#63; and parentCode = &#63;.
	 *
	 * @param companyId the company ID
	 * @param screenName the screen name
	 * @param parentCode the parent code
	 * @return the number of matching agents
	 */
	@Override
	public int countByScreenNameAndParentCode(
		long companyId, String screenName, String parentCode) {

		screenName = Objects.toString(screenName, "");
		parentCode = Objects.toString(parentCode, "");

		FinderPath finderPath = _finderPathCountByScreenNameAndParentCode;

		Object[] finderArgs = new Object[] {companyId, screenName, parentCode};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_COMPANYID_2);

			boolean bindScreenName = false;

			if (screenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_SCREENNAME_3);
			}
			else {
				bindScreenName = true;

				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_SCREENNAME_2);
			}

			boolean bindParentCode = false;

			if (parentCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_PARENTCODE_3);
			}
			else {
				bindParentCode = true;

				query.append(
					_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_PARENTCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindScreenName) {
					qPos.add(screenName);
				}

				if (bindParentCode) {
					qPos.add(parentCode);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_COMPANYID_2 =
			"agent.companyId = ? AND ";

	private static final String
		_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_SCREENNAME_2 =
			"agent.screenName = ? AND ";

	private static final String
		_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_SCREENNAME_3 =
			"(agent.screenName IS NULL OR agent.screenName = '') AND ";

	private static final String
		_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_PARENTCODE_2 =
			"agent.parentCode = ?";

	private static final String
		_FINDER_COLUMN_SCREENNAMEANDPARENTCODE_PARENTCODE_3 =
			"(agent.parentCode IS NULL OR agent.parentCode = '')";

	private FinderPath _finderPathWithPaginationFindByPrimaryStatus;
	private FinderPath _finderPathWithoutPaginationFindByPrimaryStatus;
	private FinderPath _finderPathCountByPrimaryStatus;

	/**
	 * Returns all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @return the matching agents
	 */
	@Override
	public List<Agent> findByPrimaryStatus(long companyId, boolean primary) {
		return findByPrimaryStatus(
			companyId, primary, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of matching agents
	 */
	@Override
	public List<Agent> findByPrimaryStatus(
		long companyId, boolean primary, int start, int end) {

		return findByPrimaryStatus(companyId, primary, start, end, null);
	}

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByPrimaryStatus(
		long companyId, boolean primary, int start, int end,
		OrderByComparator<Agent> orderByComparator) {

		return findByPrimaryStatus(
			companyId, primary, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agents where companyId = &#63; and primary = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching agents
	 */
	@Override
	public List<Agent> findByPrimaryStatus(
		long companyId, boolean primary, int start, int end,
		OrderByComparator<Agent> orderByComparator, boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByPrimaryStatus;
			finderArgs = new Object[] {companyId, primary};
		}
		else {
			finderPath = _finderPathWithPaginationFindByPrimaryStatus;
			finderArgs = new Object[] {
				companyId, primary, start, end, orderByComparator
			};
		}

		List<Agent> list = null;

		if (retrieveFromCache) {
			list = (List<Agent>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Agent agent : list) {
					if ((companyId != agent.getCompanyId()) ||
						(primary != agent.isPrimary())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_PRIMARYSTATUS_COMPANYID_2);

			query.append(_FINDER_COLUMN_PRIMARYSTATUS_PRIMARY_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(AgentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				qPos.add(primary);

				if (!pagination) {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByPrimaryStatus_First(
			long companyId, boolean primary,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByPrimaryStatus_First(
			companyId, primary, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", primary=");
		msg.append(primary);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the first agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByPrimaryStatus_First(
		long companyId, boolean primary,
		OrderByComparator<Agent> orderByComparator) {

		List<Agent> list = findByPrimaryStatus(
			companyId, primary, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent
	 * @throws NoSuchAgentException if a matching agent could not be found
	 */
	@Override
	public Agent findByPrimaryStatus_Last(
			long companyId, boolean primary,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = fetchByPrimaryStatus_Last(
			companyId, primary, orderByComparator);

		if (agent != null) {
			return agent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(", primary=");
		msg.append(primary);

		msg.append("}");

		throw new NoSuchAgentException(msg.toString());
	}

	/**
	 * Returns the last agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching agent, or <code>null</code> if a matching agent could not be found
	 */
	@Override
	public Agent fetchByPrimaryStatus_Last(
		long companyId, boolean primary,
		OrderByComparator<Agent> orderByComparator) {

		int count = countByPrimaryStatus(companyId, primary);

		if (count == 0) {
			return null;
		}

		List<Agent> list = findByPrimaryStatus(
			companyId, primary, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the agents before and after the current agent in the ordered set where companyId = &#63; and primary = &#63;.
	 *
	 * @param agentId the primary key of the current agent
	 * @param companyId the company ID
	 * @param primary the primary
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent[] findByPrimaryStatus_PrevAndNext(
			String agentId, long companyId, boolean primary,
			OrderByComparator<Agent> orderByComparator)
		throws NoSuchAgentException {

		Agent agent = findByPrimaryKey(agentId);

		Session session = null;

		try {
			session = openSession();

			Agent[] array = new AgentImpl[3];

			array[0] = getByPrimaryStatus_PrevAndNext(
				session, agent, companyId, primary, orderByComparator, true);

			array[1] = agent;

			array[2] = getByPrimaryStatus_PrevAndNext(
				session, agent, companyId, primary, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Agent getByPrimaryStatus_PrevAndNext(
		Session session, Agent agent, long companyId, boolean primary,
		OrderByComparator<Agent> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_AGENT_WHERE);

		query.append(_FINDER_COLUMN_PRIMARYSTATUS_COMPANYID_2);

		query.append(_FINDER_COLUMN_PRIMARYSTATUS_PRIMARY_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AgentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		qPos.add(primary);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(agent)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Agent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the agents where companyId = &#63; and primary = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 */
	@Override
	public void removeByPrimaryStatus(long companyId, boolean primary) {
		for (Agent agent :
				findByPrimaryStatus(
					companyId, primary, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(agent);
		}
	}

	/**
	 * Returns the number of agents where companyId = &#63; and primary = &#63;.
	 *
	 * @param companyId the company ID
	 * @param primary the primary
	 * @return the number of matching agents
	 */
	@Override
	public int countByPrimaryStatus(long companyId, boolean primary) {
		FinderPath finderPath = _finderPathCountByPrimaryStatus;

		Object[] finderArgs = new Object[] {companyId, primary};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_AGENT_WHERE);

			query.append(_FINDER_COLUMN_PRIMARYSTATUS_COMPANYID_2);

			query.append(_FINDER_COLUMN_PRIMARYSTATUS_PRIMARY_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				qPos.add(primary);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PRIMARYSTATUS_COMPANYID_2 =
		"agent.companyId = ? AND ";

	private static final String _FINDER_COLUMN_PRIMARYSTATUS_PRIMARY_2 =
		"agent.primary = ?";

	public AgentPersistenceImpl() {
		setModelClass(Agent.class);

		setModelImplClass(AgentImpl.class);
		setModelPKClass(String.class);

		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("primary", "primary_");

		setDBColumnNames(dbColumnNames);
	}

	/**
	 * Caches the agent in the entity cache if it is enabled.
	 *
	 * @param agent the agent
	 */
	@Override
	public void cacheResult(Agent agent) {
		entityCache.putResult(
			entityCacheEnabled, AgentImpl.class, agent.getPrimaryKey(), agent);

		finderCache.putResult(
			_finderPathFetchByScreenName,
			new Object[] {agent.getCompanyId(), agent.getScreenName()}, agent);

		finderCache.putResult(
			_finderPathFetchByLegacyCode,
			new Object[] {agent.getCompanyId(), agent.getLegacyCode()}, agent);

		finderCache.putResult(
			_finderPathFetchByClientCode,
			new Object[] {agent.getCompanyId(), agent.getClientCode()}, agent);

		finderCache.putResult(
			_finderPathFetchByScreenNameAndParentCode,
			new Object[] {
				agent.getCompanyId(), agent.getScreenName(),
				agent.getParentCode()
			},
			agent);

		agent.resetOriginalValues();
	}

	/**
	 * Caches the agents in the entity cache if it is enabled.
	 *
	 * @param agents the agents
	 */
	@Override
	public void cacheResult(List<Agent> agents) {
		for (Agent agent : agents) {
			if (entityCache.getResult(
					entityCacheEnabled, AgentImpl.class,
					agent.getPrimaryKey()) == null) {

				cacheResult(agent);
			}
			else {
				agent.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all agents.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(AgentImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the agent.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Agent agent) {
		entityCache.removeResult(
			entityCacheEnabled, AgentImpl.class, agent.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache((AgentModelImpl)agent, true);
	}

	@Override
	public void clearCache(List<Agent> agents) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Agent agent : agents) {
			entityCache.removeResult(
				entityCacheEnabled, AgentImpl.class, agent.getPrimaryKey());

			clearUniqueFindersCache((AgentModelImpl)agent, true);
		}
	}

	protected void cacheUniqueFindersCache(AgentModelImpl agentModelImpl) {
		Object[] args = new Object[] {
			agentModelImpl.getCompanyId(), agentModelImpl.getScreenName()
		};

		finderCache.putResult(
			_finderPathCountByScreenName, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByScreenName, args, agentModelImpl, false);

		args = new Object[] {
			agentModelImpl.getCompanyId(), agentModelImpl.getLegacyCode()
		};

		finderCache.putResult(
			_finderPathCountByLegacyCode, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByLegacyCode, args, agentModelImpl, false);

		args = new Object[] {
			agentModelImpl.getCompanyId(), agentModelImpl.getClientCode()
		};

		finderCache.putResult(
			_finderPathCountByClientCode, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByClientCode, args, agentModelImpl, false);

		args = new Object[] {
			agentModelImpl.getCompanyId(), agentModelImpl.getScreenName(),
			agentModelImpl.getParentCode()
		};

		finderCache.putResult(
			_finderPathCountByScreenNameAndParentCode, args, Long.valueOf(1),
			false);
		finderCache.putResult(
			_finderPathFetchByScreenNameAndParentCode, args, agentModelImpl,
			false);
	}

	protected void clearUniqueFindersCache(
		AgentModelImpl agentModelImpl, boolean clearCurrent) {

		if (clearCurrent) {
			Object[] args = new Object[] {
				agentModelImpl.getCompanyId(), agentModelImpl.getScreenName()
			};

			finderCache.removeResult(_finderPathCountByScreenName, args);
			finderCache.removeResult(_finderPathFetchByScreenName, args);
		}

		if ((agentModelImpl.getColumnBitmask() &
			 _finderPathFetchByScreenName.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				agentModelImpl.getOriginalCompanyId(),
				agentModelImpl.getOriginalScreenName()
			};

			finderCache.removeResult(_finderPathCountByScreenName, args);
			finderCache.removeResult(_finderPathFetchByScreenName, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				agentModelImpl.getCompanyId(), agentModelImpl.getLegacyCode()
			};

			finderCache.removeResult(_finderPathCountByLegacyCode, args);
			finderCache.removeResult(_finderPathFetchByLegacyCode, args);
		}

		if ((agentModelImpl.getColumnBitmask() &
			 _finderPathFetchByLegacyCode.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				agentModelImpl.getOriginalCompanyId(),
				agentModelImpl.getOriginalLegacyCode()
			};

			finderCache.removeResult(_finderPathCountByLegacyCode, args);
			finderCache.removeResult(_finderPathFetchByLegacyCode, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				agentModelImpl.getCompanyId(), agentModelImpl.getClientCode()
			};

			finderCache.removeResult(_finderPathCountByClientCode, args);
			finderCache.removeResult(_finderPathFetchByClientCode, args);
		}

		if ((agentModelImpl.getColumnBitmask() &
			 _finderPathFetchByClientCode.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				agentModelImpl.getOriginalCompanyId(),
				agentModelImpl.getOriginalClientCode()
			};

			finderCache.removeResult(_finderPathCountByClientCode, args);
			finderCache.removeResult(_finderPathFetchByClientCode, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				agentModelImpl.getCompanyId(), agentModelImpl.getScreenName(),
				agentModelImpl.getParentCode()
			};

			finderCache.removeResult(
				_finderPathCountByScreenNameAndParentCode, args);
			finderCache.removeResult(
				_finderPathFetchByScreenNameAndParentCode, args);
		}

		if ((agentModelImpl.getColumnBitmask() &
			 _finderPathFetchByScreenNameAndParentCode.getColumnBitmask()) !=
				 0) {

			Object[] args = new Object[] {
				agentModelImpl.getOriginalCompanyId(),
				agentModelImpl.getOriginalScreenName(),
				agentModelImpl.getOriginalParentCode()
			};

			finderCache.removeResult(
				_finderPathCountByScreenNameAndParentCode, args);
			finderCache.removeResult(
				_finderPathFetchByScreenNameAndParentCode, args);
		}
	}

	/**
	 * Creates a new agent with the primary key. Does not add the agent to the database.
	 *
	 * @param agentId the primary key for the new agent
	 * @return the new agent
	 */
	@Override
	public Agent create(String agentId) {
		Agent agent = new AgentImpl();

		agent.setNew(true);
		agent.setPrimaryKey(agentId);

		agent.setCompanyId(companyProvider.getCompanyId());

		return agent;
	}

	/**
	 * Removes the agent with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent that was removed
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent remove(String agentId) throws NoSuchAgentException {
		return remove((Serializable)agentId);
	}

	/**
	 * Removes the agent with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the agent
	 * @return the agent that was removed
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent remove(Serializable primaryKey) throws NoSuchAgentException {
		Session session = null;

		try {
			session = openSession();

			Agent agent = (Agent)session.get(AgentImpl.class, primaryKey);

			if (agent == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchAgentException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(agent);
		}
		catch (NoSuchAgentException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Agent removeImpl(Agent agent) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(agent)) {
				agent = (Agent)session.get(
					AgentImpl.class, agent.getPrimaryKeyObj());
			}

			if (agent != null) {
				session.delete(agent);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (agent != null) {
			clearCache(agent);
		}

		return agent;
	}

	@Override
	public Agent updateImpl(Agent agent) {
		boolean isNew = agent.isNew();

		if (!(agent instanceof AgentModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(agent.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(agent);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in agent proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom Agent implementation " +
					agent.getClass());
		}

		AgentModelImpl agentModelImpl = (AgentModelImpl)agent;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (agent.getCreateDate() == null)) {
			if (serviceContext == null) {
				agent.setCreateDate(now);
			}
			else {
				agent.setCreateDate(serviceContext.getCreateDate(now));
			}
		}

		if (!agentModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				agent.setModifiedDate(now);
			}
			else {
				agent.setModifiedDate(serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (agent.isNew()) {
				session.save(agent);

				agent.setNew(false);
			}
			else {
				agent = (Agent)session.merge(agent);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {agentModelImpl.getCompanyId()};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			args = new Object[] {
				agentModelImpl.getCompanyId(), agentModelImpl.getParentCode(),
				agentModelImpl.isPrimary()
			};

			finderCache.removeResult(
				_finderPathCountByParentCodeAndIsPrimary, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByParentCodeAndIsPrimary, args);

			args = new Object[] {
				agentModelImpl.getParentCode(), agentModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByParentCode, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByParentCode, args);

			args = new Object[] {
				agentModelImpl.getCompanyId(), agentModelImpl.isPrimary()
			};

			finderCache.removeResult(_finderPathCountByPrimaryStatus, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByPrimaryStatus, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((agentModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {agentModelImpl.getCompanyId()};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}

			if ((agentModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByParentCodeAndIsPrimary.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentModelImpl.getOriginalCompanyId(),
					agentModelImpl.getOriginalParentCode(),
					agentModelImpl.getOriginalPrimary()
				};

				finderCache.removeResult(
					_finderPathCountByParentCodeAndIsPrimary, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByParentCodeAndIsPrimary,
					args);

				args = new Object[] {
					agentModelImpl.getCompanyId(),
					agentModelImpl.getParentCode(), agentModelImpl.isPrimary()
				};

				finderCache.removeResult(
					_finderPathCountByParentCodeAndIsPrimary, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByParentCodeAndIsPrimary,
					args);
			}

			if ((agentModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByParentCode.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentModelImpl.getOriginalParentCode(),
					agentModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByParentCode, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByParentCode, args);

				args = new Object[] {
					agentModelImpl.getParentCode(),
					agentModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByParentCode, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByParentCode, args);
			}

			if ((agentModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByPrimaryStatus.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					agentModelImpl.getOriginalCompanyId(),
					agentModelImpl.getOriginalPrimary()
				};

				finderCache.removeResult(_finderPathCountByPrimaryStatus, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByPrimaryStatus, args);

				args = new Object[] {
					agentModelImpl.getCompanyId(), agentModelImpl.isPrimary()
				};

				finderCache.removeResult(_finderPathCountByPrimaryStatus, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByPrimaryStatus, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, AgentImpl.class, agent.getPrimaryKey(), agent,
			false);

		clearUniqueFindersCache(agentModelImpl, false);
		cacheUniqueFindersCache(agentModelImpl);

		agent.resetOriginalValues();

		return agent;
	}

	/**
	 * Returns the agent with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the agent
	 * @return the agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent findByPrimaryKey(Serializable primaryKey)
		throws NoSuchAgentException {

		Agent agent = fetchByPrimaryKey(primaryKey);

		if (agent == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchAgentException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return agent;
	}

	/**
	 * Returns the agent with the primary key or throws a <code>NoSuchAgentException</code> if it could not be found.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent
	 * @throws NoSuchAgentException if a agent with the primary key could not be found
	 */
	@Override
	public Agent findByPrimaryKey(String agentId) throws NoSuchAgentException {
		return findByPrimaryKey((Serializable)agentId);
	}

	/**
	 * Returns the agent with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param agentId the primary key of the agent
	 * @return the agent, or <code>null</code> if a agent with the primary key could not be found
	 */
	@Override
	public Agent fetchByPrimaryKey(String agentId) {
		return fetchByPrimaryKey((Serializable)agentId);
	}

	/**
	 * Returns all the agents.
	 *
	 * @return the agents
	 */
	@Override
	public List<Agent> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @return the range of agents
	 */
	@Override
	public List<Agent> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of agents
	 */
	@Override
	public List<Agent> findAll(
		int start, int end, OrderByComparator<Agent> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the agents.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>AgentModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of agents
	 * @param end the upper bound of the range of agents (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of agents
	 */
	@Override
	public List<Agent> findAll(
		int start, int end, OrderByComparator<Agent> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<Agent> list = null;

		if (retrieveFromCache) {
			list = (List<Agent>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_AGENT);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_AGENT;

				if (pagination) {
					sql = sql.concat(AgentModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Agent>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the agents from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (Agent agent : findAll()) {
			remove(agent);
		}
	}

	/**
	 * Returns the number of agents.
	 *
	 * @return the number of agents
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_AGENT);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "agentId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_AGENT;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return AgentModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the agent persistence.
	 */
	@Activate
	public void activate() {
		AgentModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		AgentModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});

		_finderPathFetchByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByScreenName",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.SCREENNAME_COLUMN_BITMASK);

		_finderPathCountByScreenName = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByScreenName",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathFetchByLegacyCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByLegacyCode",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.LEGACYCODE_COLUMN_BITMASK);

		_finderPathCountByLegacyCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByLegacyCode",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathFetchByClientCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByClientCode",
			new String[] {Long.class.getName(), String.class.getName()},
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.CLIENTCODE_COLUMN_BITMASK);

		_finderPathCountByClientCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByClientCode",
			new String[] {Long.class.getName(), String.class.getName()});

		_finderPathWithPaginationFindByParentCodeAndIsPrimary = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByParentCodeAndIsPrimary",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Boolean.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByParentCodeAndIsPrimary =
			new FinderPath(
				entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
				FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
				"findByParentCodeAndIsPrimary",
				new String[] {
					Long.class.getName(), String.class.getName(),
					Boolean.class.getName()
				},
				AgentModelImpl.COMPANYID_COLUMN_BITMASK |
				AgentModelImpl.PARENTCODE_COLUMN_BITMASK |
				AgentModelImpl.PRIMARY_COLUMN_BITMASK |
				AgentModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByParentCodeAndIsPrimary = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByParentCodeAndIsPrimary",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Boolean.class.getName()
			});

		_finderPathWithPaginationFindByParentCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByParentCode",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByParentCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByParentCode",
			new String[] {String.class.getName(), Long.class.getName()},
			AgentModelImpl.PARENTCODE_COLUMN_BITMASK |
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByParentCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByParentCode",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByScreenNameAndParentCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByScreenNameAndParentCode",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			},
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.SCREENNAME_COLUMN_BITMASK |
			AgentModelImpl.PARENTCODE_COLUMN_BITMASK);

		_finderPathCountByScreenNameAndParentCode = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByScreenNameAndParentCode",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName()
			});

		_finderPathWithPaginationFindByPrimaryStatus = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByPrimaryStatus",
			new String[] {
				Long.class.getName(), Boolean.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByPrimaryStatus = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, AgentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByPrimaryStatus",
			new String[] {Long.class.getName(), Boolean.class.getName()},
			AgentModelImpl.COMPANYID_COLUMN_BITMASK |
			AgentModelImpl.PRIMARY_COLUMN_BITMASK |
			AgentModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByPrimaryStatus = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByPrimaryStatus",
			new String[] {Long.class.getName(), Boolean.class.getName()});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(AgentImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.model.Agent"),
			true);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ACCOUNTPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_AGENT =
		"SELECT agent FROM Agent agent";

	private static final String _SQL_SELECT_AGENT_WHERE =
		"SELECT agent FROM Agent agent WHERE ";

	private static final String _SQL_COUNT_AGENT =
		"SELECT COUNT(agent) FROM Agent agent";

	private static final String _SQL_COUNT_AGENT_WHERE =
		"SELECT COUNT(agent) FROM Agent agent WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "agent.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No Agent exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No Agent exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		AgentPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"primary"});

}