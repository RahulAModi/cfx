/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model.impl;

import com.jio.account.model.AgentCustomerMapping;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The cache model class for representing AgentCustomerMapping in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class AgentCustomerMappingCacheModel
	implements CacheModel<AgentCustomerMapping>, Externalizable {

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AgentCustomerMappingCacheModel)) {
			return false;
		}

		AgentCustomerMappingCacheModel agentCustomerMappingCacheModel =
			(AgentCustomerMappingCacheModel)obj;

		if (mappingId.equals(agentCustomerMappingCacheModel.mappingId)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, mappingId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{mappingId=");
		sb.append(mappingId);
		sb.append(", agentScreenName=");
		sb.append(agentScreenName);
		sb.append(", customerScreenName=");
		sb.append(customerScreenName);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createBy=");
		sb.append(createBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public AgentCustomerMapping toEntityModel() {
		AgentCustomerMappingImpl agentCustomerMappingImpl =
			new AgentCustomerMappingImpl();

		if (mappingId == null) {
			agentCustomerMappingImpl.setMappingId("");
		}
		else {
			agentCustomerMappingImpl.setMappingId(mappingId);
		}

		if (agentScreenName == null) {
			agentCustomerMappingImpl.setAgentScreenName("");
		}
		else {
			agentCustomerMappingImpl.setAgentScreenName(agentScreenName);
		}

		if (customerScreenName == null) {
			agentCustomerMappingImpl.setCustomerScreenName("");
		}
		else {
			agentCustomerMappingImpl.setCustomerScreenName(customerScreenName);
		}

		agentCustomerMappingImpl.setGroupId(groupId);
		agentCustomerMappingImpl.setCompanyId(companyId);

		if (createBy == null) {
			agentCustomerMappingImpl.setCreateBy("");
		}
		else {
			agentCustomerMappingImpl.setCreateBy(createBy);
		}

		if (createDate == Long.MIN_VALUE) {
			agentCustomerMappingImpl.setCreateDate(null);
		}
		else {
			agentCustomerMappingImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			agentCustomerMappingImpl.setModifiedDate(null);
		}
		else {
			agentCustomerMappingImpl.setModifiedDate(new Date(modifiedDate));
		}

		agentCustomerMappingImpl.resetOriginalValues();

		return agentCustomerMappingImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		mappingId = objectInput.readUTF();
		agentScreenName = objectInput.readUTF();
		customerScreenName = objectInput.readUTF();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();
		createBy = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (mappingId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(mappingId);
		}

		if (agentScreenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(agentScreenName);
		}

		if (customerScreenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerScreenName);
		}

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		if (createBy == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(createBy);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);
	}

	public String mappingId;
	public String agentScreenName;
	public String customerScreenName;
	public long groupId;
	public long companyId;
	public String createBy;
	public long createDate;
	public long modifiedDate;

}