/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.model.impl;

import com.jio.account.model.Customer;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The cache model class for representing Customer in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class CustomerCacheModel
	implements CacheModel<Customer>, Externalizable {

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CustomerCacheModel)) {
			return false;
		}

		CustomerCacheModel customerCacheModel = (CustomerCacheModel)obj;

		if (customerId.equals(customerCacheModel.customerId)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, customerId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(59);

		sb.append("{customerId=");
		sb.append(customerId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createBy=");
		sb.append(createBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", salutation=");
		sb.append(salutation);
		sb.append(", firstName=");
		sb.append(firstName);
		sb.append(", middleName=");
		sb.append(middleName);
		sb.append(", lastName=");
		sb.append(lastName);
		sb.append(", screenName=");
		sb.append(screenName);
		sb.append(", agentScreenName=");
		sb.append(agentScreenName);
		sb.append(", brmId=");
		sb.append(brmId);
		sb.append(", vcId=");
		sb.append(vcId);
		sb.append(", stbNo=");
		sb.append(stbNo);
		sb.append(", macId=");
		sb.append(macId);
		sb.append(", accountNo=");
		sb.append(accountNo);
		sb.append(", poId=");
		sb.append(poId);
		sb.append(", connectionType=");
		sb.append(connectionType);
		sb.append(", batId=");
		sb.append(batId);
		sb.append(", serviceType=");
		sb.append(serviceType);
		sb.append(", status=");
		sb.append(status);
		sb.append(", primary=");
		sb.append(primary);
		sb.append(", remark=");
		sb.append(remark);
		sb.append(", vcPoId=");
		sb.append(vcPoId);
		sb.append(", stbPoId=");
		sb.append(stbPoId);
		sb.append(", macPoId=");
		sb.append(macPoId);
		sb.append(", servicePoId=");
		sb.append(servicePoId);
		sb.append(", autoRenew=");
		sb.append(autoRenew);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Customer toEntityModel() {
		CustomerImpl customerImpl = new CustomerImpl();

		if (customerId == null) {
			customerImpl.setCustomerId("");
		}
		else {
			customerImpl.setCustomerId(customerId);
		}

		customerImpl.setGroupId(groupId);
		customerImpl.setCompanyId(companyId);

		if (createBy == null) {
			customerImpl.setCreateBy("");
		}
		else {
			customerImpl.setCreateBy(createBy);
		}

		if (createDate == Long.MIN_VALUE) {
			customerImpl.setCreateDate(null);
		}
		else {
			customerImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			customerImpl.setModifiedDate(null);
		}
		else {
			customerImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (salutation == null) {
			customerImpl.setSalutation("");
		}
		else {
			customerImpl.setSalutation(salutation);
		}

		if (firstName == null) {
			customerImpl.setFirstName("");
		}
		else {
			customerImpl.setFirstName(firstName);
		}

		if (middleName == null) {
			customerImpl.setMiddleName("");
		}
		else {
			customerImpl.setMiddleName(middleName);
		}

		if (lastName == null) {
			customerImpl.setLastName("");
		}
		else {
			customerImpl.setLastName(lastName);
		}

		if (screenName == null) {
			customerImpl.setScreenName("");
		}
		else {
			customerImpl.setScreenName(screenName);
		}

		if (agentScreenName == null) {
			customerImpl.setAgentScreenName("");
		}
		else {
			customerImpl.setAgentScreenName(agentScreenName);
		}

		if (brmId == null) {
			customerImpl.setBrmId("");
		}
		else {
			customerImpl.setBrmId(brmId);
		}

		if (vcId == null) {
			customerImpl.setVcId("");
		}
		else {
			customerImpl.setVcId(vcId);
		}

		if (stbNo == null) {
			customerImpl.setStbNo("");
		}
		else {
			customerImpl.setStbNo(stbNo);
		}

		if (macId == null) {
			customerImpl.setMacId("");
		}
		else {
			customerImpl.setMacId(macId);
		}

		if (accountNo == null) {
			customerImpl.setAccountNo("");
		}
		else {
			customerImpl.setAccountNo(accountNo);
		}

		if (poId == null) {
			customerImpl.setPoId("");
		}
		else {
			customerImpl.setPoId(poId);
		}

		if (connectionType == null) {
			customerImpl.setConnectionType("");
		}
		else {
			customerImpl.setConnectionType(connectionType);
		}

		if (batId == null) {
			customerImpl.setBatId("");
		}
		else {
			customerImpl.setBatId(batId);
		}

		if (serviceType == null) {
			customerImpl.setServiceType("");
		}
		else {
			customerImpl.setServiceType(serviceType);
		}

		if (status == null) {
			customerImpl.setStatus("");
		}
		else {
			customerImpl.setStatus(status);
		}

		customerImpl.setPrimary(primary);

		if (remark == null) {
			customerImpl.setRemark("");
		}
		else {
			customerImpl.setRemark(remark);
		}

		if (vcPoId == null) {
			customerImpl.setVcPoId("");
		}
		else {
			customerImpl.setVcPoId(vcPoId);
		}

		if (stbPoId == null) {
			customerImpl.setStbPoId("");
		}
		else {
			customerImpl.setStbPoId(stbPoId);
		}

		if (macPoId == null) {
			customerImpl.setMacPoId("");
		}
		else {
			customerImpl.setMacPoId(macPoId);
		}

		if (servicePoId == null) {
			customerImpl.setServicePoId("");
		}
		else {
			customerImpl.setServicePoId(servicePoId);
		}

		customerImpl.setAutoRenew(autoRenew);

		customerImpl.resetOriginalValues();

		return customerImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		customerId = objectInput.readUTF();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();
		createBy = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		salutation = objectInput.readUTF();
		firstName = objectInput.readUTF();
		middleName = objectInput.readUTF();
		lastName = objectInput.readUTF();
		screenName = objectInput.readUTF();
		agentScreenName = objectInput.readUTF();
		brmId = objectInput.readUTF();
		vcId = objectInput.readUTF();
		stbNo = objectInput.readUTF();
		macId = objectInput.readUTF();
		accountNo = objectInput.readUTF();
		poId = objectInput.readUTF();
		connectionType = objectInput.readUTF();
		batId = objectInput.readUTF();
		serviceType = objectInput.readUTF();
		status = objectInput.readUTF();

		primary = objectInput.readBoolean();
		remark = objectInput.readUTF();
		vcPoId = objectInput.readUTF();
		stbPoId = objectInput.readUTF();
		macPoId = objectInput.readUTF();
		servicePoId = objectInput.readUTF();

		autoRenew = objectInput.readBoolean();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (customerId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerId);
		}

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		if (createBy == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(createBy);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (salutation == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(salutation);
		}

		if (firstName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(firstName);
		}

		if (middleName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(middleName);
		}

		if (lastName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(lastName);
		}

		if (screenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(screenName);
		}

		if (agentScreenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(agentScreenName);
		}

		if (brmId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(brmId);
		}

		if (vcId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(vcId);
		}

		if (stbNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(stbNo);
		}

		if (macId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(macId);
		}

		if (accountNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(accountNo);
		}

		if (poId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(poId);
		}

		if (connectionType == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(connectionType);
		}

		if (batId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(batId);
		}

		if (serviceType == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(serviceType);
		}

		if (status == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(status);
		}

		objectOutput.writeBoolean(primary);

		if (remark == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(remark);
		}

		if (vcPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(vcPoId);
		}

		if (stbPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(stbPoId);
		}

		if (macPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(macPoId);
		}

		if (servicePoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(servicePoId);
		}

		objectOutput.writeBoolean(autoRenew);
	}

	public String customerId;
	public long groupId;
	public long companyId;
	public String createBy;
	public long createDate;
	public long modifiedDate;
	public String salutation;
	public String firstName;
	public String middleName;
	public String lastName;
	public String screenName;
	public String agentScreenName;
	public String brmId;
	public String vcId;
	public String stbNo;
	public String macId;
	public String accountNo;
	public String poId;
	public String connectionType;
	public String batId;
	public String serviceType;
	public String status;
	public boolean primary;
	public String remark;
	public String vcPoId;
	public String stbPoId;
	public String macPoId;
	public String servicePoId;
	public boolean autoRenew;

}