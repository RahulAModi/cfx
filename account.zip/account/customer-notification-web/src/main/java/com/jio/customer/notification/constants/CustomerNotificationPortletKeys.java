package com.jio.customer.notification.constants;

/**
 * @author Rahul1.Panchivala
 */
public class CustomerNotificationPortletKeys {

	public static final String PORTLET_NAME = "com_jio_customer_notification_portlet_CustomerNotificationPortlet";

	public static final String CONFIGURATION_NAME = "com_jio_customer_notification_configuration_NotificationConfiguration";

}