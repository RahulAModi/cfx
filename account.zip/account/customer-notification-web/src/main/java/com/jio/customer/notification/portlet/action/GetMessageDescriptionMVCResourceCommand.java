package com.jio.customer.notification.portlet.action;

import com.jio.customer.notification.constants.CustomerNotificationPortletKeys;
import com.jio.customer.notification.constants.MVCCommandNames;
import com.jio.master.message.exception.NoSuchMessageTemplateDescException;
import com.jio.master.message.model.MessageTemplateDesc;
import com.jio.master.message.service.MessageTemplateDescLocalService;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerNotificationPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_MESSAGE_DESCRIPTION }, service = MVCResourceCommand.class)
public class GetMessageDescriptionMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		long descriptionId = ParamUtil.getLong(resourceRequest, "descriptionId");
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		boolean response = Boolean.FALSE;
		try {
			MessageTemplateDesc messageTemplateDesc = messageTemplateDescLocalService.getMessageTemplateDesc(descriptionId, companyId);
			if (Validator.isNotNull(messageTemplateDesc)) {
				JSONObject outputObject = getJsonObject(messageTemplateDesc);
				try {
					resourceResponse.getWriter().println(outputObject);
					response = Boolean.TRUE;
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.getMessage());
					response = Boolean.FALSE;
				}
			}
		} catch (NoSuchMessageTemplateDescException e) {
			LOGGER.error("NoSuchMessageTemplateDescException : " + e.toString());
			response = Boolean.FALSE;
		}

		return response;
	}

	public JSONObject getJsonObject(MessageTemplateDesc messageTemplateDesc) {
		JSONObject outputObject = JSONFactoryUtil.createJSONObject();
		outputObject.put("subject", messageTemplateDesc.getSubject());
		outputObject.put("description", messageTemplateDesc.getDescription());
		outputObject.put("name", messageTemplateDesc.getName());
		outputObject.put("id", messageTemplateDesc.getDescriptionId());
		return outputObject;
	}

	@Reference
	protected MessageTemplateDescLocalService messageTemplateDescLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(GetMessageDescriptionMVCResourceCommand.class);
}
