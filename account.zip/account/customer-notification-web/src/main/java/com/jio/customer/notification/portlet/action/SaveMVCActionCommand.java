/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.customer.notification.portlet.action;

import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.notification.service.NotificationLogLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.customer.notification.constants.CustomerNotificationPortletKeys;
import com.jio.customer.notification.constants.MVCCommandNames;
import com.jio.customer.notification.service.NotificationService;
import com.jio.master.message.exception.NoSuchMessageTemplateDescException;
import com.jio.master.message.exception.NoSuchMessageTemplateException;
import com.jio.master.message.model.MessageTemplate;
import com.jio.master.message.model.MessageTemplateDesc;
import com.jio.master.message.service.MessageTemplateDescLocalService;
import com.jio.master.message.service.MessageTemplateLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.File;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletPreferences;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerNotificationPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE }, service = MVCActionCommand.class)
public class SaveMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveMVCActionCommand.class);

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) {
		long companyId = PortalUtil.getCompanyId(actionRequest);
		
		PortletPreferences portletPreferences = actionRequest.getPreferences();
		String messageTemplateId = portletPreferences.getValue("messageTemplateId", StringPool.BLANK);

		long messageTemplateDescId = ParamUtil.getLong(actionRequest, "messageTemplateDescId");

		String sendType = ParamUtil.getString(actionRequest, "sendType");
		String txRefNo = AccountUtil.getTxRefNo();
		try {
			User user = PortalUtil.getUser(actionRequest);
			long groupId = PortalUtil.getScopeGroupId(actionRequest);

			MessageTemplate messageTemplate = messTemplateLocalService.getMessageTemplate(GetterUtil.getLong(messageTemplateId), companyId);
			MessageTemplateDesc messageTemplateDesc = mtdLocalService.getMessageTemplateDesc(messageTemplateDescId, companyId);

			if (messageTemplate.getName().equalsIgnoreCase("SMS")) {
				if (sendType.equalsIgnoreCase("individual")) {
					String customerAccountNo = ParamUtil.getString(actionRequest, "customerAccountNo");
					try {
						notificationService.sendSMSNotifiation(customerAccountNo, messageTemplate.getCode(), messageTemplateDesc.getDescriptionId(), messageTemplateDesc.getNeTemplateId(), messageTemplateDesc.getSubject(), messageTemplateDesc.getDescription(), txRefNo, user, companyId, groupId);
					} catch (NoSuchCustomerException e) {
						LOGGER.error("NoSuchCustomerException : " + e.toString());
					} catch (NoSuchContactException e) {
						LOGGER.error("NoSuchContactException : " + e.toString());
					}
				}

				if (sendType.equalsIgnoreCase("bulk")) {
					UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
					File file = uploadRequest.getFile("file");
					Runnable runnable = new Runnable() {
						@Override
						public void run() {
							notificationService.addNotificationLog(file, txRefNo, messageTemplate, messageTemplateDesc, companyId, groupId, user.getScreenName());
						}
					};
					Thread thread = new Thread(runnable);
					thread.start();
				}
			}

			if (messageTemplate.getName().equalsIgnoreCase("BMAIL")) {
				if (sendType.equalsIgnoreCase("individual")) {
					String customerAccountNo = ParamUtil.getString(actionRequest, "customerAccountNo");
					try {
						notificationService.sendBmailNotifiation(customerAccountNo, messageTemplate.getCode(), messageTemplateDesc.getDescriptionId(), notificationService.getDate(0), notificationService.getDate(1), messageTemplateDesc.getSubject(), messageTemplateDesc.getDescription(), txRefNo,
								user, companyId, groupId);
					} catch (NoSuchCustomerException e) {
						LOGGER.error("NoSuchCustomerException : " + e.toString());
					}
				}

				if (sendType.equalsIgnoreCase("bulk")) {
					UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
					File file = uploadRequest.getFile("file");
					Runnable runnable = new Runnable() {
						@Override
						public void run() {
							notificationService.sendBmailNotifiations(file, messageTemplate.getCode(), messageTemplateDesc.getDescriptionId(), notificationService.getDate(0), notificationService.getDate(1), messageTemplateDesc.getSubject(), messageTemplateDesc.getDescription(), txRefNo, user,
									companyId, groupId);
						}
					};
					Thread thread = new Thread(runnable);
					thread.start();

				}
			}

		} catch (NoSuchMessageTemplateException e) {
			LOGGER.error("NoSuchMessageTemplateException :: " + e.toString());
		} catch (NoSuchMessageTemplateDescException e) {
			LOGGER.error("NoSuchMessageTemplateDescException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

	}

	@Reference
	private MessageTemplateLocalService messTemplateLocalService;

	@Reference
	private MessageTemplateDescLocalService mtdLocalService;

	@Reference
	private NotificationLogLocalService nlLocalService;

	@Reference
	private NotificationService notificationService;

}