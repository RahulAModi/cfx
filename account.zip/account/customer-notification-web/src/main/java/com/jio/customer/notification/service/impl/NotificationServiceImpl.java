package com.jio.customer.notification.service.impl;

import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.notification.model.NotificationLog;
import com.jio.account.notification.service.NotificationLogLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.brm.create.action.service.CreateActionService;
import com.jio.customer.notification.service.NotificationService;
import com.jio.master.message.model.MessageTemplate;
import com.jio.master.message.model.MessageTemplateDesc;
import com.jio.ne.service.api.NEService;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.Validator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, service = NotificationService.class)
public class NotificationServiceImpl implements NotificationService {

	private static final Log LOGGER = LogFactoryUtil.getLog(NotificationServiceImpl.class);

	@Override
	public NotificationLog sendSMSNotifiation(String customerAccountNo, String messageTemplateCode, long messageTemplateDescId, String neTemplateId, String subject, String message, String txRefNo, User user, long companyId, long groupId) throws NoSuchCustomerException, NoSuchContactException {
		Customer customer = customerLocalService.getCustomer(customerAccountNo, companyId);
		Contact contact = contactLocalService.getContact(companyId, customer.getScreenName());
		Runnable runnable = () -> {
			Map<String, String> nameValuePairs = new HashMap<String, String>();
			neService.ne(companyId, txRefNo, neTemplateId, contact.getMobileNo(), contact.getEmail(), nameValuePairs);
		};
		Thread thread = new Thread(runnable);
		thread.start();
		return addNotificationLog(customer.getScreenName(), customer.getAccountNo(), customer.getAgentScreenName(), txRefNo, messageTemplateCode, messageTemplateDescId, companyId, groupId, user.getScreenName());
	}

	@Override
	public NotificationLog sendBmailNotifiation(String customerAccountNo, String messageTemplateCode, long messageTemplateDescId, String emmgDeletionDate, String stbDeletionDate, String subject, String message, String txRefNo, User user, long companyId, long groupId) throws NoSuchCustomerException {
		Customer customer = customerLocalService.getCustomer(customerAccountNo, companyId);
		createActionService.sendBmail(customer.getVcId(), customer.getMacId(), message, subject, emmgDeletionDate, stbDeletionDate, txRefNo, customer.getCustomerId(), txRefNo, user.getScreenName(), user.getUserId(), companyId, groupId);
		return addNotificationLog(customer.getScreenName(), customer.getAccountNo(), customer.getAgentScreenName(), txRefNo, messageTemplateCode, messageTemplateDescId, companyId, groupId, user.getScreenName());
	}

	@Override
	public void sendBmailNotifiations(File file, String messageTemplateCode, long messageTemplateDescId, String emmgDeletionDate, String stbDeletionDate, String subject, String message, String txRefNo, User user, long companyId, long groupId) {
		try {
			FileInputStream excelFile = new FileInputStream(file);
			Workbook workbook = new XSSFWorkbook(excelFile);
			Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
			while (iterator.hasNext()) {
				Row currentRow = iterator.next();
				if (currentRow.getRowNum() != 0) {
					String customerAccountNo = getCellValue(currentRow.getCell(0));
					try {
						sendBmailNotifiation(customerAccountNo, messageTemplateCode, messageTemplateDescId, emmgDeletionDate, stbDeletionDate, subject, message, txRefNo, user, companyId, groupId);
					} catch (NoSuchCustomerException e) {
						LOGGER.error("NoSuchCustomerException : " + e.toString());
					}
				}
			}

			workbook.close();
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException :: " + e.toString());
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		}
	}

	private static String getCellValue(Cell cell) {
		String value = StringPool.BLANK;
		if (Validator.isNotNull(cell)) {
			if (cell.getCellTypeEnum() == CellType.STRING) {
				value = cell.getStringCellValue();
			}
			if (cell.getCellTypeEnum() == CellType.NUMERIC) {
				value = String.valueOf(cell.getNumericCellValue());
			}
		}
		return value;
	}

	@Override
	public String getDate(int increment) {
		Calendar calendar = Calendar.getInstance();
		if (increment != 0) {
			calendar.add(Calendar.DATE, increment);
		}
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DATE);

		return StringBundler.concat(String.valueOf(year), String.valueOf(month), String.valueOf(day));
	}

	@Override
	public void addNotificationLog(File file, String transactionNo, MessageTemplate messageTemplate, MessageTemplateDesc messageTemplateDesc, long companyId, long groupId, String agentScreenName) {
		try {
			FileInputStream excelFile = new FileInputStream(file);
			Workbook workbook = new XSSFWorkbook(excelFile);
			Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
			Customer customer = null;
			Contact contact = null;
			List<String> mobileList = new ArrayList<String>();
			while (iterator.hasNext()) {
				Row currentRow = iterator.next();
				if (currentRow.getRowNum() != 0 && currentRow.getCell(0) != null) {
					LOGGER.info(currentRow.getCell(0).toString());
					try {
						customer = customerLocalService.getCustomer(currentRow.getCell(0).toString(), companyId);
						contact = contactLocalService.getContact(companyId, customer.getScreenName());
						mobileList.add(contact.getMobileNo());
						addNotificationLog(customer.getScreenName(), customer.getAccountNo(), customer.getAgentScreenName(), transactionNo, messageTemplate.getCode(), messageTemplateDesc.getDescriptionId(), companyId, groupId, agentScreenName);
					} catch (NoSuchCustomerException e) {
						LOGGER.error("NoSuchCustomerException :: " + e.toString());
					} catch (NoSuchContactException e) {
						LOGGER.error("NoSuchContactException :: " + e.toString());
					}
				}
			}
			if (!mobileList.isEmpty()) {
				generateCSV(mobileList, transactionNo, messageTemplateDesc.getDescription(), messageTemplate.getCode());
			}
			workbook.close();
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException :: " + e.toString());
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		}
	}

	private void generateCSV(List<String> mobileList, String transactionNo, String freeText, String templateId) {
		int DELTA = (Integer.parseInt(PropsUtil.get("sms.file.delta")));
		String PATH = PropsUtil.get("sms.file.path");
		String BACKUP_FILE_PATH = PropsUtil.get("sms.file.backup.path");
		List<List<String>> chunks = getChunks(mobileList, DELTA);
		for (List<String> list : chunks) {
			String msg = writeMessage(transactionNo, freeText, templateId, list);
			String filename = "SMS_" + transactionNo + "_" + System.currentTimeMillis() + ".txt";
			String filePath = PATH + filename;

			File file = new File(filePath);
			try {
				file.createNewFile();
				writeToFile(file, msg);
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}

			// backup
			String backupFilePath = BACKUP_FILE_PATH + filename;
			File backupFile = new File(backupFilePath);
			try {
				backupFile.createNewFile();
				writeToFile(backupFile, msg);
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}
		}
	}

	private String writeMessage(String transactionNo, String freeText, String templateId, List<String> mobiles) {
		String APP_ID = PropsUtil.get("jio.sms.app.id");
		String SECRET_KEY = PropsUtil.get("jio.sms.secret.key");

		StringBuilder sb = new StringBuilder();
		sb.append("# APP_ID=" + APP_ID);
		sb.append(StringPool.NEW_LINE);
		sb.append("# SECRET_KEY=" + SECRET_KEY);
		sb.append(StringPool.NEW_LINE);
		sb.append("# APP_TRANSACTION_ID=" + transactionNo);
		sb.append(StringPool.NEW_LINE);
		sb.append("# FREE_TEXT=" + freeText);
		sb.append(StringPool.NEW_LINE);
		sb.append("# TEMPLATE_ID=" + templateId);
		sb.append(StringPool.NEW_LINE);
		sb.append("# MOBILE_NO=");
		sb.append(StringPool.NEW_LINE);
		mobiles.stream().forEach(mobile -> {
			sb.append(mobile);
			sb.append(StringPool.NEW_LINE);
		});
		return sb.toString();
	}

	private void writeToFile(File file, String msg) {
		FileWriter fileWritter = null;
		BufferedWriter bufferWritter = null;
		try {
			fileWritter = new FileWriter(file, true);
			bufferWritter = new BufferedWriter(fileWritter);
			bufferWritter.write(msg);

		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		} finally {
			if (bufferWritter != null) {
				try {
					bufferWritter.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
			if (fileWritter != null) {
				try {
					fileWritter.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}
	}

	private List<List<String>> getChunks(List<String> list, int delta) {
		List<List<String>> parts = new ArrayList<List<String>>();
		int total = list.size();
		for (int i = 0; i < total; i += delta) {
			parts.add(new ArrayList<String>(list.subList(i, Math.min(total, i + delta))));
		}
		return parts;
	}

	private NotificationLog addNotificationLog(String customerScreenName, String customerAccountNo, String agentAccountNo, String transactionNo, String messageTemplateCode, long descriptionId, long companyId, long groupId, String createBy) {
		NotificationLog notificationLog = nlLocalService.createNotificationLog(AccountUtil.getRefNo("N"));
		notificationLog.setCustomerScreenName(customerScreenName);
		notificationLog.setCustomerAccountNo(customerAccountNo);
		notificationLog.setAgentAccountNo(agentAccountNo);
		notificationLog.setTransactionNo(transactionNo);
		notificationLog.setMessageTemplateCode(messageTemplateCode);
		notificationLog.setMessageTemplateDescId(descriptionId);
		notificationLog.setCompanyId(companyId);
		notificationLog.setGroupId(groupId);
		notificationLog.setCreateBy(createBy);
		return nlLocalService.addNotificationLog(notificationLog);
	}

	@Reference
	private NotificationLogLocalService nlLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private CounterLocalService counterLocalService;

	@Reference
	private CreateActionService createActionService;

	@Reference
	private NEService neService;

}
