package com.jio.customer.notification.portlet.action;

import com.jio.customer.notification.constants.CustomerNotificationPortletKeys;
import com.jio.customer.notification.constants.MVCCommandNames;
import com.jio.master.message.model.MessageTemplateDesc;
import com.jio.master.message.service.MessageTemplateDescLocalService;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerNotificationPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_MESSAGE }, service = MVCResourceCommand.class)
public class GetMessageMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		long messageTemplateId = ParamUtil.getLong(resourceRequest, "searchKeyword");
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		List<MessageTemplateDesc> messageTemplateDescs = _messageTemplateDescLocalService.getMessageTemplateDescs(messageTemplateId, companyId);
		boolean response = false;
		if (Validator.isNotNull(messageTemplateDescs)) {
			JSONArray outputArray = JSONFactoryUtil.createJSONArray();
			outputArray = getJsonArray(messageTemplateDescs);
			try {
				resourceResponse.getWriter().println(outputArray);
				response = Boolean.TRUE;
			} catch (IOException e) {
				_log.error("IOException : " + e.getMessage());
				response = Boolean.FALSE;
			}
		}
		return response;
	}

	public JSONArray getJsonArray(List<MessageTemplateDesc> messageTemplateDescs) {
		JSONArray outputArray = JSONFactoryUtil.createJSONArray();
		JSONObject outputObject;
		for (MessageTemplateDesc messageTemplateDesc : messageTemplateDescs) {
			outputObject = JSONFactoryUtil.createJSONObject();
			outputObject.put("subject", messageTemplateDesc.getSubject());
			outputObject.put("description", messageTemplateDesc.getDescription());
			outputObject.put("name", messageTemplateDesc.getName());
			outputObject.put("id", messageTemplateDesc.getDescriptionId());
			outputArray.put(outputObject);
		}
		return outputArray;
	}

	@Reference
	protected MessageTemplateDescLocalService _messageTemplateDescLocalService;

	private static final Log _log = LogFactoryUtil.getLog(GetMessageMVCResourceCommand.class);
}
