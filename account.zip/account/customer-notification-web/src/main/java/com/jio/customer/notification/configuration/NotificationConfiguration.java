package com.jio.customer.notification.configuration;

import com.jio.customer.notification.constants.CustomerNotificationPortletKeys;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author Vishal7.Shah
 *
 */
@Meta.OCD(id = CustomerNotificationPortletKeys.CONFIGURATION_NAME)
public interface NotificationConfiguration {

	@Meta.AD(required = false)
	public String messageTemplateId();
}
