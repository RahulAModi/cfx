package com.jio.customer.notification.portlet.action;

import com.jio.account.notification.model.NotificationLog;
import com.jio.account.notification.service.NotificationLogLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.customer.notification.constants.CustomerNotificationPortletKeys;
import com.jio.customer.notification.constants.MVCCommandNames;
import com.jio.master.message.exception.NoSuchMessageTemplateException;
import com.jio.master.message.model.MessageTemplate;
import com.jio.master.message.service.MessageTemplateLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerNotificationPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(renderRequest);
		boolean isSuperAdmin = false;

		String customerAccountNo = ParamUtil.getString(renderRequest, "customerAccountNo");
		String customerScreenName = ParamUtil.getString(renderRequest, "customerScreenName");
		String agentAccountNo = ParamUtil.getString(renderRequest, "agentAccountNo");

		PortletPreferences portletPreferences = renderRequest.getPreferences();
		String messageTemplateId = portletPreferences.getValue("messageTemplateId", StringPool.BLANK);
		String messageTemplateCode = StringPool.BLANK;
		if (Validator.isNotNull(messageTemplateId)) {
			try {
				MessageTemplate messageTemplate = messageTemplateLocalService.getMessageTemplate(GetterUtil.getLong(messageTemplateId), companyId);
				messageTemplateCode = messageTemplate.getCode();
				renderRequest.setAttribute("messageTemplate", messageTemplate);
			} catch (NoSuchMessageTemplateException e) {
				LOGGER.warn("NoSuchMessageTemplateException : " + e.toString());
			}
		}
		try {
			User userAgent = PortalUtil.getUser(renderRequest);
			isSuperAdmin = AccountUtil.isAdmin(userAgent.getUserId());

			PortletURL iteratorURL = renderResponse.createRenderURL();
			iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
			try {
				iteratorURL.setWindowState(WindowState.NORMAL);
			} catch (WindowStateException e) {
				LOGGER.error(e.toString());
			}
			SearchContainer<NotificationLog> searchContainer = new SearchContainer<NotificationLog>(renderRequest, iteratorURL, null, "there-are-no-notification");
			List<NotificationLog> notificationLogs = null;
			int count = 0;
			if (isSuperAdmin) {

				if (Validator.isNotNull(messageTemplateCode)) {

					if (Validator.isNotNull(agentAccountNo)) {
						notificationLogs = notificationLogLocalService.getNotificationLogs(messageTemplateCode, agentAccountNo, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCount(messageTemplateCode, agentAccountNo, companyId);
					} else if (Validator.isNotNull(customerScreenName)) {
						notificationLogs = notificationLogLocalService.getNotificationLogsByCustomerScreenName(messageTemplateCode, customerScreenName, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCountByCustomerScreenName(messageTemplateCode, customerScreenName, companyId);
					} else if (Validator.isNotNull(customerAccountNo)) {
						notificationLogs = notificationLogLocalService.getNotificationLogsByCustomerAccountNo(messageTemplateCode, customerAccountNo, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCountByCustomerAccountNo(messageTemplateCode, customerAccountNo, companyId);
					} else {
						notificationLogs = notificationLogLocalService.getNotificationLogs(messageTemplateCode, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCount(companyId);
					}

				} else {

					if (Validator.isNotNull(agentAccountNo)) {
						notificationLogs = notificationLogLocalService.getByAgent(agentAccountNo, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCountByAgent(agentAccountNo, companyId);
					} else if (Validator.isNotNull(customerScreenName)) {
						notificationLogs = notificationLogLocalService.getByCustomer(customerScreenName, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.countByCustomer(customerScreenName, companyId);
					} else if (Validator.isNotNull(customerAccountNo)) {
						notificationLogs = notificationLogLocalService.getByCustomerAccountNo(customerAccountNo, companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.countByCustomerAccountNo(customerAccountNo, companyId);
					} else {
						notificationLogs = notificationLogLocalService.getByCompanyId(companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCount(companyId);
					}

				}

			} else {

				if (Validator.isNotNull(messageTemplateCode)) {

					if (Validator.isNotNull(customerScreenName)) {
						notificationLogs = notificationLogLocalService.getByCustomer(messageTemplateCode, customerScreenName, userAgent.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.countByCustomer(messageTemplateCode, customerScreenName, userAgent.getScreenName(), companyId);
					} else if (Validator.isNotNull(customerAccountNo)) {
						notificationLogs = notificationLogLocalService.getByCustomerAccountNo(messageTemplateCode, customerAccountNo, userAgent.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.countByCustomerAccountNo(messageTemplateCode, customerAccountNo, userAgent.getScreenName(), companyId);
					} else {
						notificationLogs = notificationLogLocalService.getNotificationLogs(messageTemplateCode, userAgent.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCount(messageTemplateCode, userAgent.getScreenName(), companyId);
					}

				} else {

					if (Validator.isNotNull(customerScreenName)) {
						notificationLogs = notificationLogLocalService.getByCustomer(customerScreenName, userAgent.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.countByCustomer(customerScreenName, userAgent.getScreenName(), companyId);
					} else if (Validator.isNotNull(customerAccountNo)) {
						notificationLogs = notificationLogLocalService.getByCustomerAccountNo(customerAccountNo, userAgent.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCountByCustomerAccountNo(customerAccountNo, userAgent.getScreenName(), companyId);
					} else {
						notificationLogs = notificationLogLocalService.getByAgent(userAgent.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
						count = notificationLogLocalService.getNotificationLogsCountByAgent(userAgent.getScreenName(), companyId);
					}

				}

			}

			searchContainer.setTotal(count);
			searchContainer.setResults(notificationLogs);

			renderRequest.setAttribute("searchContainer", searchContainer);
			renderRequest.setAttribute("isSuperAdmin", isSuperAdmin);
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		return "/notification/view.jsp";
	}

	@Reference
	NotificationLogLocalService notificationLogLocalService;

	@Reference
	MessageTemplateLocalService messageTemplateLocalService;

}