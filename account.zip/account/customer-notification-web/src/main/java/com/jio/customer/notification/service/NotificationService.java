package com.jio.customer.notification.service;

import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.notification.model.NotificationLog;
import com.jio.master.message.model.MessageTemplate;
import com.jio.master.message.model.MessageTemplateDesc;
import com.liferay.portal.kernel.model.User;

import java.io.File;

public interface NotificationService {

	NotificationLog sendSMSNotifiation(String customerAccountNo, String messageTemplateCode, long messageTemplateDescId, String neTemplateId, String subject, String message, String txRefNo, User user, long companyId, long groupId) throws NoSuchCustomerException, NoSuchContactException;

	NotificationLog sendBmailNotifiation(String customerAccountNo, String messageTemplateCode, long messageTemplateDescId, String emmgDeletionDate, String stbDeletionDate, String subject, String message, String txRefNo, User user, long companyId, long groupId) throws NoSuchCustomerException;

	void sendBmailNotifiations(File file, String messageTemplateCode, long messageTemplateDescId, String emmgDeletionDate, String stbDeletionDate, String subject, String message, String txRefNo, User user, long companyId, long groupId);

	void addNotificationLog(File file, String transactionNo, MessageTemplate messageTemplate, MessageTemplateDesc messageTemplateDesc, long companyId, long groupId, String agentScreenName);

	String getDate(int increment);
}
