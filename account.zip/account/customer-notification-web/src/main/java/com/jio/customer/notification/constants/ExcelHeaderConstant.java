package com.jio.customer.notification.constants;

public class ExcelHeaderConstant {

	public static final String VC_ID = "VC ID";
	public static final String ACCOUNT_NO = "ACCOUNT NO";
	public static final String MOBILE_NUMBER = "MOBILE NUMBER";

	public final static String XLSX = "xlsx";
}
