package com.jio.customer.notification.constants;

public class MVCCommandNames {

	public static final String VIEW = "/notification/view";

	public static final String EDIT = "/notification/edit";

	public static final String SAVE = "/notification/save";

	public static final String GET_MESSAGE = "/notification/get-message";

	public static final String GET_MESSAGE_DESCRIPTION = "/notification/get-message-description";

	public static final String DOWNLOAD_EXCEL = "/notification/download-excel";

	public static final String SEARCH = "/notification/search";
}
