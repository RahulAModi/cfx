package com.jio.customer.notification.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.customer.notification.constants.CustomerNotificationPortletKeys;
import com.jio.customer.notification.constants.MVCCommandNames;
import com.jio.master.message.exception.NoSuchMessageTemplateException;
import com.jio.master.message.model.MessageTemplate;
import com.jio.master.message.model.MessageTemplateDesc;
import com.jio.master.message.service.MessageTemplateDescLocalService;
import com.jio.master.message.service.MessageTemplateLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerNotificationPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.EDIT }, service = MVCRenderCommand.class)
public class EditMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);

		PortletPreferences portletPreferences = renderRequest.getPreferences();
		String messageTemplateId = portletPreferences.getValue("messageTemplateId", StringPool.BLANK);
		if (Validator.isNotNull(messageTemplateId)) {

			renderRequest.setAttribute("messageTemplateId", messageTemplateId);

			try {
				MessageTemplate messageTemplate = messageTemplateLocalService.getMessageTemplate(GetterUtil.getLong(messageTemplateId), companyId);
				renderRequest.setAttribute("messageTemplate", messageTemplate);
			} catch (NoSuchMessageTemplateException e) {
				LOGGER.warn("NoSuchMessageTemplateException : " + e.toString());
			}

			List<MessageTemplateDesc> messageTemplateDescs = messageTemplateDescLocalService.getMessageTemplateDescs(GetterUtil.getLong(messageTemplateId), companyId);
			renderRequest.setAttribute("messageTemplateDescs", messageTemplateDescs);

		} else {
			List<MessageTemplate> messageTemplates = messageTemplateLocalService.getMessageTemplateList(companyId);
			renderRequest.setAttribute("messageTemplates", messageTemplates);
			long[] messageTemplateIds = messageTemplates.stream().map(messageTemplate -> messageTemplate.getMsgTemplateId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();

			List<MessageTemplateDesc> messageTemplateDescs = messageTemplateDescLocalService.getMessageTemplateDescs(messageTemplateIds, companyId);
			renderRequest.setAttribute("messageTemplateDescs", messageTemplateDescs);

		}

		try {
			User user = PortalUtil.getUser(renderRequest);

			String screenName = user.getScreenName();
			boolean isAdmin = AccountUtil.isAdmin(user.getUserId());
			if (isAdmin) {
				screenName = null;
			}

			Agent agent = agentLocalService.getParentAgent(companyId, screenName);
			renderRequest.setAttribute("agent", agent);

			List<Customer> customerList = customerLocalService.getCustomerByStatus("1", companyId, screenName, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
			renderRequest.setAttribute("customerList", customerList);

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.getMessage());
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.getMessage());
		}

		return "/notification/edit_notification.jsp";
	}

	@Reference
	MessageTemplateDescLocalService messageTemplateDescLocalService;

	@Reference
	MessageTemplateLocalService messageTemplateLocalService;

	@Reference
	CustomerLocalService customerLocalService;

	@Reference
	AgentLocalService agentLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(EditMVCRenderCommand.class);
}