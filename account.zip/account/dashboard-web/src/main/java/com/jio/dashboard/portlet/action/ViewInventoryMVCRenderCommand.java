/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.dashboard.portlet.action;

import com.jio.dashboard.constants.DashboardPortletKeys;
import com.jio.dashboard.constants.MVCCommandNames;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "javax.portlet.name=" + DashboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.VIEW_INVENTORY }, service = MVCRenderCommand.class)
public class ViewInventoryMVCRenderCommand implements MVCRenderCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(ViewInventoryMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		String key = ParamUtil.getString(renderRequest, "key");

		renderRequest.setAttribute("key", key);

		return "/dashboard/view_inventory.jsp";
	}

}