package com.jio.dashboard.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.brm.cache.constants.BRMCacheConstant;
import com.jio.brm.cache.util.BRMCacheUtil;
import com.jio.config.props.JioPropsValues;
import com.jio.dashboard.constants.DashboardPortletKeys;
import com.jio.dashboard.constants.ExcelHeaderConstant;
import com.jio.dashboard.constants.MVCCommandNames;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + DashboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD_ALL_INVENTORY }, service = MVCResourceCommand.class)
public class DownloadAllInventoryMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadAllInventoryMVCResourceCommand.class);

	@Reference
	private BRMCacheUtil brmCacheUtil;

	@Reference
	private AgentLocalService agentLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean resource = true;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String key = ParamUtil.getString(resourceRequest, "key");
		try {
			User user = PortalUtil.getUser(resourceRequest);

			Agent agent = agentLocalService.getParentAgent(companyId, user.getScreenName());

			List<Object[]> data = new ArrayList<Object[]>();
			if (key.equalsIgnoreCase(BRMCacheConstant.ACTIVE)) {
				data = brmCacheUtil.getActiveDeviceId(agent.getScreenName());
			} else if (key.equalsIgnoreCase(BRMCacheConstant.INACTIVE)) {
				data = brmCacheUtil.getInActiveDeviceId(agent.getScreenName());
			} else if (key.equalsIgnoreCase(BRMCacheConstant.TOTAL)) {
				data = brmCacheUtil.getTotalDeviceId(agent.getScreenName());
			}

			int rowNum = 0;
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(key);

			FileOutputStream out = null;
			InputStream in = null;

			XSSFCellStyle style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setBold(true);
			style.setFont(font);

			Row row = sheet.createRow(rowNum++);
			Cell cell;
			int colNum = 0;
			if (row.getRowNum() == 0) {

				cell = row.createCell(colNum++);
				cell.setCellValue(ExcelHeaderConstant.SR_NO);
				cell.setCellStyle(style);

				cell = row.createCell(colNum++);
				cell.setCellValue(ExcelHeaderConstant.SERVICE_STATUS);
				cell.setCellStyle(style);

				cell = row.createCell(colNum++);
				cell.setCellValue(ExcelHeaderConstant.STB_NO);
				cell.setCellStyle(style);

				cell = row.createCell(colNum++);
				cell.setCellValue(ExcelHeaderConstant.VC_ID);
				cell.setCellStyle(style);

			}

			for (Object[] object : data) {
				colNum = 0;
				row = sheet.createRow(rowNum++);

				cell = row.createCell(colNum++);
				cell.setCellValue(getValue(object[0]));

				cell = row.createCell(colNum++);
				cell.setCellValue(getValue(object[1]));

				cell = row.createCell(colNum++);
				cell.setCellValue(getValue(object[2]));

				cell = row.createCell(colNum++);
				cell.setCellValue(getValue(object[3]));
			}

			try {

				String fileName = StringBundler.concat(key, StringPool.UNDERLINE, agent.getScreenName(), StringPool.PERIOD, ExcelHeaderConstant.XLSX);
				String filePath = JioPropsValues.DOWNLOAD_FOLDER_PATH;
				File file = new File(filePath + File.separator + fileName);

				// Write data to file
				out = new FileOutputStream(file);
				workbook.write(out);
				out.close();
				workbook.close();
				// Complete writing

				// Download file
				in = new FileInputStream(file);
				try {
					PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, in, ContentTypes.APPLICATION_VND_MS_EXCEL);
				} catch (IOException e) {
					resource = false;
				}

				in.close();

			} catch (IOException e) {
				resource = false;
			} finally {
				try {
					if (out != null)
						out.close();
				} catch (IOException e) {
					LOGGER.info("IOException : " + e.getLocalizedMessage());
				}

				try {
					if (workbook != null)
						workbook.close();
				} catch (IOException e) {
					LOGGER.info("IOException : " + e.getLocalizedMessage());
				}

				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
					LOGGER.info("IOException : " + e.getLocalizedMessage());
				}
			}

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		return resource;
	}

	private String getValue(Object object) {
		if (Validator.isNull(object)) {
			return StringPool.BLANK;
		} else {
			return String.valueOf(object);
		}
	}

}
