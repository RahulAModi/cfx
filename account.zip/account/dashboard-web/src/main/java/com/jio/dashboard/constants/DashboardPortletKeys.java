package com.jio.dashboard.constants;

/**
 * @author Vishal7.Shah
 */
public class DashboardPortletKeys {

	public static final String PORTLET_NAME = "com_jio_dashboard_portlet_DashboardPortlet";

}