package com.jio.dashboard.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.brm.cache.util.BRMCacheUtil;
import com.jio.dashboard.constants.DashboardPortletKeys;
import com.jio.dashboard.constants.MVCCommandNames;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + DashboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_COUNT }, service = MVCResourceCommand.class)

public class GetCountMVCSResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(GetCountMVCSResourceCommand.class);

	@Reference
	private BRMCacheUtil brmCacheUtil;

	@Reference
	private AgentLocalService agentLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean flag = false;
		long companyId = PortalUtil.getCompanyId(resourceRequest);

		try {
			User user = PortalUtil.getUser(resourceRequest);

			Agent agent = agentLocalService.getParentAgent(companyId, user.getScreenName());

			int activeCount = brmCacheUtil.countActiveDeviceId(agent.getScreenName());
			int inActiveCount = brmCacheUtil.countInActiveDeviceId(agent.getScreenName());
			int totalCount = brmCacheUtil.countTotalDeviceId(agent.getScreenName());
			int expiredCount = brmCacheUtil.countExpiredPlanDeviceId(agent.getScreenName());
			int expiringCount = brmCacheUtil.countExpiringPlanDeviceId(agent.getScreenName());

			LOGGER.info("Agent : " + agent.getScreenName() + " activeCount : " + activeCount + " inActiveCount : " + inActiveCount + " totalCount : " + totalCount + " expiredCount : " + expiredCount + " expiringCount : " + expiringCount);

			JSONObject outputObject = JSONFactoryUtil.createJSONObject();
			outputObject.put("activeCount", activeCount);
			outputObject.put("inActiveCount", inActiveCount);
			outputObject.put("totalCount", totalCount);
			outputObject.put("expiredCount", expiredCount);
			outputObject.put("expiringCount", expiringCount);
			resourceResponse.getWriter().println(outputObject);
			flag = true;
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		return flag;
	}

}
