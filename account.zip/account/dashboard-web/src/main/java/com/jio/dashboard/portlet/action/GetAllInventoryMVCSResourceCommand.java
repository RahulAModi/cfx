package com.jio.dashboard.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.brm.cache.constants.BRMCacheConstant;
import com.jio.brm.cache.util.BRMCacheUtil;
import com.jio.dashboard.constants.DashboardPortletKeys;
import com.jio.dashboard.constants.MVCCommandNames;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + DashboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_ALL_INVENTORY }, service = MVCResourceCommand.class)

public class GetAllInventoryMVCSResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(GetAllInventoryMVCSResourceCommand.class);

	@Reference
	private BRMCacheUtil brmCacheUtil;

	@Reference
	private AgentLocalService agentLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean flag = false;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String key = ParamUtil.getString(resourceRequest, "key");
		try {
			User user = PortalUtil.getUser(resourceRequest);

			Agent agent = agentLocalService.getParentAgent(companyId, user.getScreenName());

			List<Object[]> data = new ArrayList<Object[]>();
			if (key.equalsIgnoreCase(BRMCacheConstant.ACTIVE)) {
				data = brmCacheUtil.getActiveDeviceId(agent.getScreenName());
			} else if (key.equalsIgnoreCase(BRMCacheConstant.INACTIVE)) {
				data = brmCacheUtil.getInActiveDeviceId(agent.getScreenName());
			} else if (key.equalsIgnoreCase(BRMCacheConstant.TOTAL)) {
				data = brmCacheUtil.getTotalDeviceId(agent.getScreenName());
			}

			resourceResponse.getWriter().println(convertJsonObject(data));
			flag = true;
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		return flag;
	}

	private JSONObject convertJsonObject(List<Object[]> data) {
		JSONObject dataObject = JSONFactoryUtil.createJSONObject();
		JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
		data.stream().forEach(arrayObject -> {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("sr_no", getValue(arrayObject[0]));
			jsonObject.put("service_status", getValue(arrayObject[1]));
			jsonObject.put("stb_id", getValue(arrayObject[2]));
			jsonObject.put("vc_id", getValue(arrayObject[3]));
			jsonArray.put(jsonObject);
		});
		dataObject.put("data", jsonArray);
		return dataObject;
	}

	private String getValue(Object object) {
		if (Validator.isNull(object)) {
			return StringPool.BLANK;
		} else {
			return String.valueOf(object);
		}
	}

}
