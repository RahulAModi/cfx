package com.jio.dashboard.constants;

public class MVCCommandNames {

	public static final String GET_COUNT = "/dashboard/get_count";

	public static final String GET_ALL_DEVICE = "/dashboard/get_all_device";

	public static final String GET_ALL_INVENTORY = "/dashboard/get_all_inventory";

	public static final String VIEW_DEVICE = "/dashboard/view_device";

	public static final String VIEW_INVENTORY = "/dashboard/view_inventory";

	public static final String DOWNLOAD_ALL_DEVICE = "/dashboard/download_all_device";

	public static final String DOWNLOAD_ALL_INVENTORY = "/dashboard/download_all_inventory";
}
