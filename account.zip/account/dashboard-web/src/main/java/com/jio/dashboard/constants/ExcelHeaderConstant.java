package com.jio.dashboard.constants;

public class ExcelHeaderConstant {

	public static final String SR_NO = "SR NO";
	public static final String SERVICE_STATUS = "SERVICE STATUS";
	public static final String STB_NO = "STB NO";
	public static final String VC_ID = "VC ID";

	public static final String DEVICE_ID = "DEVICE ID";
	public static final String PLAN_NAME = "PLAN NAME";
	public static final String END_DATE = "END DATE";
	public static final String PLAN_CODE = "PLAN CODE";
	
	public static final String ACCOUNT_NO = "ACCOUNT NO";
	public static final String B2B_SUBSCRIPTION_PRICE = "B2B SUBSCRIPTION PRICE";
	public static final String B2C_SUBSCRIPTION_PRICE = "B2C SUBSCRIPTION PRICE";
	
	public final static String XLSX = "xlsx";
}
