package com.jio.agent.customer.mapping.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.agent.customer.mapping.constants.AgentCustomerMappingPortletKeys;
import com.jio.agent.customer.mapping.constants.MVCCommandNames;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = {
		"javax.portlet.name=" + AgentCustomerMappingPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_SINGLE_AGENT_MAPPING
		}, service = MVCRenderCommand.class)
public class EditSingleAgentMappingMVCRenderCommand implements MVCRenderCommand {
	
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		
		try {
			long companyId = PortalUtil.getCompanyId(renderRequest);
			User user = PortalUtil.getUser(renderRequest);
		
			try {
				List<Agent> agents = _agentLocalService.getAgents(companyId, user.getScreenName(), QueryUtil.ALL_POS, QueryUtil.ALL_POS);
				renderRequest.setAttribute("agents", agents);
			} catch (NoSuchAgentException e) {
				_log.error("No such agent exception"+e.getLocalizedMessage());
			}
			
			SearchContainer<Customer> searchContainer = new SearchContainer<Customer>(renderRequest, null, null, SearchContainer.DEFAULT_CUR_PARAM, 10, PortletURLUtil.getCurrent(renderRequest, renderResponse), null, "no-results-found");
			List<Customer> customerList = _customerLocalService.getCustomerByLogInAgent(user.getScreenName(), companyId, searchContainer.getStart(), searchContainer.getEnd());
			searchContainer.setTotal(_customerLocalService.customerCountByLogInAgent(user.getScreenName(), companyId));
			searchContainer.setResults(customerList);
			renderRequest.setAttribute("searchContainer", searchContainer);
		} catch (PortalException e) {
			_log.error("Portlet exception : "+e.getLocalizedMessage());
		}
		return "/single_mapping.jsp";
	}

	@Reference
	protected AgentLocalService _agentLocalService;
	
	@Reference
	protected CustomerLocalService _customerLocalService;
	
	private static final Log _log = LogFactoryUtil.getLog(EditSingleAgentMappingMVCRenderCommand.class);
}
