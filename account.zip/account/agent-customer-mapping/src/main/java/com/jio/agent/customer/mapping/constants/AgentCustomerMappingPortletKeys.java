package com.jio.agent.customer.mapping.constants;

/**
 * @author Rahul1.Panchivala
 */
public class AgentCustomerMappingPortletKeys {

	public static final String PORTLET_NAME="com_jio_agent_customer_mapping_portlet_AgentCustomerMappingPortlet";

}