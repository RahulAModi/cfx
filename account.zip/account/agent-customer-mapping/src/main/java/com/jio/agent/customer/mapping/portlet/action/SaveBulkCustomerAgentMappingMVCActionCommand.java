package com.jio.agent.customer.mapping.portlet.action;

import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.agent.customer.mapping.constants.AgentCustomerMappingPortletKeys;
import com.jio.agent.customer.mapping.constants.MVCCommandNames;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.NoSuchUserException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + AgentCustomerMappingPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.UPLOAD_AGENT_CUSTOMER_MAPPING
		}, service = MVCActionCommand.class)
public class SaveBulkCustomerAgentMappingMVCActionCommand implements MVCActionCommand {
	
	private static final Log LOGGER = LogFactoryUtil.getLog(SaveBulkCustomerAgentMappingMVCActionCommand.class);

	@Override
	public boolean processAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortletException {
		
		try {
			//long userId = PortalUtil.getUserId(actionRequest);
			long groupId = PortalUtil.getScopeGroupId(actionRequest);
			long companyId = PortalUtil.getCompanyId(actionRequest);
	
			UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
			File file = request.getFile("file");
			//String fileName = request.getFileName("file").trim();
			try {

	            FileInputStream excelFile = new FileInputStream(file);
	            Iterator<Row> iterator = new XSSFWorkbook(excelFile).getSheetAt(0).iterator();
	            while (iterator.hasNext()) {

	                Row currentRow = iterator.next();
	                if(currentRow.getRowNum()!=0) {
	                	
	                	try {
	                		
		                	User agentUser = UserLocalServiceUtil.getUserByScreenName(companyId, currentRow.getCell(0).toString());
		                	User customerUser= UserLocalServiceUtil.getUserByScreenName(companyId, currentRow.getCell(1).toString());
		                	if(Validator.isNotNull(agentUser) && Validator.isNotNull(customerUser)) {
			                	AgentCustomerMapping agentCustomerMapping = null;
		            			try {
		            				agentCustomerMapping = _agentCustomerMappingLocalService.findByCustomerScreenName(companyId, currentRow.getCell(1).toString());
		            			} catch (NoSuchAgentCustomerMappingException e) {}
			                	if(Validator.isNotNull(agentCustomerMapping)) {
			                		agentCustomerMapping.setAgentScreenName(currentRow.getCell(0).toString());
			                		_agentCustomerMappingLocalService.updateAgentCustomerMapping(agentCustomerMapping);
			                	}else {
			                		agentCustomerMapping = _agentCustomerMappingLocalService.createAgentCustomerMapping("lhacm"+CounterLocalServiceUtil.increment(AgentCustomerMapping.class.getName()));
									agentCustomerMapping.setCompanyId(companyId);
									agentCustomerMapping.setGroupId(groupId);
									agentCustomerMapping.setAgentScreenName(currentRow.getCell(0).toString());
									agentCustomerMapping.setCustomerScreenName(currentRow.getCell(1).toString());
									_agentCustomerMappingLocalService.updateAgentCustomerMapping(agentCustomerMapping);
			                	}
		                	}
	                	} catch(NoSuchUserException e) {
	                		LOGGER.error("Error while saving agent bulk mapping with agent screename : "+currentRow.getCell(0).toString()+" and customer screenname : "+currentRow.getCell(1).toString());
	                	}
	                }
	            }
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
			
			SessionMessages.add(actionRequest, "bulk-agent-cutomer-mapping-updated");
		} catch (PortalException e) {
		}
		actionRequest.setAttribute("mvcRenderCommandName", MVCCommandNames.VIEW_AGENT_CUSTOMER_MAPPING);
		
		return false;
	}
	
	@Reference
	CustomerLocalService _customerLocalService;
	
	@Reference
	AgentCustomerMappingLocalService _agentCustomerMappingLocalService;
}