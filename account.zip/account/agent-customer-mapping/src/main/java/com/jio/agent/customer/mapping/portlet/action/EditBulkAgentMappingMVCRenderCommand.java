package com.jio.agent.customer.mapping.portlet.action;

import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.agent.customer.mapping.constants.AgentCustomerMappingPortletKeys;
import com.jio.agent.customer.mapping.constants.MVCCommandNames;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = {
		"javax.portlet.name=" + AgentCustomerMappingPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_BULK_AGENT_MAPPING
		}, service = MVCRenderCommand.class)
public class EditBulkAgentMappingMVCRenderCommand implements MVCRenderCommand {
	
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		return "/bulk_mapping.jsp";
	}

	@Reference
	protected AgentLocalService _agentLocalService;
	
	@Reference
	protected CustomerLocalService _customerLocalService;
	
}
