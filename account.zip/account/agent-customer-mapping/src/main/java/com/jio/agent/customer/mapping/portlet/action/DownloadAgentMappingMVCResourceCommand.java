package com.jio.agent.customer.mapping.portlet.action;

import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.agent.customer.mapping.constants.AgentCustomerMappingPortletKeys;
import com.jio.agent.customer.mapping.constants.MVCCommandNames;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.security.RandomUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = {
		"javax.portlet.name=" + AgentCustomerMappingPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.DOWNLOAD_AGENT_MAPPING
		}, service = MVCResourceCommand.class)
public class DownloadAgentMappingMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws PortletException {
		
		boolean resource = true;
		int rowNum = 0;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Agent Customer Mapping");
		
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		try {
			User user = PortalUtil.getUser(resourceRequest);
			List<Customer> customers = _customerLocalService.getCustomerByLogInAgent(user.getScreenName(), companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
			
			String[] customerScreenNames = customers.stream().map(customer -> customer.getScreenName()).collect(Collectors.toList()).stream().toArray(String[]::new);
			//List<String> screenNames = customers.stream().map(customer -> customer.getScreenName()).collect(Collectors.toList());
			//String[] agentScreenNames = screenNames.toArray(new String[screenNames.size()]);
			
			List<AgentCustomerMapping> agentCustomerMappingList = _agentCustomerMappingLocalService.getByCustomerScreenNames(companyId, customerScreenNames);		
			for (AgentCustomerMapping agentCustomerMapping : agentCustomerMappingList) {
	            
	            Row row=sheet.createRow(rowNum++);
	            Cell cell;
	            int colNum = 0;	
	            if(row.getRowNum()==0) {
	            	cell=row.createCell(colNum++);
	            	cell.setCellValue("Agent Screenname");
	            	cell = row.createCell(colNum++);
	            	cell.setCellValue("Customer Screenname");
	            	row=sheet.createRow(rowNum++);
		            colNum = 0;
	            	cell=row.createCell(colNum++);
	            	cell.setCellValue(agentCustomerMapping.getAgentScreenName());
	            	cell = row.createCell(colNum++);
	            	cell.setCellValue(agentCustomerMapping.getCustomerScreenName());
	            } else { 
	            	cell=row.createCell(colNum++);
	            	cell.setCellValue(agentCustomerMapping.getAgentScreenName());
	            	cell = row.createCell(colNum++);
	            	cell.setCellValue(agentCustomerMapping.getCustomerScreenName());
	            }
	        }
			
			try {
				String fileName = "agent_customer_mapping"+System.currentTimeMillis() + "" + RandomUtil.nextInt(1000)+".xls";
				File file = new File("C://download/"+fileName);
				file.getParentFile().mkdirs();
	
				//Write data to file
			    FileOutputStream out = new FileOutputStream(file);
			    workbook.write(out);
			    out.close();
			    workbook.close();	            
			    //Complete writing
			    
			    //Download file
			    InputStream in = new FileInputStream(file);
			    try {
			    	PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, in, ContentTypes.APPLICATION_VND_MS_EXCEL);
			    } catch (IOException e) {
			    	resource=false;
			    }	            
			    in.close();
			    //Complete download
			} catch (IOException e) {
				resource=false;
			}
		} catch (PortalException e1) {
			resource=false;
		}
		return resource;
	}
	
	@Reference
	CustomerLocalService _customerLocalService;
	
	@Reference
	AgentCustomerMappingLocalService _agentCustomerMappingLocalService;
}