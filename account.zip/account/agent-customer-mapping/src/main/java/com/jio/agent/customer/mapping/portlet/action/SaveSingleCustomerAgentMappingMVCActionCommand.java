package com.jio.agent.customer.mapping.portlet.action;

import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.agent.customer.mapping.constants.AgentCustomerMappingPortletKeys;
import com.jio.agent.customer.mapping.constants.MVCCommandNames;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.petra.string.StringUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + AgentCustomerMappingPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.SAVE_AGENT_CUSTOMER_MAPPING
		}, service = MVCActionCommand.class)
public class SaveSingleCustomerAgentMappingMVCActionCommand implements MVCActionCommand {
	
	private static final Log LOGGER = LogFactoryUtil.getLog(SaveSingleCustomerAgentMappingMVCActionCommand.class);

	@Override
	public boolean processAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortletException {
		
		try {
			long companyId = PortalUtil.getCompanyId(actionRequest);
			long groupId = PortalUtil.getScopeGroupId(actionRequest);
			List<String> customerScreenNames=StringUtil.split(ParamUtil.getString(actionRequest, "customerScreenNames"));
			String lcoScreenName = ParamUtil.getString(actionRequest, "lco");
			for (int i = 0; i < customerScreenNames.size(); i++) {
				try {
					AgentCustomerMapping mapping = _agentCustomerMappingLocalService.findByCustomerScreenName(companyId, customerScreenNames.get(i));
					mapping.setAgentScreenName(lcoScreenName);	
					_agentCustomerMappingLocalService.updateAgentCustomerMapping(mapping);
				} catch (NoSuchAgentCustomerMappingException e) {
					LOGGER.error("Error while updating agent customer mapping hence ading new mapping : "+customerScreenNames.get(i)+" : "+e.getLocalizedMessage());
					AgentCustomerMapping mapping = _agentCustomerMappingLocalService.createAgentCustomerMapping("lhacm"+CounterLocalServiceUtil.increment(AgentCustomerMapping.class.getName()));
					mapping.setCompanyId(companyId);
					mapping.setGroupId(groupId);
					mapping.setCustomerScreenName(customerScreenNames.get(i));
					mapping.setAgentScreenName(lcoScreenName);	
					_agentCustomerMappingLocalService.updateAgentCustomerMapping(mapping);
				}
			}
			SessionMessages.add(actionRequest, "single-agent-cutomer-mapping-updated");
			actionRequest.setAttribute("mvcRenderCommandName", MVCCommandNames.VIEW_AGENT_CUSTOMER_MAPPING);
		} catch (PortalException e1) {
			LOGGER.error("Error while saving customer agent mapping : "+e1.getLocalizedMessage());
		}
		return false;
	}
	
	@Reference
	CustomerLocalService _customerLocalService;
	
	@Reference
	AgentCustomerMappingLocalService _agentCustomerMappingLocalService;
}