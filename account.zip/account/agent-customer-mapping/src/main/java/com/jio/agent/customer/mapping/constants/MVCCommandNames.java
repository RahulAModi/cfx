package com.jio.agent.customer.mapping.constants;

/**
 * MVC Command name constants.
 * 
 * @author liferay
 *
 */
public class MVCCommandNames {

	public static final String VIEW_AGENT_CUSTOMER_MAPPING = "/agent-customer-mapping/view";
	
	public static final String SAVE_AGENT_CUSTOMER_MAPPING = "/agent-customer-mapping/save";
	
	public static final String EDIT_SINGLE_AGENT_MAPPING = "/single-agent-mapping/edit";
	
	public static final String EDIT_BULK_AGENT_MAPPING = "/bulk-agent-mapping/edit";
	
	public static final String UPLOAD_AGENT_CUSTOMER_MAPPING = "/agent-customer-mapping/upload";
	
	public static final String DOWNLOAD_AGENT_MAPPING = "/agent-customer-mapping/download";
	
	public static final String SEARCH_AGENT_MAPPING = "/agent-customer-mapping/search";
}
