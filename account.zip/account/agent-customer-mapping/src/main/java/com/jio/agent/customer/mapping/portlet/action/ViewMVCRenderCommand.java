package com.jio.agent.customer.mapping.portlet.action;

import com.jio.account.model.Agent;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.customer.mapping.constants.AgentCustomerMappingPortletKeys;
import com.jio.agent.customer.mapping.constants.MVCCommandNames;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + AgentCustomerMappingPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW_AGENT_CUSTOMER_MAPPING }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class);

	@Reference
	private AgentCustomerMappingLocalService agentCustomerMappingLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(renderRequest);
		String screenName = ParamUtil.getString(renderRequest, "screenName");
		String agentScreenName = ParamUtil.getString(renderRequest, "agentScreenName");

		try {
			User user = PortalUtil.getUser(renderRequest);
			if (Validator.isNotNull(user)) {
				boolean isAdmin = AccountUtil.isAdmin(user.getUserId());
				String[] agentScreenNames = new String[] {};

				Agent loggedInAgent = agentLocalService.getAgent(companyId, user.getScreenName());
				boolean isPrimaryAgent = loggedInAgent.getPrimary();
				if (isPrimaryAgent) {
					List<Agent> agents = agentLocalService.getAgents(companyId, user.getScreenName());
					renderRequest.setAttribute("agents", agents);
					agentScreenNames = agents.stream().map(agent -> agent.getScreenName()).collect(Collectors.toList()).stream().toArray(String[]::new);
				}

				PortletURL iteratorURL = renderResponse.createRenderURL();
				iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
				try {
					iteratorURL.setWindowState(WindowState.NORMAL);
				} catch (WindowStateException e) {
					LOGGER.error(e.toString());
				}

				SearchContainer<AgentCustomerMapping> searchContainer = new SearchContainer<AgentCustomerMapping>(renderRequest, iteratorURL, null, "there-are-no-agent-customer-mapping");

				List<AgentCustomerMapping> customers = null;
				int customerCount = GetterUtil.DEFAULT_INTEGER;

				try {
					if (Validator.isNotNull(agentScreenName)) {
						if (Validator.isNotNull(screenName)) {
							customers = agentCustomerMappingLocalService.getAgentCustomerMappings(companyId, agentScreenName, screenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = agentCustomerMappingLocalService.getAgentCustomerMappingsCount(companyId, agentScreenName, screenName);
						} else {
							customers = agentCustomerMappingLocalService.getAgentCustomerMappings(companyId, agentScreenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = agentCustomerMappingLocalService.getAgentCustomerMappingsCount(companyId, agentScreenName);
						}
					} else if (!ArrayUtil.isEmpty(agentScreenNames)) {
						if (Validator.isNotNull(screenName)) {
							customers = agentCustomerMappingLocalService.getAgentCustomerMappings(companyId, agentScreenNames, screenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = agentCustomerMappingLocalService.getAgentCustomerMappingsCount(companyId, agentScreenNames, screenName);
						} else {
							customers = agentCustomerMappingLocalService.getAgentCustomerMappings(companyId, agentScreenNames, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = agentCustomerMappingLocalService.getAgentCustomerMappingsCount(companyId, agentScreenNames);
						}
					} else {
						if (Validator.isNotNull(screenName)) {
							customers = agentCustomerMappingLocalService.getAgentCustomerMappings(companyId, screenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = agentCustomerMappingLocalService.getAgentCustomerMappingsCount(companyId, screenName);
						} else {
							customers = agentCustomerMappingLocalService.getAgentCustomerMappings(companyId, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = agentCustomerMappingLocalService.getAgentCustomerMappingsCount(companyId);
						}
					}
				} catch (SystemException e) {
					customers = new ArrayList<>();
					LOGGER.error("SystemException :: " + e.toString());
				}

				searchContainer.setDeltaConfigurable(true);
				searchContainer.setTotal(customerCount);
				searchContainer.setResults(customers);
				renderRequest.setAttribute("isAdmin", isAdmin);
				renderRequest.setAttribute("isPrimaryAgent", isPrimaryAgent);
				renderRequest.setAttribute("agentCustomerSearchContainer", searchContainer);
			} else {
				LOGGER.error("User is not loggedin");
			}

		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		return "/view.jsp";
	}
}
