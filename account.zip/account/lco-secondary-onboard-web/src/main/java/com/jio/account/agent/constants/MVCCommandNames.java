package com.jio.account.agent.constants;

/**
 * MVC Command name constants.
 * 
 * @author liferay
 *
 */
public class MVCCommandNames {

	public static final String UPLOAD_AGENT = "/agent/upload-agent";

	public static final String UPLOAD_AGENT_V2 = "/agent/upload-agent-v2";

	public static final String UPLOAD_AGENT_V3 = "/agent/upload-agent-v3";
	
	public static final String UPLOAD_AGENT_V4 = "/agent/upload-agent-v4";

	public static final String SAVE_UPLOAD_AGENT = "/agent/save-upload-agent";

	public static final String SAVE_UPLOAD_AGENT_V2 = "/agent/save-upload-agent-v2";

	public static final String SAVE_UPLOAD_AGENT_V3 = "/agent/save-upload-agent-v3";
	
	public static final String SAVE_UPLOAD_AGENT_V4 = "/agent/save-upload-agent-v4";

	public static final String DOWNLOAD_AGENT = "/agent/download-agent";

	public static final String EDIT_SECONDARY_LCO = "/secondary-lco/edit";

	public static final String SAVE_SECONDARY_LCO = "/secondary-lco/add";

	public static final String VIEW_SECONDARY_LCO = "/secondary-lco/view";

	public static final String DEACTIVE_SECONDARY_LCO = "/secondary-lco/deactive";

	public static final String EDIT_PRIMARY_LCO = "/primary-lco/edit";

	public static final String SAVE_PRIMARY_LCO = "/primary-lco/save";

	public static final String VIEW_PRIMARY_LCO = "/primary-lco/view";

	public static final String DEACTIVE_PRIMARY_LCO = "/primary-lco/deactive";

	public static final String EDIT_PERMISSION = "/secondary-lco/add_permission";

	public static final String SAVE_PERMISSION = "/secondary-lco/save";

	public static final String GET_LOCATION = "/agent/get-location";

	public static final String AUTO_RENEW = "/agent/auto_renew";

	public static final String VIEW_AGENT = "/agent/view-agent";

	public static final String GET_AGENT = "/agent/get-agent";

	public static final String SYNCH_BALANCE = "/agent/synch_balance";

	public static final String SYNCH_ROLE = "/agent/synch_role";

	public static final String SEARCH = "/agent/search";
}
