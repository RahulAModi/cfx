package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.bean.AgentBean;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.agent.service.AgentService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.security.auth.FullNameGeneratorFactory;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_SECONDARY_LCO }, service = MVCActionCommand.class)
public class SaveSecondaryMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		AgentBean agentBean = getLcoDetailsFromRequest(actionRequest, themeDisplay);
		LOGGER.info(">>" + agentBean.toString());
		if (validateSecondaryAgent(actionRequest, agentBean)) {
			LOGGER.info(">>" + agentBean.toString());
			agentService.saveAgent(themeDisplay.getUserId(), agentBean, ServiceContextFactory.getInstance(actionRequest));
			SessionMessages.add(actionRequest, "secondary-lco-added");
		} else {
			LOGGER.info("Error");
			PortalUtil.copyRequestParameters(actionRequest, actionResponse);
			actionResponse.setRenderParameter("mvcRenderCommandName", MVCCommandNames.EDIT_SECONDARY_LCO);
		}
		hideDefaultSuccessMessage(actionRequest);
		hideDefaultErrorMessage(actionRequest);
	}

	private AgentBean getLcoDetailsFromRequest(ActionRequest actionRequest, ThemeDisplay themeDisplay) {

		AgentBean lco = new AgentBean();
		lco.setScreenName(ParamUtil.getString(actionRequest, "screenName").toLowerCase());
		if (Validator.isNull(lco.getScreenName())) {
			lco.setUserId(ParamUtil.getLong(actionRequest, "userId"));
			try {
				lco.setScreenName(userLocalService.getUser(lco.getUserId()).getScreenName());
			} catch (PortalException e) {
			}
		}
		lco.setFirstName(ParamUtil.getString(actionRequest, "firstName"));
		lco.setMiddleName(ParamUtil.getString(actionRequest, "middleName"));
		lco.setLastName(ParamUtil.getString(actionRequest, "lastName"));
		lco.setMobileNo(ParamUtil.getString(actionRequest, "mobileNo"));
		lco.setName(FullNameGeneratorFactory.getInstance().getFullName(lco.getFirstName(), lco.getMiddleName(), lco.getLastName()));

		lco.setEmail(ParamUtil.getString(actionRequest, "email").toLowerCase());
		if (Validator.isNull(lco.getEmail())) {
			lco.setEmail(ParamUtil.getString(actionRequest, "emailAddress"));
		}

		lco.setCompanyId(themeDisplay.getCompanyId());
		lco.setGroupId(themeDisplay.getScopeGroupId());

		try {
			Agent agent = agentLocalService.getAgent(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName());
			lco.setParentCode(agent.getScreenName());
			lco.setPrimary(Boolean.FALSE);
			lco.setJvNo(agent.getJvNo());
			lco.setDirectNo(agent.getDirectNo());
			lco.setPoId(agent.getPoId());
			lco.setAccountNo(agent.getAccountNo());
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.toString());
		}

		try {
			Address address = addressLocalService.getAddress(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName());
			lco.setAddress(address.getAddress());
			lco.setState(address.getStateCode());
			lco.setCity(address.getCityCode());
			lco.setPincode(address.getPincode());
		} catch (NoSuchAddressException e) {
			LOGGER.error("NoSuchAddressException : " + e.toString());
		}
		return lco;
	}

	private boolean validateSecondaryAgent(ActionRequest actionRequest, AgentBean agentDetail) {

		boolean valid = Boolean.TRUE;

		if (Validator.isNull(agentDetail.getScreenName())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "login-id-required");
			LOGGER.error("login-id-required");
		} else {
			if (agentDetail.getUserId() == 0) {
				try {
					userLocalService.getUserByScreenName(agentDetail.getCompanyId(), agentDetail.getScreenName());
					valid = Boolean.FALSE;
					SessionErrors.add(actionRequest, "login-id-already-exist");
					LOGGER.error("login-id-already-exist");
				} catch (PortalException e) {
				}
			}
		}

		if (Validator.isNull(agentDetail.getFirstName())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "first-name-required");
			LOGGER.error("first-name-required");
		}

		if (Validator.isNull(agentDetail.getLastName())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "last-name-required");
			LOGGER.error("last-name-required");
		}

		if (Validator.isNull(agentDetail.getMobileNo())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "mobile-no-required");
			LOGGER.error("mobile-no-required");
		}

		if (Validator.isNull(agentDetail.getEmail())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "email-address-required");
			LOGGER.error("email-address-required");
		} else if (!Validator.isEmailAddress(agentDetail.getEmail())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "email-address-format");
			LOGGER.error("email-address-format");
		} else {
			if (agentDetail.getUserId() == 0) {
				try {
					userLocalService.getUserByEmailAddress(agentDetail.getCompanyId(), agentDetail.getEmail());
					valid = Boolean.FALSE;
					SessionErrors.add(actionRequest, "email-already-exist");
					LOGGER.error("email-already-exist");
				} catch (PortalException e) {
				}
			}

		}
		return valid;
	}

	@Reference
	protected AddressLocalService addressLocalService;

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	protected AgentService agentService;

	@Reference
	protected UserLocalService userLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveSecondaryMVCActionCommand.class);
}
