package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.master.location.exception.NoSuchLocationCategoryException;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.EDIT_PRIMARY_LCO }, service = MVCRenderCommand.class)
public class EditPrimaryMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
		portletDisplay.setShowBackIcon(Boolean.TRUE);
		portletDisplay.setURLBack(ParamUtil.getString(renderRequest, "redirect"));

		String agentScreenName = ParamUtil.getString(renderRequest, "agentScreenName");
		if (Validator.isNotNull(agentScreenName)) {
			try {
				renderRequest.setAttribute("primaryLCOAgent", agentLocalService.getAgent(themeDisplay.getCompanyId(), agentScreenName));
			} catch (NoSuchAgentException e) {
				_log.error("Error while getting secondary agent information : " + agentScreenName);
			}
		}
		try {
			renderRequest.setAttribute("agent", agentLocalService.getAgent(themeDisplay.getCompanyId(), agentScreenName));
		} catch (NoSuchAgentException e) {
			_log.error("Error while getting agent information : " + agentScreenName);
		}

		try {
			renderRequest.setAttribute("address", addressLocalService.getAddress(themeDisplay.getCompanyId(), agentScreenName));
		} catch (NoSuchAddressException e) {
			_log.error("Error while getting address information : " + agentScreenName);
		}

		try {
			renderRequest.setAttribute("states", locationLocalService.getStates(themeDisplay.getCompanyId()));
		} catch (NoSuchLocationCategoryException e) {
			_log.error("Error while getting states : " + e.getLocalizedMessage());
		}

		return "/edit_primary.jsp";
	}

	@Reference
	protected AddressLocalService addressLocalService;

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	protected LocationLocalService locationLocalService;

	private static final Log _log = LogFactoryUtil.getLog(EditPrimaryMVCRenderCommand.class);
}