package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.lco.permission.service.AgentPermissionLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_PERMISSION }, service = MVCActionCommand.class)
public class SavePermissionMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(SavePermissionMVCActionCommand.class);

	@Reference
	private AgentPermissionLocalService agentPermissionLocalService;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		long companyId = PortalUtil.getCompanyId(actionRequest);
		long groupId = PortalUtil.getScopeGroupId(actionRequest);
		User user = PortalUtil.getUser(actionRequest);

		String agentScreenName = ParamUtil.getString(actionRequest, "agentScreenName");
		long[] permissionIds = ParamUtil.getLongValues(actionRequest, "permissionId");
		List<Long> permissionIdList = Arrays.stream(permissionIds).boxed().collect(Collectors.toList());
		agentPermissionLocalService.addAgentPermissions(permissionIdList, agentScreenName, companyId, groupId, user.getScreenName());

	}
}