package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.WebKeys;

import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.VIEW_AGENT }, service = MVCRenderCommand.class)
public class ViewAgentMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		try {
			Agent agent = agentLocalService.getAgent(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName());
			List<Agent> agentList = null;
			if (agent.isPrimary()) {
				agentList = agentLocalService.getAgents(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName());
			} else {
				agentList = new ArrayList<Agent>();
				agentList.add(agent);
			}
			renderRequest.setAttribute("agentList", agentList);
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.toString());
		}
		return "/view_agent.jsp";
	}

	@Reference
	protected AgentLocalService agentLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(ViewAgentMVCRenderCommand.class);
}