package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Contact;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD_AGENT }, service = MVCResourceCommand.class)
public class DownloadMVCResourceCommand implements MVCResourceCommand {

	private static final Log _log = LogFactoryUtil.getLog(DownloadMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean resource = true;

		try {

			StringBundler sb = new StringBundler();
			for (String columnName : CSV_HEADER) {
				sb.append(columnName);
				sb.append(CharPool.PIPE);
			}
			sb.setIndex(sb.index() - 1);
			sb.append(CharPool.NEW_LINE);

			long companyId = PortalUtil.getCompanyId(resourceRequest);
			List<Agent> agentList = agentLocalService.getAgents(companyId);
			for (Agent agent : agentList) {
				try {
					User user = UserLocalServiceUtil.getUserByScreenName(companyId, agent.getScreenName());
					sb.append(agent.getScreenName());
					sb.append(CharPool.PIPE);
					sb.append(user.getFirstName());
					sb.append(CharPool.PIPE);
					sb.append(user.getMiddleName());
					sb.append(CharPool.PIPE);
					sb.append(user.getLastName());

					Contact contact = contactLocalService.getContact(companyId, agent.getScreenName());
					sb.append(CharPool.PIPE);
					sb.append(contact.getMobileNo());
					sb.append(CharPool.PIPE);
					sb.append(contact.getEmail());

					sb.append(CharPool.PIPE);
					sb.append(agent.getGstinNo());
					sb.append(CharPool.PIPE);
					sb.append(agent.isPrimary());
					sb.append(CharPool.PIPE);
					sb.append(agent.getParentCode());
					sb.append(CharPool.PIPE);
					sb.append(agent.getJvNo());
					sb.append(CharPool.PIPE);
					sb.append(agent.getDirectNo());
					sb.append(CharPool.PIPE);
					sb.append(agent.getPoId());
					sb.append(CharPool.PIPE);
					sb.append(agent.getAccountNo());
					sb.append(CharPool.PIPE);
					sb.append(agent.getStatus());

					Address address = addressLocalService.getAddress(companyId, agent.getScreenName());
					sb.append(CharPool.PIPE);
					sb.append(address.getAddress());

					Location location = locationLocalService.getLocationsByCode(address.getStateCode(), companyId);
					sb.append(CharPool.PIPE);
					sb.append(location.getName());
					location = locationLocalService.getLocationsByCode(address.getCityCode(), companyId);
					sb.append(CharPool.PIPE);
					sb.append(location.getName());
					location = locationLocalService.getLocationsByCode(address.getPincode(), companyId);
					sb.append(CharPool.PIPE);
					sb.append(location.getName());
					sb.append(CharPool.PIPE);
					sb.setIndex(sb.index() - 1);
					sb.append(CharPool.NEW_LINE);

				} catch (Exception e) {
					_log.error("Error while getting agent detail : " + e.getLocalizedMessage());
				}
			}

			String fileName = "lco_agent.csv";
			byte[] bytes = sb.toString().getBytes();
			String contentType = ContentTypes.APPLICATION_TEXT;
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, bytes, contentType);
			} catch (Exception e) {
				_log.error("Exception :: " + e.toString());
				resource = false;
			}

			resource = false;
		} catch (SystemException e) {
			_log.error("SystemException :: " + e.toString());
			resource = false;
		}
		return resource;
	}

	private static final String[] CSV_HEADER = new String[] { "screenName", "firstName", "middleName", "lastName", "mobileNo", "email", "gstin", "primary", "parentCode", "jvNo", "directNo", "brmPOID", "accountNo", "status", "addressLine1", "state", "city", "pincode" };

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private LocationLocalService locationLocalService;
}