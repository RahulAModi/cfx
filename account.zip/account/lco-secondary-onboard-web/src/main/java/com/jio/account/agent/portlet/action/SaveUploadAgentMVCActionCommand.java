package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.bean.AgentBean;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.agent.service.AgentService;
import com.jio.csv.util.CSVUtil;
import com.liferay.petra.string.CharPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD_AGENT }, service = MVCActionCommand.class)
public class SaveUploadAgentMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		final ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final ServiceContext serviceContext = ServiceContextFactory.getInstance(actionRequest);

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();
		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (csvUtil.isNotCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.PIPE);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;
					Runnable runnable = new Runnable() {

						@Override
						public void run() {

							saveAgentDetails(csvRecords, themeDisplay, serviceContext);
						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}

		hideDefaultSuccessMessage(actionRequest);
		hideDefaultErrorMessage(actionRequest);
	}

	public List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	private void saveAgentDetails(List<CSVRecord> csvRecords, ThemeDisplay themeDisplay, ServiceContext serviceContext) {

		for (CSVRecord csvRecord : csvRecords) {

			AgentBean lco = new AgentBean();
			lco.setScreenName(csvRecord.get("screenName").trim());
			lco.setFirstName(csvRecord.get("firstName").trim());
			lco.setLastName(csvRecord.get("lastName").trim());
			lco.setEmail(csvRecord.get("email").trim());
			lco.setPrimary(GetterUtil.getBoolean(csvRecord.get("primary").trim()));

			lco.setMiddleName(csvRecord.get("middleName").trim());
			lco.setMobileNo(csvRecord.get("mobileNo").trim());
			lco.setName(lco.getFirstName() + " " + lco.getMiddleName() + " " + lco.getLastName());
			lco.setParentCode(csvRecord.get("parentCode").trim());
			if (lco.isPrimary()) {

				lco.setGstin(csvRecord.get("gstin").trim());
				lco.setJvNo(csvRecord.get("jvNo").trim());
				lco.setDirectNo(csvRecord.get("directNo").trim());
				lco.setPoId(csvRecord.get("brmPOID").trim());
				lco.setAccountNo(lco.getScreenName());

				lco.setAddress(csvRecord.get("address").trim());
				lco.setState(csvRecord.get("state").trim());
				lco.setCity(csvRecord.get("city").trim());
				lco.setPincode(csvRecord.get("pincode").trim());
			} else {
				try {
					Agent primaryAgent = agentLocalService.getAgent(themeDisplay.getCompanyId(), lco.getParentCode());
					lco.setGstin(primaryAgent.getGstinNo());
					lco.setJvNo(primaryAgent.getJvNo());
					lco.setDirectNo(primaryAgent.getDirectNo());
					lco.setPoId(primaryAgent.getPoId());
					lco.setAccountNo(primaryAgent.getAccountNo());
				} catch (NoSuchAgentException e) {
					lco.setGstin(csvRecord.get("gstin").trim());
					lco.setJvNo(csvRecord.get("jvNo").trim());
					lco.setDirectNo(csvRecord.get("directNo").trim());
					lco.setPoId(csvRecord.get("brmPOID").trim());
					lco.setAccountNo(lco.getScreenName());
				}

				try {
					Address address = addressLocalService.getAddress(themeDisplay.getCompanyId(), lco.getParentCode());
					lco.setAddress(address.getAddress());
					lco.setState(address.getStateCode());
					lco.setCity(address.getCityCode());
					lco.setPincode(address.getPincode());
				} catch (NoSuchAddressException e) {
					lco.setAddress(csvRecord.get("address").trim());
					lco.setState(csvRecord.get("state").trim());
					lco.setCity(csvRecord.get("city").trim());
					lco.setPincode(csvRecord.get("pincode").trim());
				}
			}
			lco.setStatus(WorkflowConstants.STATUS_APPROVED);

			lco.setCompanyId(themeDisplay.getCompanyId());
			lco.setGroupId(themeDisplay.getScopeGroupId());
			if (validateAgent(lco)) {
				try {
					agentService.saveAgent(themeDisplay.getUserId(), lco, serviceContext);
				} catch (PortalException e) {
					LOGGER.info("PortalException :: " + e.toString());
				}
			}

		}
	}

	private boolean validateAgent(AgentBean lco) {

		boolean valid = Boolean.TRUE;
		if (Validator.isNull(lco.getScreenName())) {
			valid = Boolean.FALSE;
			LOGGER.error("Login ID Required");
		}
		if (Validator.isNull(lco.getFirstName())) {
			valid = Boolean.FALSE;
			LOGGER.error("First Name Required");
		}
		if (Validator.isNull(lco.getLastName())) {
			valid = Boolean.FALSE;
			LOGGER.error("Last Name Required");
		}
		if (Validator.isNull(lco.getMobileNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Mobile No Required");
		}
		if (Validator.isNull(lco.getJvNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("JV No Required");
		}
		if (Validator.isNull(lco.getDirectNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Direct No Required");
		}
		if (Validator.isNull(lco.getPoId())) {
			valid = Boolean.FALSE;
			LOGGER.error("BRM POID Required");
		}
		if (Validator.isNull(lco.getAccountNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Account No Required");
		}
		if (Validator.isNull(lco.getAddress())) {
			valid = Boolean.FALSE;
			LOGGER.error("Address Required");
		}
		if (Validator.isNull(lco.getState())) {
			valid = Boolean.FALSE;
			LOGGER.error("State Required");
		}
		if (Validator.isNull(lco.getCity())) {
			valid = Boolean.FALSE;
			LOGGER.error("City Required");
		}
		if (Validator.isNull(lco.getPincode())) {
			valid = Boolean.FALSE;
			LOGGER.error("Pincode Required");
		}
		if (Validator.isNull(lco.getEmail())) {
			valid = Boolean.FALSE;
			LOGGER.error("Email Address Required");
		}
		if (Validator.isNull(lco.getMobileNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Mobile No Required");
		}
		return valid;
	}

	@Reference
	protected AddressLocalService addressLocalService;

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	protected ContactLocalService contactLocalService;

	@Reference
	protected AgentService agentService;

	@Reference
	private CSVUtil csvUtil;

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveUploadAgentMVCActionCommand.class);
}
