package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.bean.AgentBean;
import com.jio.account.model.Agent;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.agent.service.AgentService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_PRIMARY_LCO }, service = MVCActionCommand.class)
public class SavePrimaryMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		AgentBean agentBean = getLcoDetailsFromRequest(actionRequest, themeDisplay);
		if (validateSecondaryAgent(actionRequest, agentBean)) {
			agentService.saveAgent(themeDisplay.getUserId(), agentBean, ServiceContextFactory.getInstance(actionRequest));
			SessionMessages.add(actionRequest, "primary-agentBean-added");
		} else {
			PortalUtil.copyRequestParameters(actionRequest, actionResponse);
			actionResponse.setRenderParameter("mvcRenderCommandName", MVCCommandNames.EDIT_PRIMARY_LCO);
		}
		hideDefaultSuccessMessage(actionRequest);
		hideDefaultErrorMessage(actionRequest);
	}

	private AgentBean getLcoDetailsFromRequest(ActionRequest actionRequest, ThemeDisplay themeDisplay) {

		AgentBean agentBean = new AgentBean();
		agentBean.setScreenName(ParamUtil.getString(actionRequest, "screenName").toLowerCase().trim());
		if (Validator.isNull(agentBean.getScreenName())) {
			agentBean.setUserId(ParamUtil.getLong(actionRequest, "userId"));
			try {
				agentBean.setScreenName(UserLocalServiceUtil.getUser(agentBean.getUserId()).getScreenName().toLowerCase().trim());
			} catch (PortalException e) {
				LOGGER.error("Error while getting user : " + e.getLocalizedMessage());
			}
		}
		agentBean.setFirstName(ParamUtil.getString(actionRequest, "firstName").trim());
		agentBean.setMiddleName(ParamUtil.getString(actionRequest, "middleName").trim());
		agentBean.setLastName(ParamUtil.getString(actionRequest, "lastName").trim());
		agentBean.setMobileNo(ParamUtil.getString(actionRequest, "mobileNo"));
		agentBean.setName(agentBean.getFirstName() + " " + agentBean.getMiddleName() + " " + agentBean.getLastName());

		agentBean.setEmail(ParamUtil.getString(actionRequest, "email").toLowerCase());
		if (Validator.isNull(agentBean.getEmail()) || !Validator.isEmailAddress(agentBean.getEmail())) {
			agentBean.setEmail(agentBean.getScreenName() + StringPool.AT + themeDisplay.getCompany().getMx());
		}

		agentBean.setCompanyId(themeDisplay.getCompanyId());
		agentBean.setGroupId(themeDisplay.getScopeGroupId());

		agentBean.setParentCode(agentBean.getScreenName());
		agentBean.setPrimary(Boolean.TRUE);
		agentBean.setJvNo(ParamUtil.getString(actionRequest, "jvNo"));
		agentBean.setDirectNo(ParamUtil.getString(actionRequest, "directNo"));
		agentBean.setPoId(ParamUtil.getString(actionRequest, "brmPoid"));
		agentBean.setAccountNo(ParamUtil.getString(actionRequest, "accountNo"));

		agentBean.setAddress(ParamUtil.getString(actionRequest, "address"));
		agentBean.setState(ParamUtil.getString(actionRequest, "state"));
		agentBean.setCity(ParamUtil.getString(actionRequest, "city"));
		agentBean.setPincode(ParamUtil.getString(actionRequest, "pincode"));
		agentBean.setCreatedBy(themeDisplay.getUser().getScreenName());
		return agentBean;
	}

	private boolean validateSecondaryAgent(ActionRequest actionRequest, AgentBean agentBean) {

		boolean valid = Boolean.TRUE;

		try {
			Agent agent = agentLocalService.getAgent(agentBean.getCompanyId(), agentBean.getScreenName());
			if (Validator.isNotNull(agent.getScreenName())) {
				if (UserLocalServiceUtil.getUserByScreenName(agentBean.getCompanyId(), agent.getScreenName()).getUserId() != agentBean.getUserId()) {
					valid = Boolean.FALSE;
					SessionErrors.add(actionRequest, "login-id-already-exist");
					LOGGER.error("Login ID Already Exist");
				}
			}
		} catch (PortalException e) {
		}
		if (Validator.isNull(agentBean.getScreenName())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "login-id-required");
			LOGGER.error("Login ID Required");
		}
		if (Validator.isNull(agentBean.getFirstName())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "first-name-required");
			LOGGER.error("First Name Required");
		}
		if (Validator.isNull(agentBean.getLastName())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "last-name-required");
			LOGGER.error("Last Name Required");
		}
		if (Validator.isNull(agentBean.getMobileNo())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "mobile-no-required");
			LOGGER.error("Mobile No Required");
		}
		if (Validator.isNull(agentBean.getJvNo())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "jv-no-required");
			LOGGER.error("JV No Required");
		}
		if (Validator.isNull(agentBean.getDirectNo())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "direct-no-required");
			LOGGER.error("Direct No Required");
		}
		if (Validator.isNull(agentBean.getPoId())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "brm-poid-required");
			LOGGER.error("BRM POID Required");
		}
		if (Validator.isNull(agentBean.getAccountNo())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "account-no-required");
			LOGGER.error("Account No Required");
		}
		if (Validator.isNull(agentBean.getAddress())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "address-required");
			LOGGER.error("Address Required");
		}
		if (Validator.isNull(agentBean.getState())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "state-required");
			LOGGER.error("State Required");
		}
		if (Validator.isNull(agentBean.getCity())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "city-required");
			LOGGER.error("City Required");
		}
		if (Validator.isNull(agentBean.getPincode())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "pincode-required");
			LOGGER.error("Pincode Required");
		}
		if (Validator.isNull(agentBean.getEmail())) {
			valid = Boolean.FALSE;
			SessionErrors.add(actionRequest, "email-address-required");
			LOGGER.error("Email Address Required");
		}
		return valid;
	}

	@Reference
	protected AddressLocalService addressLocalService;

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	protected AgentService agentService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SavePrimaryMVCActionCommand.class);
}
