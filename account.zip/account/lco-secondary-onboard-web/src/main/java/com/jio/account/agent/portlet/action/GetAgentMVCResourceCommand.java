package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Contact;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_AGENT }, service = MVCResourceCommand.class)
public class GetAgentMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String agentScreenName = ParamUtil.getString(resourceRequest, "agentScreenName");
		if (Validator.isNotNull(agentScreenName)) {
			try {
				Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
				Address address = addressLocalService.getAddress(agent.getCompanyId(), agent.getScreenName());
				Contact contact = contactLocalService.getContact(agent.getCompanyId(), agent.getScreenName());
				resourceRequest.setAttribute("agent", agent);
				resourceRequest.setAttribute("address", address);
				resourceRequest.setAttribute("contact", contact);

				JSONObject jsonObject = getJsonObject(agent, address, contact);
				resourceResponse.getWriter().println(jsonObject);
				return Boolean.TRUE;

			} catch (NoSuchAgentException e) {
				LOGGER.error("NoSuchAgentException : " + e.toString());
			} catch (NoSuchAddressException e) {
				LOGGER.error("NoSuchAddressException : " + e.toString());
			} catch (NoSuchContactException e) {
				LOGGER.error("NoSuchContactException : " + e.toString());
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}
		}

		return Boolean.FALSE;
	}

	private JSONObject getJsonObject(Agent agent, Address address, Contact contact) {
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		jsonObject.put("screenName", agent.getScreenName());
		jsonObject.put("name", agent.getName());
		jsonObject.put("parentCode", agent.getParentCode());
		jsonObject.put("primary", agent.getPrimary());
		jsonObject.put("jvNo", agent.getJvNo());
		jsonObject.put("jvName", agent.getJvName());
		jsonObject.put("jvPoId", agent.getJvPoId());
		jsonObject.put("directNo", agent.getDirectNo());
		jsonObject.put("dtName", agent.getDistributorName());
		jsonObject.put("dtPoId", agent.getDistributorPoId());
		jsonObject.put("sdtName", agent.getSubDistributorName());
		jsonObject.put("sdtPoId", agent.getSubDistributorPoId());
		jsonObject.put("poId", agent.getPoId());
		jsonObject.put("accountNo", agent.getAccountNo());
		jsonObject.put("status", agent.getStatus());
		jsonObject.put("autoRenew", agent.getAutoRenew() ? "ON" : "OFF");
		jsonObject.put("email", contact.getEmail());
		jsonObject.put("mobileNo", contact.getMobileNo());
		jsonObject.put("address", address.getAddress());
		try {
			jsonObject.put("city", locationLocalService.getLocationByCode(address.getCityCode(), address.getCompanyId()).getCode());
		} catch (NoSuchLocationException e) {
			LOGGER.warn("NoSuchLocationException : " + e.toString());
		}
		return jsonObject;
	}

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	protected AddressLocalService addressLocalService;

	@Reference
	protected ContactLocalService contactLocalService;

	@Reference
	protected LocationLocalService locationLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(GetAgentMVCResourceCommand.class);
}
