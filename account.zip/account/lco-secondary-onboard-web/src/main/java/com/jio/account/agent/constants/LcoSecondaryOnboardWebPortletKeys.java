package com.jio.account.agent.constants;

/**
 * @author Rahul1.Panchivala
 */
public class LcoSecondaryOnboardWebPortletKeys {

	public static final String PORTLET_NAME = "com_jio_account_portlet_LcoSecondaryOnboardWebPortlet";
	public static final String[] TYPE = { "MODULE", "ACTION" };

}