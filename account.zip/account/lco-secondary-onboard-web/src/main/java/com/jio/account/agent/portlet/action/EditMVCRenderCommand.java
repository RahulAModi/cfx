package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.EDIT_SECONDARY_LCO }, service = MVCRenderCommand.class)
public class EditMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String agentScreenName = ParamUtil.getString(renderRequest, "agentScreenName");
		String agentParentScreenName = ParamUtil.getString(renderRequest, "agentParentScreenName");
		if (Validator.isNotNull(agentScreenName)) {
			try {

				renderRequest.setAttribute("secondaryLCOAgent", _agentLocalService.getAgent(themeDisplay.getCompanyId(), agentScreenName));
			} catch (NoSuchAgentException e) {
				_log.error("Error while getting secondry agent information : " + themeDisplay.getUser().getScreenName());
			}
		}
		try {
			if (Validator.isNull(agentParentScreenName)) {
				renderRequest.setAttribute("agent", _agentLocalService.getAgent(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName()));
			} else {
				renderRequest.setAttribute("agent", _agentLocalService.getAgent(themeDisplay.getCompanyId(), agentParentScreenName));
			}
		} catch (NoSuchAgentException e) {
			_log.error("Error while getting agent information : " + themeDisplay.getUser().getScreenName());
		}
		try {
			if (Validator.isNull(agentParentScreenName)) {
				renderRequest.setAttribute("address", _addressLocalService.getAddress(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName()));
			} else {
				renderRequest.setAttribute("address", _addressLocalService.getAddress(themeDisplay.getCompanyId(), agentParentScreenName));
			}
		} catch (NoSuchAddressException e) {
			_log.error("Error while getting address information : " + agentParentScreenName);
		}

		return "/edit_secondary.jsp";
	}

	@Reference
	protected AddressLocalService _addressLocalService;

	@Reference
	protected AgentLocalService _agentLocalService;

	private static final Log _log = LogFactoryUtil.getLog(EditMVCRenderCommand.class);
}