package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_LOCATION }, service = MVCResourceCommand.class)
public class GetChildLocationMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		try {
			List<Location> locations = locationLocalService.getChildLocations(ParamUtil.getString(resourceRequest, "searchKeyword"), PortalUtil.getCompanyId(resourceRequest));

			if (Validator.isNotNull(locations)) {
				JSONArray outputArray = JSONFactoryUtil.createJSONArray();
				outputArray = getJsonArrayByLocationMasterList(locations);
				resourceResponse.getWriter().println(outputArray);
				return Boolean.TRUE;
			}
		} catch (Exception e) {
			_log.error("Error while getting cities : " + e.getLocalizedMessage());
		}
		return Boolean.FALSE;
	}

	public JSONArray getJsonArrayByLocationMasterList(List<Location> parentLocations) {

		JSONArray outputArray = JSONFactoryUtil.createJSONArray();
		JSONObject outputObject;
		for (Location location : parentLocations) {
			outputObject = JSONFactoryUtil.createJSONObject();
			outputObject.put("code", location.getCode());
			outputObject.put("name", location.getName());
			outputArray.put(outputObject);
		}
		return outputArray;
	}

	@Reference
	protected LocationLocalService locationLocalService;

	private static final Log _log = LogFactoryUtil.getLog(GetChildLocationMVCResourceCommand.class);
}
