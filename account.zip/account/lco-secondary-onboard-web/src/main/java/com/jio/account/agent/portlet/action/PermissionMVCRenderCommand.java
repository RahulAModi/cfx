package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.lco.permission.model.Permission;
import com.jio.lco.permission.service.PermissionLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.EDIT_PERMISSION }, service = MVCRenderCommand.class)
public class PermissionMVCRenderCommand implements MVCRenderCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(PermissionMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(renderRequest);
		String agentScreenName = ParamUtil.getString(renderRequest, "agentScreenName");
		try {

			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);

			renderRequest.setAttribute("secondaryLCOAgent", agent);

			List<Permission> permissions = permissionLocalService.getPermissions(0L, companyId);
			renderRequest.setAttribute("permissions", permissions);

			Map<Permission, List<Permission>> permissionMap = new HashMap<Permission, List<Permission>>();
			for (Permission permission : permissions) {
				List<Permission> childPermissions = permissionLocalService.getPermissions(permission.getPermissionId(), companyId);
				permissionMap.put(permission, childPermissions);
			}
			renderRequest.setAttribute("permissionMap", permissionMap);

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		}

		return "/edit_permission.jsp";
	}

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	private PermissionLocalService permissionLocalService;

}