package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.agent.service.AgentService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SYNCH_BALANCE }, service = MVCResourceCommand.class)
public class SynchBalanceMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		final long companyId = PortalUtil.getCompanyId(resourceRequest);
		List<Agent> agents = agentLocalService.getAgents(companyId);
		agents.parallelStream().forEach(agent -> {
			agentService.saveOrUpdateBalance(agent);

			try {
				User user = userLocalService.getUserByScreenName(companyId, agent.getAccountNo());
				String name = user.getFirstName();
				if (Validator.isNotNull(user.getMiddleName())) {
					name = name.concat(" ").concat(user.getMiddleName()).concat(" ").concat(user.getLastName());
				} else {
					name = name.concat(" ").concat(user.getLastName());
				}

				agentService.saveOrUpdateAgent(agent.getCompanyId(), agent.getGroupId(), agent.getCreateBy(), agent.getScreenName(), name, agent.getParentCode(), agent.isPrimary(), agent.getJvNo(), agent.getDirectNo(), agent.getPoId(), agent.getAccountNo(), agent.getGstinNo(), agent.getStatus(),
						agent.getDistributor(), agent.getSubDistributor(), agent.getPrefDom(), agent.getJvPoId(), agent.getDirectPoId(), agent.getDistributorPoId(), agent.getSubDistributorPoId(), agent.getDirectName(), agent.getDistributorName(), agent.getSubDistributorName(), agent.getPanNo(),
						agent.getReportDate(), agent.getPpType(), agent.getLocator());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.toString());
			}

		});

		return Boolean.TRUE;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private AgentService agentService;

	@Reference
	private UserLocalService userLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SynchBalanceMVCResourceCommand.class);
}
