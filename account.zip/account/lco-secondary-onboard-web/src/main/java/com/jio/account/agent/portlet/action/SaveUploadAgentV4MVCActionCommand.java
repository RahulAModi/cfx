package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.csv.util.CSVUtil;
import com.liferay.petra.string.CharPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD_AGENT_V4 }, service = MVCActionCommand.class)
public class SaveUploadAgentV4MVCActionCommand extends BaseMVCActionCommand {
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		long companyId = PortalUtil.getCompanyId(actionRequest);
		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();
		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (csvUtil.isNotCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.COMMA);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;
					Runnable runnable = new Runnable() {

						@Override
						public void run() {

							saveAgentDetails(csvRecords, companyId);
						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}

		hideDefaultSuccessMessage(actionRequest);
		hideDefaultErrorMessage(actionRequest);
	}

	public List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	private void saveAgentDetails(List<CSVRecord> csvRecords, long companyId) {

		for (CSVRecord csvRecord : csvRecords) {
			String locCode = csvRecord.get("LCO_CODE");
			String jvNo = csvRecord.get("JV_NO");
			String directNo = csvRecord.get("DIRECT_NO");
			String directName = csvRecord.get("DIRECT_NO_COMPANY");
			String directPoId = csvRecord.get("DIRECT_NO_POID");
			String jvPoId = csvRecord.get("JV_POID");
			String jvName = csvRecord.get("JV_COMPANY");
			try {
				Agent agent = agentLocalService.getAgent(companyId, locCode);
				agent.setDirectNo(directNo);
				agent.setDirectName(directName);
				agent.setDirectPoId(directPoId);
				agent.setJvNo(jvNo);
				agent.setJvPoId(jvPoId);
				agent.setJvName(jvName);
				agentLocalService.updateAgent(agent);
			} catch (NoSuchAgentException e) {
				LOGGER.error("NoSuchAgentException : " + e.toString());
			}

		}
	}

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	private CSVUtil csvUtil;

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveUploadAgentV4MVCActionCommand.class);
}