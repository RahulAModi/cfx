package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;

@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME,
			"mvc.command.name=" + MVCCommandNames.DEACTIVE_SECONDARY_LCO
		},
		service = MVCActionCommand.class
	)
	public class DeactiveMVCActionCommand extends BaseMVCActionCommand {

		@Override
		protected void doProcessAction(
			ActionRequest actionRequest, ActionResponse actionResponse)
			throws Exception {

			ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
			String screenName = ParamUtil.getString(actionRequest, "agentScreenName");
			User user = UserLocalServiceUtil.getUserByScreenName(themeDisplay.getCompanyId(), screenName);
			if(user.getStatus()==WorkflowConstants.STATUS_INACTIVE) {
				user.setStatus(WorkflowConstants.STATUS_APPROVED);
			} else {
				user.setStatus(WorkflowConstants.STATUS_INACTIVE);
			}
			UserLocalServiceUtil.updateUser(user);
			SessionMessages.add(actionRequest, "status-updated");
			hideDefaultSuccessMessage(actionRequest);
			hideDefaultErrorMessage(actionRequest);
		}
		
	/*
	 * private static final Log _log =
	 * LogFactoryUtil.getLog(DeactiveSecondaryLCOMVCActionCommand.class);
	 */
	}
