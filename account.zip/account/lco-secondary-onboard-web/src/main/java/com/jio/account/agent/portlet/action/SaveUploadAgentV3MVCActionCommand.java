package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.bean.AgentBean;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.agent.service.AgentService;
import com.jio.csv.util.CSVUtil;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD_AGENT_V3 }, service = MVCActionCommand.class)
public class SaveUploadAgentV3MVCActionCommand extends BaseMVCActionCommand {
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		final ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final ServiceContext serviceContext = ServiceContextFactory.getInstance(actionRequest);

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();
		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (csvUtil.isNotCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.COMMA);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;
					Runnable runnable = new Runnable() {

						@Override
						public void run() {

							saveAgentDetails(csvRecords, themeDisplay, serviceContext);
						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}

		hideDefaultSuccessMessage(actionRequest);
		hideDefaultErrorMessage(actionRequest);
	}

	public List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	private void saveAgentDetails(List<CSVRecord> csvRecords, ThemeDisplay themeDisplay, ServiceContext serviceContext) {

		for (CSVRecord csvRecord : csvRecords) {

			AgentBean lco = new AgentBean();
			lco.setScreenName(csvRecord.get("VAR_USERMST_USERNAME").trim());
			lco.setFirstName(csvRecord.get("VAR_USERMST_FIRSTNAME").trim());
			lco.setMiddleName(csvRecord.get("VAR_USERMST_MIDDLENAME").trim());
			lco.setLastName(csvRecord.get("VAR_USERMST_LASTNAME").trim());
			lco.setEmail(csvRecord.get("VAR_USERMST_EMAIL").trim());
			lco.setMobileNo(csvRecord.get("NUM_USERMST_MOBILENO").trim());
			lco.setPoId(csvRecord.get("VAR_USERMST_BRMPOID").trim());

			try {
				lco.setScreenName(lco.getScreenName());
				lco.setFirstName(lco.getFirstName());
				lco.setMiddleName(lco.getMiddleName());
				lco.setLastName(lco.getLastName());
				lco.setEmail(lco.getEmail());
				lco.setMobileNo(lco.getMobileNo());
				lco.setPoId(lco.getPoId());
				lco.setCompanyId(themeDisplay.getCompanyId());
				lco.setGroupId(themeDisplay.getScopeGroupId());
				if (validateAgent(lco)) {
					agentService.saveAgent(themeDisplay.getUserId(), lco, serviceContext);
				}
			} catch (Exception e) {
				LOGGER.info("SomeThing Wrong");

			}
			try {
				Agent agent = agentLocalService.getAgent(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName());
				lco.setParentCode(agent.getScreenName());
				lco.setPrimary(Boolean.FALSE);
				lco.setJvNo(agent.getJvNo());
				lco.setDirectNo(agent.getDirectNo());
				lco.setPoId(agent.getPoId());
				lco.setAccountNo(agent.getAccountNo());
				try {
					agentService.saveAgent(themeDisplay.getUserId(), lco, serviceContext);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (NoSuchAgentException e) {
				LOGGER.error("NoSuchAgentException : " + e.toString());
			}
			try {
				Address address = addressLocalService.getAddress(themeDisplay.getCompanyId(), themeDisplay.getUser().getScreenName());
				lco.setAddress(address.getAddress());
				lco.setState(address.getStateCode());
				lco.setCity(address.getCityCode());
				lco.setPincode(address.getPincode());
				try {
					agentService.saveAgent(themeDisplay.getUserId(), lco, serviceContext);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (NoSuchAddressException e) {
				LOGGER.error("NoSuchAddressException : " + e.toString());
			}

		}
	}

	private String setEmailAddress(String email) {
		List<String> emailAddr = StringUtil.split(email, '@');
		return emailAddr.get(0) + emailAddr.get(1);
	}

	private boolean validateAgent(AgentBean lco) {

		boolean valid = Boolean.TRUE;
		if (Validator.isNull(lco.getScreenName())) {
			valid = Boolean.FALSE;
			LOGGER.error("Login ID Required");
		}
		if (Validator.isNull(lco.getFirstName())) {
			valid = Boolean.FALSE;
			LOGGER.error("First Name Required");
		}
		if (Validator.isNull(lco.getLastName())) {
			valid = Boolean.FALSE;
			LOGGER.error("Last Name Required");
		}
		if (Validator.isNull(lco.getMobileNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Mobile No Required");
		}

		if (Validator.isNull(lco.getPoId())) {
			valid = Boolean.FALSE;
			LOGGER.error("BRM POID Required");
		}

		if (Validator.isNull(lco.getEmail())) {
			valid = Boolean.FALSE;

			LOGGER.error("email-address-required");
		} else if (!Validator.isEmailAddress(lco.getEmail())) {
			valid = Boolean.FALSE;

			LOGGER.error("email-address-format");
		} else {
			if (lco.getUserId() == 0) {
				try {
					userLocalService.getUserByEmailAddress(lco.getCompanyId(), lco.getEmail());
					valid = Boolean.FALSE;

					LOGGER.error("email-already-exist");
				} catch (PortalException e) {
				}
			}

		}
		if (Validator.isNull(lco.getMobileNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Mobile No Required");
		}
		return valid;
	}

	@Reference
	protected AddressLocalService addressLocalService;

	@Reference
	protected AgentLocalService agentLocalService;

	@Reference
	protected ContactLocalService contactLocalService;

	@Reference
	protected AgentService agentService;

	@Reference
	protected UserLocalService userLocalService;

	@Reference
	private CSVUtil csvUtil;

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveUploadAgentV3MVCActionCommand.class);
}