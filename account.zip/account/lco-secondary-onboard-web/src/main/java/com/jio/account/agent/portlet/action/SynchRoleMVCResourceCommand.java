package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.agent.service.AgentService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;
import java.util.stream.LongStream;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SYNCH_ROLE }, service = MVCResourceCommand.class)
public class SynchRoleMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		final long companyId = PortalUtil.getCompanyId(resourceRequest);
		final long roleId = agentService.getAgentRoleId(companyId);
		if (roleId != 0L) {
			SessionMessages.add(resourceRequest, "agent-role-start-to-configure");
			List<Agent> agents = agentLocalService.getAgents(companyId);
			agents.parallelStream().forEach(agent -> {

				try {
					User user = userLocalService.getUserByScreenName(companyId, agent.getAccountNo());

					boolean present = LongStream.of(user.getRoleIds()).filter(l -> l == roleId).findAny().isPresent();
					if (!present) {
						userLocalService.addRoleUser(roleId, user);
						LOGGER.info("Agent Role Added : " + roleId + " User : " + user.getScreenName());
					}

				} catch (Exception e) {
					LOGGER.error("Exception : " + e.toString());
				}

			});
		} else {
			SessionErrors.add(resourceRequest, "agent-role-not-configured");
		}

		return Boolean.TRUE;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private AgentService agentService;

	@Reference
	private UserLocalService userLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SynchRoleMVCResourceCommand.class);
}
