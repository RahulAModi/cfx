package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.bean.AgentBean;
import com.jio.agent.service.AgentService;
import com.jio.csv.util.CSVUtil;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD_AGENT_V2 }, service = MVCActionCommand.class)
public class SaveUploadAgentV2MVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		final ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final ServiceContext serviceContext = ServiceContextFactory.getInstance(actionRequest);

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();
		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (csvUtil.isNotCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.COMMA);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;
					Runnable runnable = new Runnable() {

						@Override
						public void run() {

							saveAgents(csvRecords, themeDisplay, serviceContext);

						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}
	}

	public List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	private void saveAgents(List<CSVRecord> csvRecords, ThemeDisplay themeDisplay, ServiceContext serviceContext) {
		long companyId = themeDisplay.getCompanyId();
		long groupId = themeDisplay.getScopeGroupId();
		for (CSVRecord csvRecord : csvRecords) {

			AgentBean agentBean = new AgentBean();
			agentBean.setPoId(getValue(csvRecord, "BRM_POID").trim());
			agentBean.setScreenName(getValue(csvRecord, "LCO_CODE").trim()); // screenName
			agentBean.setAccountNo(agentBean.getScreenName());
			agentBean.setFirstName(getValue(csvRecord, "FIRST_NAME").trim());
			agentBean.setMiddleName(getValue(csvRecord, "MIDDLE_NAME").trim());
			agentBean.setLastName(getValue(csvRecord, "LAST_NAME").trim());
			agentBean.setAddress(getValue(csvRecord, "ADDRESS").trim());
			agentBean.setCreatedBy(themeDisplay.getUser().getScreenName());

			agentBean.setPrimary(true);
			agentBean.setParentCode(agentBean.getAccountNo());

			String zipCode = getValue(csvRecord, "ZIPCODE").trim();
			String areaCode = getValue(csvRecord, "AREA").trim();
			String cityCode = getValue(csvRecord, "CITY").trim();
			String stateCode = getValue(csvRecord, "STATE").trim();
			String regionCode = StringPool.BLANK;
			String countryCode = StringPool.BLANK;
			try {
				Location location = locationLocalService.getLocationsByCode(zipCode, companyId);
				Location areaLocation = locationLocalService.getParentLocation(location.getCode(), companyId);
				areaCode = areaLocation.getCode();
				Location cityLocation = locationLocalService.getParentLocation(areaLocation.getCode(), companyId);
				cityCode = cityLocation.getCode();
				Location stateLocation = locationLocalService.getParentLocation(cityLocation.getCode(), companyId);
				stateCode = stateLocation.getCode();
				Location regionLocation = locationLocalService.getParentLocation(stateLocation.getCode(), companyId);
				regionCode = regionLocation.getCode();
				Location countryLocation = locationLocalService.getParentLocation(stateLocation.getCode(), companyId);
				countryCode = countryLocation.getCode();
			} catch (NoSuchLocationException e) {
				LOGGER.warn("NoSuchLocationException : " + e.toString());
			}
			agentBean.setPincode(zipCode);
			agentBean.setArea(areaCode);
			agentBean.setCity(cityCode);
			agentBean.setState(stateCode);
			agentBean.setRegion(regionCode);
			agentBean.setCountry(countryCode);

			String email = getValue(csvRecord, "EMAIL").trim().replace("-", StringPool.SPACE);
			if (email.equalsIgnoreCase("-")) {
				email = getValue(csvRecord, "BRM_POID").trim().concat("@denonline.com");
			} else {
				email = getValue(csvRecord, "BRM_POID").trim().concat("_").concat(getValue(csvRecord, "EMAIL").trim().replace("-", StringPool.SPACE));
			}

			agentBean.setEmail(email);
			agentBean.setMobileNo(getValue(csvRecord, "PHONE").trim());

			agentBean.setJvNo(getValue(csvRecord, "JV").trim());
			agentBean.setJvPoId(getValue(csvRecord, "JV_POID").trim());
			agentBean.setJvName(getValue(csvRecord, "JV_COMPANY_NAME").trim());

			String dt = getValue(csvRecord, "DT").trim();
			if (dt.equalsIgnoreCase("NA")) {
				dt = StringPool.BLANK;
			}

			agentBean.setDistributor(dt);
			agentBean.setDistributorPoId(getValue(csvRecord, "DT_POID").trim());
			agentBean.setDistributorName(getValue(csvRecord, "DT_COMPANY_NAME").trim());

			String sdt = getValue(csvRecord, "SDT").trim();
			if (sdt.equalsIgnoreCase("NA")) {
				sdt = StringPool.BLANK;
			}
			agentBean.setSubDistributor(getValue(csvRecord, "SDT").trim());
			agentBean.setSubDistributorPoId(getValue(csvRecord, "SDT_POID").trim());
			agentBean.setSubDistributorName(getValue(csvRecord, "SDT_COMPANY_NAME").trim());

			agentBean.setPrefDom(getValue(csvRecord, "PREF_DOM").trim());
			String pan = getValue(csvRecord, "PAN_NO").trim();
			if (pan.equalsIgnoreCase("NULL")) {
				pan = StringPool.BLANK;
			}
			agentBean.setPanNo(pan);
			agentBean.setStRegNo(getValue(csvRecord, "ST_REG_NO").trim());
			agentBean.setVatTaxNo(getValue(csvRecord, "VAT_TAX_NO").trim());

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-mm-yyyy");
			Date reportDate;
			try {
				reportDate = simpleDateFormat.parse(getValue(csvRecord, "REPORT_DATE").trim());
			} catch (ParseException e) {
				reportDate = new Date();
				LOGGER.warn("ParseException : " + e.toString());
			}

			agentBean.setReportDate(reportDate);

			agentBean.setPpType(getValue(csvRecord, "PP_TYPE").trim());

			if (getValue(csvRecord, "LCO_STATUS").trim().equalsIgnoreCase("ACTIVE")) {
				agentBean.setStatus(WorkflowConstants.STATUS_APPROVED);
			} else {
				agentBean.setStatus(WorkflowConstants.STATUS_DENIED);
			}
			String locator = getValue(csvRecord, "LOCATOR").trim();
			if (locator.equalsIgnoreCase("NULL")) {
				locator = StringPool.BLANK;
			}
			agentBean.setLocator(locator);

			String gstin = getValue(csvRecord, "GSTIN").trim();
			if (Validator.isNull(gstin)) {
				gstin = getValue(csvRecord, "LCO_GSTIN").trim();
			}

			agentBean.setGstin(gstin);

			agentBean.setCompanyId(companyId);
			agentBean.setGroupId(groupId);

			if (validateAgent(agentBean)) {
				try {
					agentService.saveAgent(themeDisplay.getUserId(), agentBean, serviceContext);
				} catch (PortalException e) {
					LOGGER.info("PortalException :: " + e.toString());
				}
			}
		}
	}

	private String getValue(CSVRecord csvRecord, String key) {
		String value = StringPool.BLANK;
		try {
			value = csvRecord.get(key);
		} catch (IllegalStateException e) {
		} catch (IllegalArgumentException e) {
		}
		return value;
	}

	protected boolean validateAgent(AgentBean agentBean) {

		boolean valid = Boolean.TRUE;
		if (Validator.isNull(agentBean.getScreenName())) {
			valid = Boolean.FALSE;
			LOGGER.error("Login ID Required");
		}
		if (Validator.isNull(agentBean.getFirstName())) {
			valid = Boolean.FALSE;
			LOGGER.error("First Name Required");
		}
		if (Validator.isNull(agentBean.getLastName())) {
			valid = Boolean.FALSE;
			LOGGER.error("Last Name Required");
		}
		if (Validator.isNull(agentBean.getMobileNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Mobile No Required");
		}
		if (Validator.isNull(agentBean.getJvNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("JV No Required");
		}

		if (Validator.isNull(agentBean.getPoId())) {
			valid = Boolean.FALSE;
			LOGGER.error("BRM POID Required");
		}
		if (Validator.isNull(agentBean.getAccountNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Account No Required");
		}

		if (Validator.isNull(agentBean.getState())) {
			valid = Boolean.FALSE;
			LOGGER.error("State Required");
		}
		if (Validator.isNull(agentBean.getCity())) {
			valid = Boolean.FALSE;
			LOGGER.error("City Required");
		}
		if (Validator.isNull(agentBean.getPincode())) {
			valid = Boolean.FALSE;
			LOGGER.error("Pincode Required");
		}
		if (Validator.isNull(agentBean.getEmail())) {
			valid = Boolean.FALSE;
			LOGGER.error("Email Address Required");
		}

		/*
		 * if (!agentService.validUser(agentBean.getCompanyId(), agentBean.getScreenName(), agentBean.getEmail())) { valid = Boolean.FALSE; LOGGER.error("Email Address Or Screen Name Already Exist"); }
		 */

		if (Validator.isNull(agentBean.getMobileNo())) {
			valid = Boolean.FALSE;
			LOGGER.error("Mobile No Required");
		}
		return valid;
	}

	@Reference
	protected AgentService agentService;

	@Reference
	private CSVUtil csvUtil;

	@Reference
	private LocationLocalService locationLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveUploadAgentV2MVCActionCommand.class);
}
