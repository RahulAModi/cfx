package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.customer.plan.service.CustomerPlanService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.AUTO_RENEW }, service = MVCActionCommand.class)
public class AutoRenewMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(AutoRenewMVCActionCommand.class);

	@Reference
	AgentLocalService agentLocalService;

	@Reference
	CustomerLocalService customerLocalService;

	@Reference
	CustomerPlanService customerPlanService;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		String agentScreenName = ParamUtil.getString(actionRequest, "agentScreenName");
		long companyId = PortalUtil.getCompanyId(actionRequest);
		try {
			Agent agent = agentLocalService.getAgent(companyId, agentScreenName);

			String message = "agent-account-auto-renwal";
			if (agent.isAutoRenew()) {
				agent.setAutoRenew(false);
				message = "agent-account-auto-renwal-off";
			} else {
				agent.setAutoRenew(true);
				message = "agent-account-auto-renwal-on";
			}

			agentLocalService.updateAgent(agent);

			SessionMessages.add(actionRequest, message);

			// Update All Agent -> Customer -> Attached Plan AutoRenew Flag
			setAutoRenewal(agentScreenName, companyId, agent.getAutoRenew());

		} catch (NoSuchAgentException e) {
			SessionErrors.add(actionRequest, NoSuchAgentException.class);
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		}

	}

	private void setAutoRenewal(String agentScreenName, long companyId, boolean autoRenewal) {
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				customerPlanService.setAutoRenewalAgentCustomerPlan(agentScreenName, companyId, autoRenewal);
			}
		};

		Thread thread = new Thread(runnable);
		thread.start();
	}

}
