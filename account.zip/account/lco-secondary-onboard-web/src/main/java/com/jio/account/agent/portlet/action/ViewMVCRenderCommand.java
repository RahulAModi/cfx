package com.jio.account.agent.portlet.action;

import com.jio.account.agent.constants.LcoSecondaryOnboardWebPortletKeys;
import com.jio.account.agent.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.account.util.AccountUtil;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + LcoSecondaryOnboardWebPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW_SECONDARY_LCO }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		String agentScreenName = ParamUtil.getString(renderRequest, "agentScreenName");
		String screenName = ParamUtil.getString(renderRequest, "screenName");
		long companyId = PortalUtil.getCompanyId(renderRequest);
		User user = null;
		try {
			user = PortalUtil.getUser(renderRequest);
			if (Validator.isNotNull(user)) {

				boolean isAdmin = AccountUtil.isAdmin(user.getUserId());
				boolean isPrimaryAgent = false;
				if (!isAdmin) {
					try {
						Agent agent = agentLocalService.getAgent(companyId, user.getScreenName());
						isPrimaryAgent = agent.getPrimary();
					} catch (NoSuchAgentException e) {
						LOGGER.error("NoSuchAgentException :: " + e.toString());
					}
				}

				renderRequest.setAttribute("isAdmin", isAdmin);
				renderRequest.setAttribute("isPrimaryAgent", isPrimaryAgent);

				PortletURL iteratorURL = renderResponse.createRenderURL();
				iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
				try {
					iteratorURL.setWindowState(WindowState.NORMAL);
				} catch (WindowStateException e) {
					LOGGER.error(e.toString());
				}
				SearchContainer<Agent> searchContainer = new SearchContainer<Agent>(renderRequest, iteratorURL, null, "there-are-no-agents");

				List<Agent> agents = new ArrayList<Agent>();
				int agentCount = GetterUtil.DEFAULT_INTEGER;

				if (isAdmin) {
					if (Validator.isNotNull(agentScreenName)) {
						agents = agentLocalService.getAgents(companyId, agentScreenName, false, searchContainer.getStart(), searchContainer.getEnd());
						agentCount = agentLocalService.getAgentsCount(companyId, agentScreenName, false);
					} else if (Validator.isName(screenName)) {
						agents = agentLocalService.getAgents(companyId, screenName, true, searchContainer.getStart(), searchContainer.getEnd());
						agentCount = agentLocalService.getAgentsCount(companyId, screenName, true);
					} else {
						agents = agentLocalService.getAgents(companyId, true, searchContainer.getStart(), searchContainer.getEnd());
						agentCount = agentLocalService.getAgentsCount(companyId, true);
					}
				} else {
					agents = agentLocalService.getAgents(companyId, user.getScreenName(), false, searchContainer.getStart(), searchContainer.getEnd());
					agentCount = agentLocalService.getAgentsCount(companyId, user.getScreenName(), false);
				}

				searchContainer.setDeltaConfigurable(true);
				searchContainer.setTotal(agentCount);
				searchContainer.setResults(agents);

				renderRequest.setAttribute("agentSearchContainer", searchContainer);

			} else {
				LOGGER.warn("User is not loggedin");
			}

		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		return "/view.jsp";
	}

	@Reference
	protected AgentLocalService agentLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveSecondaryMVCActionCommand.class);
}