/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.constant.StatusConstant;
import com.jio.customer.service.CustomerService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.SEARCH, "mvc.command.name=" + MVCCommandNames.CONFIRM,
		"mvc.command.name=" + MVCCommandNames.MODIFY }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerService customerService;

	@Reference
	private AgentService agentService;

	private final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);
		String accountNo = ParamUtil.getString(renderRequest, "accountNo");
		String screenName = ParamUtil.getString(renderRequest, "screenName");
		String status = ParamUtil.getString(renderRequest, "status");
		String vcId = ParamUtil.getString(renderRequest, "vcId");
		String stbNo = ParamUtil.getString(renderRequest, "stbNo");
		String macId = ParamUtil.getString(renderRequest, "macId");

		String txRefNo = AccountUtil.getTxRefNo();
		String referenceNumber = txRefNo;
		String transactionRefNo = txRefNo;
		boolean isSuperAdmin = false;
		try {
			ServiceContext serviceContext = ServiceContextFactory.getInstance(renderRequest);
			serviceContext.setCompanyId(companyId);

			long groupId = PortalUtil.getScopeGroupId(renderRequest);
			User userAgent = PortalUtil.getUser(renderRequest);
			long userId = userAgent.getUserId();
			String createdBy = userAgent.getScreenName();

			PortletURL iteratorURL = renderResponse.createRenderURL();
			iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
			try {
				iteratorURL.setWindowState(WindowState.NORMAL);
			} catch (WindowStateException e) {
				LOGGER.error(e.toString());
			}
			SearchContainer<Customer> searchContainer = new SearchContainer<Customer>(renderRequest, iteratorURL, null, "there-are-no-customers");

			List<Customer> customers = null;
			int customerCount = GetterUtil.DEFAULT_INTEGER;

			if (Validator.isNotNull(userAgent)) {
				isSuperAdmin = AccountUtil.isAdmin(userAgent.getUserId());
				String agentScreenName = StringPool.BLANK;
				if (!isSuperAdmin) {
					Agent agent = agentLocalService.getParentAgent(companyId, userAgent.getScreenName());
					agentScreenName = agent.getScreenName();
				}

				try {
					if (Validator.isNotNull(accountNo)) {
						customers = new ArrayList<>();
						if (isSuperAdmin) {
							Customer customer = customerLocalService.getCustomer(accountNo, companyId);
							customers.add(customer);
						} else {
							Customer customer = customerService.getOrCreateCustomer(accountNo, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId, serviceContext);
							if (Validator.isNotNull(customer) && customer.getAgentScreenName().equalsIgnoreCase(agentScreenName)) {
								customers.add(customer);
							}
						}
						customerCount = customers.size();
					} else if (Validator.isNotNull(screenName)) {
						customers = customerLocalService.getCustomerByScreenName(screenName, companyId, agentScreenName, searchContainer.getStart(), searchContainer.getEnd());
						customerCount = customerLocalService.customerCountByScreenName(screenName, companyId, agentScreenName);
					} else if (Validator.isNotNull(vcId)) {
						if (isSuperAdmin) {
							customers = customerLocalService.getCustomerByVcId(vcId, companyId, agentScreenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = customerLocalService.customerCountByVcId(vcId, companyId, agentScreenName);
						} else {
							String primaryAgentScreenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());
							customers = new ArrayList<>();
							Customer customer = customerService.getOrCreateCustomer(accountNo, vcId, StringPool.BLANK, primaryAgentScreenName, userAgent, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId, serviceContext);
							if (Validator.isNotNull(customer) && customer.getAgentScreenName().equalsIgnoreCase(agentScreenName)) {
								customers.add(customer);
							}
							customerCount = customers.size();
						}

					} else if (Validator.isNotNull(stbNo)) {
						if (isSuperAdmin) {
							customers = customerLocalService.getCustomerByStbNo(stbNo, companyId, agentScreenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = customerLocalService.customerCountByStbNo(stbNo, companyId, agentScreenName);
						} else {
							String primaryAgentScreenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());
							customers = new ArrayList<>();
							Customer customer = customerService.getOrCreateCustomer(accountNo, StringPool.BLANK, stbNo, primaryAgentScreenName, userAgent, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId, serviceContext);
							if (Validator.isNotNull(customer) && customer.getAgentScreenName().equalsIgnoreCase(agentScreenName)) {
								customers.add(customer);
							}
							customerCount = customers.size();
						}

					} else if (Validator.isNotNull(macId)) {
						if (isSuperAdmin) {
							customers = customerLocalService.getCustomerByMacId(macId, companyId, agentScreenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = customerLocalService.customerCountByMacId(macId, companyId, agentScreenName);
						} else {
							String primaryAgentScreenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());
							customers = new ArrayList<>();
							Customer customer = customerService.getOrCreateCustomer(accountNo, StringPool.BLANK, macId, primaryAgentScreenName, userAgent, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId, serviceContext);
							if (Validator.isNotNull(customer) && customer.getAgentScreenName().equalsIgnoreCase(agentScreenName)) {
								customers.add(customer);
							}
							customerCount = customers.size();
						}
					} else if (Validator.isNotNull(status)) {
						if (isSuperAdmin) {
							customers = customerLocalService.getCustomerByStatus(status, companyId, agentScreenName, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = customerLocalService.customerCountByStatus(status, companyId, agentScreenName);
						} else {
							customers = new ArrayList<>();
						}

					} else {
						if (isSuperAdmin) {
							customers = customerLocalService.getCustomerByLogInAgent(agentScreenName, companyId, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = customerLocalService.customerCountByLogInAgent(agentScreenName, companyId);
						} else if (GetterUtil.getBoolean(JioPropsUtil.get(ConfigConstant.VIEW_CUSTOMER_LIST, companyId))) {
							customers = customerLocalService.getCustomerByLogInAgent(agentScreenName, companyId, searchContainer.getStart(), searchContainer.getEnd());
							customerCount = customerLocalService.customerCountByLogInAgent(agentScreenName, companyId);
						} else {
							customers = new ArrayList<>();
						}

					}
				} catch (SystemException e) {
					customers = new ArrayList<>();
					LOGGER.error("SystemException :: " + e.toString());
				}

			} else {
				customers = new ArrayList<>();
				LOGGER.warn("User is not loggedin");
			}

			searchContainer.setDeltaConfigurable(true);
			searchContainer.setTotal(customerCount);
			searchContainer.setResults(customers);
			renderRequest.setAttribute("customerSearchContainer", searchContainer);
			renderRequest.setAttribute("isSuperAdmin", isSuperAdmin);
			renderRequest.setAttribute("customerStatusCssClasses", StatusConstant.getCustomerStatusCssClasses());
			renderRequest.setAttribute("customerStatuses", StatusConstant.getCustomerStatuses());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}
		return "/customer/view.jsp";
	}

}