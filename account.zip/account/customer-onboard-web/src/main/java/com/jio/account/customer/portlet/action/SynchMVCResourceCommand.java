package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.model.Address;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.nas.invoice.api.NASInvoiceHelper;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SYNCH }, service = MVCResourceCommand.class)

public class SynchMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(SynchMVCResourceCommand.class);

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	CPLocalService cpLocalService;

	@Reference
	NASInvoiceHelper nasInvoiceHelper;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		final long companyId = PortalUtil.getCompanyId(resourceRequest);
		nasInvoiceHelper.moveNasInvoice();
		return Boolean.TRUE;
	}

	void synchCustomer(long companyId) {
		try {

			List<CP> cps = cpLocalService.getCPs(companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
			cps.parallelStream().forEach(cp -> {
				try {
					cpLocalService.saveOrUpdateCP(cp.getGroupId(), cp.getCompanyId(), cp.getCreateBy(), cp.getCustomerScreenName(), cp.getAccountNo(), cp.getCustomerId(), cp.isActive(), cp.getPlanCode(), cp.getReason(), cp.getCityCode(), cp.isAutoRenew(), cp.getPackageId(),
							cp.getPurchasedProductPoId(), cp.getStartDate(), cp.getEndDate());
				} catch (Exception e) {
					LOGGER.error("Exception : " + e.toString());
				}
			});

			List<Customer> customers = customerLocalService.getCustomers(companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
			customers.parallelStream().forEach(customer -> {
				List<Address> addresses = addressLocalService.getAddresses(customer.getScreenName(), companyId);
				addresses.stream().skip(1).forEach(address -> {
					address = addressLocalService.deleteAddress(address);
					LOGGER.info("Address : " + address.toString());
				});

				List<Contact> contacts = contactLocalService.getContacts(customer.getScreenName(), companyId);
				contacts.stream().skip(1).forEach(contact -> {
					contact = contactLocalService.deleteContact(contact);
					LOGGER.info("Contact : " + contact.toString());
				});

			});

		} catch (SystemException e) {
			LOGGER.error("SystemException :: " + e.toString());
		}
	}

}
