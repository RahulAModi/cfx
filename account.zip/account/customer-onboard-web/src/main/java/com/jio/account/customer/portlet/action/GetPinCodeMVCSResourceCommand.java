package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_PINCODE }, service = MVCResourceCommand.class)

public class GetPinCodeMVCSResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(GetPinCodeMVCSResourceCommand.class);

	@Reference
	private LocationLocalService locationLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean flag = false;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String areaCode = ParamUtil.getString(resourceRequest, "areaCode");
		try {
			List<Location> pincodes = locationLocalService.getChildLocations(areaCode, companyId);
			if (Validator.isNotNull(pincodes)) {
				resourceResponse.getWriter().println(convertJSONArray(pincodes));
				flag = true;
			}
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		} catch (NoSuchLocationException e) {
			LOGGER.error("NoSuchLocationException :: " + e.toString());
		}

		return flag;
	}

	public JSONArray convertJSONArray(List<Location> locations) {
		JSONArray outputArray = JSONFactoryUtil.createJSONArray();
		JSONObject outputObject = null;
		for (Location location : locations) {
			outputObject = JSONFactoryUtil.createJSONObject();
			outputObject.put("code", location.getCode());
			outputObject.put("id", location.getLocationId());
			outputObject.put("name", location.getName());
			outputArray.put(outputObject);
		}
		return outputArray;
	}

}
