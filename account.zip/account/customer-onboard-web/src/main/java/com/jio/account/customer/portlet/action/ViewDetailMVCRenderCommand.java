/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.VIEW_DETAIL }, service = MVCRenderCommand.class)
public class ViewDetailMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	private final Log LOGGER = LogFactoryUtil.getLog(ViewDetailMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);
		String screenName = ParamUtil.getString(renderRequest, "screenName");
		try {

			Customer customer = customerLocalService.getCustomerByScreenName(screenName, companyId);
			Address address = addressLocalService.getAddress(companyId, screenName);
			Contact contact = contactLocalService.getContact(companyId, screenName);

			Agent agent = agentLocalService.getParentAgent(companyId, customer.getAgentScreenName());

			Map<String, Location> locationMap = locationLocalService.getLocationByPinCode(address.getPincode(), companyId);

			renderRequest.setAttribute("customer", customer);
			renderRequest.setAttribute("customerAddress", address);
			renderRequest.setAttribute("customerContact", contact);

			renderRequest.setAttribute("locationMap", locationMap);

			renderRequest.setAttribute("agent", agent);

		} catch (NoSuchCustomerException e) {
			LOGGER.error("NoSuchCustomerException : " + e.toString());
		} catch (NoSuchAddressException e) {
			LOGGER.error("NoSuchAddressException : " + e.toString());
		} catch (NoSuchContactException e) {
			LOGGER.error("NoSuchContactException : " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}
		return "/customer/view_customer.jsp";
	}

}