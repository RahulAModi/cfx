package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DEATIVATE }, service = MVCActionCommand.class)
public class DeactivateMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		String screenName = ParamUtil.getString(actionRequest, "screenName");
		long companyId = PortalUtil.getCompanyId(actionRequest);
		User user = userLocalService.getUserByScreenName(companyId, screenName);
		if (user.getStatus() == WorkflowConstants.STATUS_INACTIVE) {
			user.setStatus(WorkflowConstants.STATUS_APPROVED);
		} else {
			user.setStatus(WorkflowConstants.STATUS_INACTIVE);
		}
		userLocalService.updateUser(user);
		SessionMessages.add(actionRequest, "status-updated");
		hideDefaultSuccessMessage(actionRequest);
		hideDefaultErrorMessage(actionRequest);
	}

	@Reference
	UserLocalService userLocalService;

}
