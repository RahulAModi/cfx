package com.jio.account.customer.portlet.action;

import com.jio.account.bean.CustomerBean;
import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.csv.util.CSVUtil;
import com.jio.customer.service.CustomerService;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.service.ConnectionTypeLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD_V2 }, service = MVCActionCommand.class)

public class SaveUploadV2MVCActionCommand extends BaseMVCActionCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(SaveUploadV2MVCActionCommand.class);

	@Reference
	private ConnectionTypeLocalService connectionTypeLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private CustomerService customerService;

	@Reference
	private CSVUtil csvUtil;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		final User userAgent = PortalUtil.getUser(actionRequest);
		final long groupId = PortalUtil.getScopeGroupId(actionRequest);
		final long companyId = PortalUtil.getCompanyId(actionRequest);

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();
		ServiceContext serviceContext = ServiceContextFactory.getInstance(actionRequest);
		final String txRefNo = AccountUtil.getTxRefNo();
		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (csvUtil.isNotCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.COMMA);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;

					Runnable runnable = new Runnable() {
						@Override
						public void run() {
							addCustomers(txRefNo, userAgent, groupId, companyId, csvRecords, actionRequest, serviceContext);
						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}

	}

	private List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	private List<Customer> addCustomers(String txRefNo, User userAgent, long groupId, long companyId, List<CSVRecord> csvRecords, ActionRequest actionRequest, ServiceContext serviceContext) {
		List<Customer> customers = new ArrayList<Customer>();

		csvRecords.parallelStream().forEach(csvRecord -> {
			Customer customer = null;
			try {
				customer = addCustomer(txRefNo, userAgent, groupId, companyId, csvRecord, actionRequest, serviceContext);
				if (Validator.isNotNull(customer)) {
					customers.add(customer);
				}
			} catch (PortalException e) {
				LOGGER.error("PortalException :: " + e.toString());
			}
		});

		return customers;
	}

	private Customer addCustomer(String txRefNo, User userAgent, long groupId, long companyId, CSVRecord csvRecord, ActionRequest actionRequest, ServiceContext serviceContext) throws PortalException {

		CustomerBean customerBean = getCustomerBeanFromCSV(csvRecord, groupId, companyId);

		boolean validCustomer = customerValidation(customerBean);
		Customer customer = null;
		if (validCustomer) {
			if (Validator.isNull(customer)) {
				customerService.getOrCreateCustomer(customerBean.getAccountNo(), txRefNo, customerBean.getAccountNo(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId, serviceContext);
				// customerService.saveOrUpdateCustomer(companyId, groupId, customerBean, userAgent, serviceContext);
			}
		}
		return customer;
	}

	private Boolean customerValidation(CustomerBean customerBean) throws PortalException {
		if (Validator.isNull(customerBean.getScreenName())) {
			LOGGER.error("Screen Name Empty or Invalid");
			return false;
		}
		// Agent Check
		try {
			agentLocalService.getAgent(customerBean.getCompanyId(), customerBean.getAgentScreenName());
		} catch (NoSuchAgentException e) {
			LOGGER.error("For customer " + customerBean.getScreenName() + "NoSuchAgentException :: No agent with screenName ::  " + customerBean.getAgentScreenName() + "::" + e.toString());
			return false;
		}

		// address check
		try {
			locationLocalService.getLocationsByCode(customerBean.getPincode(), customerBean.getCompanyId());
		} catch (NoSuchLocationException e) {
			LOGGER.error("For customer " + customerBean.getScreenName() + " NoSuchLocationException :: No location with code ::  " + customerBean.getLocation() + "::" + e.toString());
			return false;
		}

		return true;
	}

	private CustomerBean getCustomerBeanFromCSV(CSVRecord csvRecord, long groupId, long companyId) throws NoSuchLocationException {

		CustomerBean customerBean = new CustomerBean();
		customerBean.setCompanyId(companyId);
		customerBean.setGroupId(groupId);

		String accountNo = getValue(csvRecord, "ACCOUNT_NO");

		String screenName = accountNo;
		String agentScreenName = getValue(csvRecord, "LCO_CODE");
		String vcId = getValue(csvRecord, "VC");
		String stbNo = getValue(csvRecord, "STB");
		String macId = getValue(csvRecord, "MAC");

		String connectionType = getValue(csvRecord, "connectionType");
		String serviceType = JioPropsUtil.get(ConfigConstant.SERVICETYPE_CODE, companyId);

		String status = getValue(csvRecord, "STATUS").equalsIgnoreCase("ACTIVE") ? "1" : "0";

		boolean primary = getValue(csvRecord, "CONNECTION_TYPE").equalsIgnoreCase("MAIN") ? true : false;

		String firstName = getValue(csvRecord, "FIRST_NAME");
		String middleName = getValue(csvRecord, "MIDDLE_NAME");
		String lastName = getValue(csvRecord, "LAST_NAME");

		String email = accountNo.concat("@denonline.com");
		String mobileNo = getValue(csvRecord, "MOBILE");

		String addressType = getValue(csvRecord, "CUST_CATEGORY");
		String pincode = getValue(csvRecord, "ZIP");
		String address = getValue(csvRecord, "ADDRESS");

		String accountPoId = getValue(csvRecord, "ACCOUNT_POID");
		String servicePoId = getValue(csvRecord, "SERVICE_POID");
		String planPoId = getValue(csvRecord, "PLAN_POID");

		Location pinCodeLocation = locationLocalService.getLocationByCode(pincode, companyId);
		Location areaLocation = locationLocalService.getParentLocation(pinCodeLocation.getCode(), companyId);
		Location cityLocation = locationLocalService.getParentLocation(areaLocation.getCode(), companyId);
		Location stateLocation = locationLocalService.getParentLocation(cityLocation.getCode(), companyId);
		Location regionLocation = locationLocalService.getParentLocation(stateLocation.getCode(), companyId);
		Location countryLocation = locationLocalService.getParentLocation(regionLocation.getCode(), companyId);

		customerBean.setAccountNo(accountNo);
		customerBean.setScreenName(screenName);
		customerBean.setAgentScreenName(agentScreenName);
		customerBean.setVcId(vcId);
		customerBean.setStbNo(stbNo);
		customerBean.setMacId(macId);
		customerBean.setConnectionType(connectionType);
		customerBean.setServiceType(serviceType);
		customerBean.setStatus(status);
		customerBean.setPrimary(primary);

		customerBean.setFirstName(firstName);
		customerBean.setMiddleName(middleName);
		customerBean.setLastName(lastName);
		customerBean.setEmail(email);
		customerBean.setMobileNo(mobileNo);
		customerBean.setAddressType(addressType);
		customerBean.setPincode(pinCodeLocation.getCode());
		customerBean.setAreaCode(areaLocation.getCode());
		customerBean.setCityCode(cityLocation.getCode());
		customerBean.setStateCode(stateLocation.getCode());
		customerBean.setRegionCode(regionLocation.getCode());
		customerBean.setCountryCode(countryLocation.getCode());
		customerBean.setAddress(address);
		customerBean.setPrimaryContact(true);
		customerBean.setPoId(accountPoId);
		customerBean.setServicePoId(servicePoId);
		customerBean.setPlanPoId(planPoId);
		LOGGER.info("::::" + customerBean.toString());
		return customerBean;
	}

	private String getValue(CSVRecord csvRecord, String key) {
		try {
			return csvRecord.get(key);
		} catch (IllegalStateException e) {
		} catch (IllegalArgumentException e) {
		}
		return StringPool.BLANK;
	}

}
