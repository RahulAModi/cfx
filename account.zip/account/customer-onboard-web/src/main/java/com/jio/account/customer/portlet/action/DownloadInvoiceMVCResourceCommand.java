package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.nas.invoice.api.NASInvoiceHelper;
import com.jio.nas.rest.constant.NASConstant;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD_INVOICE }, service = MVCResourceCommand.class)

public class DownloadInvoiceMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadInvoiceMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean resource = false;
		try {

			long companyId = PortalUtil.getCompanyId(resourceRequest);
			String accountNo = ParamUtil.getString(resourceRequest, "accountNo");
			String screenName = ParamUtil.getString(resourceRequest, "screenName");
			String fileName = ParamUtil.getString(resourceRequest, "fileName");

			Map<String, Object> map = nasInvoiceHelper.getNASInvoiceFile(accountNo, fileName);
			try {
				InputStream in = (BufferedInputStream) map.get(NASConstant.BODY);
				Map<String, String> headers = (Map<String, String>) map.get(NASConstant.HEADERS);
				String contentType = headers.get("content-type");

				try {
					PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, in, contentType);
					resource = true;
				} catch (IOException e) {
					resource = false;
				}
				in.close();
			} catch (IOException e) {
				resource = false;
			}

			resource = true;
		} catch (SystemException e) {
			LOGGER.error("SystemException :: " + e.toString());
			resource = false;
		}

		return resource;
	}

	@Reference
	NASInvoiceHelper nasInvoiceHelper;

}
