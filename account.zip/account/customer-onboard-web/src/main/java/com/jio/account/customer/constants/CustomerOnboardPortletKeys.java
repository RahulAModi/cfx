package com.jio.account.customer.constants;

/**
 * @author Rahul1.Panchivala
 */
public class CustomerOnboardPortletKeys {

	public static final String PORTLET_NAME = "com_jio_account_customer_portlet_CustomerOnboardPortlet";

}