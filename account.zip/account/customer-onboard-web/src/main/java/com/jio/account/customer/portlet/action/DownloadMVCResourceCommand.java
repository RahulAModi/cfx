package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.model.Address;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.NoSuchUserException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD }, service = MVCResourceCommand.class)

public class DownloadMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadMVCResourceCommand.class);

	private static final String[] CSV_HEADER = new String[] { "accountNo", "screenName", "agentScreenName", "vcId", "stbNo", "macId", "connectionType", "serviceType", "status", "primary", "firstName", "middleName", "lastName", "mobileNo", "landLineNo", "email", "contactPrimary", "addressType",
			"pincode", "areaCode", "buildingNo", "cityCode", "stateCode", "countryCode", "regionCode", "addressLine" };

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(resourceRequest);
		boolean resource = true;

		try {

			StringBundler sb = new StringBundler();
			for (String columnName : CSV_HEADER) {
				sb.append(columnName);
				sb.append(CharPool.PIPE);
			}
			sb.setIndex(sb.index() - 1);
			sb.append(CharPool.NEW_LINE);

			List<Customer> customers = customerLocalService.getCustomersByCompanyId(companyId);
			for (Customer customer : customers) {

				User user = null;
				Contact contact = null;
				Address address = null;

				String firstName = StringPool.BLANK;
				String lastName = StringPool.BLANK;
				String middleName = StringPool.BLANK;

				String mobileNo = StringPool.BLANK;
				String homeNo = StringPool.BLANK;
				String email = StringPool.BLANK;

				String addressType = StringPool.BLANK;
				String pincode = StringPool.BLANK;
				String areaCode = StringPool.BLANK;
				String buildingNo = StringPool.BLANK;
				String cityCode = StringPool.BLANK;
				String stateCode = StringPool.BLANK;
				String regionCode = StringPool.BLANK;
				String countryCode = StringPool.BLANK;
				String addressLine = StringPool.BLANK;
				Boolean primary = false;

				// user info
				try {
					user = userLocalService.getUserByScreenName(companyId, customer.getScreenName());
				} catch (NoSuchUserException e) {
					e.printStackTrace();
				} catch (PortalException e2) {
					e2.printStackTrace();

				}

				if (Validator.isNotNull(user)) {
					firstName = user.getFirstName();
					middleName = user.getMiddleName();
					lastName = user.getLastName();
				}

				// contact info
				try {
					contact = contactLocalService.getContact(companyId, customer.getScreenName());
				} catch (NoSuchContactException e) {
					e.printStackTrace();
				}

				if (Validator.isNotNull(contact)) {
					mobileNo = contact.getMobileNo();
					homeNo = contact.getLandLineNo();
					email = contact.getEmail();
					primary = contact.getPrimary();
				}

				// address info
				try {
					address = addressLocalService.getAddress(companyId, customer.getScreenName());
				} catch (NoSuchAddressException e) {
					e.printStackTrace();

				}

				if (Validator.isNotNull(address)) {
					addressType = address.getType();
					pincode = address.getPincode();
					areaCode = address.getAreaCode();
					//buildingNo = address.getBuildingNo();
					cityCode = address.getCityCode();
					stateCode = address.getStateCode();
					regionCode = address.getRegionCode();
					countryCode = address.getCountryCode();
					addressLine = address.getAddress();
				}

				sb.append(customer.getAccountNo());
				sb.append(CharPool.PIPE);

				sb.append(customer.getScreenName());
				sb.append(CharPool.PIPE);

				sb.append(customer.getAgentScreenName());
				sb.append(CharPool.PIPE);

				sb.append(customer.getVcId());
				sb.append(CharPool.PIPE);

				sb.append(customer.getStbNo());
				sb.append(CharPool.PIPE);

				sb.append(customer.getMacId());
				sb.append(CharPool.PIPE);

				sb.append(customer.getConnectionType());
				sb.append(CharPool.PIPE);

				sb.append(customer.getServiceType());
				sb.append(CharPool.PIPE);

				sb.append(customer.getStatus());
				sb.append(CharPool.PIPE);

				sb.append(customer.getPrimary());
				sb.append(CharPool.PIPE);

				sb.append(firstName);
				sb.append(CharPool.PIPE);

				sb.append(middleName);
				sb.append(CharPool.PIPE);

				sb.append(lastName);
				sb.append(CharPool.PIPE);

				sb.append(mobileNo);
				sb.append(CharPool.PIPE);

				sb.append(homeNo);
				sb.append(CharPool.PIPE);

				sb.append(email);
				sb.append(CharPool.PIPE);

				sb.append(primary);
				sb.append(CharPool.PIPE);

				sb.append(addressType);
				sb.append(CharPool.PIPE);

				sb.append(pincode);
				sb.append(CharPool.PIPE);

				sb.append(areaCode);
				sb.append(CharPool.PIPE);

				sb.append(buildingNo);
				sb.append(CharPool.PIPE);

				sb.append(cityCode);
				sb.append(CharPool.PIPE);

				sb.append(stateCode);
				sb.append(CharPool.PIPE);

				sb.append(regionCode);
				sb.append(CharPool.PIPE);

				sb.append(countryCode);
				sb.append(CharPool.PIPE);

				sb.append(addressLine);
				sb.append(CharPool.PIPE);

				sb.setIndex(sb.index() - 1);
				sb.append(CharPool.NEW_LINE);

			}
			String fileName = "customers.csv";
			byte[] bytes = sb.toString().getBytes();
			String contentType = ContentTypes.APPLICATION_TEXT;
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, bytes, contentType);
			} catch (Exception e) {
				LOGGER.error("Exception :: " + e.toString());
				resource = false;
			}

			resource = false;

		} catch (SystemException e) {
			LOGGER.error("SystemException :: " + e.toString());
			resource = false;
		}

		return resource;
	}

}
