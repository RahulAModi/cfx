package com.jio.account.customer.constants;

public class MVCCommandNames {

	public static final String VIEW_DETAIL = "/customer/view-detail";

	public static final String EDIT = "/customer/edit";

	public static final String ADD = "/customer/add";

	public static final String CONFIRM = "/customer/confirm";

	public static final String MODIFY = "/customer/modify";

	public static final String SEARCH = "/customer/search";

	public static final String DEATIVATE = "/customer/deativate";

	public static final String GET_PINCODE = "/customer/get_pincode";

	public static final String GET_AREA = "/customer/get_area";

	public static final String SYNCH = "/customer/synch";

	public static final String DOWNLOAD_DOCUMENT = "/customer/download_document";

	public static final String DOWNLOAD = "/customer/download";

	public static final String UPLOAD = "/customer/upload";

	public static final String SAVE_UPLOAD = "/customer/save_upload";

	public static final String UPLOAD_V2 = "/customer/upload_v2";

	public static final String SAVE_UPLOAD_V2 = "/customer/save_upload_v2";

	public static final String SAVE_PAIR = "/customer/save_pair";

	public static final String VIEW_INVOICE = "/customer/view_invoice";

	public static final String DOWNLOAD_INVOICE = "/customer/download_invoice";

	public static final String SYNCH_ROLE = "/customer/synch_role";
}
