package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.model.Customer;
import com.jio.account.service.CustomerLocalService;
import com.jio.customer.service.CustomerService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;
import java.util.stream.LongStream;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SYNCH_ROLE }, service = MVCResourceCommand.class)
public class SynchRoleMVCResourceCommand implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		final long companyId = PortalUtil.getCompanyId(resourceRequest);
		final long roleId = customerService.getCustomerRoleId(companyId);
		if (roleId != 0L) {
			SessionMessages.add(resourceRequest, "customer-role-start-to-configure");
			List<Customer> customers = customerLocalService.getCustomersByCompanyId(companyId);
			customers.parallelStream().forEach(customer -> {

				try {
					User user = userLocalService.getUserByScreenName(companyId, customer.getScreenName());

					boolean present = LongStream.of(user.getRoleIds()).filter(l -> l == roleId).findAny().isPresent();
					if (!present) {
						userLocalService.addRoleUser(roleId, user);
						LOGGER.info("Customer Role Added : " + roleId + " User : " + user.getScreenName());
					}

				} catch (Exception e) {
					LOGGER.error("Exception : " + e.toString());
				}

			});
		} else {
			SessionErrors.add(resourceRequest, "customer-role-not-configured");
		}

		return Boolean.TRUE;
	}

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CustomerService customerService;

	@Reference
	private UserLocalService userLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SynchRoleMVCResourceCommand.class);
}
