/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchDocumentException;
import com.jio.account.model.Document;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.service.DocumentLocalService;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.customer.service.CustomerService;
import com.jio.master.document.model.DocumentCategory;
import com.jio.master.document.service.DocumentCategoryLocalService;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.jio.master.telecom.service.PlanLocalService;
import com.jio.nas.api.NASHelper;
import com.jio.nas.rest.constant.NASConstant;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.MODIFY }, service = MVCActionCommand.class)
public class ModifyMVCActionCommand extends BaseMVCActionCommand {

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CounterLocalService counterLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private AgentCustomerMappingLocalService agentCustomerMappingLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private CustomerService customerService;
	
	@Reference
	DocumentCategoryLocalService documentCategoryLocalService;

	@Reference
	DocumentLocalService documentLocalService;

	@Reference
	com.jio.account.service.DocumentLocalService customerDocumentLocalService;

	@Reference
	private NASHelper nasHelper;
	
	private static final Log LOGGER = LogFactoryUtil.getLog(ModifyMVCActionCommand.class);

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		long companyId = PortalUtil.getCompanyId(actionRequest);
		long groupId = PortalUtil.getScopeGroupId(actionRequest);
		User userAgent = PortalUtil.getUser(actionRequest);
		ServiceContext serviceContext = ServiceContextFactory.getInstance(actionRequest);
		serviceContext.setCompanyId(companyId);
		serviceContext.setUserId(userAgent.getUserId());

		// Customer Process
		String salutation = ParamUtil.getString(actionRequest, "salutation");
		String firstName = ParamUtil.getString(actionRequest, "firstName");
		String lastName = ParamUtil.getString(actionRequest, "lastName");
		String middleName = ParamUtil.getString(actionRequest, "middleName");
		String accountNo = ParamUtil.getString(actionRequest, "accountNo");
		String vcId = ParamUtil.getString(actionRequest, "vcId");
		String stbNo = ParamUtil.getString(actionRequest, "stbNo");
		String macId = ParamUtil.getString(actionRequest, "macId");
		String serviceType = ParamUtil.getString(actionRequest, "serviceType");
		String connectionType = ParamUtil.getString(actionRequest, "connectionType");

		// Contact Process
		String email = ParamUtil.getString(actionRequest, "email");
		String mobileNo = ParamUtil.getString(actionRequest, "mobileNo");
		String landline = ParamUtil.getString(actionRequest, "landline");

		// Address Process
		String pincode = ParamUtil.getString(actionRequest, "pincode");
		String areaCode = ParamUtil.getString(actionRequest, "areaCode");
		String building = ParamUtil.getString(actionRequest, "building");
		String street = ParamUtil.getString(actionRequest, "street");
		String location = ParamUtil.getString(actionRequest, "location");
		String flatNo = ParamUtil.getString(actionRequest, "flatNo");
		String cityCode = ParamUtil.getString(actionRequest, "cityCode");
		String addressLine = ParamUtil.getString(actionRequest, "addressLine");
		String addressLineFull = flatNo + "," + addressLine + "|" + building + "|" + location + "|" + street;

		String customerId = ParamUtil.getString(actionRequest, "customerId");
		String servicePoId = ParamUtil.getString(actionRequest, "servicePoId");
		String poId = ParamUtil.getString(actionRequest, "poId");
		String stbPoId = ParamUtil.getString(actionRequest, "stbPoId");
		String vcPoId = ParamUtil.getString(actionRequest, "vcPoId");
		String macPoId = ParamUtil.getString(actionRequest, "macPoId");

		String txRefNo = AccountUtil.getTxRefNo();
		try {
			Map<String, String> map = customerService.modifyCustomer(accountNo, vcId, stbNo, macId, connectionType, serviceType, customerId, salutation, firstName, middleName, lastName, addressLineFull, street, location, building, flatNo, mobileNo, landline, email, cityCode, areaCode, pincode, servicePoId,
					poId, stbPoId, vcPoId, macPoId, txRefNo, userAgent, companyId, groupId, serviceContext);
			if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
				
				UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
				InputStream is = null;
				File document = null;
				try {
					for (DocumentCategory category : documentCategoryLocalService.getDocumentCategories(companyId)) {
						document = request.getFile("document" + category.getCategoryId());
						is = new FileInputStream(document);
						String documentTypeCategoryId = ParamUtil.getString(request, "documentType" + category.getCategoryId());
						uploadDocument(companyId, groupId, userAgent.getScreenName(), is, category.getCode(), document.getName(), customerId, documentTypeCategoryId);
					}

					document = request.getFile("documentIMAGE");
					is = new FileInputStream(document);
					uploadDocument(companyId, groupId, userAgent.getScreenName(), is, "IMAGE", document.getName(), customerId, "IMAGE");

					document = request.getFile("documentPDF");
					is = new FileInputStream(document);
					uploadDocument(companyId, groupId, userAgent.getScreenName(), is, "PDF", document.getName(), customerId, "PDF");
				
					actionRequest.setAttribute("successMessage", map.get("MESSAGE"));
				} catch (FileNotFoundException e) {
					LOGGER.error("FileNotFoundException : " + e.getMessage());
				}
			} else {
				actionRequest.setAttribute("errorMessage", map.get("MESSAGE"));
			}
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (NoSuchPlanException e) {
			LOGGER.error("NoSuchPlanException :: " + e.toString());
		}
	}
	
	private void uploadDocument(long companyId, long groupId, String userScreenName,InputStream is, String categoryCode, String documentName, String customerId, String documentType) {
		Map<String, Object> response = nasHelper._createNASFile(is, documentName, categoryCode, categoryCode, customerId, true);
		try {
			JSONObject json = JSONFactoryUtil.createJSONObject(response.get(NASConstant.BODY).toString());
			saveOrUpdateDocument(companyId, groupId, userScreenName, categoryCode, customerId, documentType, json.get("id").toString());
		} catch (JSONException e) {
			LOGGER.error("JSONException : " + e.getMessage());
		}
	}
	
	private void saveOrUpdateDocument(long companyId, long groupId, String userScreenName, String categoryCode, String customerId, String documentType, String responseFileName) {

		Document customerDocument = null;
		try {
			customerDocument = customerDocumentLocalService.getDocumentByC_S_C(companyId, customerId, categoryCode);
		} catch (NoSuchDocumentException e) {
			LOGGER.error("NoSuchDocumentException : " + e.getMessage());
		}
		if (Validator.isNull(customerDocument)) {
			customerDocument = customerDocumentLocalService.createDocument(AccountUtil.getRefNo("D"));
		}
		customerDocument.setCompanyId(companyId);
		customerDocument.setGroupId(groupId);
		customerDocument.setCreateBy(userScreenName);
		customerDocument.setCustomerId(customerId);
		customerDocument.setName(responseFileName);
		customerDocument.setType(documentType);
		customerDocument.setCategory(categoryCode);
		customerDocument.setName(responseFileName);

		if (customerDocument.isNew()) {
			customerDocumentLocalService.addDocument(customerDocument);
		} else {
			customerDocumentLocalService.updateDocument(customerDocument);
		}
	}
}