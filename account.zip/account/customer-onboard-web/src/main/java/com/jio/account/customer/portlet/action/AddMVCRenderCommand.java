/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.customer.portlet.action;

import com.jio.account.bean.CustomerBean;
import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.model.Address;
import com.jio.account.model.Document;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.service.DocumentLocalService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.master.document.model.DocumentCategory;
import com.jio.master.document.service.DocumentCategoryLocalService;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.exception.NoSuchServiceTypeException;
import com.jio.master.telecom.model.ConnectionType;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.model.PlanCategory;
import com.jio.master.telecom.model.PlanCategoryGroup;
import com.jio.master.telecom.model.ServiceType;
import com.jio.master.telecom.service.ConnectionTypeLocalService;
import com.jio.master.telecom.service.PlanCategoryGroupLocalService;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

// "mvc.command.name=" + MVCCommandNames.SAVE, "mvc.command.name=" + MVCCommandNames.SAVE_DOCUMENT 

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.ADD }, service = MVCRenderCommand.class)
public class AddMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private ConnectionTypeLocalService connectionTypeLocalService;

	@Reference
	com.jio.master.document.service.DocumentLocalService documentLocalService;

	@Reference
	DocumentLocalService customerDocumentLocalService;

	@Reference
	DocumentCategoryLocalService documentCategoryLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private PlanCategoryGroupLocalService planCategoryGroupLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(AddMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) {
		String vcId = ParamUtil.getString(renderRequest, "vcId");
		String stbNo = ParamUtil.getString(renderRequest, "stbNo");
		String macId = ParamUtil.getString(renderRequest, "macId");
		String customerId = ParamUtil.getString(renderRequest, "customerId");
		String deviceType = ParamUtil.getString(renderRequest, "deviceType");
		String vcPoId = ParamUtil.getString(renderRequest, "vcPoId");
		String devicePoId = ParamUtil.getString(renderRequest, "devicePoId");
		String serviceTypeCode = "";
		String cityCode = "";
		try {
			User user = PortalUtil.getUser(renderRequest);
			long companyId = PortalUtil.getCompanyId(renderRequest);

			// SAVE
			Address address = addressLocalService.getAddress(companyId, user.getScreenName());
			if (Validator.isNotNull(address)) {
				Location city = locationLocalService.getLocationsByCode(address.getCityCode(), companyId);
				List<Location> areas = locationLocalService.getChildLocations(city.getCode(), companyId);
				List<ServiceType> serviceTypes = serviceTypeLocalService.getServiceTypes(companyId);
				List<ConnectionType> connectionTypes = connectionTypeLocalService.getConnectionTypes(companyId);
				List<Location> pincodes = locationLocalService.getSubChildLocations(city.getCode(), companyId);
				String[] salutations = JioPropsUtil.getArray(ConfigConstant.CUSTOMER_SALUTATION, companyId);
				renderRequest.setAttribute("city", city);
				renderRequest.setAttribute("areas", areas);
				renderRequest.setAttribute("pincodes", pincodes);
				renderRequest.setAttribute("serviceTypes", serviceTypes);
				renderRequest.setAttribute("connectionTypes", connectionTypes);
				renderRequest.setAttribute("salutations", salutations);
			}

			// DOCUMENT
			List<DocumentCategory> documentCategories = documentCategoryLocalService.getDocumentCategories(companyId);
			renderRequest.setAttribute("documentCategories", documentCategories);

			List<Document> documents = customerDocumentLocalService.getDocuments(customerId, companyId);

			Map<String, Document> documentMap = new HashMap<String, Document>();
			for (Document document : documents) {
				documentMap.put(document.getCategory(), document);
			}
			renderRequest.setAttribute("documentMap", documentMap);

			// ADD PLAN
			cityCode = address.getCityCode();
			serviceTypeCode = JioPropsUtil.get(ConfigConstant.SERVICETYPE_CODE, companyId);

			List<Plan> plans = null;

			try {
				ServiceType serviceType = serviceTypeLocalService.getServiceTypeByCode(serviceTypeCode, companyId);
				long serviceTypeId = serviceType.getServiceTypeId();

				List<PlanCategoryGroup> planCategoryGroups = planCategoryGroupLocalService.getPlanCategoryGroups(true, true, serviceTypeId, companyId);
				long[] categoryGroupIds = planCategoryGroups.stream().map(planCategoryGroup -> planCategoryGroup.getCategoryGroupId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();

				renderRequest.setAttribute("planCategoryGroups", planCategoryGroups);

				List<PlanCategory> planCategories = planCategoryLocalService.getPlanCategories(true, serviceTypeId, categoryGroupIds, companyId);
				long[] categoryIds = planCategories.stream().map(planCategory -> planCategory.getCategoryId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();
				String[] cityCodes = { cityCode };
				plans = planLocalService.getPlansByCategory(categoryIds, true, companyId, cityCodes);

			} catch (NoSuchServiceTypeException e) {
				LOGGER.error("NoSuchServiceTypeException :: " + e.toString());
				plans = new ArrayList<Plan>();
			}

			renderRequest.setAttribute("plans", plans);

		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}
		renderRequest.setAttribute("isAdd", Boolean.TRUE);
		renderRequest.setAttribute("customer", getCustomerBean(vcId, stbNo, macId, vcPoId, devicePoId, serviceTypeCode, deviceType, cityCode, customerId));
		return "/customer/edit_customer.jsp";
	}

	private CustomerBean getCustomerBean(String vcId, String stbNo, String macId, String vcPoId, String devicePoId, String serviceType, String connectionType, String cityCode, String customerId) {
		CustomerBean customerBean = new CustomerBean();
		customerBean.setVcId(vcId);
		customerBean.setStbNo(stbNo);
		customerBean.setMacId(macId);
		customerBean.setCustomerId(customerId);
		customerBean.setConnectionType(connectionType);
		customerBean.setServiceType(serviceType);
		customerBean.setVcId(vcPoId);
		customerBean.setDevicePoId(devicePoId);
		customerBean.setCityCode(cityCode);
		return customerBean;
	}

}