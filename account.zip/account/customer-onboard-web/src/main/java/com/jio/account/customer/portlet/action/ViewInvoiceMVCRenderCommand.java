package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.nas.invoice.api.NASInvoiceHelper;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.VIEW_INVOICE, }, service = MVCRenderCommand.class)
public class ViewInvoiceMVCRenderCommand implements MVCRenderCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(ViewInvoiceMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		//long companyId = PortalUtil.getCompanyId(renderRequest);
		String accountNo = ParamUtil.getString(renderRequest, "accountNo");
		String screenName = ParamUtil.getString(renderRequest, "screenName");

		PortletURL iteratorURL = renderResponse.createRenderURL();
		iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
		try {
			iteratorURL.setWindowState(WindowState.NORMAL);
		} catch (WindowStateException e) {
			LOGGER.error(e.toString());
		}

		SearchContainer<String> searchContainer = new SearchContainer<String>(renderRequest, iteratorURL, null, "there-are-no-customer-invoices");

		List<String> fileNames = nasInvoiceHelper.getNasInvoices(accountNo);

		searchContainer.setDeltaConfigurable(true);
		searchContainer.setTotal(fileNames.size());
		searchContainer.setResults(fileNames);
		renderRequest.setAttribute("customerInvoiceSearchContainer", searchContainer);

		renderRequest.setAttribute("accountNo", accountNo);
		renderRequest.setAttribute("screenName", screenName);

		return "/customer/view_invoice.jsp";
	}

	@Reference
	NASInvoiceHelper nasInvoiceHelper;
}