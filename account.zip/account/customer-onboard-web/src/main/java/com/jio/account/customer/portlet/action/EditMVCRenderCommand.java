/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.customer.portlet.action;

import com.jio.account.bean.CustomerBean;
import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.model.Address;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.model.Document;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.service.DocumentLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.service.CustomerService;
import com.jio.master.document.model.DocumentCategory;
import com.jio.master.document.service.DocumentCategoryLocalService;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.model.ConnectionType;
import com.jio.master.telecom.model.ServiceType;
import com.jio.master.telecom.service.ConnectionTypeLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.EDIT }, service = MVCRenderCommand.class)
public class EditMVCRenderCommand implements MVCRenderCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(EditMVCRenderCommand.class);

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	DocumentLocalService documentLocalService;

	@Reference
	DocumentLocalService customerDocumentLocalService;

	@Reference
	DocumentCategoryLocalService documentCategoryLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private ConnectionTypeLocalService connectionTypeLocalService;

	@Reference
	private CustomerService customerService;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		String screenName = ParamUtil.getString(renderRequest, "screenName");
		String accountNo = ParamUtil.getString(renderRequest, "accountNo");

		String txRefNo = AccountUtil.getTxRefNo();
		String referenceNumber = txRefNo;
		String transactionRefNo = txRefNo;

		try {
			User user = PortalUtil.getUser(renderRequest);
			long companyId = PortalUtil.getCompanyId(renderRequest);
			long groupId = PortalUtil.getScopeGroupId(renderRequest);
			long userId = user.getUserId();
			String createdBy = user.getScreenName();

			ServiceContext serviceContext = ServiceContextFactory.getInstance(renderRequest);
			serviceContext.setCompanyId(companyId);

			Customer customer = customerService.getOrCreateCustomer(accountNo, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId, serviceContext);
			Contact contact = contactLocalService.getContact(companyId, screenName);

			// DOCUMENT
			List<DocumentCategory> documentCategories = documentCategoryLocalService.getDocumentCategories(companyId);
			renderRequest.setAttribute("documentCategories", documentCategories);

			List<Document> documents = customerDocumentLocalService.getDocuments(customer.getCustomerId(), companyId);
			Map<String, Document> documentMap = new HashMap<String, Document>();
			for (Document document : documents) {
				documentMap.put(document.getCategory(), document);
			}
			renderRequest.setAttribute("documentMap", documentMap);

			user = userLocalService.getUserByScreenName(companyId, screenName);
			// ADDRESS
			Address address = addressLocalService.getAddress(companyId, user.getScreenName());
			if (Validator.isNotNull(address)) {
				Location city = locationLocalService.getLocationsByCode(address.getCityCode(), companyId);
				List<Location> areas = locationLocalService.getChildLocations(city.getCode(), companyId);
				List<ServiceType> serviceTypes = serviceTypeLocalService.getServiceTypes(companyId);
				List<ConnectionType> connectionTypes = connectionTypeLocalService.getConnectionTypes(companyId);
				List<Location> pincodes = locationLocalService.getSubChildLocations(city.getCode(), companyId);
				String[] salutations = JioPropsUtil.getArray(ConfigConstant.CUSTOMER_SALUTATION, companyId);
				renderRequest.setAttribute("city", city);
				renderRequest.setAttribute("areas", areas);
				renderRequest.setAttribute("pincodes", pincodes);
				renderRequest.setAttribute("serviceTypes", serviceTypes);
				renderRequest.setAttribute("connectionTypes", connectionTypes);
				renderRequest.setAttribute("salutations", salutations);
			}

			renderRequest.setAttribute("customer", getCustomerBean(customer, contact, address, user));
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		renderRequest.setAttribute("isAdd", Boolean.FALSE);
		return "/customer/edit_customer.jsp";
	}

	private CustomerBean getCustomerBean(Customer customer, Contact contact, Address address, User user) {
		CustomerBean customerBean = new CustomerBean();
		if (Validator.isNotNull(customer) && Validator.isNotNull(contact) && Validator.isNotNull(address) && Validator.isNotNull(user)) {
			customerBean.setVcId(customer.getVcId());
			customerBean.setStbNo(customer.getStbNo());
			customerBean.setMacId(customer.getMacId());
			customerBean.setFirstName(user.getFirstName());
			customerBean.setMiddleName(user.getMiddleName());
			customerBean.setLastName(user.getLastName());
			customerBean.setAccountNo(customer.getAccountNo());
			customerBean.setScreenName(customer.getScreenName());
			customerBean.setEmail(contact.getEmail());
			customerBean.setMobileNo(contact.getMobileNo());
			customerBean.setLandline(contact.getLandLineNo());
			customerBean.setPincode(address.getPincode());

			customerBean.setStreet(address.getStreet());
			customerBean.setLocation(address.getLocation());
			customerBean.setFlatNo(address.getFlatNo());
			customerBean.setBuilding(address.getBuilding());

			customerBean.setAreaCode(address.getAreaCode());
			customerBean.setCityCode(address.getCityCode());
			customerBean.setStateCode(address.getStateCode());
			customerBean.setCountryCode(address.getCountryCode());
			customerBean.setRegionCode(address.getRegionCode());
			customerBean.setAddress(address.getAddress());
			customerBean.setServiceType(customer.getServiceType());
			customerBean.setConnectionType(customer.getConnectionType());

			customerBean.setPoId(customer.getPoId());
			customerBean.setServicePoId(customer.getServicePoId());
			customerBean.setCustomerId(customer.getCustomerId());

			customerBean.setVcPoId(customer.getVcPoId());
			customerBean.setStbPoId(customer.getStbPoId());
			customerBean.setMacPoId(customer.getMacPoId());
		}
		return customerBean;
	}
}