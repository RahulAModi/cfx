package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_AREA }, service = MVCResourceCommand.class)

public class GetAreaMVCSResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(GetAreaMVCSResourceCommand.class);

	@Reference
	private LocationLocalService locationLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean flag = false;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String pincode = ParamUtil.getString(resourceRequest, "pincode");
		try {
			Location area = locationLocalService.getParentLocation(pincode, companyId);
			if (Validator.isNotNull(area)) {
				resourceResponse.getWriter().println(convertJSONObject(area));
				flag = true;
			}
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		} catch (NoSuchLocationException e) {
			LOGGER.error("NoSuchLocationException :: " + e.toString());
		}

		return flag;
	}

	public JSONObject convertJSONObject(Location location) {
		JSONObject outputObject = null;
		outputObject = JSONFactoryUtil.createJSONObject();
		outputObject.put("code", location.getCode());
		outputObject.put("id", location.getLocationId());
		outputObject.put("name", location.getName());
		return outputObject;
	}

}
