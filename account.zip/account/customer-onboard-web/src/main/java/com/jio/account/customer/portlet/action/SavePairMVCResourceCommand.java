/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.customer.portlet.action;

import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.device.exception.NoSuchDeviceException;
import com.jio.account.device.model.Device;
import com.jio.account.device.service.DeviceLocalService;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.service.AgentLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.service.CustomerService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.util.Map;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_PAIR }, service = MVCResourceCommand.class)
public class SavePairMVCResourceCommand implements MVCResourceCommand {

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerService customerService;

	@Reference
	private AgentService agentService;

	private static final Log LOGGER = LogFactoryUtil.getLog(SavePairMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		boolean flag = false;

		try {

			long companyId = PortalUtil.getCompanyId(resourceRequest);
			long groupId = PortalUtil.getScopeGroupId(resourceRequest);

			String vcId = ParamUtil.getString(resourceRequest, "vcId");
			String stbNo = ParamUtil.getString(resourceRequest, "stbNo");
			String macId = ParamUtil.getString(resourceRequest, "macId");
			User userAgent = PortalUtil.getUser(resourceRequest);
			String screenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());

			Device device = null;
			try {
				if (Validator.isNotNull(vcId)) {
					device = deviceLocalService.getDeviceByVcId(vcId, companyId);
				} else if (Validator.isNotNull(stbNo)) {
					device = deviceLocalService.getDeviceByStbNo(stbNo, companyId);
				}
			} catch (NoSuchDeviceException e) {
				LOGGER.warn("NoSuchDeviceException : " + e.toString());
			}

			if (Validator.isNotNull(device)) {
				vcId = device.getVcId();
				stbNo = device.getStbNo();
			}

			String txRefNo = AccountUtil.getTxRefNo();

			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();

			if ((Validator.isNotNull(vcId) && Validator.isNotNull(stbNo)) || Validator.isNotNull(macId)) {
				Map<String, String> map = customerService.pairInventoryDetail(vcId, stbNo, macId, screenName, txRefNo, userAgent, companyId, groupId);

				boolean pair = GetterUtil.getBoolean(map.get("PAIR"));
				String message = map.get("MESSAGE");
				String deviceType = map.get("DEVICETYPE");
				String devicePoId = map.get("DEVICEPOID");
				String vcPoId = map.get("VCPOID");
				String source = map.get("SOURCE");
				String category = map.get("CATEGORY");
				String connectionType = map.get("CONNECTIONTYPE");
				
				jsonObject.put("device", false);
				jsonObject.put("success", pair);
				jsonObject.put("message", message);
				jsonObject.put("vcId", vcId);
				jsonObject.put("stbNo", stbNo);
				jsonObject.put("macId", macId);
				jsonObject.put("deviceType", deviceType);
				jsonObject.put("devicePoId", devicePoId);
				jsonObject.put("vcPoId", vcPoId);
				jsonObject.put("source", source);
				jsonObject.put("category", category);
				jsonObject.put("serviceType", JioPropsUtil.get(ConfigConstant.SERVICETYPE_CODE, companyId));
				jsonObject.put("connectionType", connectionType);
			} else if (Validator.isNotNull(vcId) || Validator.isNotNull(stbNo)) {

				jsonObject.put("device", true);
				
				if (Validator.isNotNull(device)) {
					jsonObject.put("exist", true);
					jsonObject.put("vcId", device.getVcId());
					jsonObject.put("stbNo", device.getStbNo());
				} else {
					jsonObject.put("exist", false);
				}

			}

			resourceResponse.getWriter().println(jsonObject.toJSONString());
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		}

		return flag;
	}

	@Reference
	DeviceLocalService deviceLocalService;

}