package com.jio.account.customer.portlet.action;

import com.jio.account.bean.CustomerBean;
import com.jio.account.customer.constants.CustomerOnboardPortletKeys;
import com.jio.account.customer.constants.MVCCommandNames;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.csv.util.CSVUtil;
import com.jio.customer.service.CustomerService;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.exception.NoSuchConnectionTypeException;
import com.jio.master.telecom.exception.NoSuchServiceTypeException;
import com.jio.master.telecom.service.ConnectionTypeLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerOnboardPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD }, service = MVCActionCommand.class)

public class SaveUploadMVCActionCommand extends BaseMVCActionCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(SaveUploadMVCActionCommand.class);

	@Reference
	private ConnectionTypeLocalService connectionTypeLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private CustomerService customerService;

	@Reference
	private CSVUtil csvUtil;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		final User userAgent = PortalUtil.getUser(actionRequest);
		final long groupId = PortalUtil.getScopeGroupId(actionRequest);
		final long companyId = PortalUtil.getCompanyId(actionRequest);

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();
		ServiceContext serviceContext = ServiceContextFactory.getInstance(actionRequest);

		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (csvUtil.isNotCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.PIPE);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;

					Runnable runnable = new Runnable() {
						@Override
						public void run() {
							try {
								addCustomers(userAgent, groupId, companyId, csvRecords, actionRequest, serviceContext);
							} catch (PortalException e) {
								LOGGER.error("PortalException :: " + e.toString());
							}
						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}

	}

	private List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	private List<Customer> addCustomers(User userAgent, long groupId, long companyId, List<CSVRecord> csvRecords, ActionRequest actionRequest, ServiceContext serviceContext) throws PortalException {
		List<Customer> customers = new ArrayList<Customer>();
		for (CSVRecord csvRecord : csvRecords) {
			Customer customer;
			try {
				customer = addCustomer(userAgent, groupId, companyId, csvRecord, actionRequest, serviceContext);
				if (Validator.isNotNull(customer)) {
					customers.add(customer);
				}
			} catch (NoSuchCustomerException e) {
				LOGGER.error("Exception :: " + e.toString());
			}

		}
		return customers;
	}

	private Customer addCustomer(User userAgent, long groupId, long companyId, CSVRecord csvRecord, ActionRequest actionRequest, ServiceContext serviceContext) throws PortalException {

		CustomerBean customerBean = getCustomerBeanFromCSV(csvRecord, groupId, companyId);

		boolean validCustomer = customerValidation(customerBean);
		Customer customer = null;
		if (validCustomer) {
			if (Validator.isNull(customer)) {
				customerService.saveOrUpdateCustomer(companyId, groupId, customerBean, userAgent, serviceContext);
			}
		}
		return customer;
	}

	private Boolean customerValidation(CustomerBean customerBean) throws PortalException {
		if (Validator.isNull(customerBean.getScreenName())) {
			LOGGER.error("Screen Name Empty or Invalid");
			return false;
		}
		// Agent Check
		try {
			agentLocalService.getAgent(customerBean.getCompanyId(), customerBean.getAgentScreenName());
		} catch (NoSuchAgentException e) {
			LOGGER.error("For customer " + customerBean.getScreenName() + "NoSuchAgentException :: No agent with screenName ::  " + customerBean.getAgentScreenName() + "::" + e.toString());
			return false;
		}
		// connection type Type check
		try {
			connectionTypeLocalService.getConnectionTypeByCode(customerBean.getConnectionType(), customerBean.getCompanyId());
		} catch (NoSuchConnectionTypeException e) {
			LOGGER.error("For customer " + customerBean.getScreenName() + "NoSuchConnectionServiceException :: No connectionType with code :: " + customerBean.getConnectionType() + "::" + e.toString());
			return false;

		}
		// service type check
		try {
			serviceTypeLocalService.getServiceTypeByCode(customerBean.getServiceType(), customerBean.getCompanyId());
		} catch (NoSuchServiceTypeException e) {
			LOGGER.error("For customer " + customerBean.getScreenName() + " NoSuchServiceException :: No ServiceType with code ::  " + customerBean.getServiceType() + "::" + e.toString());
			return false;
		}

		// address check
		try {
			locationLocalService.getLocationsByCode(customerBean.getPincode(), customerBean.getCompanyId());
		} catch (NoSuchLocationException e) {
			LOGGER.error("For customer " + customerBean.getScreenName() + " NoSuchLocationException :: No location with code ::  " + customerBean.getLocation() + "::" + e.toString());
			return false;
		}

		return true;
	}

	private CustomerBean getCustomerBeanFromCSV(CSVRecord csvRecord, long groupId, long companyId) {

		CustomerBean customerBean = new CustomerBean();
		customerBean.setCompanyId(companyId);
		customerBean.setGroupId(groupId);

		String accountNo = csvRecord.get("accountNo");
		String screenName = csvRecord.get("screenName");
		String agentScreenName = csvRecord.get("agentScreenName");
		String vcId = csvRecord.get("vcId");
		String stbNo = csvRecord.get("stbNo");
		String macId = csvRecord.get("macId");
		String connectionType = csvRecord.get("connectionType");
		String serviceType = csvRecord.get("serviceType");
		String status = csvRecord.get("status");
		boolean primary = GetterUtil.getBoolean(csvRecord.get("primary"));

		String firstName = csvRecord.get("firstName");
		String secondName = csvRecord.get("secondName");
		String lastName = csvRecord.get("lastName");
		String email = csvRecord.get("email");

		String addressType = csvRecord.get("addressType");
		String pincode = csvRecord.get("pincode");
		String areaCode = csvRecord.get("areaCode");
		String streetCode = csvRecord.get("streetCode");
		String locationCode = csvRecord.get("locationCode");
		String buildingCode = csvRecord.get("buildingCode");
		String flatNo = csvRecord.get("flatNo");
		String cityCode = csvRecord.get("cityCode");
		String stateCode = csvRecord.get("stateCode");
		String countryCode = csvRecord.get("countryCode");
		String regionCode = csvRecord.get("regionCode");
		String address = csvRecord.get("address");
		boolean primaryContact = GetterUtil.getBoolean(csvRecord.get("primaryContact"));

		customerBean.setAccountNo(accountNo);
		customerBean.setScreenName(screenName);
		customerBean.setAgentScreenName(agentScreenName);
		customerBean.setVcId(vcId);
		customerBean.setStbNo(stbNo);
		customerBean.setMacId(macId);
		customerBean.setConnectionType(connectionType);
		customerBean.setServiceType(serviceType);
		customerBean.setStatus(status);
		customerBean.setPrimary(primary);

		customerBean.setFirstName(firstName);
		customerBean.setMiddleName(secondName);
		customerBean.setLastName(lastName);
		customerBean.setEmail(email);

		customerBean.setAddressType(addressType);
		customerBean.setPincode(pincode);
		customerBean.setAreaCode(areaCode);
		customerBean.setStreet(streetCode);
		customerBean.setLocation(locationCode);
		customerBean.setBuilding(buildingCode);
		customerBean.setFlatNo(flatNo);
		customerBean.setCityCode(cityCode);
		customerBean.setStateCode(stateCode);
		customerBean.setRegionCode(regionCode);
		customerBean.setCountryCode(countryCode);
		customerBean.setAddress(address);
		customerBean.setPrimaryContact(primaryContact);

		return customerBean;
	}

}
