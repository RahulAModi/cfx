package com.jio.customer.service;

import com.jio.account.bean.CustomerBean;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;

import java.util.Map;

/**
 * @author Vishal7.Shah
 */
public interface CustomerService {

	/**
	 * 
	 * @param accountNo
	 * @param vcId
	 * @param stbNo
	 * @param macId
	 * @param connectionType
	 * @param serviceType
	 * @param customerId
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param addressLine
	 * @param street
	 * @param location
	 * @param building
	 * @param flatNo
	 * @param mobileNo
	 * @param landline
	 * @param email
	 * @param cityCode
	 * @param areaCode
	 * @param pincode
	 * @param servicePoId
	 * @param poId
	 * @param stbPoId
	 * @param vcPoId
	 * @param macPoId
	 * @param txRefNo
	 * @param userAgent
	 * @param companyId
	 * @param groupId
	 * @param serviceContext
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchLocationException
	 * @throws NoSuchPlanException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws PortalException
	 */
	Map<String, String> modifyCustomer(String accountNo, String vcId, String stbNo, String macId, String connectionType, String serviceType, String customerId, String salutation, String firstName, String middleName, String lastName, String addressLine, String street, String location,
			String building, String flatNo, String mobileNo, String landline, String email, String cityCode, String areaCode, String pincode, String servicePoId, String poId, String stbPoId, String vcPoId, String macPoId, String txRefNo, User userAgent, long companyId, long groupId,
			ServiceContext serviceContext) throws NoSuchAgentException, NoSuchLocationException, NoSuchPlanException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, PortalException;

	/**
	 * 
	 * @param vcId
	 * @param stbNo
	 * @param macId
	 * @param connectionType
	 * @param serviceType
	 * @param customerId
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param addressLine
	 * @param street
	 * @param location
	 * @param building
	 * @param flatNo
	 * @param mobileNo
	 * @param landline
	 * @param email
	 * @param cityCode
	 * @param areaCode
	 * @param pincode
	 * @param planId
	 * @param txRefNo
	 * @param userAgent
	 * @param companyId
	 * @param groupId
	 * @param serviceContext
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentException
	 * @throws NoSuchLocationException
	 * @throws PortalException
	 */
	Map<String, String> createCustomer(String vcId, String stbNo, String macId, String connectionType, String serviceType, String customerId, String salutation, String firstName, String middleName, String lastName, String addressLine, String street, String location, String building, String flatNo,
			String mobileNo, String landline, String email, String cityCode, String areaCode, String pincode, String planId, String txRefNo, User userAgent, long companyId, long groupId, ServiceContext serviceContext) throws NoSuchAgentException, NoSuchLocationException, PortalException;

	/**
	 * 
	 * @param accountNo
	 * @param vcId
	 * @param deviceId
	 * @param primaryAgentScreenName
	 * @param userAgent
	 * @param txRefNo
	 * @param referenceNumber
	 * @param transactionRefNo
	 * @param createdBy
	 * @param userId
	 * @param companyId
	 * @param groupId
	 * @param serviceContext
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchLocationException
	 * @throws PortalException
	 */
	Customer getOrCreateCustomer(String accountNo, String vcId, String deviceId, String primaryAgentScreenName, User userAgent, String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, ServiceContext serviceContext)
			throws NoSuchCustomerException, NoSuchLocationException, PortalException;

	/**
	 * 
	 * @param accountNo
	 * @param txRefNo
	 * @param referenceNumber
	 * @param transactionRefNo
	 * @param createdBy
	 * @param userId
	 * @param companyId
	 * @param groupId
	 * @param serviceContext
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchLocationException
	 * @throws PortalException
	 */
	Customer getOrCreateCustomer(String accountNo, String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, ServiceContext serviceContext) throws NoSuchCustomerException, PortalException;

	/**
	 * Create and Update Contact Details
	 * 
	 * 
	 * @param customerId
	 * @param screenName
	 * @param companyId
	 * @param groupId
	 * @param mobileNo
	 * @param landline
	 * @param email
	 * @param userAgent  - LCO or Agent User
	 * @return
	 */
	Contact saveOrUpdateContact(String customerId, String screenName, long companyId, long groupId, String mobileNo, String landline, String email, User userAgent);

	/**
	 * 
	 * Create and Update Address Details
	 * 
	 * @param customerId
	 * @param screenName
	 * @param companyId
	 * @param groupId
	 * @param countryCode
	 * @param regionCode
	 * @param stateCode
	 * @param cityCode
	 * @param areaCode
	 * @param pincode
	 * @param buildingCode
	 * @param addressLine
	 * @param userAgent    - LCO or Agent User
	 * @return
	 */
	Address saveOrUpdateAddress(String customerId, String screenName, long companyId, long groupId, String countryCode, String regionCode, String stateCode, String cityCode, String areaCode, String pincode, String street, String location, String building, String flatNo, String addressLine,
			User userAgent);

	/**
	 * 
	 * Create and Update Customer Details
	 * 
	 * @param customerId
	 * @param accountNo
	 * @param companyId
	 * @param groupId
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param agentScreenName
	 * @param vcId
	 * @param stbNo
	 * @param macId
	 * @param connectionType
	 * @param serviceType
	 * @param poId
	 * @param servicePoId
	 * @param stbPoId
	 * @param vcPoId
	 * @param macPoId
	 * @param status
	 * @param userAgent       - LCO or Agent User
	 * @return
	 */
	Customer saveOrUpdateCustomer(String customerId, String accountNo, long companyId, long groupId, String salutation, String firstName, String middleName, String lastName, String agentScreenName, String vcId, String stbNo, String macId, String connectionType, String serviceType, String poId,
			String servicePoId, String stbPoId, String vcPoId, String macPoId, String status, User userAgent);

	/**
	 * 
	 * Create and Update User Details
	 * 
	 * @param creatorUserId
	 * @param companyId
	 * @param screenName
	 * @param email
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param serviceContext
	 * @return
	 * @throws PortalException
	 */
	User saveOrUpdateUser(long creatorUserId, long companyId, String screenName, String email, String salutation, String firstName, String middleName, String lastName, ServiceContext serviceContext) throws PortalException;

	/**
	 * 
	 * Create and Update Agent Customer Mapping
	 * 
	 * @param screenName
	 * @param companyId
	 * @param groupId
	 * @param agentScreenName
	 * @param userAgent       - LCO or Agent User
	 * @return
	 */
	AgentCustomerMapping saveOrUpdateAgentCustomerMapping(String screenName, long companyId, long groupId, String agentScreenName, User userAgent);

	/**
	 * 
	 * @param companyId
	 * @param groupId
	 * @param customerBean
	 * @param userAgent      - LCO or Agent User
	 * @param serviceContext
	 * @return
	 * @throws PortalException
	 */
	Customer saveOrUpdateCustomer(long companyId, long groupId, CustomerBean customerBean, User userAgent, ServiceContext serviceContext) throws PortalException;

	/**
	 * 
	 * @param vcId
	 * @param stbNo
	 * @param macId
	 * @param primaryAgentScreenName - VC ID and STB NO connected LCO code / Screen Name
	 * @param txRefNo
	 * @param userAgent              - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 */
	Map<String, String> getInventoryDetail(String vcId, String stbNo, String macId, String primaryAgentScreenName, String txRefNo, User userAgent, long companyId, long groupId);

	/**
	 * 
	 * @param vcId
	 * @param stbNo
	 * @param macId
	 * @param primaryAgentScreenName - VC ID and STB NO connected LCO code / Screen Name
	 * @param txRefNo
	 * @param userAgent              - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 */
	Map<String, String> pairInventoryDetail(String vcId, String stbNo, String macId, String primaryAgentScreenName, String txRefNo, User userAgent, long companyId, long groupId);

	/**
	 * 
	 * @param vcId
	 * @param stbNo
	 * @param macId
	 * @param primaryAgentScreenName - VC ID and STB NO connected LCO code / Screen Name
	 * @param txRefNo
	 * @param userAgent              - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @param global                 - IF true then global search otherwise primary agent wise search
	 * @return
	 */
	Map<String, String> getInventory(String vcId, String stbNo, String macId, String primaryAgentScreenName, String txRefNo, User userAgent, long companyId, long groupId, boolean global);

	/**
	 * 
	 * @param accountNo   - Customer account no
	 * @param screenName  - Customer screen name - If NULL then take Customer from account no
	 * @param reasonKey   - if this value blank then reasonValue mandatory, if not balnk then take value from KEY PROPERTY : customer.suspend.reason
	 * @param reasonValue - if this value blank then reasonValue = OTHER
	 * @param txRefNo
	 * @param userAgent   - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchCustomerException
	 */
	Map<String, String> suspendCustomer(String accountNo, String screenName, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException;

	/**
	 * 
	 * @param accountNo   - Customer account no
	 * @param screenName  - Customer screen name - If NULL then take Customer from account no
	 * @param reasonKey   - if this value blank then reasonValue mandatory, if not balnk then take value from KEY PROPERTY : customer.reactive.reason
	 * @param reasonValue - if this value blank then reasonValue = OTHER
	 * @param txRefNo
	 * @param userAgent   - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @throws NoSuchCustomerException
	 */
	Map<String, String> reactiveCustomer(String accountNo, String screenName, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException;

	/**
	 * 
	 * @param accountNo   - Customer account no
	 * @param screenName  - Customer screen name
	 * @param reasonKey   - if this value blank then reasonValue mandatory, if not balnk then take value from KEY PROPERTY : customer.terminate.reason
	 * @param reasonValue - if this value blank then reasonValue = OTHER
	 * @param txRefNo
	 * @param userAgent   - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchCustomerException
	 * @throws PortalException
	 */
	Map<String, String> terminateCustomer(String accountNo, String screenName, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException, PortalException;

	/**
	 * 
	 * @param accountNo
	 * @param screenName
	 * @param newVcId
	 * @param reasonKey   - if this value blank then reasonValue mandatory, if not balnk then take value from KEY PROPERTY : swap.vc.reason
	 * @param reasonValue - if this value blank then reasonValue = OTHER
	 * @param txRefNo
	 * @param userAgent   - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAgentException
	 */
	Map<String, String> swapVCCustomer(String accountNo, String screenName, String newVcId, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException, NoSuchAgentException;

	/**
	 * 
	 * @param accountNo
	 * @param screenName
	 * @param newStbNo    - NEW STB NO
	 * @param reasonKey   - if this value blank then reasonValue mandatory, if not balnk then take value from KEY PROPERTY : swap.stb.reason
	 * @param reasonValue - if this value blank then reasonValue = OTHER
	 * @param txRefNo
	 * @param userAgent   - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAgentException
	 */
	Map<String, String> swapStbCustomer(String accountNo, String screenName, String newStbNo, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException, NoSuchAgentException;

	/**
	 * 
	 * @param accountNo  - Customer account no
	 * @param screenName - Customer screen name - If NULL then take Customer from account no
	 * @param txRefNo
	 * @param userAgent  - LCO or Agent User
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchCustomerException
	 */
	Map<String, String> retractCustomer(String accountNo, String screenName, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException;

	/**
	 * 
	 * @param status
	 * @param message
	 * @return
	 */
	Map<String, String> getMap(String status, String message);

	/**
	 * 
	 * @param companyId
	 * @return
	 */
	long getCustomerRoleId(long companyId);

}