package com.jio.customer.service.impl;

import com.jio.account.bean.CustomerBean;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.brm.customer.create.api.ActiveDevices;
import com.jio.brm.customer.create.api.ActiveService;
import com.jio.brm.customer.create.api.CustomerCreateResponse;
import com.jio.brm.customer.create.service.CustomerCreateService;
import com.jio.brm.customer.info.api.CustomerInfoResponse;
import com.jio.brm.customer.info.api.CustomerNameInfo;
import com.jio.brm.customer.info.api.Devices;
import com.jio.brm.customer.info.api.Phones;
import com.jio.brm.customer.info.api.Services;
import com.jio.brm.customer.info.service.CustomerInfoService;
import com.jio.brm.customer.modify.api.CustomerModifyResponse;
import com.jio.brm.customer.modify.service.CustomerModifyService;
import com.jio.brm.inventory.detail.api.InventoryDetailResponse;
import com.jio.brm.inventory.detail.api.Result;
import com.jio.brm.inventory.detail.service.InventoryDetailService;
import com.jio.brm.reactive.action.api.ReactiveActionResponse;
import com.jio.brm.reactive.action.service.ReactiveActionService;
import com.jio.brm.retract.action.api.RetractActionResponse;
import com.jio.brm.retract.action.service.RetractActionService;
import com.jio.brm.suspend.action.api.SuspendActionResponse;
import com.jio.brm.suspend.action.service.SuspendActionService;
import com.jio.brm.swap.action.api.SwapActionResponse;
import com.jio.brm.swap.action.service.SwapActionService;
import com.jio.brm.terminate.action.api.TerminateActionResponse;
import com.jio.brm.terminate.action.service.TerminateActionService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.config.service.LanguagePropertyLocalService;
import com.jio.customer.constant.CustomerConstant;
import com.jio.customer.constant.StatusConstant;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.customer.service.CustomerService;
import com.jio.customer.util.ConvertUtil;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.language.LanguageUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.RoleLocalService;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Vishal7.Shah
 */

@Component(immediate = true, service = CustomerService.class)
public class CustomerServiceImpl implements CustomerService {

	@Override
	public Map<String, String> modifyCustomer(String accountNo, String vcId, String stbNo, String macId, String connectionType, String serviceType, String customerId, String salutation, String firstName, String middleName, String lastName, String addressLine, String street, String location,
			String building, String flatNo, String mobileNo, String landline, String email, String cityCode, String areaCode, String pincode, String servicePoId, String poId, String stbPoId, String vcPoId, String macPoId, String txRefNo, User userAgent, long companyId, long groupId,
			ServiceContext serviceContext) throws NoSuchAgentException, NoSuchLocationException, PortalException {
		LOGGER.info("CustomerServiceImpl::modifyCustomer");
		String primaryAgentScreenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());

		String finalStatus = StringPool.BLANK;
		String finalMessage = StringPool.BLANK;

		// BRM Service Call
		Location areaLocation = locationLocalService.getLocationByCode(areaCode, companyId);
		Location cityLocation = locationLocalService.getLocationByCode(cityCode, companyId);
		Location stateLocation = locationLocalService.getParentLocation(cityLocation.getCode(), companyId);
		Location regionLocation = locationLocalService.getParentLocation(stateLocation.getCode(), companyId);
		Location countryLocation = locationLocalService.getParentLocation(regionLocation.getCode(), companyId);

		String area = StringBundler.concat(stateLocation.getCode(), StringPool.PIPE, cityCode, StringPool.PIPE, areaCode);

		String referenceNumber = txRefNo;
		String transactionRefNo = txRefNo;
		Contact agentContact = contactLocalService.getContact(companyId, userAgent.getScreenName());

		CustomerModifyResponse customerModifyResponse = customerModifyService.getHwayOBRMCustomerModify(accountNo, salutation, firstName, middleName, lastName, addressLine, areaLocation.getName(), area, building, street, location, pincode, cityLocation.getName(), stateLocation.getName(),
				countryLocation.getName(), mobileNo, landline, email, txRefNo, referenceNumber, transactionRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId, userAgent.getEmailAddress(), agentContact.getMobileNo(), poId, servicePoId);

		if (Validator.isNotNull(customerModifyResponse)) {

			String status = customerModifyResponse.getStatus();
			if (status.equals(StatusConstant.STATUS_SUCCESS)) {
				accountNo = customerModifyResponse.getAccountNo();

				// Customer Process
				Customer customer = saveOrUpdateCustomer(customerId, accountNo, companyId, groupId, salutation, firstName, middleName, lastName, primaryAgentScreenName, vcId, stbNo, macId, connectionType, serviceType, poId, servicePoId, stbPoId, vcPoId, macPoId, StatusConstant.ACTIVE, userAgent);
				// Customer Process

				// Contact Process
				Contact contact = saveOrUpdateContact(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, mobileNo, landline, email, userAgent);
				// Contact Process

				// Address Process
				saveOrUpdateAddress(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, countryLocation.getCode(), regionLocation.getCode(), stateLocation.getCode(), cityCode, areaCode, pincode, street, location, building, flatNo, addressLine, userAgent);
				// Address Process

				saveOrUpdateUser(userAgent.getUserId(), companyId, customer.getScreenName(), contact.getEmail(), customer.getSalutation(), customer.getFirstName(), customer.getMiddleName(), customer.getLastName(), serviceContext);

				finalStatus = "SUCCESS";
				finalMessage = "customer-data-update";

			} else {
				String errorCode = customerModifyResponse.getErrorCode();
				String errorDesc = customerModifyResponse.getErrorDescr();
				String message = errorCode.concat(" : ").concat(errorDesc);
				finalStatus = "FAIL";
				finalMessage = message;
			}
		} else {
			finalStatus = "FAIL";
			finalMessage = "customer-create-service-error";
		}
		return getMap(finalStatus, finalMessage);
	}

	@Override
	public Map<String, String> createCustomer(String vcId, String stbNo, String macId, String connectionType, String serviceType, String customerId, String salutation, String firstName, String middleName, String lastName, String addressLine, String street, String location, String building,
			String flatNo, String mobileNo, String landline, String email, String cityCode, String areaCode, String pincode, String planId, String txRefNo, User userAgent, long companyId, long groupId, ServiceContext serviceContext)
			throws NoSuchAgentException, NoSuchLocationException, NoSuchPlanException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, PortalException {
		LOGGER.info("CustomerServiceImpl::createCustomer");
		Locale locale = serviceContext.getLocale();
		Agent agent = agentLocalService.getAgent(companyId, userAgent.getScreenName());
		String primaryAgentScreenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());

		String finalStatus = StringPool.BLANK;
		String finalMessage = StringPool.BLANK;

		if (customerPlanService.isAgentBalanceBlockOrInsufficentAmount(userAgent.getScreenName(), companyId)) {

			// BRM Service Call
			Location areaLocation = locationLocalService.getLocationByCode(areaCode, companyId);
			Location cityLocation = locationLocalService.getLocationByCode(cityCode, companyId);
			Location stateLocation = locationLocalService.getParentLocation(cityLocation.getCode(), companyId);
			Location regionLocation = locationLocalService.getParentLocation(stateLocation.getCode(), companyId);
			Location countryLocation = locationLocalService.getParentLocation(regionLocation.getCode(), companyId);

			String area = StringBundler.concat(stateLocation.getCode(), StringPool.PIPE, cityCode, StringPool.PIPE, areaCode);
			String deviceId = Validator.isNotNull(stbNo) ? stbNo : macId;

			String referenceNumber = txRefNo;
			String transactionRefNo = txRefNo;

			Plan plan = planLocalService.getPlan(GetterUtil.get(planId, 0L), companyId);
			String planName = plan.getName();
			CustomerCreateResponse customerCreateResponse = customerCreateService.getHwayOBRMCustomerCreate(salutation, firstName, middleName, lastName, addressLine, areaLocation.getName(), area, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, pincode, cityLocation.getName(),
					stateLocation.getName(), countryLocation.getName(), regionLocation.getCode(), deviceId, vcId, primaryAgentScreenName, mobileNo, email, planName, txRefNo, referenceNumber, transactionRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);

			if (Validator.isNotNull(customerCreateResponse)) {

				String status = customerCreateResponse.getStatus();
				if (status.equals(StatusConstant.STATUS_SUCCESS)) {
					String accountNo = customerCreateResponse.getAccountNo();
					String poId = customerCreateResponse.getPoId().get("object_id");
					ActiveService activeService = customerCreateResponse.getServiceInfo().getServices().get(0);
					String serviceStatus = activeService.getStatus(); // 10100
					List<ActiveDevices> activeDeviceses = activeService.getDevices();
					String stbPoId = StringPool.BLANK;
					String vcPoId = StringPool.BLANK;
					String macPoId = StringPool.BLANK;
					for (ActiveDevices activeDevices : activeDeviceses) {
						if (Validator.isNotNull(activeDevices.getStbId())) {
							stbPoId = activeDevices.getDeviceObj().get("object_id");
						} else if (Validator.isNotNull(activeDevices.getVcId())) {
							vcPoId = activeDevices.getDeviceObj().get("object_id");
						}
					}
					String servicePoId = activeService.getPoId().get("object_id");
					// BRM Service Call

					// Customer Process
					Customer customer = saveOrUpdateCustomer(customerId, accountNo, companyId, groupId, salutation, firstName, middleName, lastName, primaryAgentScreenName, vcId, stbNo, macId, connectionType, serviceType, poId, servicePoId, stbPoId, vcPoId, macPoId,
							StatusConstant.getServiceStatus(serviceStatus), userAgent);
					// Customer Process

					// Contact Process
					Contact contact = saveOrUpdateContact(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, mobileNo, landline, email, userAgent);
					// Contact Process

					// Address Process
					Address address = saveOrUpdateAddress(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, countryLocation.getCode(), regionLocation.getCode(), stateLocation.getCode(), cityCode, areaCode, pincode, street, location, building, flatNo, addressLine, userAgent);

					// Address Process
					saveOrUpdateUser(userAgent.getUserId(), companyId, customer.getScreenName(), contact.getEmail(), customer.getSalutation(), customer.getFirstName(), customer.getMiddleName(), customer.getLastName(), serviceContext);
					// Customer Details update and User Creation

					// Plan Add activate mode
					List<CP> customerPlans = new ArrayList<CP>();
					List<String> successPlans = new ArrayList<String>();
					List<String> errorPlans = new ArrayList<String>();
					boolean autoRenew = customerPlanService.isAutoRenew(agent, customer);

					Date currentTime = new Date();
					Date endTime = customerPlanService.getEndTime(customerPlanUtil.getEndDate(currentTime), customer, companyId);

					CP cutomerPlan = customerPlanService.saveOrUpdateCustomerPlan(customerPlans, GetterUtil.get(planId, 0L), groupId, companyId, customer, userAgent, address, successPlans, errorPlans, autoRenew, currentTime, endTime);
					LOGGER.info("CP : " + cutomerPlan.toString());

					String receiptNo = customerPlanUtil.getReceiptNo();

					customerPlans = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), companyId);

					List<Double> planPrice = new ArrayList<Double>();
					customerPlans = customerPlanService.activateCustomerPlans(false, customerPlans, customer, userAgent, address, receiptNo, successPlans, errorPlans, planPrice, autoRenew, currentTime, endTime);
					LOGGER.info("CPS : " + customerPlans.toString());

					if (errorPlans.size() > 0) {
						String errorPlan = errorPlans.stream().collect(Collectors.joining(StringPool.COMMA_AND_SPACE));
						finalStatus = "FAIL";
						finalMessage = LanguageUtil.format(locale, "plan-add-error", errorPlan);
					}

					if (successPlans.size() > 0) {
						double finalPrice = planPrice.stream().mapToDouble(price -> price.doubleValue()).sum();
						String successPlan = successPlans.stream().collect(Collectors.joining(StringPool.COMMA_AND_SPACE));
						finalStatus = "SUCCESS";
						finalMessage = LanguageUtil.format(locale, "plan-add-success", successPlan) + " : " + LanguageUtil.format(locale, "plan-amount-debit", finalPrice);
					}

					// Plan Add activate mode
					CustomerInfoResponse customerInfoResponse = customerInfoService.getHwayOBRMCustInfo(accountNo, txRefNo, referenceNumber, transactionRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);

					if (Validator.isNotNull(customerInfoResponse)) {
						// If and information update based on CustomerInfoResponse
						String customerInfoStatus = customerInfoResponse.getStatus();
						if (customerInfoStatus.equals(StatusConstant.SERVICE_ACTIVE)) {
							for (CP cp : customerPlans) {
								com.jio.brm.customer.info.api.Plan customerInfoPlan = customerInfoService.getHwayOBRMCustInfoPlan(customerInfoResponse, cp.getPlanCode());
								List<com.jio.brm.customer.info.api.Product> customerInfoPlanProducts = customerInfoPlan.getProducts();
								com.jio.brm.customer.info.api.Product customerInfoPlanProduct = null;
								if (!customerInfoPlanProducts.isEmpty()) {
									customerInfoPlanProduct = customerInfoPlanProducts.get(customerInfoPlanProducts.size() - 1);
								}
								if (Validator.isNotNull(customerInfoPlanProduct)) {
									cp = cpLocalService.saveOrUpdateCP(cp, customerInfoPlanProduct.getPackageId(), customerInfoPlanProduct.getPoId().get("object_id"));
									LOGGER.info("CP : " + cp.toString());
								}
							}
						} else {
							String errorCode = customerCreateResponse.getErrorCode();
							String errorDesc = customerCreateResponse.getErrorDescr();
							String message = errorCode.concat(" : ").concat(errorDesc);
							finalStatus = "FAIL";
							finalMessage = message;
						}
					} else {
						finalStatus = "FAIL";
						finalMessage = "customer-info-service-error";
					}

				} else {
					String errorCode = customerCreateResponse.getErrorCode();
					String errorDesc = customerCreateResponse.getErrorDescr();
					String message = errorCode.concat(" : ").concat(errorDesc);
					finalStatus = "FAIL";
					finalMessage = message;
				}
			} else {
				finalStatus = "FAIL";
				finalMessage = "customer-create-service-error";
			}

		}

		return getMap(finalStatus, finalMessage);
	}

	public Map<String, String> getInventoryDetail(String vcId, String stbNo, String macId, String primaryAgentScreenName, String txRefNo, User userAgent, long companyId, long groupId) {
		LOGGER.info("CustomerServiceImpl::getInventoryDetail");
		Map<String, String> map = new HashMap<String, String>();
		map.put("EXIST", String.valueOf(false));
		InventoryDetailResponse inventoryDetailResponse = null;
		if (Validator.isNotNull(vcId)) {
			inventoryDetailResponse = inventoryDetailService.getInventoryDetailVC(vcId, primaryAgentScreenName, txRefNo, vcId, vcId, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		} else if (Validator.isNotNull(stbNo)) {
			inventoryDetailResponse = inventoryDetailService.getInventoryDetailSTBMAC(stbNo, primaryAgentScreenName, txRefNo, stbNo, stbNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		} else if (Validator.isNotNull(macId)) {
			inventoryDetailResponse = inventoryDetailService.getInventoryDetailSTBMAC(macId, primaryAgentScreenName, txRefNo, macId, macId, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		}
		if (Validator.isNotNull(inventoryDetailResponse)) {
			inventoryDetailResponse.getResults().stream().findFirst().ifPresent(result -> {
				map.put("EXIST", String.valueOf(true));
				map.put("SOURCE", result.getSource());
				map.put("CATEGORY", result.getCategory());
				map.put("STATEID", result.getStateId());
				map.put("POID", result.getPoId());
				map.put("DEVICETYPE", result.getDeviceType());
				map.put("MANUFACTURER", result.getManufacturer());
			});
		}
		return map;
	}

	@Override
	public Map<String, String> pairInventoryDetail(String vcId, String stbNo, String macId, String primaryAgentScreenName, String txRefNo, User userAgent, long companyId, long groupId) {
		LOGGER.info("CustomerServiceImpl::pairInventoryDetail");
		Map<String, String> map = new HashMap<String, String>();
		boolean pair = false;
		String message = StringPool.BLANK;
		String deviceType = StringPool.BLANK;
		String devicePoId = StringPool.BLANK;
		String vcPoId = StringPool.BLANK;
		String source = StringPool.BLANK;
		String category = StringPool.BLANK;
		String connectionType = StringPool.BLANK;
		String stateId = StringPool.BLANK;
		String vcManufacture = StringPool.BLANK;
		String stbManufacture = StringPool.BLANK;
		if (Validator.isNotNull(vcId) && Validator.isNotNull(stbNo)) {
			InventoryDetailResponse inventoryDetailVCResponse = inventoryDetailService.getInventoryDetailVC(vcId, primaryAgentScreenName, txRefNo, vcId, vcId, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
			if (Validator.isNotNull(inventoryDetailVCResponse)) {
				Optional<Result> result = inventoryDetailVCResponse.getResults().stream().findFirst();
				if (result.isPresent()) {
					source = result.get().getSource();
					category = result.get().getCategory();
					stateId = result.get().getStateId();
					vcPoId = result.get().getPoId();
					deviceType = result.get().getDeviceType();
					vcManufacture = result.get().getManufacturer();
					Map<String, String> _map = validInventory("VC Id", "VC Id", stateId, source, StringPool.BLANK, StringPool.BLANK, userAgent.getScreenName());
					pair = GetterUtil.getBoolean(_map.get("PAIR"));
					message = _map.get("MESSAGE");
					if (pair) {
						InventoryDetailResponse inventoryDetailSTBResponse = inventoryDetailService.getInventoryDetailSTBMAC(stbNo, primaryAgentScreenName, txRefNo, stbNo, stbNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
						result = inventoryDetailSTBResponse.getResults().stream().findFirst();
						if (result.isPresent()) {
							source = result.get().getSource();
							category = result.get().getCategory();
							stateId = result.get().getStateId();
							connectionType = result.get().getDeviceType();
							devicePoId = result.get().getPoId();
							stbManufacture = result.get().getManufacturer();
							_map = validInventory("STB No and VC Id", "STB No", stateId, source, vcManufacture, stbManufacture, userAgent.getScreenName());
							pair = GetterUtil.getBoolean(_map.get("PAIR"));
							message = _map.get("MESSAGE");
						} else {
							message = getMessage("inventory-result-service-error", companyId);
						}
					}
				} else {
					message = getMessage("inventory-result-service-error", companyId);
				}
			} else {
				message = "inventory-detail-service-error";
			}

		} else if (Validator.isNotNull(macId)) {
			InventoryDetailResponse inventoryDetailMACResponse = inventoryDetailService.getInventoryDetailSTBMAC(macId, primaryAgentScreenName, txRefNo, macId, macId, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
			if (Validator.isNotNull(inventoryDetailMACResponse)) {
				Optional<Result> result = inventoryDetailMACResponse.getResults().stream().findFirst();
				if (result.isPresent()) {
					source = result.get().getSource();
					category = result.get().getCategory();
					stateId = result.get().getStateId();
					connectionType = result.get().getDeviceType();
					devicePoId = result.get().getPoId();
					vcManufacture = result.get().getManufacturer();
					stbManufacture = result.get().getManufacturer();
					Map<String, String> _map = validInventory("MAC Id", "MAC Id", stateId, source, StringPool.BLANK, StringPool.BLANK, userAgent.getScreenName());
					pair = GetterUtil.getBoolean(_map.get("PAIR"));
					message = _map.get("MESSAGE");
				} else {
					message = getMessage("inventory-result-service-error", companyId);
				}
			} else {
				message = "inventory-detail-service-error";
			}
		} else {
			message = "VC Id and STB No or MAC Id is required";
		}

		map.put("PAIR", String.valueOf(pair));
		map.put("STATUS", pair ? "SUCCESS" : "FAIL");
		map.put("MESSAGE", message);
		map.put("DEVICETYPE", deviceType);
		map.put("DEVICEPOID", devicePoId);
		map.put("VCPOID", vcPoId);
		map.put("SOURCE", source);
		map.put("CATEGORY", category);
		map.put("CONNECTIONTYPE", connectionType);
		return map;
	}

	public Map<String, String> getInventory(String vcId, String stbNo, String macId, String primaryAgentScreenName, String txRefNo, User userAgent, long companyId, long groupId, boolean global) {
		LOGGER.info("CustomerServiceImpl::getInventory");
		Map<String, String> map = new HashMap<String, String>();
		InventoryDetailResponse inventoryDetailResponse = null;
		String inventoryName = StringPool.BLANK;
		if (Validator.isNotNull(vcId)) {
			inventoryName = "VC Id";
			inventoryDetailResponse = inventoryDetailService.getInventoryDetailVC(vcId, primaryAgentScreenName, txRefNo, vcId, vcId, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		} else if (Validator.isNotNull(stbNo)) {
			inventoryName = "STB No";
			inventoryDetailResponse = inventoryDetailService.getInventoryDetailSTBMAC(stbNo, primaryAgentScreenName, txRefNo, stbNo, stbNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		} else if (Validator.isNotNull(macId)) {
			inventoryName = "MAC Id";
			inventoryDetailResponse = inventoryDetailService.getInventoryDetailSTBMAC(macId, primaryAgentScreenName, txRefNo, macId, macId, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		}
		if (Validator.isNotNull(inventoryDetailResponse)) {
			Optional<Result> optional = inventoryDetailResponse.getResults().stream().findFirst();
			if (optional.isPresent()) {
				Result result = optional.get();
				if (global) {
					map = getInventroyResult(result, companyId);
				} else {
					if (result.getSource().equalsIgnoreCase(primaryAgentScreenName)) {
						map = getInventroyResult(result, companyId);
					} else {
						map = getMap("FAIL", inventoryName + " mapped with your account");
					}
				}
			}
		} else {
			map = getMap("FAIL", getMessage("inventory-result-service-error", companyId));
		}

		return map;
	}

	private String getMessage(String propertyKey, long companyId) {
		return languagePropertyLocalService.getLanguagePropertyByKey(propertyKey, companyId);
	}

	private Map<String, String> getInventroyResult(Result result, long companyId) {
		LOGGER.info("CustomerServiceImpl::getInventroyResult");
		Map<String, String> map = new HashMap<String, String>();
		map.put("channelName", result.getChannelName());
		map.put("cdAdjDate", formatDate(result.getCdAdjDate(), companyId));
		map.put("licenseNo", result.getLicenseNo());
		map.put("serialNo", result.getSerialNo());
		map.put("vendorWarrantyEnd", formatDate(result.getVendorWarrantyEnd(), companyId));
		map.put("warrantyEnd", formatDate(result.getWarrantyEnd(), companyId));
		map.put("accountNo", result.getAccountNo());
		map.put("category", result.getCategory());
		map.put("company", result.getCompany());
		map.put("country", result.getCountry());
		map.put("deliveryStatus", result.getDeliveryStatus());
		map.put("deviceId", result.getDeviceId());
		map.put("deviceType", result.getDeviceType());
		map.put("manufacturer", result.getManufacturer());
		map.put("model", result.getModel());
		map.put("poId", result.getPoId());
		map.put("source", result.getSource());
		map.put("startT", formatDate(result.getStartT(), companyId));
		map.put("stateId", result.getStateId());
		map.put("validTo", formatDate(result.getValidTo(), companyId));
		map.put("STATUS", "SUCCESS");
		return map;
	}

	private String formatDate(Date date, long companyId) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(JioPropsUtil.get(ConfigConstant.DATE_PATTERN, companyId), Locale.ENGLISH);
		LocalDateTime localDateTime = Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
		return formatter.format(localDateTime);
	}

	private Map<String, String> validInventory(String inventorySuccessName, String inventoryErrorName, String stateId, String source, String vcManufacture, String stbManufacture, String screenName) {
		LOGGER.info("CustomerServiceImpl::validInventory");
		String message = StringPool.BLANK;
		boolean pair = false;
		if (source.equalsIgnoreCase(screenName)) {
			if (StatusConstant.ACTIVE.equalsIgnoreCase(stateId)) {
				pair = true;
				message = inventorySuccessName.concat(" mapped with your account");
			} else {
				message = inventoryErrorName.concat(" is already used");
			}
		} else {
			message = inventoryErrorName.concat(" is not mapped with your account");
		}
		return isSameManufacture(pair, message, inventorySuccessName, vcManufacture, stbManufacture);
	}

	private Map<String, String> isSameManufacture(boolean pair, String message, String inventoryName, String vcManufacture, String stbManufacture) {
		LOGGER.info("CustomerServiceImpl::isSameManufacture");
		Map<String, String> map = new HashMap<String, String>();
		if (pair && Validator.isNotNull(vcManufacture) && Validator.isNotNull(stbManufacture)) {
			if (vcManufacture.equalsIgnoreCase(stbManufacture)) {
				pair = true;
				message = inventoryName.concat(" mapped with your account");
			} else {
				pair = false;
				message = inventoryName.concat(" manufacture are different");
			}
		}
		map.put("MESSAGE", message);
		map.put("PAIR", String.valueOf(pair));
		return map;
	}

	@Override
	public Customer getOrCreateCustomer(String accountNo, String vcId, String deviceId, String primaryAgentScreenName, User userAgent, String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, ServiceContext serviceContext)
			throws NoSuchAgentException, NoSuchCustomerException, NoSuchLocationException, PortalException {
		LOGGER.info("CustomerServiceImpl::getOrCreateCustomer");
		if (Validator.isNotNull(vcId)) {
			InventoryDetailResponse inventoryDetailVCResponse = inventoryDetailService.getInventoryDetailVC(vcId, primaryAgentScreenName, txRefNo, referenceNumber, transactionRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
			accountNo = inventoryDetailVCResponse.getResults().get(0).getAccountNo();
		} else if (Validator.isNotNull(deviceId)) {
			InventoryDetailResponse inventoryDetailSTBMACResponse = inventoryDetailService.getInventoryDetailSTBMAC(deviceId, primaryAgentScreenName, txRefNo, referenceNumber, transactionRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
			accountNo = inventoryDetailSTBMACResponse.getResults().get(0).getAccountNo();
		}
		if (Validator.isNotNull(accountNo)) {
			return getOrCreateCustomer(accountNo, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId, serviceContext);
		} else {
			return null;
		}
	}

	@Override
	public Customer getOrCreateCustomer(String accountNo, String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, ServiceContext serviceContext)
			throws NoSuchAgentException, NoSuchCustomerException, NoSuchLocationException, PortalException {
		LOGGER.info("CustomerServiceImpl::getOrCreateCustomer");
		CustomerInfoResponse customerInfoResponse = customerInfoService.getHwayOBRMCustInfo(accountNo, txRefNo, referenceNumber, transactionRefNo, createdBy, userId, companyId, groupId);
		return getOrCreateCustomer(customerInfoResponse, accountNo, companyId, groupId, serviceContext);
	}

	protected Customer getOrCreateCustomer(CustomerInfoResponse customerInfoResponse, String accountNo, long companyId, long groupId, ServiceContext serviceContext) throws NoSuchAgentException, NoSuchCustomerException, NoSuchLocationException, PortalException {
		LOGGER.info("CustomerServiceImpl::getOrCreateCustomer");
		Customer customer = null;
		if (Validator.isNotNull(customerInfoResponse)) {

			String status = customerInfoResponse.getStatus();
			if (status.equals(StatusConstant.SERVICE_ACTIVE)) {
				accountNo = customerInfoResponse.getAccountNo();

				// String agentAccountNo = customerInfoResponse.getOrgStructure().getAccountNo();

				String poId = customerInfoResponse.getPoId().get("object_id");
				List<CustomerNameInfo> customerNameInfos = customerInfoResponse.getNameInfo();

				// String areaName = StringPool.BLANK;
				String addressLine = StringPool.BLANK;
				// String city = StringPool.BLANK;
				String email = StringPool.BLANK;
				String salutation = StringPool.BLANK;
				String firstName = StringPool.BLANK;
				String lastName = StringPool.BLANK;
				String middleName = StringPool.BLANK;
				String pincode = StringPool.BLANK;
				String mobileNo = StringPool.BLANK;
				String landline = StringPool.BLANK;
				String buildingCode = StringPool.BLANK;
				String streetName = StringPool.BLANK;
				String landmark = StringPool.BLANK;
				String buildingName = StringPool.BLANK;

				Optional<CustomerNameInfo> optionalCustomerNameInfo = customerNameInfos.stream().sorted((m1, m2) -> Integer.parseInt(m1.getElem()) - Integer.parseInt(m2.getElem())).findFirst();

				if (optionalCustomerNameInfo.isPresent()) {
					CustomerNameInfo customerNameInfo = optionalCustomerNameInfo.get();
					// areaName = customerNameInfo.getAreaName();
					addressLine = customerNameInfo.getAddress();
					// city = customerNameInfo.getCity();
					email = accountNo.concat("@denonline.com");
					firstName = customerNameInfo.getFirstName();
					salutation = customerNameInfo.getSalutation();
					lastName = customerNameInfo.getLastName();
					middleName = customerNameInfo.getMiddleName();
					pincode = customerNameInfo.getZip();
					buildingCode = customerNameInfo.getBuildingName();
					streetName = customerNameInfo.getStreetName();
					landmark = customerNameInfo.getLandmark();
					buildingName = customerNameInfo.getBuildingName();
					List<Phones> phones = customerNameInfo.getPhones();

					Optional<Phones> mobilePhone = phones.stream().filter(isPhoneType(CustomerConstant.PHONE_TYPE_MOBILE).and(validPhone())).findFirst();
					if (mobilePhone.isPresent()) {
						mobileNo = mobilePhone.get().getPhone();
					}

					Optional<Phones> landlinePhone = phones.stream().filter(isPhoneType(CustomerConstant.PHONE_TYPE_HOME).and(validPhone())).findFirst();
					if (landlinePhone.isPresent()) {
						landline = landlinePhone.get().getPhone();
					}

				}

				Services service = customerInfoResponse.getServiceInfo().getServices().get(0);
				String serviceStatus = service.getStatus(); // VC ID / Customer active or not
				String servicePoId = service.getPoId().get("object_id");
				String vcId = StringPool.BLANK;
				String stbNo = StringPool.BLANK;
				String stbPoId = StringPool.BLANK;
				String vcPoId = StringPool.BLANK;
				String macPoId = StringPool.BLANK;
				String macId = StringPool.BLANK;
				String source = StringPool.BLANK;
				String connectionType = StringPool.BLANK;
				String serviceType = JioPropsUtil.get(ConfigConstant.SERVICETYPE_CODE, companyId);
				List<Devices> devices = service.getDevices();
				if (Validator.isNotNull(devices)) {
					for (Devices device : devices) {
						if (device.getDeviceType().equalsIgnoreCase("SD") || device.getDeviceType().equalsIgnoreCase("HD")) {
							stbNo = device.getDeviceId();
							stbPoId = device.getPoId().get("object_id");
							connectionType = device.getDeviceType();
						} else if (device.getDeviceType().equalsIgnoreCase("P2")) {
							vcId = device.getDeviceId();
							vcPoId = device.getPoId().get("object_id");
						} else {
							macId = device.getDeviceId();
							macPoId = device.getPoId().get("object_id");
						}
						source = device.getSource();
					}
				}

				Location areaLocation = locationLocalService.getParentLocation(pincode, companyId);
				Location cityLocation = locationLocalService.getParentLocation(areaLocation.getCode(), companyId);
				Location stateLocation = locationLocalService.getParentLocation(cityLocation.getCode(), companyId);
				Location regionLocation = locationLocalService.getParentLocation(stateLocation.getCode(), companyId);
				Location countryLocation = locationLocalService.getParentLocation(regionLocation.getCode(), companyId);

				User userAgent = null;
				if (Validator.isNotNull(source)) {
					userAgent = userLocalService.getUserByScreenName(companyId, source);
				} else {
					customer = customerLocalService.getCustomer(accountNo, companyId);
					userAgent = userLocalService.getUserByScreenName(companyId, customer.getAgentScreenName());
				}

				String agentScreenName = userAgent.getScreenName();

				// Agent Process

				// Agent Process

				// Customer Process
				customer = saveOrUpdateCustomer(StringPool.BLANK, accountNo, companyId, groupId, salutation, firstName, middleName, lastName, agentScreenName, vcId, stbNo, macId, connectionType, serviceType, poId, servicePoId, stbPoId, vcPoId, macPoId, StatusConstant.getServiceStatus(serviceStatus),
						userAgent);
				// Customer Process

				// Contact Process
				Contact contact = saveOrUpdateContact(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, mobileNo, landline, email, userAgent);
				// Contact Process

				// Address Process
				Address address = saveOrUpdateAddress(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, countryLocation.getCode(), regionLocation.getCode(), stateLocation.getCode(), cityLocation.getCode(), areaLocation.getCode(), pincode, streetName, landmark, buildingCode,
						buildingName, addressLine, userAgent);
				// Address Process

				// User
				serviceContext.setUserId(userAgent.getUserId());
				saveOrUpdateUser(userAgent.getUserId(), companyId, customer.getScreenName(), contact.getEmail(), customer.getSalutation(), customer.getFirstName(), customer.getMiddleName(), customer.getLastName(), serviceContext);
				// User

				// Plans

				Agent agent = agentLocalService.getAgent(companyId, userAgent.getScreenName());

				Map<String, String> map = customerPlanService.getOrCreateCustomerPlans(customerInfoResponse, customer, address, agent, companyId, groupId, userAgent);
				if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
					LOGGER.info(map.get("MESSAGE"));
				} else {
					LOGGER.error(map.get("MESSAGE"));
				}
				// Plans
			} else {
				String errorCode = customerInfoResponse.getErrorCode();
				String errorDesc = customerInfoResponse.getErrorDescr();
				String message = errorCode.concat(" : ").concat(errorDesc);
				LOGGER.error(message);
			}
		} else {
			LOGGER.error("customer-info-service-error");
		}
		return customer;
	}

	/**
	 * 
	 * @param phoneType
	 * @return
	 */
	private Predicate<Phones> isPhoneType(String phoneType) {
		return phone -> phone.getType().equals(phoneType);
	}

	/**
	 * 
	 * @return
	 */
	private Predicate<Phones> validPhone() {
		return phone -> (Validator.isNotNull(phone.getPhone()) && phone.getPhone().length() >= 10);
	}

	@Override
	public Customer saveOrUpdateCustomer(long companyId, long groupId, CustomerBean customerBean, User userAgent, ServiceContext serviceContext) throws PortalException {
		LOGGER.info("CustomerServiceImpl::saveOrUpdateCustomer");
		// Customer Process
		Customer customer = saveOrUpdateCustomer(customerBean.getCustomerId(), customerBean.getAccountNo(), companyId, groupId, customerBean.getSalutation(), customerBean.getFirstName(), customerBean.getMiddleName(), customerBean.getLastName(), customerBean.getAgentScreenName(),
				customerBean.getVcId(), customerBean.getStbNo(), customerBean.getMacId(), customerBean.getConnectionType(), customerBean.getServiceType(), customerBean.getPoId(), customerBean.getServicePoId(), customerBean.getStbPoId(), customerBean.getVcPoId(), customerBean.getMacPoId(),
				StatusConstant.ACTIVE, userAgent);
		// Customer Process

		// Contact Process
		Contact contact = saveOrUpdateContact(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, customerBean.getMobileNo(), customerBean.getLandline(), customerBean.getEmail(), userAgent);
		// Contact Process

		// Address Process
		saveOrUpdateAddress(customer.getCustomerId(), customer.getScreenName(), companyId, groupId, customerBean.getCountryCode(), customerBean.getRegionCode(), customerBean.getStateCode(), customerBean.getCityCode(), customerBean.getAreaCode(), customerBean.getPincode(), customerBean.getStreet(),
				customerBean.getLocation(), customerBean.getBuilding(), customerBean.getFlatNo(), customerBean.getAddress(), userAgent);

		// Address Process
		saveOrUpdateUser(userAgent.getUserId(), companyId, customer.getScreenName(), contact.getEmail(), customer.getSalutation(), customer.getFirstName(), customer.getMiddleName(), customer.getLastName(), serviceContext);
		// Customer Details update and User Creation

		return customer;
	}

	@Override
	public Contact saveOrUpdateContact(String customerId, String screenName, long companyId, long groupId, String mobileNo, String landline, String email, User userAgent) {
		LOGGER.info("CustomerServiceImpl::saveOrUpdateContact");
		Contact contact = null;
		if (Validator.isNotNull(screenName)) {
			try {
				contact = contactLocalService.getContact(companyId, screenName);
			} catch (NoSuchContactException e) {
				LOGGER.warn("NoSuchContactException :: " + e.toString());
			}
		}

		if (Validator.isNull(contact)) {
			contact = contactLocalService.createContact(AccountUtil.getRefNo("CC"));
		}
		contact.setScreenName(screenName);
		contact.setCompanyId(companyId);
		contact.setGroupId(groupId);
		contact.setMobileNo(mobileNo);
		contact.setLandLineNo(landline);
		contact.setEmail(email);
		contact.setPrimary(true);
		contact.setCreateBy(userAgent.getScreenName());

		if (contact.isNew()) {
			contact = contactLocalService.addContact(contact);
		} else {
			contact = contactLocalService.updateContact(contact);
		}
		LOGGER.info("Contact : " + contact.toString());
		return contact;
	}

	@Override
	public Address saveOrUpdateAddress(String customerId, String screenName, long companyId, long groupId, String countryCode, String regionCode, String stateCode, String cityCode, String areaCode, String pincode, String street, String location, String building, String flatNo, String addressLine,
			User userAgent) {
		LOGGER.info("CustomerServiceImpl::saveOrUpdateAddress");
		Address address = null;
		if (Validator.isNotNull(screenName)) {
			try {
				address = addressLocalService.getAddress(companyId, screenName);
			} catch (NoSuchAddressException e) {
				LOGGER.warn("NoSuchAddressException :: " + e.toString());
			}
		}
		if (Validator.isNull(address)) {
			address = addressLocalService.createAddress(AccountUtil.getRefNo("A"));
		}
		address.setScreenName(screenName);
		address.setCompanyId(companyId);
		address.setGroupId(groupId);
		address.setCountryCode(countryCode);
		address.setRegionCode(regionCode);
		address.setStateCode(stateCode);
		address.setCityCode(cityCode);
		address.setAreaCode(areaCode);
		address.setPincode(pincode);
		address.setStreet(street);
		address.setLocation(location);
		address.setBuilding(building);
		address.setFlatNo(flatNo);
		address.setAddress(addressLine);
		address.setType("RESIDENTIAL");
		address.setCreateBy(userAgent.getScreenName());

		if (address.isNew()) {
			address = addressLocalService.addAddress(address);
		} else {
			address = addressLocalService.updateAddress(address);
		}
		LOGGER.info("Address : " + address.toString());
		return address;
	}

	@Override
	public Customer saveOrUpdateCustomer(String customerId, String accountNo, long companyId, long groupId, String salutation, String firstName, String middleName, String lastName, String agentScreenName, String vcId, String stbNo, String macId, String connectionType, String serviceType,
			String poId, String servicePoId, String stbPoId, String vcPoId, String macPoId, String status, User userAgent) {
		LOGGER.info("CustomerServiceImpl::saveOrUpdateCustomer");
		Customer customer = null;
		try {
			customer = customerLocalService.getCustomer(accountNo, companyId);
		} catch (NoSuchCustomerException e) {
			LOGGER.warn("NoSuchCustomerException :: " + e.toString());
		}
		if (Validator.isNull(customer)) {
			customer = customerLocalService.createCustomer(AccountUtil.getRefNo("C"));
		}
		customer.setSalutation(salutation);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setMiddleName(middleName);
		customer.setCompanyId(companyId);
		customer.setGroupId(groupId);
		customer.setAgentScreenName(agentScreenName);
		customer.setVcId(vcId);
		customer.setStbNo(stbNo);
		customer.setMacId(macId);
		customer.setConnectionType(connectionType);
		customer.setServiceType(serviceType);
		customer.setStatus(status); // StatusConstant.ACTIVE
		customer.setPoId(poId);
		customer.setAccountNo(accountNo);
		customer.setScreenName(accountNo);
		customer.setServicePoId(servicePoId);
		customer.setStbPoId(stbPoId);
		customer.setVcPoId(vcPoId);
		customer.setMacPoId(macPoId);
		customer.setPrimary(true);
		customer.setCreateBy(userAgent.getScreenName());

		if (customer.isNew()) {
			customer = customerLocalService.addCustomer(customer);
		} else {
			customer = customerLocalService.updateCustomer(customer);
		}
		LOGGER.info("Customer : " + customer.toString());
		return customer;
	}

	@Override
	public User saveOrUpdateUser(long creatorUserId, long companyId, String screenName, String email, String salutation, String firstName, String middleName, String lastName, ServiceContext serviceContext) throws PortalException {
		LOGGER.info("CustomerServiceImpl::saveOrUpdateUser");
		User user = null;
		try {
			if (Validator.isNotNull(screenName)) {
				user = userLocalService.getUserByScreenName(companyId, screenName);
			}
		} catch (PortalException e) {
			LOGGER.warn("PortalException :: " + e.toString());
		}
		if (Validator.isNotNull(user)) {
			// Update
			user.setFirstName(firstName);
			user.setMiddleName(middleName);
			user.setLastName(lastName);
			user = userLocalService.updateUser(user);
		} else {
			// Add
			String jobTitle = "Customer";
			long[] roles = getCustomerRoleIds(companyId);
			user = userLocalService.addUserWithWorkflow(creatorUserId, companyId, false, "test", "test", false, screenName, email, 0L, StringPool.BLANK, serviceContext.getLocale(), firstName, middleName, lastName, 0L, 0L, true, 0, 15, 1991, jobTitle, new long[] {}, new long[] {}, roles,
					new long[] {}, false, serviceContext);
		}
		LOGGER.info("User : " + user.toString());
		return user;
	}

	private long[] getCustomerRoleIds(long companyId) {
		long roleId = getCustomerRoleId(companyId);
		if (roleId != 0L) {
			return new long[] { roleId };
		}
		return new long[] {};
	}

	public long getCustomerRoleId(long companyId) {
		String name = GetterUtil.getString(JioPropsUtil.get(ConfigConstant.CUSTOMER_ROLE, companyId));
		if (Validator.isNotNull(name)) {
			try {
				Role role = roleLocalService.getRole(companyId, name);
				return role.getRoleId();
			} catch (PortalException e) {
				LOGGER.error("PortalException : " + e.toString());
			}
		}
		return 0L;
	}

	@Override
	public AgentCustomerMapping saveOrUpdateAgentCustomerMapping(String screenName, long companyId, long groupId, String agentScreenName, User userAgent) {
		LOGGER.info("CustomerServiceImpl::saveOrUpdateAgentCustomerMapping");
		AgentCustomerMapping agentCustomerMapping = null;
		if (Validator.isNotNull(screenName)) {
			try {
				agentCustomerMapping = agentCustomerMappingLocalService.findByCustomerScreenName(companyId, screenName);
			} catch (NoSuchAgentCustomerMappingException e) {
				LOGGER.warn("NoSuchAgentCustomerMappingException :: " + e.toString());
			}
		}

		if (Validator.isNull(agentCustomerMapping)) {
			agentCustomerMapping = agentCustomerMappingLocalService.createAgentCustomerMapping(String.valueOf(counterLocalService.increment(AgentCustomerMapping.class.getName())));
		}

		agentCustomerMapping.setCompanyId(companyId);
		agentCustomerMapping.setGroupId(groupId);
		agentCustomerMapping.setCustomerScreenName(screenName);
		agentCustomerMapping.setAgentScreenName(agentScreenName);
		agentCustomerMapping.setCreateBy(userAgent.getScreenName());

		if (agentCustomerMapping.isNew()) {
			agentCustomerMapping = agentCustomerMappingLocalService.addAgentCustomerMapping(agentCustomerMapping);
		} else {
			agentCustomerMapping = agentCustomerMappingLocalService.updateAgentCustomerMapping(agentCustomerMapping);
		}
		LOGGER.info("AgentCustomerMapping : " + agentCustomerMapping.toString());
		return agentCustomerMapping;
	}

	protected boolean validUser(long companyId, String screenName, String emailAddress) {
		LOGGER.info("CustomerServiceImpl::validUser");
		boolean validUser = true;
		User user = null;
		try {
			if (Validator.isNotNull(screenName)) {
				user = userLocalService.getUserByScreenName(companyId, screenName);
				if (Validator.isNotNull(user)) {
					validUser = false;
				}
			} else {
				validUser = false;
			}

		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		try {
			if (Validator.isNotNull(emailAddress)) {
				user = userLocalService.getUserByEmailAddress(companyId, emailAddress);
				if (Validator.isNotNull(user)) {
					validUser = true;
				}
			} else {
				validUser = false;
			}
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		return validUser;
	}

	@Override
	public Map<String, String> suspendCustomer(String accountNo, String screenName, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException {
		LOGGER.info("CustomerServiceImpl::suspendCustomer");
		String description = StringPool.BLANK;
		Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);
		if (Validator.isNotNull(reasonKey)) {
			reasonValue = ConvertUtil.getValueFromKeyPropertyJsonObjectValue("customer.suspend.reason", companyId, reasonKey);
			description = "SUSPEND : " + reasonKey + " : " + reasonValue;
		} else if (Validator.isNotNull(reasonValue)) {
			description = "SUSPEND : " + reasonValue;
		} else {
			description = "SUSPEND : OTHER";
		}
		return suspendCustomer(description, customer, txRefNo, userAgent, companyId, groupId);
	}

	protected Map<String, String> suspendCustomer(String description, Customer customer, String txRefNo, User userAgent, long companyId, long groupId) {
		LOGGER.info("CustomerServiceImpl::suspendCustomer");
		SuspendActionResponse suspendActionResponse = suspendActionService.getHwayOBRMSespendService(description, customer.getPoId(), customer.getServicePoId(), txRefNo, customer.getCustomerId(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		if (Validator.isNotNull(suspendActionResponse)) {
			String status = suspendActionResponse.getStatus();
			if (status.equals(StatusConstant.STATUS_SUCCESS)) {
				customer.setStatus(StatusConstant.SUSPEND); // Suspend
				customer.setRemark(description);
				customerLocalService.updateCustomer(customer);
				return getMap("SUCCESS", suspendActionResponse.getDescr());
			} else {
				String errorMessage = suspendActionResponse.getErrorCode() + " : " + suspendActionResponse.getErrorDescr();
				return getMap("FAIL", errorMessage);
			}
		} else {
			return getMap("FAIL", "suspend-action-service-error");
		}
	}

	@Override
	public Map<String, String> reactiveCustomer(String accountNo, String screenName, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException {
		LOGGER.info("CustomerServiceImpl::reactiveCustomer");
		String description = StringPool.BLANK;
		Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);
		if (Validator.isNotNull(reasonKey)) {
			reasonValue = ConvertUtil.getValueFromKeyPropertyJsonObjectValue("customer.reactive.reason", companyId, reasonKey);
			description = "REACTIVE : " + reasonKey + " : " + reasonValue;
		} else if (Validator.isNotNull(reasonValue)) {
			description = "REACTIVE : " + reasonValue;
		} else {
			description = "REACTIVE : OTHER";
		}
		return reactiveCustomer(description, customer, txRefNo, userAgent, companyId, groupId);
	}

	protected Map<String, String> reactiveCustomer(String description, Customer customer, String txRefNo, User userAgent, long companyId, long groupId) {
		LOGGER.info("CustomerServiceImpl::reactiveCustomer");
		ReactiveActionResponse reactiveActionResponse = reactiveActionService.getHwayOBRMActiveService(description, customer.getPoId(), customer.getServicePoId(), txRefNo, customer.getCustomerId(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);

		if (Validator.isNotNull(reactiveActionResponse)) {
			String status = reactiveActionResponse.getStatus();
			if (status.equals(StatusConstant.STATUS_SUCCESS)) {
				customer.setStatus(StatusConstant.ACTIVE); // Active
				customer.setRemark(description);
				customerLocalService.updateCustomer(customer);
				return getMap("SUCCESS", reactiveActionResponse.getDescr());
			} else {
				String errorMessage = reactiveActionResponse.getErrorCode() + " : " + reactiveActionResponse.getErrorDescr();
				return getMap("FAIL", errorMessage);
			}
		} else {
			return getMap("FAIL", "reactive-action-service-error");
		}
	}

	@Override
	public Map<String, String> terminateCustomer(String accountNo, String screenName, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException, PortalException {
		LOGGER.info("CustomerServiceImpl::terminateCustomer");
		String description = StringPool.BLANK;
		Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);
		if (Validator.isNotNull(reasonKey)) {
			reasonValue = ConvertUtil.getValueFromKeyPropertyJsonObjectValue("customer.terminate.reason", companyId, reasonKey);
			description = "TERMIANTE : " + reasonKey + " : " + reasonValue;
		} else if (Validator.isNotNull(reasonValue)) {
			description = "TERMIANTE : " + reasonValue;
		} else {
			description = "TERMIANTE : OTHER";
		}
		return terminateCustomer(description, customer, txRefNo, userAgent, companyId, groupId);
	}

	protected Map<String, String> terminateCustomer(String description, Customer customer, String txRefNo, User userAgent, long companyId, long groupId) throws PortalException {
		LOGGER.info("CustomerServiceImpl::terminateCustomer");
		TerminateActionResponse terminateActionResponse = terminateActionService.getHwayOBRMTerminateService(description, customer.getPoId(), customer.getServicePoId(), txRefNo, customer.getCustomerId(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		if (Validator.isNotNull(terminateActionResponse)) {
			String status = terminateActionResponse.getStatus();
			if (status.equals(StatusConstant.STATUS_SUCCESS)) {
				customer.setStatus(StatusConstant.TERMINATE); // Termiante
				customer.setRemark(description);
				customerLocalService.updateCustomer(customer);
				User user = userLocalService.getUserByScreenName(companyId, customer.getScreenName());
				userLocalService.updateStatus(user.getUserId(), WorkflowConstants.STATUS_INACTIVE, new ServiceContext());
				return getMap("SUCCESS", terminateActionResponse.getDescr());
			} else {
				String errorMessage = terminateActionResponse.getErrorCode() + " : " + terminateActionResponse.getErrorDescr();
				return getMap("FAIL", errorMessage);
			}
		} else {
			return getMap("FAIL", "termiante-action-service-error");
		}
	}

	@Override
	public Map<String, String> swapVCCustomer(String accountNo, String screenName, String newVcId, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException, NoSuchAgentException {
		LOGGER.info("CustomerServiceImpl::swapVCCustomer");
		String description = StringPool.BLANK;
		Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);
		if (Validator.isNotNull(reasonKey)) {
			reasonValue = ConvertUtil.getValueFromKeyPropertyJsonObjectValue("swap.vc.reason", companyId, reasonKey);
			description = "SWAP VC : " + reasonKey + " : " + reasonValue;
		} else if (Validator.isNotNull(reasonValue)) {
			description = "SWAP VC : " + reasonValue;
		} else {
			description = "SWAP VC : OTHER";
		}
		return swapVCCustomer(description, customer, newVcId, txRefNo, userAgent, companyId, groupId);
	}

	protected Map<String, String> validSwap(String vcId, String stbNo, String macId, String newVcId, String newStbNo, String newMacId, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchAgentException {
		LOGGER.info("CustomerServiceImpl::validSwap");
		Map<String, String> map = new HashMap<String, String>();
		String primaryAgentScreenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());
		if (Validator.isNotNull(vcId) && Validator.isNotNull(newVcId)) {
			Map<String, String> oldMap = getInventoryDetail(vcId, StringPool.BLANK, StringPool.BLANK, primaryAgentScreenName, txRefNo, userAgent, companyId, groupId);
			Map<String, String> newMap = getInventoryDetail(newVcId, StringPool.BLANK, StringPool.BLANK, primaryAgentScreenName, txRefNo, userAgent, companyId, groupId);
			if (GetterUtil.getBoolean(oldMap.get("EXIST")) && GetterUtil.getBoolean(newMap.get("EXIST"))) {
				map = validInventory("Old VC Id", "New VC Id", newMap.get("STATEID"), newMap.get("SOURCE"), oldMap.get("MANUFACTURER"), newMap.get("MANUFACTURER"), userAgent.getScreenName());
			}
		} else if (Validator.isNotNull(stbNo) && Validator.isNotNull(newStbNo)) {
			Map<String, String> oldMap = getInventoryDetail(StringPool.BLANK, stbNo, StringPool.BLANK, primaryAgentScreenName, txRefNo, userAgent, companyId, groupId);
			Map<String, String> newMap = getInventoryDetail(StringPool.BLANK, newStbNo, StringPool.BLANK, primaryAgentScreenName, txRefNo, userAgent, companyId, groupId);
			if (GetterUtil.getBoolean(oldMap.get("EXIST")) && GetterUtil.getBoolean(newMap.get("EXIST"))) {
				map = validInventory("Old STB No", "New STB No", newMap.get("STATEID"), newMap.get("SOURCE"), oldMap.get("MANUFACTURER"), newMap.get("MANUFACTURER"), userAgent.getScreenName());
			}
		} else if (Validator.isNotNull(macId) && Validator.isNotNull(newMacId)) {
			Map<String, String> oldMap = getInventoryDetail(StringPool.BLANK, StringPool.BLANK, macId, primaryAgentScreenName, txRefNo, userAgent, companyId, groupId);
			Map<String, String> newMap = getInventoryDetail(StringPool.BLANK, StringPool.BLANK, newMacId, primaryAgentScreenName, txRefNo, userAgent, companyId, groupId);
			if (GetterUtil.getBoolean(oldMap.get("EXIST")) && GetterUtil.getBoolean(newMap.get("EXIST"))) {
				map = validInventory("Old MAC Id", "New MAC Id", newMap.get("STATEID"), newMap.get("SOURCE"), oldMap.get("MANUFACTURER"), newMap.get("MANUFACTURER"), userAgent.getScreenName());
			}
		}
		return map;
	}

	protected Map<String, String> swapVCCustomer(String description, Customer customer, String newVcId, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchAgentException {
		LOGGER.info("CustomerServiceImpl::swapVCCustomer");
		Map<String, String> map = validSwap(customer.getVcId(), StringPool.BLANK, StringPool.BLANK, newVcId, StringPool.BLANK, StringPool.BLANK, txRefNo, userAgent, companyId, groupId);
		if (GetterUtil.getBoolean(map.get("PAIR"))) {
			SwapActionResponse swapActionResponse = swapActionService.getHwayOBRMSwapVcAction(customer.getPoId(), customer.getVcId(), newVcId, txRefNo, customer.getCustomerId(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
			if (Validator.isNotNull(swapActionResponse)) {
				String status = swapActionResponse.getStatus();
				if (status.equals(StatusConstant.STATUS_SUCCESS)) {
					customer.setStbNo(swapActionResponse.getNewValue());
					customer.setRemark(description);
					customerLocalService.updateCustomer(customer);
					return getMap("SUCCESS", "swap-vc-action-service-success");
				} else {
					String errorMessage = swapActionResponse.getErrorCode() + " : " + swapActionResponse.getErrorDescr();
					return getMap("FAIL", errorMessage);
				}
			} else {
				return getMap("FAIL", "swap-vc-action-service-error");
			}
		} else {
			return getMap("FAIL", map.get("MESSAGE"));
		}
	}

	@Override
	public Map<String, String> swapStbCustomer(String accountNo, String screenName, String newStbNo, String reasonKey, String reasonValue, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException, NoSuchAgentException {
		LOGGER.info("CustomerServiceImpl::swapStbCustomer");
		String description = StringPool.BLANK;
		Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);
		if (Validator.isNotNull(reasonKey)) {
			reasonValue = ConvertUtil.getValueFromKeyPropertyJsonObjectValue("swap.stb.reason", companyId, reasonKey);
			description = "SWAP STB : " + reasonKey + " : " + reasonValue;
		} else if (Validator.isNotNull(reasonValue)) {
			description = "SWAP STB : " + reasonValue;
		} else {
			description = "SWAP STB : OTHER";
		}
		return swapStbCustomer(description, customer, newStbNo, txRefNo, userAgent, companyId, groupId);
	}

	protected Map<String, String> swapStbCustomer(String description, Customer customer, String newStbNo, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchAgentException {
		LOGGER.info("CustomerServiceImpl::swapStbCustomer");
		Map<String, String> map = validSwap(StringPool.BLANK, customer.getStbNo(), StringPool.BLANK, StringPool.BLANK, newStbNo, StringPool.BLANK, txRefNo, userAgent, companyId, groupId);
		if (GetterUtil.getBoolean(map.get("PAIR"))) {
			SwapActionResponse swapActionResponse = swapActionService.getHwayOBRMSwapStbAction(customer.getPoId(), customer.getStbNo(), newStbNo, txRefNo, customer.getCustomerId(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
			if (Validator.isNotNull(swapActionResponse)) {
				String status = swapActionResponse.getStatus();
				if (status.equals(StatusConstant.STATUS_SUCCESS)) {
					customer.setStbNo(swapActionResponse.getNewValue());
					if (swapActionResponse.getDeviceType().equalsIgnoreCase("SD") || swapActionResponse.getDeviceType().equalsIgnoreCase("HD")) {
						customer.setConnectionType(swapActionResponse.getDeviceType());
					}
					customer.setRemark(description);
					customerLocalService.updateCustomer(customer);
					return getMap("SUCCESS", "swap-stb-action-service-success");
				} else {
					String errorMessage = swapActionResponse.getErrorCode() + " : " + swapActionResponse.getErrorDescr();
					return getMap("FAIL", errorMessage);
				}
			} else {
				return getMap("FAIL", "swap-stb-action-service-error");
			}
		} else {
			return getMap("FAIL", map.get("MESSAGE"));
		}
	}

	@Override
	public Map<String, String> retractCustomer(String accountNo, String screenName, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException {
		LOGGER.info("CustomerServiceImpl::retractCustomer");
		Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);
		RetractActionResponse retractActionResponse = retractActionService.getHwayOBRMRetractServiceByVC(customer.getPoId(), customer.getServicePoId(), customer.getVcId(), txRefNo, customer.getCustomerId(), txRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		if (Validator.isNotNull(retractActionResponse)) {
			String status = retractActionResponse.getStatus();
			if (status.equals(StatusConstant.STATUS_SUCCESS)) {
				String orderId = retractActionResponse.getOrderId();
				String successMessage = "Retract Service : " + orderId + " for Customer Account : " + customer.getAccountNo();
				return getMap("SUCCESS", successMessage);
			} else {
				String errorMessage = retractActionResponse.getErrorCode() + " : " + retractActionResponse.getErrorDescr();
				return getMap("FAIL", errorMessage);
			}
		} else {
			return getMap("FAIL", "retract-action-service-error");
		}
	}

	/**
	 * 
	 * @param status
	 * @param message
	 * @return
	 */
	public Map<String, String> getMap(String status, String message) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("STATUS", status);
		map.put("MESSAGE", message);
		if (status.equalsIgnoreCase("FAIL")) {
			LOGGER.error(message);
		}
		return map;
	}

	private static final Log LOGGER = LogFactoryUtil.getLog(CustomerServiceImpl.class);

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private SuspendActionService suspendActionService;

	@Reference
	private ReactiveActionService reactiveActionService;

	@Reference
	private TerminateActionService terminateActionService;

	@Reference
	private RetractActionService retractActionService;

	@Reference
	private SwapActionService swapActionService;

	@Reference
	private CounterLocalService counterLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private AgentCustomerMappingLocalService agentCustomerMappingLocalService;

	@Reference
	private CustomerCreateService customerCreateService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private InventoryDetailService inventoryDetailService;

	@Reference
	private CustomerInfoService customerInfoService;

	@Reference
	private CustomerModifyService customerModifyService;

	@Reference
	private AgentService agentService;

	@Reference
	private RoleLocalService roleLocalService;

	@Reference
	private LanguagePropertyLocalService languagePropertyLocalService;
}
