package com.jio.customer.util;

import com.jio.config.props.util.JioPropsUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

public class ConvertUtil {

	private static final Log LOGGER = LogFactoryUtil.getLog(ConvertUtil.class);

	public static Map<String, String> getMapFromKeyPropertyJsonObjectValue(String keyProperty, long companyId) {
		String reasons = JioPropsUtil.get(keyProperty, companyId);
		Map<String, String> map = null;
		try {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject(reasons);
			map = jsonObjectToMap(jsonObject);
		} catch (JSONException e) {
			LOGGER.error("JSONException : " + e.toString());
		}
		return map;
	}

	public static JSONArray getJsonArrayFromKeyPropertyJsonObjectValue(String keyProperty, long companyId) {
		String reasons = JioPropsUtil.get(keyProperty, companyId);
		JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
		try {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject(reasons);
			jsonArray = jsonObject.getJSONArray("reasons");
		} catch (JSONException e) {
			LOGGER.error("JSONException : " + e.toString());
		}
		return jsonArray;
	}

	public static Map<String, String> jsonObjectToMap(JSONObject jsonObject) {
		Map<String, String> map = new HashMap<String, String>();
		JSONArray jsonArray = jsonObject.getJSONArray("reasons");
		IntStream.range(0, jsonArray.length()).forEach(i -> {
			JSONObject _jsonObject = jsonArray.getJSONObject(i);
			String key = _jsonObject.getString("key");
			String value = _jsonObject.getString("value");
			map.put(key, value);
		});
		return map;
	}

	public static JSONArray mapToJsonArray(Map<String, String> map) {
		JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
		map.entrySet().forEach(entry -> {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("key", entry.getKey());
			jsonObject.put("value", entry.getValue());
			jsonArray.put(jsonObject);
		});
		return jsonArray;
	}

	public static String getValueFromKeyPropertyJsonObjectValue(String keyProperty, long companyId, String key) {
		String reasons = JioPropsUtil.get(keyProperty, companyId);
		String value = StringPool.BLANK;
		try {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject(reasons);
			JSONArray jsonArray = jsonObject.getJSONArray("reasons");
			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject _jsonObject = jsonArray.getJSONObject(i);
				if (key.equalsIgnoreCase(_jsonObject.getString("key"))) {
					value = _jsonObject.getString("value");
					break;
				}
			}
		} catch (JSONException e) {
			LOGGER.error("JSONException : " + e.toString());
		}
		return value;
	}

}
