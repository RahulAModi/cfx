package com.jio.customer.constant;

public class CustomerConstant {

	public static final String PHONE_TYPE_HOME = "1";

	public static final String PHONE_TYPE_MOBILE = "5";

}
