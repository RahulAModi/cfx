package com.jio.customer.constant;

import java.util.HashMap;
import java.util.Map;

public class StatusConstant {

	public static final String STATUS_SUCCESS = "0";

	public static final String STATUS_ERROR = "1";

	public static final String ACTIVE = "1";

	public static final String SUSPEND = "2";

	public static final String TERMINATE = "3";

	public static final String DISCONNECT = "4";

	public static final String CANCEL = "5";

	public static final String DEACTIVATED = "6";

	public static final String SERVICE_ACTIVE = "10100";

	public static final String SERVICE_SUSPEND = "10102";

	public static final String SERVICE_INACTIVE = "10103";

	public static final String ACTIVE_LABEL = "ACTIVE";

	public static final String SUSPEND_LABEL = "INACTIVE";

	public static final String TERMINATE_LABEL = "TERMINATE";

	public static final String CANCEL_LABEL = "CANCEL";

	public static String getServiceStatus(String label) {
		if (label.equals(SERVICE_ACTIVE)) {
			return ACTIVE;
		} else if (label.equals(SERVICE_SUSPEND)) {
			return SUSPEND;
		} else if (label.equals(SERVICE_INACTIVE)) {
			return TERMINATE;
		}
		return ACTIVE;
	}

	public static Map<String, String> getCustomerStatusCssClasses() {
		Map<String, String> map = new HashMap<String, String>();
		map.put(ACTIVE, getStatusCssClass(ACTIVE));
		map.put(TERMINATE, getStatusCssClass(TERMINATE));
		map.put(SUSPEND, getStatusCssClass(SUSPEND));
		map.put(CANCEL, getStatusCssClass(CANCEL));
		return map;
	}

	public static Map<String, String> getCustomerStatuses() {
		Map<String, String> map = new HashMap<String, String>();
		map.put(ACTIVE, ACTIVE_LABEL);
		map.put(SUSPEND, SUSPEND_LABEL);
		map.put(TERMINATE, TERMINATE_LABEL);
		map.put(CANCEL, CANCEL_LABEL);
		return map;
	}

	public static String getStatusCssClass(String status) {
		if (status.equals(ACTIVE)) {
			return "success";
		} else if (status.equals(SUSPEND)) {
			return "warning";
		} else if (status.equals(TERMINATE)) {
			return "danger";
		}
		return "dark";
	}

	public static String getStatusLabel(String status) {
		if (status.equals(ACTIVE)) {
			return ACTIVE_LABEL;
		} else if (status.equals(SUSPEND)) {
			return SUSPEND_LABEL;
		} else if (status.equals(TERMINATE)) {
			return TERMINATE_LABEL;
		}
		return CANCEL_LABEL;
	}

}
