package com.jio.account.change.password.constants;

/**
 * MVC Command name constants.
 * 
 * @author liferay
 *
 */
public class MVCCommandNames {

	public static final String SAVE_CHANGE_PASSWORD = "/account/save_change_password";

}
