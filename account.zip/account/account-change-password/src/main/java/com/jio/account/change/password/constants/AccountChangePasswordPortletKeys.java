package com.jio.account.change.password.constants;

/**
 * @author Vishal7.Shah
 */
public class AccountChangePasswordPortletKeys {

	public static final String PORTLET_NAME = "com_jio_account_change_password_portlet_AccountChangePasswordPortlet";

}