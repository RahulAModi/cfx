/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.account.change.password.portlet.action;

import com.jio.account.change.password.constants.AccountChangePasswordPortletKeys;
import com.jio.account.change.password.constants.MVCCommandNames;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.CompanyConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + AccountChangePasswordPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_CHANGE_PASSWORD }, service = MVCActionCommand.class)
public class SaveChangePasswordMVCActionCommand extends BaseMVCActionCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(SaveChangePasswordMVCActionCommand.class);

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		Company company = PortalUtil.getCompany(actionRequest);
		long companyId = PortalUtil.getCompanyId(actionRequest);
		String password = ParamUtil.getString(actionRequest, "password");
		String password1 = ParamUtil.getString(actionRequest, "password1");
		String password2 = ParamUtil.getString(actionRequest, "password2");

		try {
			User user = PortalUtil.getUser(actionRequest);

			String authType = company.getAuthType();
			String login = StringPool.BLANK;
			if (authType.equals(CompanyConstants.AUTH_TYPE_EA)) {
				login = user.getEmailAddress();
			} else if (authType.equals(CompanyConstants.AUTH_TYPE_SN)) {
				login = user.getScreenName();
			} else if (authType.equals(CompanyConstants.AUTH_TYPE_ID)) {
				login = String.valueOf(user.getUserId());
			}
			String error = StringPool.BLANK;
			try {
				long userId = userLocalService.authenticateForBasic(companyId, authType, login, password);
				if (user.getUserId() != userId) {
					error = "invalid-current-password";
				} else if (!password1.equals(password2)) {
					error = "new-password-not-match";
				}
			} catch (PortalException e) {
				LOGGER.error("PortalException : " + e.toString());
				actionRequest.setAttribute("errorMessage", e.getMessage());
				error = "invalid-current-password-validate";
			}

			if (Validator.isNull(error)) {
				try {
					user = userLocalService.updatePassword(user.getUserId(), password1, password2, false);
					SessionMessages.add(actionRequest, "new-password-update");
				} catch (PortalException e) {
					LOGGER.error("PortalException : " + e.toString());
					actionRequest.setAttribute("errorMessage", e.getMessage());
					error = "invalid-new-password-validate-update";
				}
			}

			if (Validator.isNotNull(error)) {
				SessionErrors.add(actionRequest, error);
			}
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		hideDefaultErrorMessage(actionRequest);
		hideDefaultSuccessMessage(actionRequest);
	}

	@Reference
	UserLocalService userLocalService;

}