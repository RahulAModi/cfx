package com.jio.account.util;

import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;

import java.util.Calendar;
import java.util.List;
import java.util.function.Predicate;

/**
 * @author Vishal7.Shah
 */
public class AccountUtil {

	public static boolean isAdmin(long userId) {
		try {
			User user = UserLocalServiceUtil.getUser(userId);
			return isAdmin(user);
		} catch (PortalException e) {
		}
		return Boolean.FALSE;
	}

	public static boolean isNotAdmin(long userId) {
		return !isAdmin(userId);
	}

	public static boolean isAdmin(String screenName, String companyId) {
		try {
			User user = UserLocalServiceUtil.getUserByScreenName(GetterUtil.get(companyId, 0L), screenName);
			return isAdmin(user);
		} catch (PortalException e) {
		}
		return Boolean.FALSE;
	}

	public static boolean isNotAdmin(String screenName, String companyId) {
		return !isAdmin(screenName, companyId);
	}

	public static boolean isAdmin(User user) {
		return isAdmin(user.getRoles(), user.getCompanyId());
	}

	public static boolean isNotAdmin(User user) {
		return !isAdmin(user);
	}

	public static boolean isAdmin(List<Role> roles, long companyId) {
		Predicate<Role> predicate = role -> (role.getName().equals("Administrator") || role.getName().equalsIgnoreCase(JioPropsUtil.get(ConfigConstant.ADMIN_ROLE, companyId)));
		return roles.stream().filter(predicate).findAny().isPresent();
	}

	public static boolean isAgent(List<Role> roles, long companyId) {
		Predicate<Role> predicate = role -> role.getName().equals(JioPropsUtil.get(ConfigConstant.AGENT_ROLE, companyId));
		return roles.stream().filter(predicate).findAny().isPresent();
	}

	public static boolean isCustomer(List<Role> roles, long companyId) {
		Predicate<Role> predicate = role -> role.getName().equals(JioPropsUtil.get(ConfigConstant.CUSTOMER_ROLE, companyId));
		return roles.stream().filter(predicate).findAny().isPresent();
	}

	public static String getRefNo(String code) {
		Calendar calendar = Calendar.getInstance();
		long milliSecond = calendar.getTimeInMillis();
		return String.valueOf(milliSecond).concat(code).concat(getNode());
	}

	public static String getTxRefNo() {
		Calendar calendar = Calendar.getInstance();
		long milliSecond = calendar.getTimeInMillis();
		return String.valueOf(milliSecond).concat(getNode());
	}

	public static String getNode() {
		return GetterUtil.getString(PropsUtil.get(SERVER_NODE), "N");
	}

	private static final String SERVER_NODE = "server.node";

}