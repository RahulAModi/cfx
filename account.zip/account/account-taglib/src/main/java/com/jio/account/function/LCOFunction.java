package com.jio.account.function;

import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Agent;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentCustomerMappingLocalServiceUtil;
import com.jio.account.service.AgentLocalServiceUtil;
import com.jio.account.service.ContactLocalServiceUtil;
import com.jio.account.service.CustomerLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

public class LCOFunction {

	private static final Log LOGGER = LogFactoryUtil.getLog(LCOFunction.class);

	public static Agent getAgentByScreenName(String companyId, String screenName) {

		if (Validator.isNotNull(companyId) && Validator.isNotNull(screenName)) {
			try {
				return AgentLocalServiceUtil.getAgent(GetterUtil.get(companyId, 0L), screenName);
			} catch (NoSuchAgentException e) {
				LOGGER.error("NoSuchAgentException :: " + e.toString());
			}
		}
		return null;
	}

	public static Customer getCustomerByScreenName(String companyId, String screenName) {
		if (Validator.isNotNull(companyId) && Validator.isNotNull(screenName)) {
			try {
				return CustomerLocalServiceUtil.getCustomerByScreenName(screenName, GetterUtil.get(companyId, 0L));
			} catch (NoSuchCustomerException e) {
				LOGGER.error("NoSuchCustomerException :: " + e.toString());
			}
		}
		return null;
	}

	public static Customer getCustomerByAccountNo(String companyId, String accountNo) {

		if (Validator.isNotNull(companyId) && Validator.isNotNull(accountNo)) {
			try {
				return CustomerLocalServiceUtil.getCustomer(accountNo, GetterUtil.get(companyId, 0L));
			} catch (NoSuchCustomerException e) {
				LOGGER.error("NoSuchCustomerException :: " + e.toString());
			}
		}
		return null;
	}

	public static User getUserByScreenName(String companyId, String screenName) {

		if (Validator.isNotNull(companyId) && Validator.isNotNull(screenName)) {
			try {
				return UserLocalServiceUtil.getUserByScreenName(GetterUtil.getLong(companyId), screenName);
			} catch (PortalException e) {
				LOGGER.error("PortalException :: " + e.toString());
			}
		}
		return null;
	}

	public static Contact getContactByScreenName(String companyId, String screenName) {

		if (Validator.isNotNull(companyId) && Validator.isNotNull(screenName)) {
			try {
				return ContactLocalServiceUtil.getContact(GetterUtil.getLong(companyId), screenName);
			} catch (NoSuchContactException e) {
				LOGGER.error("NoSuchContactException :: " + e.toString());
			}
		}
		return null;
	}

	public static User getAgentByCustomerScreenName(String strCompanyId, String customerScreenName) {

		if (Validator.isNotNull(strCompanyId) && Validator.isNotNull(customerScreenName)) {
			try {
				long companyId = GetterUtil.getLong(strCompanyId);
				AgentCustomerMapping agentCustomerMapping = AgentCustomerMappingLocalServiceUtil.findByCustomerScreenName(GetterUtil.getLong(companyId), customerScreenName);
				String agentScreenName = agentCustomerMapping.getAgentScreenName();
				return UserLocalServiceUtil.getUserByScreenName(companyId, agentScreenName);
			} catch (NoSuchAgentCustomerMappingException e) {
				LOGGER.error("NoSuchAgentCustomerMappingException :: " + e.toString());
			} catch (PortalException e) {
				LOGGER.error("PortalException : " + e.toString());
			}
		}
		return null;
	}
}
