package com.lnt.constants;

/**
 * @author Rahul
 */
public class GmapPortletKeys {

	public static final String GMAP =
		"com_lnt_GmapPortlet";

}