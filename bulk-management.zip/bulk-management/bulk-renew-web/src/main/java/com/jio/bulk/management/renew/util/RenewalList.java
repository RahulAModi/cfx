package com.jio.bulk.management.renew.util;

public class RenewalList {
	
	private long id;
	
	private String accountNo;
	
	private String vcId;
	
	private String lcoCode;
	
	private String firstName;
	
	private String lastName;
	
	private String planName;
	
	private String categoryGroupCode;
	
	private String endDate;
	
	private String cityCode;
	
	public RenewalList(long id, String accountNo, String vcId, String lcoCode, String firstName, String lastName,
			String planName, String categoryGroupCode, String endDate, String cityCode) {
		super();
		this.id = id;
		this.accountNo = accountNo;
		this.vcId = vcId;
		this.lcoCode = lcoCode;
		this.firstName = firstName;
		this.lastName = lastName;
		this.planName = planName;
		this.categoryGroupCode = categoryGroupCode;
		this.endDate = endDate;
		this.cityCode = cityCode;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getVcId() {
		return vcId;
	}

	public void setVcId(String vcId) {
		this.vcId = vcId;
	}

	public String getLcoCode() {
		return lcoCode;
	}

	public void setLcoCode(String lcoCode) {
		this.lcoCode = lcoCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getCategoryGroupCode() {
		return categoryGroupCode;
	}

	public void setCategoryGroupCode(String categoryGroupCode) {
		this.categoryGroupCode = categoryGroupCode;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	@Override
	public String toString() {
		return "BulkRenewUtility [id=" + id + ", accountNo=" + accountNo + ", vcId=" + vcId + ", lcoCode=" + lcoCode
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", planName=" + planName
				+ ", categoryGroupCode=" + categoryGroupCode + ", endDate=" + endDate + ", cityCode=" + cityCode + "]";
	}
	
	
	
	
	

}
