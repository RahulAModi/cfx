package com.jio.bulk.management.renew.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Agent;
import com.jio.account.service.AgentLocalService;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.bulk.management.renew.constants.BulkRenewalPortletKeys;
import com.jio.bulk.management.renew.constants.MVCCommandNames;
import com.jio.bulk.management.renew.util.RenewalList;
import com.jio.master.telecom.model.PlanCategoryGroup;
import com.jio.master.telecom.service.PlanCategoryGroupLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
@Component(immediate = true, property = { "javax.portlet.name=" + BulkRenewalPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class);
	
	private static final SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	private static final SimpleDateFormat dBformatter = new SimpleDateFormat("yyyy-MM-dd");
	
	@Reference
	private PlanCategoryGroupLocalService planCategoryGroupLocalService;
	
	@Reference
	private CPLocalService cpLocalService;
	
	@Reference
	private AgentLocalService agentLocalService;
	
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		List<PlanCategoryGroup> planGroupList = planCategoryGroupLocalService.getPlanCategoryGroups(themeDisplay.getCompanyId());
		renderRequest.setAttribute("planCategoryGroupList", planGroupList);
		User loggedInUser = themeDisplay.getUser();
		
		boolean fetchData = ParamUtil.getBoolean(renderRequest, "fetchData", false);
		if(fetchData) {
			Date startDate = ParamUtil.getDate(renderRequest, "startDate", formatter);
			Date endDate = ParamUtil.getDate(renderRequest, "endDate", formatter);
			
			String planCategoryGroup = ParamUtil.getString(renderRequest, "planCategoryGroup");
			String vcId = ParamUtil.getString(renderRequest, "vcId");
			boolean active = ParamUtil.getBoolean(renderRequest, "planStatus");
			
			
			
			String primaryCode = null;
			Agent agent = null;
			try {
				agent = agentLocalService.getAgent(themeDisplay.getCompanyId(), loggedInUser.getScreenName());
				if (!agent.isPrimary()) {
					agent = agentLocalService.getAgent(themeDisplay.getCompanyId(), agent.getParentCode());
				}
				primaryCode = agent.getScreenName();
			} catch (NoSuchAgentException e) {
				LOGGER.error("NoSuchAgentException :: " + e.getMessage());
			}
			
			PortletURL iteratorURL = renderResponse.createRenderURL();
			iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
			try {
				iteratorURL.setWindowState(WindowState.NORMAL);
			} catch (WindowStateException e) {
				LOGGER.error(e.toString());
			}
			
			SearchContainer<RenewalList> searchContainer = new SearchContainer<RenewalList>(renderRequest, iteratorURL, null, "there-record-found");

			List<RenewalList> dataList = null;
			int count = GetterUtil.DEFAULT_INTEGER;
			try {
					List<Object[]> list = cpLocalService.getBulkRenewalList(primaryCode, vcId, dBformatter.format(startDate),
						dBformatter.format(endDate), false, active, planCategoryGroup, searchContainer.getStart(), searchContainer.getEnd()); 
					dataList = getBulkRenewUtility(list);
					count = cpLocalService.getBulkRenewalListCount(primaryCode, vcId, dBformatter.format(startDate),
							dBformatter.format(endDate), false, active, planCategoryGroup); 
					if(list.size()>0) {
						renderRequest.setAttribute("showForm", true);
					}
			} catch (SystemException e) {
				dataList = new ArrayList<RenewalList>();
				LOGGER.error("SystemException :: " + e.toString());
			}

			searchContainer.setDeltaConfigurable(true);
			searchContainer.setTotal(count);
			searchContainer.setResults(dataList);
			renderRequest.setAttribute("searchContainer", searchContainer);
			renderRequest.setAttribute("showTable", true);
		}
		
		return "/view.jsp";
	}
	
	private List<RenewalList> getBulkRenewUtility(List<Object[]> list) {
		List<RenewalList> bulkList = new ArrayList<RenewalList>();
		Long id = null;
		String accountNo = null;
		String vcId=null;
		String lcoCode=null;
		String firstName=null;
		String lastName=null;
		String planName=null;
		String categoryGroupCode=null;
		String endDate=null;
		String cityCode=null;
		
		for(Object[] obj : list) {
			id = Long.parseLong(obj[0].toString());
			accountNo = GetterUtil.getString(obj[1], StringPool.BLANK);
			vcId = GetterUtil.getString(obj[2], StringPool.BLANK);
			lcoCode = GetterUtil.getString(obj[3], StringPool.BLANK);
			firstName = GetterUtil.getString(obj[4], StringPool.BLANK);
			lastName = GetterUtil.getString(obj[5], StringPool.BLANK);
			planName = GetterUtil.getString(obj[6], StringPool.BLANK);
			categoryGroupCode = GetterUtil.getString(obj[7], StringPool.BLANK);
			endDate = GetterUtil.getString(obj[8], StringPool.BLANK);
			cityCode = GetterUtil.getString(obj[9], StringPool.BLANK);
			
			bulkList.add(new RenewalList(id, accountNo, vcId, lcoCode, firstName, lastName, planName, categoryGroupCode, endDate, cityCode));
		}
		return bulkList;
	}

	

}