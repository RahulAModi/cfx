package com.jio.bulk.management.renew.portlet.action;

import com.jio.account.service.AgentLocalService;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.bulk.management.renew.constants.BulkRenewalPortletKeys;
import com.jio.bulk.management.renew.constants.MVCCommandNames;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkRenewalPortletKeys.PORTLET_NAME, 
		"mvc.command.name=" + MVCCommandNames.FETCH_DATA }, service = MVCActionCommand.class)

public class FetchDataMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(FetchDataMVCActionCommand.class);
	
	@Reference
	private CPLocalService cpLocalService;
	
	@Reference
	private AgentLocalService agentLocalService;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		
	}


}
