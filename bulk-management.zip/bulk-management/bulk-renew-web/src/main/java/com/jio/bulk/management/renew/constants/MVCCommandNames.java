package com.jio.bulk.management.renew.constants;

public class MVCCommandNames {

	public static final String VIEW = "/bulk-plan-renewal/view";
	
	public static final String SAVE_BULK = "/bulk-plan-renewal/save";
	
	public static final String FETCH_DATA = "/bulk-plan-renewal/fetch-data";

}
