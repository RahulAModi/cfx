package com.jio.bulk.management.renew.constants;

/**
 * @author Vinay.Kahar
 */
public class BulkRenewalPortletKeys {

	public static final String PORTLET_NAME = "com_jio_bulk_management_renew_portlet_BulkRenewalPortlet";

}