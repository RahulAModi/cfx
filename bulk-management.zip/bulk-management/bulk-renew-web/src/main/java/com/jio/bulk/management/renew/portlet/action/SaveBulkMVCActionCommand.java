package com.jio.bulk.management.renew.portlet.action;

import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.bulk.management.renew.constants.BulkRenewalPortletKeys;
import com.jio.bulk.management.renew.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkRenewalPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_BULK }, service = MVCActionCommand.class)
public class SaveBulkMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveBulkMVCActionCommand.class);

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		String[] bulkIds = ParamUtil.getStringValues(actionRequest, "bulkId");
		long companyId = PortalUtil.getCompanyId(actionRequest);
		long groupId = PortalUtil.getScopeGroupId(actionRequest);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		User userAgent = PortalUtil.getUser(actionRequest);
		String receiptNo = customerPlanUtil.getReceiptNo();
		String txRefNo = AccountUtil.getTxRefNo();
		Date currentDate = sdf.parse(sdf.format(new Date()));
		Date endDate = null;
		CP cp = null;
		String[] cpArray = null;
		for (String cpId : bulkIds) {
			cpArray = new String[1];
			cpArray[0] = cpId;

			cp = cpLocalService.getCP(cpId, companyId);
			endDate = sdf.parse((cp.getEndDate()).toString());
			if (endDate.compareTo(currentDate) == 0 || endDate.compareTo(currentDate) > 0) {
				cp.setAutoRenew(true);
				cpLocalService.updateCP(cp);
				LOGGER.info("db save Called");
			} else {
				LOGGER.info("API Called");
				customerPlanService.renewCustomerPlans(cpArray, true, cp.getAccountNo(), receiptNo, txRefNo, userAgent, companyId, groupId);
			}
		}

	}

}
