package com.jio.bulk.management.constants;

/**
 * @author Vinay.Kahar
 */
public class BulkTransactionPortletKeys {

	public static final String PORTLET_NAME = "com_jio_bulk_management_portlet_BulkTransactionPortlet";

	public static final String CONFIGURATION_NAME = "com_jio_bulk_management_configuration_TransactionConfiguration";

}