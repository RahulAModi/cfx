package com.jio.bulk.management.constants;

public class ExcelHeaderConstant {
	public static final String ACNO = "A/C No.";
	public static final String VCID = "VC ID";
	public static final String USERID = "User ID";
	public static final String PLAN_NAME = "Plan Name";
	public static final String ACTION = "Action";
	public static final String RENEWAL_FLAG = "Renewal Flag";
	public static final String STATUS = "Status";
	
	public static final String XLSX = "xlsx";
}
