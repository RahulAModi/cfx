package com.jio.bulk.management.constants;

public class MVCCommandNames {

	public static final String VIEW = "/bulk-management/view";
	
	public static final String UPLOAD_BULK = "/bulk-management/save";

	public static final String DOWNLOAD_EXCEL = "/bulk-management/download-excel";
	
	public static final String UPLOAD_BULK_RESOURCE = "/bulk-management/save-excel";

}
