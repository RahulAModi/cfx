package com.jio.bulk.management.listner.impl;

import com.jio.account.telecom.model.CP;
import com.jio.account.util.AccountUtil;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.service.ProcessLocalService;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.management.constants.ExcelHeaderConstant;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=" + ProcessConstant.BULK_CUSTOMER_PLAN_DESTINATION }, service = MessageListener.class)
public class TransactionListnerImpl implements MessageListener {

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	private void doReceive(Message msg) {
		String processId = GetterUtil.getString(msg.get("processId"));
		try {
			com.jio.background.process.model.Process process = processLocalService.getProcess(processId);
			User loggedInUser = userLocalService.getUserByScreenName(process.getCompanyId(), process.getCreateBy());
			executeTransaction(processId, process.getCompanyId(), process.getGroupId(), loggedInUser);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}
	}

	private void executeTransaction(String processId, long companyId, long groupId, User loggedInUser) {
		try {

			InputStream in = backgroundProcessUtil.getDocumentByProcessId(processId);
			Workbook workbook = null;

			String msg = StringPool.BLANK;
			String accountNo = StringPool.BLANK;
			String vcId = StringPool.BLANK;
			String userId = StringPool.BLANK;
			String planName = StringPool.BLANK;
			String action = StringPool.BLANK;
			String renewalFlag = StringPool.BLANK;
			boolean autorenew = false;
			FileOutputStream out = null;

			Workbook workbookDownload = new XSSFWorkbook();
			Sheet sheetDownload = workbookDownload.createSheet("CustomerPlan");
			int rowNumDownload = 0;

			Row rowDownload = sheetDownload.createRow(rowNumDownload++);
			Cell cellDownload;
			if (rowDownload.getRowNum() == 0) {

				cellDownload = rowDownload.createCell(0);
				cellDownload.setCellValue(ExcelHeaderConstant.ACNO);

				cellDownload = rowDownload.createCell(1);
				cellDownload.setCellValue(ExcelHeaderConstant.VCID);

				cellDownload = rowDownload.createCell(2);
				cellDownload.setCellValue(ExcelHeaderConstant.USERID);

				cellDownload = rowDownload.createCell(3);
				cellDownload.setCellValue(ExcelHeaderConstant.PLAN_NAME);

				cellDownload = rowDownload.createCell(4);
				cellDownload.setCellValue(ExcelHeaderConstant.ACTION);

				cellDownload = rowDownload.createCell(5);
				cellDownload.setCellValue(ExcelHeaderConstant.RENEWAL_FLAG);

				cellDownload = rowDownload.createCell(6);
				cellDownload.setCellValue(ExcelHeaderConstant.STATUS);

			}

			int successCount = 0;
			int errorCount = 0;

			try {
				workbook = new XSSFWorkbook(in);
				Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
				Row currentRow = null;

				Cell cell = null;
				iterator.next();
				String receiptNo = customerPlanUtil.getReceiptNo();
				String txRefNo = AccountUtil.getTxRefNo();
				while (iterator.hasNext()) {
					currentRow = iterator.next();
					if (Validator.isNotNull(currentRow.getCell(0))) {
						cell = currentRow.getCell(0);
						cell.setCellType(CellType.STRING);
						accountNo = cell.getStringCellValue();
					} else {
						accountNo = StringPool.BLANK;
					}

					if (Validator.isNotNull(currentRow.getCell(2))) {
						cell = currentRow.getCell(2);
						cell.setCellType(CellType.STRING);
						userId = cell.getStringCellValue();
					} else {
						userId = StringPool.BLANK;
					}

					// accountNo = Validator.isNotNull(currentRow.getCell(0)) ? currentRow.getCell(0).toString():StringPool.BLANK;
					vcId = Validator.isNotNull(currentRow.getCell(1)) ? currentRow.getCell(1).toString() : StringPool.BLANK;
					// userId = Validator.isNotNull(currentRow.getCell(2)) ? currentRow.getCell(2).toString():StringPool.BLANK;
					planName = Validator.isNotNull(currentRow.getCell(3)) ? currentRow.getCell(3).toString() : StringPool.BLANK;
					action = Validator.isNotNull(currentRow.getCell(4)) ? currentRow.getCell(4).toString() : StringPool.BLANK;
					renewalFlag = Validator.isNotNull(currentRow.getCell(5)) ? currentRow.getCell(5).toString() : StringPool.BLANK;

					if (renewalFlag != null && (renewalFlag.equalsIgnoreCase("Y") || renewalFlag.equalsIgnoreCase("YES"))) {
						autorenew = true;
					}

					LOGGER.info(accountNo + "=" + vcId + "=" + userId + "=" + planName + "=" + renewalFlag);

					if (currentRow.getRowNum() != 0 && !Validator.isBlank(accountNo) && !Validator.isBlank(vcId) && !Validator.isBlank(userId) && !Validator.isBlank(planName) && !Validator.isBlank(action)) {

						if (Validator.isNotNull(currentRow.getCell(4)) && (currentRow.getCell(4).toString().equalsIgnoreCase("A") || currentRow.getCell(4).toString().equalsIgnoreCase("ADD"))) {
							try {
								Map<String, String> map = customerPlanService.addCustomerPlan(StringPool.BLANK, planName, autorenew, accountNo, receiptNo, txRefNo, loggedInUser, companyId, groupId);
								msg = map.get("STATUS") + map.get("MESSAGE");
								if (map.get("STATUS").equalsIgnoreCase("FAIL")) {
									errorCount = errorCount + 1;
								} else {
									successCount = successCount + 1;
								}
							} catch (Exception e) {
								msg = "FAIL: " + e.getMessage();
								errorCount = errorCount + 1;
							}

						}

						if (Validator.isNotNull(currentRow.getCell(4)) && (currentRow.getCell(4).toString().equalsIgnoreCase("R") || currentRow.getCell(4).toString().equalsIgnoreCase("RENEW"))) {

							try {
								Map<String, String> map = customerPlanService.renewCustomerPlan(planName, StringPool.BLANK, autorenew, accountNo, receiptNo, txRefNo, loggedInUser, companyId, groupId);
								msg = map.get("STATUS") + map.get("MESSAGE");
								if (map.get("STATUS").equalsIgnoreCase("FAIL")) {
									errorCount = errorCount + 1;
								} else {
									successCount = successCount + 1;
								}
							} catch (Exception e) {
								msg = "FAIL: " + e.getMessage();
								errorCount = errorCount + 1;
							}

						}

						if (Validator.isNotNull(currentRow.getCell(4)) && currentRow.getCell(4).toString().equalsIgnoreCase("C")) {
							try {
								Map<String, String> map = customerPlanService.cancelCustomerPlan(planName, StringPool.BLANK, accountNo, receiptNo, txRefNo, loggedInUser, companyId, groupId);
								msg = map.get("STATUS") + map.get("MESSAGE");
								if (map.get("STATUS").equalsIgnoreCase("FAIL")) {
									errorCount = errorCount + 1;
								} else {
									successCount = successCount + 1;
								}
							} catch (Exception e) {
								msg = "FAIL: " + e.getMessage();
								errorCount = errorCount + 1;
							}
						}
					} else {
						msg = "FAIL: Some field is missing";
						errorCount = errorCount + 1;
					}

					rowDownload = sheetDownload.createRow(currentRow.getRowNum());
					cellDownload = rowDownload.createCell(0);
					cellDownload.setCellValue(accountNo);

					cellDownload = rowDownload.createCell(1);
					cellDownload.setCellValue(vcId);

					cellDownload = rowDownload.createCell(2);
					cellDownload.setCellValue(userId);

					cellDownload = rowDownload.createCell(3);
					cellDownload.setCellValue(planName);

					cellDownload = rowDownload.createCell(4);
					cellDownload.setCellValue(action);

					cellDownload = rowDownload.createCell(5);
					cellDownload.setCellValue(renewalFlag);

					cellDownload = rowDownload.createCell(6);
					cellDownload.setCellValue(msg);
					LOGGER.info("API Call Message" + msg);
				}

				try {
					String fileName = ProcessConstant.BULK_CUSTOMER_PLAN_STATUS.concat(processId);
					String statusFileName = fileName.concat(StringPool.PERIOD).concat(ExcelHeaderConstant.XLSX);
					File statusFile = new File(statusFileName);
					out = new FileOutputStream(statusFile);
					workbookDownload.write(out);
					out.close();
					workbookDownload.close();

					backgroundProcessUtil.getProcessIdAndUploadFile(processId, CP.class.getName(), loggedInUser.getScreenName(), statusFile, ProcessConstant.BULK_CUSTOMER_PLAN_STATUS, successCount, errorCount);

					if (statusFile.exists()) {
						statusFile.delete();
					}
				} catch (IOException e) {
					LOGGER.error("IOException :: " + e.toString());
				} finally {
					try {
						if (workbookDownload != null)
							workbookDownload.close();
					} catch (IOException e) {
					}
					try {
						if (out != null)
							out.close();
					} catch (IOException e) {
					}
				}

				workbook.close();
				in.close();

			} catch (FileNotFoundException e) {
				LOGGER.error("FileNotFoundException :: " + e.toString());
			} catch (IOException e) {
				LOGGER.error("IOException :: " + e.toString());
			} finally {
				try {
					if (workbook != null)
						workbook.close();
				} catch (IOException e) {
				}
				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
				}
			}

		} catch (Exception e1) {
			LOGGER.error("Excel import error" + e1.getMessage());
		}
	}

	private static final Log LOGGER = LogFactoryUtil.getLog(TransactionListnerImpl.class.getName());

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private ProcessLocalService processLocalService;

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;
}
