package com.jio.bulk.management.portlet.actions;

import com.jio.bulk.management.constants.BulkTransactionPortletKeys;
import com.jio.bulk.management.constants.ExcelHeaderConstant;
import com.jio.bulk.management.constants.MVCCommandNames;
import com.jio.config.props.JioPropsValues;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkTransactionPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD_EXCEL }, service = MVCResourceCommand.class)
public class DownloadExcelMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadExcelMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		boolean resource = true;
		int rowNum = 0;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Bulk Transaction");

		FileOutputStream out = null;
		InputStream in = null;

		XSSFCellStyle columnStyle = workbook.createCellStyle();
		columnStyle.setDataFormat(workbook.createDataFormat().getFormat("@"));
		sheet.setDefaultColumnStyle(0, columnStyle);
		sheet.setDefaultColumnStyle(1, columnStyle);
		sheet.setDefaultColumnStyle(2, columnStyle);
		sheet.setDefaultColumnStyle(3, columnStyle);
		sheet.setDefaultColumnStyle(4, columnStyle);
		sheet.setDefaultColumnStyle(5, columnStyle);
		sheet.setDefaultColumnStyle(6, columnStyle);

		XSSFCellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setBold(true);
		style.setFont(font);

		Row row = sheet.createRow(rowNum++);
		Cell cell;
		int colNum = 0;
		if (row.getRowNum() == 0) {

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.ACNO);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.VCID);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.USERID);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.PLAN_NAME);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.ACTION);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.RENEWAL_FLAG);
			cell.setCellStyle(style);

		}

		try {

			String fileName = "BULK_TRANSATION_UPLOAD_TEMPLATE.".concat(ExcelHeaderConstant.XLSX);
			String filePath = JioPropsValues.TEMPLATE_FOLDER_PATH;
			File file = new File(filePath + File.separator + fileName);

			// Write data to file
			out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
			workbook.close();
			// Complete writing

			// Download file
			in = new FileInputStream(file);
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, in, ContentTypes.APPLICATION_VND_MS_EXCEL);
			} catch (IOException e) {
				resource = false;
			}

			in.close();
			// Complete download
		} catch (IOException e) {
			resource = false;
		} finally {

			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}

			try {
				if (workbook != null)
					workbook.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}

			try {
				if (in != null)
					in.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}
		}

		return resource;
	}

}
