package com.jio.bulk.management.configuration;

import com.jio.bulk.management.constants.BulkTransactionPortletKeys;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author Vishal7.Shah
 *
 */
@Meta.OCD(id = BulkTransactionPortletKeys.CONFIGURATION_NAME)
public interface TransactionConfiguration {

	@Meta.AD(required = false)
	public boolean isScheduler();
	
	@Meta.AD(required = false)
	public String articleId();
}
