package com.jio.bulk.customer.constants;

/**
 * @author Rahul1.Panchivala
 */
public class BulkCustomerPortletKeys {

	public static final String PORTLET_NAME = "com_jio_bulk_customer_portlet_BulkCustomerPortlet";

	public static final String CONFIGURATION_NAME = "com_jio_bulk_customer_configuration_BulkCustomerConfiguration";
}