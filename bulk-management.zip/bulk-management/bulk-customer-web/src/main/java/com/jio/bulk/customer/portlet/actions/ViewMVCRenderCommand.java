package com.jio.bulk.customer.portlet.actions;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.bulk.customer.constants.BulkCustomerPortletKeys;
import com.jio.bulk.customer.constants.MVCCommandNames;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkCustomerPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);
		try {
			User userAgent = PortalUtil.getUser(renderRequest);
			Agent agent = agentLocalService.getAgent(companyId, userAgent.getScreenName());
			Address address = addressLocalService.getAddress(companyId, agent.getScreenName());
			List<Location> pincodes = locationLocalService.getSubChildLocations(address.getCityCode(), companyId);
			renderRequest.setAttribute("pincodes", pincodes);
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.toString());
		} catch (NoSuchAddressException e) {
			LOGGER.error("NoSuchAddressException : " + e.toString());
		} catch (NoSuchLocationException e) {
			LOGGER.error("NoSuchLocationException : " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		return "/view.jsp";
	}

	@Reference
	AgentLocalService agentLocalService;

	@Reference
	LocationLocalService locationLocalService;

	@Reference
	AddressLocalService addressLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class.getName());
}