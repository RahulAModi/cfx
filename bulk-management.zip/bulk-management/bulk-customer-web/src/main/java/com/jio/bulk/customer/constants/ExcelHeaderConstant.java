package com.jio.bulk.customer.constants;

public class ExcelHeaderConstant {

	public static final String STB_NO = "STB NO";
	public static final String VC_ID = "VC ID";
	public static final String MAC_ID = "MAC ID";
	public static final String ACCOUNT_NO = "ACCOUNT NO";
	public static final String SALUTATION = "SALUTATION";
	public static final String FIRST_NAME = "FIRST NAME";
	public static final String LAST_NAME = "LAST NAME";
	public static final String MOBILE_NUMBER = "MOBILE NUMBER";
	public static final String EMAIL_ID = "EMAIL ID";
	public static final String ADDRESS = "ADDRESS";
	public static final String BUILDING_NAME = "BUILDING NAME";
	public static final String FLAT_NO = "FLAT NO";
	public static final String PLAN_NAME = "PLAN NAME";

	public static final String STATUS = "Status";

	public final static String XLSX = "xlsx";
}
