package com.jio.bulk.customer.configuration;

import com.jio.bulk.customer.constants.BulkCustomerPortletKeys;

import aQute.bnd.annotation.metatype.Meta;

@Meta.OCD(id = BulkCustomerPortletKeys.CONFIGURATION_NAME)
public interface BulkCustomerConfiguration {

	@Meta.AD(required = false)
	public String articleId();
}
