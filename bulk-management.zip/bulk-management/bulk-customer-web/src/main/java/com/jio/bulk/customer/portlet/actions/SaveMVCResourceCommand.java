package com.jio.bulk.customer.portlet.actions;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.agent.service.AgentService;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.customer.constants.BulkCustomerPortletKeys;
import com.jio.bulk.customer.constants.ExcelHeaderConstant;
import com.jio.bulk.customer.constants.MVCCommandNames;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.service.CustomerService;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.petra.string.StringUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.KeyValuePair;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkCustomerPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.UPLOAD_SAVE }, service = MVCResourceCommand.class)
public class SaveMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveMVCResourceCommand.class);

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerService customerService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private AgentService agentService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		try {
			long groupId = PortalUtil.getScopeGroupId(resourceRequest);
			User userAgent = PortalUtil.getUser(resourceRequest);
			String lcoCode = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());

			UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(resourceRequest);
			File file = uploadRequest.getFile("file");
			String pincode = ParamUtil.getString(resourceRequest, "pincode");
			ServiceContext serviceContext = ServiceContextFactory.getInstance(resourceRequest);
			List<KeyValuePair> errorList = validateExcel(file, resourceRequest);

			if (errorList.isEmpty()) {
				String processId = readExcelAndSave(file, companyId, groupId, userAgent, lcoCode);
				Message message = new Message();
				message.put("processId", processId);
				message.put("pincode", pincode);
				message.put("serviceContext", serviceContext);
				MessageBusUtil.sendMessage(ProcessConstant.BULK_CUSTOMER_DESTINATION, message);
				SessionMessages.add(resourceRequest, "start-process");
			} else {
				SessionErrors.add(resourceRequest, "validation-error");
				try {
					downloadErrorCSV(resourceRequest, resourceResponse, errorList);
				} catch (IOException e) {
					LOGGER.error("Error while generating csv file: " + e.getMessage());
				}
			}

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.getMessage());
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.getMessage());
		}

		return false;
	}

	public static final String[] CSV_HEADER_NDC = { "Row No", "Error" };

	private void downloadErrorCSV(ResourceRequest resourceRequest, ResourceResponse resourceResponse, List<KeyValuePair> errorList) throws IOException {
		String errorFile = "errorReport.csv";
		StringBundler sb = new StringBundler();
		for (String columnName : CSV_HEADER_NDC) {
			sb.append(columnName);
			sb.append(CharPool.COMMA);
		}

		sb.setIndex(sb.index() - 1);
		sb.append(CharPool.NEW_LINE);

		for (KeyValuePair obj : errorList) {
			sb.append(GetterUtil.getString(obj.getKey(), StringPool.BLANK));
			sb.append(CharPool.COMMA);
			sb.append(GetterUtil.getString(obj.getValue(), StringPool.BLANK));
			sb.append(CharPool.PIPE);
			sb.setIndex(sb.index() - 1);
			sb.append(CharPool.NEW_LINE);
		}
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, errorFile, sb.toString().getBytes(), ContentTypes.APPLICATION_TEXT);
	}

	private String readExcelAndSave(File file, long companyId, long groupId, User userAgent, String lcoCode) {

		try {
			return backgroundProcessUtil.getProcessIdAndUploadFile(companyId, groupId, userAgent.getUserId(), Customer.class.getName(), lcoCode, file, ProcessConstant.BULK_CUSTOMER, ProcessConstant.BULK_CUSTOMER_DESTINATION, null);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.getMessage());
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e.getMessage());
		}
		return null;
	}

	private List<KeyValuePair> validateExcel(File file, ResourceRequest resourceRequest) {
		List<KeyValuePair> list = new ArrayList<KeyValuePair>();
		FileInputStream excelFileInputStream = null;
		Workbook workbook = null;
		int count = 0;
		try {
			excelFileInputStream = new FileInputStream(file);
			workbook = new XSSFWorkbook(excelFileInputStream);
			Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
			Row currentRow = null;
			Cell cell = null;
			String[] salutations = JioPropsUtil.getArray(ConfigConstant.CUSTOMER_SALUTATION, PortalUtil.getCompanyId(resourceRequest));
			
			while (iterator.hasNext()) {
				currentRow = iterator.next();

				if (currentRow.getRowNum() == 0) {
					if (((Validator.isNotNull(currentRow.getCell(0)) && !currentRow.getCell(0).toString().equals(ExcelHeaderConstant.STB_NO)) || Validator.isNull(currentRow.getCell(0)))
							|| ((Validator.isNotNull(currentRow.getCell(1)) && !currentRow.getCell(1).toString().equals(ExcelHeaderConstant.VC_ID)) || Validator.isNull(currentRow.getCell(1)))
							|| ((Validator.isNotNull(currentRow.getCell(2)) && !currentRow.getCell(2).toString().equals(ExcelHeaderConstant.MAC_ID)) || Validator.isNull(currentRow.getCell(2)))
							|| ((Validator.isNotNull(currentRow.getCell(3)) && !currentRow.getCell(3).toString().equals(ExcelHeaderConstant.ACCOUNT_NO)) || Validator.isNull(currentRow.getCell(3)))
							|| ((Validator.isNotNull(currentRow.getCell(4)) && !currentRow.getCell(4).toString().equals(ExcelHeaderConstant.SALUTATION)) || Validator.isNull(currentRow.getCell(4)))
							|| ((Validator.isNotNull(currentRow.getCell(5)) && !currentRow.getCell(5).toString().equals(ExcelHeaderConstant.FIRST_NAME)) || Validator.isNull(currentRow.getCell(5)))
							|| ((Validator.isNotNull(currentRow.getCell(6)) && !currentRow.getCell(6).toString().equals(ExcelHeaderConstant.LAST_NAME)) || Validator.isNull(currentRow.getCell(6)))
							|| ((Validator.isNotNull(currentRow.getCell(7)) && !currentRow.getCell(7).toString().equals(ExcelHeaderConstant.MOBILE_NUMBER)) || Validator.isNull(currentRow.getCell(7)))
							|| ((Validator.isNotNull(currentRow.getCell(8)) && !currentRow.getCell(8).toString().equals(ExcelHeaderConstant.EMAIL_ID)) || Validator.isNull(currentRow.getCell(8)))
							|| ((Validator.isNotNull(currentRow.getCell(9)) && !currentRow.getCell(9).toString().equals(ExcelHeaderConstant.ADDRESS)) || Validator.isNull(currentRow.getCell(9)))
							|| ((Validator.isNotNull(currentRow.getCell(10)) && !currentRow.getCell(10).toString().equals(ExcelHeaderConstant.BUILDING_NAME)) || Validator.isNull(currentRow.getCell(10)))
							|| ((Validator.isNotNull(currentRow.getCell(11)) && !currentRow.getCell(11).toString().equals(ExcelHeaderConstant.FLAT_NO)) || Validator.isNull(currentRow.getCell(11)))
							|| ((Validator.isNotNull(currentRow.getCell(12)) && !currentRow.getCell(12).toString().equals(ExcelHeaderConstant.PLAN_NAME)) || Validator.isNull(currentRow.getCell(12)))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Header of the file has been changed"));
					}
				} else {
					count = count + 1;
					if ((Validator.isNull(currentRow.getCell(0)) && Validator.isNull(currentRow.getCell(1))) && Validator.isNull(currentRow.getCell(2))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Please enter STB NO and VC ID or MAC ID"));
					}
					if(Validator.isNull(currentRow.getCell(4)) && !ArrayUtil.contains(salutations, String.valueOf(currentRow.getCell(4)), true)) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Please enter valid Salutation!"));
					}
					if (Validator.isNull(currentRow.getCell(5))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "First name cannot be empty!"));
					}
					if (Validator.isNull(currentRow.getCell(6))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Last name cannot be empty!"));
					}
					if (Validator.isNull(currentRow.getCell(7))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Mobile number cannot be empty!"));
					}
					if (Validator.isNull(currentRow.getCell(12))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Plan name cannot be empty!"));
					}
				}

			}
			workbook.close();
			excelFileInputStream.close();
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e.toString());
		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		} finally {

			try {
				if (workbook != null)
					workbook.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.getLocalizedMessage());
			}
			try {
				if (excelFileInputStream != null)
					excelFileInputStream.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.getLocalizedMessage());
			}
		}
		LOGGER.info("count value" + count);
		if (count == 0) {
			list.add(new KeyValuePair(String.valueOf(StringPool.BLANK), "Enter at least one record!"));
		}
		return list;
	}

}
