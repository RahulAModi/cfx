package com.jio.bulk.customer.listner.impl;

import com.jio.account.model.Address;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.service.ProcessLocalService;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.customer.constants.ExcelHeaderConstant;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.service.CustomerService;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=" + ProcessConstant.BULK_CUSTOMER_DESTINATION }, service = MessageListener.class)
public class BulkCustomerListnerImpl implements MessageListener {

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	private void doReceive(Message msg) {
		String processId = GetterUtil.getString(msg.get("processId"));
		String pincode = GetterUtil.getString(msg.get("pincode"));
		ServiceContext serviceContext = null;
		if (Validator.isNotNull(msg.get("serviceContext"))) {
			serviceContext = (ServiceContext) msg.get("serviceContext");
		} else {
			serviceContext = new ServiceContext();
		}
		try {
			com.jio.background.process.model.Process process = processLocalService.getProcess(processId);
			User userAgent = userLocalService.getUserByScreenName(process.getCompanyId(), process.getCreateBy());
			executeBulkCustomerSave(processId, process.getCompanyId(), process.getGroupId(), userAgent, pincode, serviceContext);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}
	}

	private void executeBulkCustomerSave(String processId, long companyId, long groupId, User userAgent, String pincode, ServiceContext serviceContext) {

		try {
			InputStream in = backgroundProcessUtil.getDocumentByProcessId(processId);
			Workbook workbook = null;

			String msg = StringPool.BLANK;
			String stbNo = StringPool.BLANK;
			String vcId = StringPool.BLANK;
			String macId = StringPool.BLANK;
			String accountNo = StringPool.BLANK;
			String salutation = StringPool.BLANK;
			String firstName = StringPool.BLANK;
			String lastName = StringPool.BLANK;
			String mobileNo = StringPool.BLANK;
			String emailId = StringPool.BLANK;
			String address = StringPool.BLANK;
			String buildingName = StringPool.BLANK;
			String flatNo = StringPool.BLANK;
			String planName = StringPool.BLANK;

			FileOutputStream out = null;
			Workbook workbookDownload = new XSSFWorkbook();
			Sheet sheetDownload = workbookDownload.createSheet("Bulk Customer");
			Map<String, String> customerCreateMap = null;
			Map<String, String> customerPairMap = null;

			int rowNumDownload = 0;

			Row rowDownload = sheetDownload.createRow(rowNumDownload++);
			Cell cellDownload;
			if (rowDownload.getRowNum() == 0) {

				cellDownload = rowDownload.createCell(0);
				cellDownload.setCellValue(ExcelHeaderConstant.STB_NO);

				cellDownload = rowDownload.createCell(1);
				cellDownload.setCellValue(ExcelHeaderConstant.VC_ID);

				cellDownload = rowDownload.createCell(2);
				cellDownload.setCellValue(ExcelHeaderConstant.MAC_ID);

				cellDownload = rowDownload.createCell(3);
				cellDownload.setCellValue(ExcelHeaderConstant.ACCOUNT_NO);

				cellDownload = rowDownload.createCell(4);
				cellDownload.setCellValue(ExcelHeaderConstant.SALUTATION);

				cellDownload = rowDownload.createCell(5);
				cellDownload.setCellValue(ExcelHeaderConstant.FIRST_NAME);

				cellDownload = rowDownload.createCell(6);
				cellDownload.setCellValue(ExcelHeaderConstant.LAST_NAME);

				cellDownload = rowDownload.createCell(7);
				cellDownload.setCellValue(ExcelHeaderConstant.MOBILE_NUMBER);

				cellDownload = rowDownload.createCell(8);
				cellDownload.setCellValue(ExcelHeaderConstant.EMAIL_ID);

				cellDownload = rowDownload.createCell(9);
				cellDownload.setCellValue(ExcelHeaderConstant.ADDRESS);

				cellDownload = rowDownload.createCell(10);
				cellDownload.setCellValue(ExcelHeaderConstant.BUILDING_NAME);

				cellDownload = rowDownload.createCell(11);
				cellDownload.setCellValue(ExcelHeaderConstant.FLAT_NO);

				cellDownload = rowDownload.createCell(12);
				cellDownload.setCellValue(ExcelHeaderConstant.PLAN_NAME);

				cellDownload = rowDownload.createCell(13);
				cellDownload.setCellValue(ExcelHeaderConstant.STATUS);
			}

			int successCount = 0;
			int errorCount = 0;
			try {
				workbook = new XSSFWorkbook(in);
				Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
				Row currentRow = null;
				iterator.next();
				while (iterator.hasNext()) {
					currentRow = iterator.next();

					Cell cell = currentRow.getCell(0);
					cell.setCellType(CellType.STRING);
					stbNo = Validator.isNotNull(currentRow.getCell(0)) ? cell.getStringCellValue() : StringPool.BLANK;

					cell = currentRow.getCell(1);
					cell.setCellType(CellType.STRING);
					vcId = Validator.isNotNull(currentRow.getCell(1)) ? cell.getStringCellValue() : StringPool.BLANK;

					macId = Validator.isNotNull(currentRow.getCell(2)) ? currentRow.getCell(2).toString() : StringPool.BLANK;
					accountNo = Validator.isNotNull(currentRow.getCell(3)) ? currentRow.getCell(3).toString() : StringPool.BLANK;
					salutation = Validator.isNotNull(currentRow.getCell(4)) ? currentRow.getCell(4).toString() : StringPool.BLANK;
					firstName = Validator.isNotNull(currentRow.getCell(5)) ? currentRow.getCell(5).toString() : StringPool.BLANK;
					lastName = Validator.isNotNull(currentRow.getCell(6)) ? currentRow.getCell(6).toString() : StringPool.BLANK;

					cell = currentRow.getCell(7);
					cell.setCellType(CellType.STRING);
					mobileNo = Validator.isNotNull(currentRow.getCell(7)) ? cell.getStringCellValue() : StringPool.BLANK;

					emailId = Validator.isNotNull(currentRow.getCell(8)) ? currentRow.getCell(8).toString() : StringPool.BLANK;
					address = Validator.isNotNull(currentRow.getCell(9)) ? currentRow.getCell(9).toString() : StringPool.BLANK;
					buildingName = Validator.isNotNull(currentRow.getCell(10)) ? currentRow.getCell(10).toString() : StringPool.BLANK;
					flatNo = Validator.isNotNull(currentRow.getCell(11)) ? currentRow.getCell(11).toString() : StringPool.BLANK;

					cell = currentRow.getCell(11);
					cell.setCellType(CellType.STRING);
					planName = Validator.isNotNull(currentRow.getCell(12)) ? cell.getStringCellValue() : StringPool.BLANK;

					if (currentRow.getRowNum() != 0) {

						Location pincodeLocation = locationLocalService.getLocationByCode(pincode, companyId);
						Location areaLocation = locationLocalService.getParentLocation(pincodeLocation.getCode(), companyId);
						Location cityLocation = locationLocalService.getParentLocation(areaLocation.getCode(), companyId);

						String screenName = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());

						String txRefNo = AccountUtil.getTxRefNo();
						if (Validator.isNull(accountNo)) {
							customerPairMap = customerService.pairInventoryDetail(vcId, stbNo, macId, screenName, txRefNo, userAgent, companyId, groupId);
							Plan plan = planLocalService.getPlanByName(planName, companyId, cityLocation.getCode());
							if (GetterUtil.getBoolean(customerPairMap.get("PAIR"))) {
								customerCreateMap = customerService.createCustomer(vcId, stbNo, macId, customerPairMap.get("CONNECTIONTYPE"), JioPropsUtil.get(ConfigConstant.SERVICETYPE_CODE, companyId), StringPool.BLANK, salutation, firstName, StringPool.BLANK, lastName, address, StringPool.BLANK,
										StringPool.BLANK, buildingName, flatNo, mobileNo, StringPool.BLANK, emailId, cityLocation.getCode(), areaLocation.getCode(), pincode, String.valueOf(plan.getPlanId()), txRefNo, userAgent, companyId, groupId, serviceContext);

								if (customerCreateMap.get("STATUS").equalsIgnoreCase("SUCCESS")) {
									successCount = successCount++;
								}
							} else {
								msg = "FAIL : " + customerPairMap.get("MESSAGE");
								errorCount = errorCount++;
							}
						} else {

							Customer customer = customerLocalService.getCustomer(accountNo, companyId);
							Address customerAddress = addressLocalService.getAddress(companyId, accountNo);
							Contact customerContact = contactLocalService.getContact(companyId, accountNo);
							Map<String, String> modifyMap = customerService.modifyCustomer(accountNo, vcId, stbNo, macId, customer.getConnectionType(), customer.getServiceType(), customer.getCustomerId(), salutation, firstName, customer.getMiddleName(), lastName,
									Validator.isNotNull(address) ? address : customerAddress.getAddress(), customerAddress.getStreet(), customerAddress.getLocation(), Validator.isNotNull(buildingName) ? buildingName : customerAddress.getBuilding(), flatNo, mobileNo, customerContact.getLandLineNo(),
									customerContact.getEmail(), cityLocation.getCode(), areaLocation.getCode(), pincode, customer.getServicePoId(), customer.getPoId(), customer.getStbPoId(), customer.getVcPoId(), customer.getMacPoId(), txRefNo, userAgent, companyId, groupId, serviceContext);
							if (modifyMap.get("STATUS").equalsIgnoreCase("SUCCESS")) {
								successCount = successCount++;
							} else {
								msg = "FAIL : " + customerPairMap.get("MESSAGE");
								errorCount = errorCount++;
							}
						}
					} else {
						msg = "FAIL : Some fields are missing";
						errorCount = errorCount++;
					}

					rowDownload = sheetDownload.createRow(currentRow.getRowNum());
					cellDownload = rowDownload.createCell(0);
					cellDownload.setCellValue(stbNo);

					cellDownload = rowDownload.createCell(1);
					cellDownload.setCellValue(vcId);

					cellDownload = rowDownload.createCell(2);
					cellDownload.setCellValue(macId);

					cellDownload = rowDownload.createCell(3);
					cellDownload.setCellValue(accountNo);

					cellDownload = rowDownload.createCell(4);
					cellDownload.setCellValue(salutation);

					cellDownload = rowDownload.createCell(5);
					cellDownload.setCellValue(firstName);

					cellDownload = rowDownload.createCell(6);
					cellDownload.setCellValue(lastName);

					cellDownload = rowDownload.createCell(7);
					cellDownload.setCellValue(mobileNo);

					cellDownload = rowDownload.createCell(8);
					cellDownload.setCellValue(emailId);

					cellDownload = rowDownload.createCell(9);
					cellDownload.setCellValue(address);

					cellDownload = rowDownload.createCell(10);
					cellDownload.setCellValue(buildingName);

					cellDownload = rowDownload.createCell(11);
					cellDownload.setCellValue(flatNo);

					cellDownload = rowDownload.createCell(12);
					cellDownload.setCellValue(planName);

					cellDownload = rowDownload.createCell(13);
					cellDownload.setCellValue(msg);
				}

				try {
					String fileName = ProcessConstant.BULK_CUSTOMER_STATUS.concat(processId);
					String statusFileName = fileName.concat(StringPool.PERIOD).concat(ExcelHeaderConstant.XLSX);
					File statusFile = new File(statusFileName);
					out = new FileOutputStream(statusFile);
					workbookDownload.write(out);
					out.close();
					workbookDownload.close();

					backgroundProcessUtil.getProcessIdAndUploadFile(processId, Customer.class.getName(), userAgent.getScreenName(), statusFile, ProcessConstant.BULK_CUSTOMER_STATUS, successCount, errorCount);
					if (statusFile.exists()) {
						statusFile.delete();
					}
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				} finally {
					try {
						if (workbookDownload != null)
							workbookDownload.close();
					} catch (IOException e) {
						LOGGER.error("IOException : " + e.toString());
					}
					try {
						if (out != null)
							out.close();
					} catch (IOException e) {
						LOGGER.error("IOException : " + e.toString());
					}
				}
				workbook.close();
				in.close();
			} catch (FileNotFoundException e) {
				LOGGER.error("FileNotFoundException : " + e.toString());
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			} finally {
				try {
					if (workbook != null)
						workbook.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception : " + e.toString());
		}
	}

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private ProcessLocalService processLocalService;

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private CustomerService customerService;

	@Reference
	private AgentService agentService;

	@Reference
	private LocationLocalService locationLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private PlanLocalService planLocalService;

	public static final String XLSX = "xlsx";

	private static final Log LOGGER = LogFactoryUtil.getLog(BulkCustomerListnerImpl.class.getName());

}
