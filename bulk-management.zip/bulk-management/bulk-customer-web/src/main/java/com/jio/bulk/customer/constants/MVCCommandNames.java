package com.jio.bulk.customer.constants;

public class MVCCommandNames {

	public static final String VIEW = "/bulk-customer/view";
	
	public static final String SAVE = "/bulk-customer/save";

	public static final String DOWNLOAD = "/bulk-customer/download";
	
	public static final String UPLOAD_SAVE = "/bulk-customer/save-excel";
	
	public static final String ADD = "/bulk-customer/add";
	
	public static final String GET_ADDRESS = "/bulk-customer/get_address";
	
}