package com.jio.bulk.customer.auto.renewal.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.customer.auto.renewal.constants.BulkCustomerAutoRenewalPortletKeys;
import com.jio.bulk.customer.auto.renewal.constants.ExcelHeaderConstant;
import com.jio.bulk.customer.auto.renewal.constants.MVCCommandNames;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.KeyValuePair;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkCustomerAutoRenewalPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.UPLOAD_SAVE }, service = MVCResourceCommand.class)
public class SaveMVCResourceCommand implements MVCResourceCommand {
	private static final Log LOGGER = LogFactoryUtil.getLog(SaveMVCResourceCommand.class);

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private AgentService agentService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(resourceRequest);
		File file = uploadRequest.getFile("file");

		try {
			long groupId = PortalUtil.getScopeGroupId(resourceRequest);
			User userAgent = PortalUtil.getUser(resourceRequest);
			String lcoCode = agentService.getPrimaryAgentScreenName(companyId, userAgent.getScreenName());

			List<KeyValuePair> errorList = validateExcel(file, lcoCode, companyId);
			if (errorList.isEmpty()) {
				String processId = readExcelAndSave(file, companyId, groupId, userAgent, lcoCode);
				Message message = new Message();
				message.put("processId", processId);
				MessageBusUtil.sendMessage(ProcessConstant.BULK_CUSTOMER_AUTO_RENEWAL_DESTINATION, message);
				SessionMessages.add(resourceRequest, "start-process");
			} else {
				SessionErrors.add(resourceRequest, "validation-error");
				try {
					downloadErrorCSV(resourceRequest, resourceResponse, errorList);
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.getMessage());
				}
			}

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :  " + e.getMessage());
			SessionErrors.add(resourceRequest, "lco-code-not-found");
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.getMessage());
			SessionErrors.add(resourceRequest, "user-not-found");
		}

		return false;
	}

	public static final String[] CSV_HEADER_NDC = { "Row No", "Error" };

	private void downloadErrorCSV(ResourceRequest resourceRequest, ResourceResponse resourceResponse, List<KeyValuePair> errorList) throws IOException {
		String errorFile = "errorReport.csv";
		StringBundler sb = new StringBundler();
		for (String columnName : CSV_HEADER_NDC) {
			sb.append(columnName);
			sb.append(CharPool.COMMA);
		}

		sb.setIndex(sb.index() - 1);
		sb.append(CharPool.NEW_LINE);

		for (KeyValuePair obj : errorList) {
			sb.append(GetterUtil.getString(obj.getKey(), StringPool.BLANK));
			sb.append(CharPool.COMMA);
			sb.append(GetterUtil.getString(obj.getValue(), StringPool.BLANK));
			sb.append(CharPool.PIPE);
			sb.setIndex(sb.index() - 1);
			sb.append(CharPool.NEW_LINE);
		}
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, errorFile, sb.toString().getBytes(), ContentTypes.APPLICATION_TEXT);
	}

	private String readExcelAndSave(File file, long companyId, long groupId, User userAgent, String lcoCode) {

		try {
			return backgroundProcessUtil.getProcessIdAndUploadFile(companyId, groupId, userAgent.getUserId(), Customer.class.getName(), lcoCode, file, ProcessConstant.BULK_CUSTOMER_AUTO_RENEWAL, ProcessConstant.BULK_CUSTOMER_AUTO_RENEWAL_DESTINATION, null);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.getMessage());
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e.getMessage());
		}
		return null;
	}

	private List<KeyValuePair> validateExcel(File file, String primaryLcoCode, long companyId) {
		List<KeyValuePair> list = new ArrayList<KeyValuePair>();
		FileInputStream excelFileInputStream = null;
		Workbook workbook = null;
		int count = 0;
		try {
			excelFileInputStream = new FileInputStream(file);
			workbook = new XSSFWorkbook(excelFileInputStream);
			Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
			String accountNo = null;
			Row currentRow = null;
			String vcId = null;
			String lcoCode = null;
			Cell cell = null;
			while (iterator.hasNext()) {
				count = count++;
				currentRow = iterator.next();
				if (currentRow.getRowNum() == 0) {
					if ((validCell(currentRow, 0, ExcelHeaderConstant.ACCOUNT_NO)) || (validCell(currentRow, 1, ExcelHeaderConstant.VC_ID)) || (validCell(currentRow, 2, ExcelHeaderConstant.LCO_CODE)) || (validCell(currentRow, 3, ExcelHeaderConstant.FLAG))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Header of the file has been changed"));
					}
				} else if (Validator.isNotNull(currentRow.getCell(0)) && Validator.isNotNull(currentRow.getCell(1)) && Validator.isNotNull(currentRow.getCell(2)) && Validator.isNotNull(currentRow.getCell(3))) {

					if (Validator.isNotNull(currentRow.getCell(2))) {
						cell = currentRow.getCell(2);
						cell.setCellType(CellType.STRING);
						lcoCode = cell.getStringCellValue();
						if (AccountUtil.isNotAdmin(primaryLcoCode, String.valueOf(companyId))) {
							if (!lcoCode.equalsIgnoreCase(primaryLcoCode)) {
								list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "LCO code mismatch with uploaded file user"));
							}
						}
					}

					if (Validator.isNotNull(currentRow.getCell(0))) {
						cell = currentRow.getCell(0);
						cell.setCellType(CellType.STRING);
						accountNo = cell.getStringCellValue();
					}

					if (Validator.isNotNull(currentRow.getCell(1))) {
						cell = currentRow.getCell(1);
						cell.setCellType(CellType.STRING);
						vcId = cell.getStringCellValue();
					}

					try {
						customerLocalService.getCustomerByVcId(accountNo, vcId, lcoCode, companyId);
					} catch (NoSuchCustomerException e) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Account no, VC ID and LCO code mismatch error"));
					}

				} else {
					list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Account no | VC ID | LCO code and Flag must not be empty"));
				}

			}
			workbook.close();
			excelFileInputStream.close();
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e.toString());
		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		} finally {

			try {
				if (workbook != null)
					workbook.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}
			try {
				if (excelFileInputStream != null)
					excelFileInputStream.close();
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.toString());
			}
		}
		if (count == 1) {
			list.add(new KeyValuePair(String.valueOf(StringPool.BLANK), "Enter at least one record!"));
		}
		return list;
	}

	private static boolean validRow(Row row, String[] columnNames) {
		boolean[] valids = new boolean[columnNames.length];
		int i = 0;
		for (String columnName : columnNames) {
			valids[i] = validCell(row, i, columnName);
		}
		return ArrayUtil.contains(valids, false);
	}

	private static boolean validCell(Row row, int columnNumber, String columnName) {
		return ((Validator.isNotNull(row.getCell(columnNumber)) && !row.getCell(columnNumber).toString().equals(columnName)) || Validator.isNull(row.getCell(columnNumber)));
	}

	private static String getCellValue(Cell cell) {
		String value = StringPool.BLANK;
		if (Validator.isNotNull(cell)) {
			if (cell.getCellTypeEnum() == CellType.STRING) {
				value = cell.getStringCellValue();
			}
			if (cell.getCellTypeEnum() == CellType.NUMERIC) {
				value = String.valueOf(cell.getNumericCellValue());
			}
		}
		return value;
	}

}
