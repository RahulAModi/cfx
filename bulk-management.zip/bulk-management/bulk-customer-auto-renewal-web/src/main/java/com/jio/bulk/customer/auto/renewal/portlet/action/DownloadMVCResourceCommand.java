package com.jio.bulk.customer.auto.renewal.portlet.action;

import com.jio.bulk.customer.auto.renewal.constants.BulkCustomerAutoRenewalPortletKeys;
import com.jio.bulk.customer.auto.renewal.constants.ExcelHeaderConstant;
import com.jio.bulk.customer.auto.renewal.constants.MVCCommandNames;
import com.jio.config.props.JioPropsValues;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkCustomerAutoRenewalPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD }, service = MVCResourceCommand.class)
public class DownloadMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean resource = true;
		int rowNum = 0;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Bulk Customer Auto Renewal");

		FileOutputStream out = null;
		InputStream in = null;

		XSSFCellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setBold(true);
		style.setFont(font);

		Row row = sheet.createRow(rowNum++);
		Cell cell;
		int colNum = 0;
		if (row.getRowNum() == 0) {

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.ACCOUNT_NO);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.VC_ID);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.LCO_CODE);
			cell.setCellStyle(style);

			cell = row.createCell(colNum++);
			cell.setCellValue(ExcelHeaderConstant.FLAG);
			cell.setCellStyle(style);

		}
		try {

			String fileName = "BULK_CUSTOMER_AUTO_RENEWAL_UPLOAD_TEMPLATE.".concat(ExcelHeaderConstant.XLSX);
			String filePath = JioPropsValues.TEMPLATE_FOLDER_PATH;
			File file = new File(filePath + File.separator + fileName);
			file.getParentFile().mkdirs();

			// Write data to file
			out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
			workbook.close();
			// Complete writing

			// Download file
			in = new FileInputStream(file);
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, in, ContentTypes.APPLICATION_VND_MS_EXCEL);
			} catch (IOException e) {
				resource = false;
			}

			in.close();
			// Complete download
		} catch (IOException e) {
			resource = false;
		} finally {
			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				LOGGER.info("IOException : " + e.toString());
			}

			try {
				if (workbook != null)
					workbook.close();
			} catch (IOException e) {
				LOGGER.info("IOException : " + e.toString());
			}

			try {
				if (in != null)
					in.close();
			} catch (IOException e) {
				LOGGER.info("IOException : " + e.toString());
			}
		}

		return resource;
	}
}