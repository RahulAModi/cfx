package com.jio.bulk.customer.auto.renewal.constants;

/**
 * @author Vishal7.Shah
 */
public class BulkCustomerAutoRenewalPortletKeys {

	public static final String PORTLET_NAME = "com_jio_bulk_customer_auto_renewal_portlet_BulkCustomerAutoRenewalPortlet";

	public static final String CONFIGURATION_NAME = "com_jio_bulk_customer_auto_renewal_configuration_BulkCustomerAutoRenewalConfiguration";
}