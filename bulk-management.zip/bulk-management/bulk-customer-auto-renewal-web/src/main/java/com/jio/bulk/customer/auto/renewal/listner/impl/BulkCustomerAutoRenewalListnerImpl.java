package com.jio.bulk.customer.auto.renewal.listner.impl;

import com.jio.account.model.Customer;
import com.jio.account.service.CustomerLocalService;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.service.ProcessLocalService;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.customer.auto.renewal.constants.ExcelHeaderConstant;
import com.jio.customer.plan.service.CustomerPlanService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=" + ProcessConstant.BULK_CUSTOMER_AUTO_RENEWAL_DESTINATION }, service = MessageListener.class)
public class BulkCustomerAutoRenewalListnerImpl implements MessageListener {

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	private void doReceive(Message message) {
		String processId = GetterUtil.getString(message.get("processId"));
		try {
			com.jio.background.process.model.Process process = processLocalService.getProcess(processId);
			User userAgent = userLocalService.getUserByScreenName(process.getCompanyId(), process.getCreateBy());
			executeBulkCustomerAutoRenewal(processId, process.getCompanyId(), process.getGroupId(), userAgent);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}
	}

	private void executeBulkCustomerAutoRenewal(String processId, long companyId, long groupId, User userAgent) {
		try {
			InputStream in = backgroundProcessUtil.getDocumentByProcessId(processId);
			Workbook workbook = null;

			String message = StringPool.BLANK;
			String accountNo = StringPool.BLANK;
			String vcId = StringPool.BLANK;
			String lcoCode = StringPool.BLANK;
			String flag = StringPool.BLANK;

			FileOutputStream out = null;
			Workbook workbookDownload = new XSSFWorkbook();
			Sheet sheetDownload = workbookDownload.createSheet("Bulk Customer Auto Renewal");

			int rowNumDownload = 0;

			Row rowDownload = sheetDownload.createRow(rowNumDownload++);
			Cell cellDownload;
			if (rowDownload.getRowNum() == 0) {

				cellDownload = rowDownload.createCell(0);
				cellDownload.setCellValue(ExcelHeaderConstant.ACCOUNT_NO);

				cellDownload = rowDownload.createCell(1);
				cellDownload.setCellValue(ExcelHeaderConstant.VC_ID);

				cellDownload = rowDownload.createCell(2);
				cellDownload.setCellValue(ExcelHeaderConstant.LCO_CODE);

				cellDownload = rowDownload.createCell(3);
				cellDownload.setCellValue(ExcelHeaderConstant.FLAG);

				cellDownload = rowDownload.createCell(4);
				cellDownload.setCellValue(ExcelHeaderConstant.STATUS);
			}

			int successCount = 0;
			int errorCount = 0;
			try {
				workbook = new XSSFWorkbook(in);
				Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
				Row currentRow = null;
				while (iterator.hasNext()) {
					currentRow = iterator.next();

					Cell cell = currentRow.getCell(0);
					cell.setCellType(CellType.STRING);
					accountNo = Validator.isNotNull(cell) ? cell.getStringCellValue() : StringPool.BLANK;

					cell = currentRow.getCell(1);
					cell.setCellType(CellType.STRING);
					vcId = Validator.isNotNull(currentRow.getCell(1)) ? cell.getStringCellValue() : StringPool.BLANK;

					cell = currentRow.getCell(2);
					cell.setCellType(CellType.STRING);
					lcoCode = Validator.isNotNull(cell) ? cell.getStringCellValue() : StringPool.BLANK;

					cell = currentRow.getCell(3);
					flag = Validator.isNotNull(cell) ? cell.getStringCellValue() : StringPool.BLANK;

					if (currentRow.getRowNum() != 0) {

						if (Validator.isNotNull(accountNo) && Validator.isNotNull(flag)) {
							boolean autoRenewal = false;
							if ("YES".equalsIgnoreCase(flag) || "Y".equalsIgnoreCase(flag)) {
								autoRenewal = true;
							}

							Customer customer = customerLocalService.getCustomer(accountNo, companyId);
							customer.setAutoRenew(autoRenewal);
							customer = customerLocalService.updateCustomer(customer);

							customerPlanService.setAutoRenewalCustomerPlan(accountNo, customer.getScreenName(), companyId, customer.getAutoRenew());

							if (autoRenewal) {
								message = "SUCCESS : Customer account plan auto renewal off";
							} else {
								message = "SUCCESS : Customer Account plan auto renewal on";
							}

						} else {
							message = "FAIL : Customer account and Flag are missing";
							errorCount = errorCount++;
						}
					}

					rowDownload = sheetDownload.createRow(currentRow.getRowNum());
					cellDownload = rowDownload.createCell(0);
					cellDownload.setCellValue(accountNo);

					cellDownload = rowDownload.createCell(1);
					cellDownload.setCellValue(vcId);

					cellDownload = rowDownload.createCell(2);
					cellDownload.setCellValue(lcoCode);

					cellDownload = rowDownload.createCell(3);
					cellDownload.setCellValue(flag);

					cellDownload = rowDownload.createCell(4);
					cellDownload.setCellValue(message);
				}

				try {
					String fileName = ProcessConstant.BULK_CUSTOMER_AUTO_RENEWAL_STATUS.concat(processId);
					String statusFileName = fileName.concat(StringPool.PERIOD).concat(ExcelHeaderConstant.XLSX);
					File statusFile = new File(statusFileName);
					out = new FileOutputStream(statusFile);
					workbookDownload.write(out);
					out.close();
					workbookDownload.close();

					backgroundProcessUtil.getProcessIdAndUploadFile(processId, Customer.class.getName(), userAgent.getScreenName(), statusFile, ProcessConstant.BULK_CUSTOMER_AUTO_RENEWAL_STATUS, successCount, errorCount);
					if (statusFile.exists()) {
						statusFile.delete();
					}
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.getLocalizedMessage());
				} finally {
					try {
						if (workbookDownload != null)
							workbookDownload.close();
					} catch (IOException e) {
						LOGGER.error("IOException : " + e.getLocalizedMessage());
					}
					try {
						if (out != null)
							out.close();
					} catch (IOException e) {
						LOGGER.error("IOException : " + e.getLocalizedMessage());
					}
				}
				workbook.close();
				in.close();
			} catch (FileNotFoundException e) {
				LOGGER.error("FileNotFoundException : " + e.getLocalizedMessage());
			} catch (IOException e) {
				LOGGER.error("IOException : " + e.getLocalizedMessage());
			} finally {
				try {
					if (workbook != null)
						workbook.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.getLocalizedMessage());
				}
				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception : " + e.getLocalizedMessage());
		}
	}

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private ProcessLocalService processLocalService;

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private CustomerPlanService customerPlanService;

	private static final Log LOGGER = LogFactoryUtil.getLog(BulkCustomerAutoRenewalListnerImpl.class.getName());
}
