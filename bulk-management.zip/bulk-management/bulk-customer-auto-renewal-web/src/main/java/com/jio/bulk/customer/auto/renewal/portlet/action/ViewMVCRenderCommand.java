package com.jio.bulk.customer.auto.renewal.portlet.action;

import com.jio.bulk.customer.auto.renewal.constants.BulkCustomerAutoRenewalPortletKeys;
import com.jio.bulk.customer.auto.renewal.constants.MVCCommandNames;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkCustomerAutoRenewalPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		return "/view.jsp";
	}
}