package com.jio.bulk.customer.auto.renewal.constants;

public class ExcelHeaderConstant {

	public static final String VC_ID = "VC ID";
	public static final String ACCOUNT_NO = "ACCOUNT NO";
	public static final String LCO_CODE = "LCO CODE";
	public static final String FLAG = "FLAG";

	public static final String STATUS = "STATUS";

	public final static String XLSX = "xlsx";
}
