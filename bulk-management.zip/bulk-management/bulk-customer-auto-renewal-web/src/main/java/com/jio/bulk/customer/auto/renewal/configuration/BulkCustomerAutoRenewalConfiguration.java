package com.jio.bulk.customer.auto.renewal.configuration;

import com.jio.bulk.customer.auto.renewal.constants.BulkCustomerAutoRenewalPortletKeys;

import aQute.bnd.annotation.metatype.Meta;

@Meta.OCD(id = BulkCustomerAutoRenewalPortletKeys.CONFIGURATION_NAME)
public interface BulkCustomerAutoRenewalConfiguration {

	@Meta.AD(required = false)
	public String articleId();
}
