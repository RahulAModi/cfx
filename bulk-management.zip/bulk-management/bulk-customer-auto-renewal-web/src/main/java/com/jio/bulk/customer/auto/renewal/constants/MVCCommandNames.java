package com.jio.bulk.customer.auto.renewal.constants;

public class MVCCommandNames {

	public static final String VIEW = "/bulk-customer-auto-renewal/view";
	
	public static final String SAVE = "/bulk-customer-auto-renewal/save";

	public static final String DOWNLOAD = "/bulk-customer-auto-renewal/download";
	
	public static final String UPLOAD_SAVE = "/bulk-customer-auto-renewal/save-excel";
	
	public static final String ADD = "/bulk-customer-auto-renewal/add";
	
	public static final String GET_ADDRESS = "/bulk-customer-auto-renewal/get_address";
	
}