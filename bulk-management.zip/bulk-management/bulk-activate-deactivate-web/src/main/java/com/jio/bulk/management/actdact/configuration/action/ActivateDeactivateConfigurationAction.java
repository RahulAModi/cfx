package com.jio.bulk.management.actdact.configuration.action;

import com.jio.bulk.management.actdact.configuration.ActivateDeactivateConfiguration;
import com.jio.bulk.management.actdact.constants.BulkActivateDeactivatePortletKeys;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalService;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.ConfigurationAction;
import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author Vishal7.Shah
 *
 */
@Component(configurationPid = BulkActivateDeactivatePortletKeys.CONFIGURATION_NAME, configurationPolicy = ConfigurationPolicy.OPTIONAL, immediate = true, property = { "javax.portlet.name=" + BulkActivateDeactivatePortletKeys.PORTLET_NAME }, service = ConfigurationAction.class)
public class ActivateDeactivateConfigurationAction extends DefaultConfigurationAction {

	@Override
	public void include(PortletConfig portletConfig, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {

		httpServletRequest.setAttribute(ActivateDeactivateConfiguration.class.getName(), activateDeactivateConfiguration);

		long companyId = PortalUtil.getCompanyId(httpServletRequest);

		List<JournalArticle> journalArticles = journalArticleLocalService.getCompanyArticles(companyId, WorkflowConstants.STATUS_APPROVED, QueryUtil.ALL_POS, QueryUtil.ALL_POS);

		httpServletRequest.setAttribute("journalArticles", journalArticles);

		super.include(portletConfig, httpServletRequest, httpServletResponse);
	}

	@Override
	public void processAction(PortletConfig portletConfig, ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		boolean isScheduler = ParamUtil.getBoolean(actionRequest, "isScheduler");
		String articleId = ParamUtil.getString(actionRequest, "articleId");

		setPreference(actionRequest, "isScheduler", String.valueOf(isScheduler));
		setPreference(actionRequest, "articleId", String.valueOf(articleId));
		super.processAction(portletConfig, actionRequest, actionResponse);
	}

	@Activate
	@Modified
	protected void activate(Map<Object, Object> properties) {

		activateDeactivateConfiguration = ConfigurableUtil.createConfigurable(ActivateDeactivateConfiguration.class, properties);
	}

	private static final Log LOGGER = LogFactoryUtil.getLog(ActivateDeactivateConfigurationAction.class);

	private volatile ActivateDeactivateConfiguration activateDeactivateConfiguration;

	@Reference
	private JournalArticleLocalService journalArticleLocalService;

}
