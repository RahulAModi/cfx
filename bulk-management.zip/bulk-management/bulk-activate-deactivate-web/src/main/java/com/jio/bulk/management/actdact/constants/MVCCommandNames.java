package com.jio.bulk.management.actdact.constants;

public class MVCCommandNames {

	public static final String VIEW = "/bulk-act-dact/view";
	
	public static final String UPLOAD_BULK = "/bulk-act-dact/save";

	public static final String DOWNLOAD_EXCEL = "/bulk-act-dact/download-excel";
	
	public static final String UPLOAD_EXCEL_BULK = "/bulk-act-dact/save-excel";

}
