package com.jio.bulk.management.actdact.portlet.actions;

import com.jio.bulk.management.actdact.constants.BulkActivateDeactivatePortletKeys;
import com.jio.bulk.management.actdact.constants.ExcelHeaderConstant;
import com.jio.bulk.management.actdact.constants.MVCCommandNames;
import com.jio.config.props.JioPropsValues;
import com.jio.customer.util.ConvertUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkActivateDeactivatePortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD_EXCEL }, service = MVCResourceCommand.class)
public class DownloadExcelMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadExcelMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(resourceRequest);
		boolean resource = true;
		int rowNum = 0;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Bulk Activate Deactivate");

		XSSFCellStyle columnStyle = workbook.createCellStyle();
		columnStyle.setDataFormat(workbook.createDataFormat().getFormat("@"));
		sheet.setDefaultColumnStyle(0, columnStyle);
		sheet.setDefaultColumnStyle(1, columnStyle);
		sheet.setDefaultColumnStyle(2, columnStyle);
		sheet.setDefaultColumnStyle(3, columnStyle);
		sheet.setDefaultColumnStyle(4, columnStyle);
		sheet.setDefaultColumnStyle(5, columnStyle);
		FileOutputStream out = null;
		InputStream in = null;

		XSSFCellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setBold(true);
		style.setFont(font);

		Row row = sheet.createRow(rowNum++);
		Cell cell;
		if (row.getRowNum() == 0) {

			cell = row.createCell(0);
			cell.setCellValue(ExcelHeaderConstant.ACNO);
			cell.setCellStyle(style);

			cell = row.createCell(1);
			cell.setCellValue(ExcelHeaderConstant.VCID);
			cell.setCellStyle(style);

			cell = row.createCell(2);
			cell.setCellValue(ExcelHeaderConstant.REASON);
			cell.setCellStyle(style);

			cell = row.createCell(3);
			cell.setCellValue(ExcelHeaderConstant.LCO_CODE);
			cell.setCellStyle(style);

			cell = row.createCell(4);
			cell.setCellValue(ExcelHeaderConstant.ACTION);
			cell.setCellStyle(style);

		}

		Map<String, String> mapDA = ConvertUtil.getMapFromKeyPropertyJsonObjectValue("customer.suspend.reason", companyId);
		Map<String, String> mapRA = ConvertUtil.getMapFromKeyPropertyJsonObjectValue("customer.reactive.reason", companyId);

		for (Map.Entry<String, String> entry : mapDA.entrySet()) {
			row = sheet.createRow(rowNum++);

			cell = row.createCell(2);
			cell.setCellValue(entry.getValue());
			cell.setCellStyle(columnStyle);

			cell = row.createCell(4);
			cell.setCellValue("DA");
			cell.setCellStyle(columnStyle);
		}

		for (Map.Entry<String, String> entry : mapRA.entrySet()) {
			row = sheet.createRow(rowNum++);
			cell = row.createCell(2);
			cell.setCellValue(entry.getValue());
			cell.setCellStyle(columnStyle);
			cell = row.createCell(4);
			cell.setCellValue("RA");
			cell.setCellStyle(columnStyle);
		}

		try {

			String fileName = "BULK_ACTIVATE_DEACTIVATE_UPLOAD_TEMPLATE.".concat(ExcelHeaderConstant.XLSX);
			String filePath = JioPropsValues.TEMPLATE_FOLDER_PATH;
			File file = new File(filePath + File.separator + fileName);

			// Write data to file
			out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
			workbook.close();
			// Complete writing

			// Download file
			in = new FileInputStream(file);
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, in, ContentTypes.APPLICATION_VND_MS_EXCEL);
			} catch (IOException e) {
				resource = false;
			}

			in.close();
			// Complete download
		} catch (IOException e) {
			resource = false;
		} finally {

			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				LOGGER.info("IOException : " + e.toString());
			}

			try {
				if (workbook != null)
					workbook.close();
			} catch (IOException e) {
				LOGGER.info("IOException : " + e.toString());
			}

			try {
				if (in != null)
					in.close();
			} catch (IOException e) {
				LOGGER.info("IOException : " + e.toString());
			}
		}

		return resource;
	}

}
