package com.jio.bulk.management.actdact.configuration;

import com.jio.bulk.management.actdact.constants.BulkActivateDeactivatePortletKeys;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * @author Vishal7.Shah
 *
 */
@Meta.OCD(id = BulkActivateDeactivatePortletKeys.CONFIGURATION_NAME)
public interface ActivateDeactivateConfiguration {

	@Meta.AD(required = false)
	public boolean isScheduler();

	@Meta.AD(required = false)
	public String articleId();
}
