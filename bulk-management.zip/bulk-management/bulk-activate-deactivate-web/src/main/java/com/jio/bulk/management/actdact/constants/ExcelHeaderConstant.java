package com.jio.bulk.management.actdact.constants;

public class ExcelHeaderConstant {
	public static final String ACNO = "ACCOUNT NO";
	public static final String VCID = "VC ID";
	public static final String REASON = "REASON";
	public static final String LCO_CODE = "LCO CODE";
	public static final String ACTION = "Action";
	public static final String STATUS = "Status";
	
	public static final String XLSX = "xlsx";
}
