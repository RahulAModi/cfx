package com.jio.bulk.management.actdact.listner.impl;

import com.jio.account.model.Customer;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.service.ProcessLocalService;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.management.actdact.constants.ExcelHeaderConstant;
import com.jio.customer.service.CustomerService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=" + ProcessConstant.BULK_CUSTOMER_ACTIVATE_DEACTIVATE_DESTINATION }, service = MessageListener.class)
public class ActivateDeactivateListnerImpl implements MessageListener {

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	private void doReceive(Message msg) {
		String processId = GetterUtil.getString(msg.get("processId"));
		try {
			com.jio.background.process.model.Process process = processLocalService.getProcess(processId);
			User loggedInUser = userLocalService.getUserByScreenName(process.getCompanyId(), process.getCreateBy());
			executeTransaction(processId, process.getCompanyId(), process.getGroupId(), loggedInUser);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}
	}

	private void executeTransaction(String processId, long companyId, long groupId, User loggedInUser) {
		try {
			InputStream in = backgroundProcessUtil.getDocumentByProcessId(processId);
			Workbook workbook = null;
			LOGGER.info("Excel read started started");
			String msg = StringPool.BLANK;
			String accountNo = StringPool.BLANK;
			String vcId = StringPool.BLANK;
			String reason = StringPool.BLANK;
			String lcoCode = StringPool.BLANK;
			String action = StringPool.BLANK;
			FileOutputStream out = null;

			Workbook workbookDownload = new XSSFWorkbook();
			Sheet sheetDownload = workbookDownload.createSheet("CustomerPlan");
			int rowNumDownload = 0;

			Row rowDownload = sheetDownload.createRow(rowNumDownload++);
			Cell cellDownload;
			if (rowDownload.getRowNum() == 0) {

				cellDownload = rowDownload.createCell(0);
				cellDownload.setCellValue(ExcelHeaderConstant.ACNO);

				cellDownload = rowDownload.createCell(1);
				cellDownload.setCellValue(ExcelHeaderConstant.VCID);

				cellDownload = rowDownload.createCell(2);
				cellDownload.setCellValue(ExcelHeaderConstant.REASON);

				cellDownload = rowDownload.createCell(3);
				cellDownload.setCellValue(ExcelHeaderConstant.LCO_CODE);

				cellDownload = rowDownload.createCell(4);
				cellDownload.setCellValue(ExcelHeaderConstant.ACTION);

				cellDownload = rowDownload.createCell(5);
				cellDownload.setCellValue(ExcelHeaderConstant.STATUS);

			}

			int successCount = 0;
			int errorCount = 0;

			try {
				workbook = new XSSFWorkbook(in);
				Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
				Row currentRow = null;
				Cell cell = null;
				iterator.next();
				while (iterator.hasNext()) {
					currentRow = iterator.next();
					if (Validator.isNotNull(currentRow.getCell(0))) {
						cell = currentRow.getCell(0);
						cell.setCellType(CellType.STRING);
						accountNo = cell.getStringCellValue();
					} else {
						accountNo = StringPool.BLANK;
					}

					if (Validator.isNotNull(currentRow.getCell(3))) {
						cell = currentRow.getCell(3);
						cell.setCellType(CellType.STRING);
						lcoCode = cell.getStringCellValue();
					} else {
						lcoCode = StringPool.BLANK;
					}

					// accountNo = Validator.isNotNull(currentRow.getCell(0)) ? currentRow.getCell(0).toString():StringPool.BLANK;
					vcId = Validator.isNotNull(currentRow.getCell(1)) ? currentRow.getCell(1).toString() : StringPool.BLANK;
					reason = Validator.isNotNull(currentRow.getCell(2)) ? currentRow.getCell(2).toString() : StringPool.BLANK;
					// lcoCode = Validator.isNotNull(currentRow.getCell(3)) ? currentRow.getCell(3).toString():StringPool.BLANK;
					action = Validator.isNotNull(currentRow.getCell(4)) ? currentRow.getCell(4).toString() : StringPool.BLANK;

					LOGGER.info(lcoCode + "  " + accountNo);

					if (currentRow.getRowNum() != 0 && !Validator.isBlank(accountNo) && !Validator.isBlank(vcId) && !Validator.isBlank(reason) && !Validator.isBlank(action)) {

						if (action.equalsIgnoreCase("DA") || action.equalsIgnoreCase("DEACTIVATE")) {
							try {
								Map<String, String> map = customerService.suspendCustomer(currentRow.getCell(0).toString(), null, null, currentRow.getCell(2).toString(), processId, loggedInUser, companyId, groupId);

								msg = map.get("STATUS") + map.get("MESSAGE");
								if (map.get("STATUS").equalsIgnoreCase("FAIL")) {
									errorCount = errorCount + 1;
								} else {
									successCount = successCount + 1;
								}
							} catch (Exception e) {
								msg = "FAIL: " + e.getMessage();
								errorCount = errorCount + 1;
							}
						}

						if (currentRow.getCell(4).toString().equalsIgnoreCase("RA") || currentRow.getCell(4).toString().equalsIgnoreCase("REACTIVATE")) {
							try {
								Map<String, String> map = customerService.reactiveCustomer(currentRow.getCell(0).toString(), null, null, currentRow.getCell(2).toString(), processId, loggedInUser, companyId, groupId);

								msg = map.get("STATUS") + map.get("MESSAGE");
								if (map.get("STATUS").equalsIgnoreCase("FAIL")) {
									errorCount = errorCount + 1;
								} else {
									successCount = successCount + 1;
								}
							} catch (Exception e) {
								msg = "FAIL: " + e.getMessage();
							}
						}
					} else {
						msg = "FAIL: Some field is missing";
						errorCount = errorCount + 1;
					}

					rowDownload = sheetDownload.createRow(currentRow.getRowNum());
					cellDownload = rowDownload.createCell(0);
					cellDownload.setCellValue(accountNo);

					cellDownload = rowDownload.createCell(1);
					cellDownload.setCellValue(vcId);

					cellDownload = rowDownload.createCell(2);
					cellDownload.setCellValue(reason);

					cellDownload = rowDownload.createCell(3);
					cellDownload.setCellValue(lcoCode);

					cellDownload = rowDownload.createCell(4);
					cellDownload.setCellValue(action);

					cellDownload = rowDownload.createCell(5);
					cellDownload.setCellValue(msg);
					LOGGER.info("API Call Message" + msg);

				}

				try {
					String fileName = ProcessConstant.BULK_CUSTOMER_ACTIVATE_DEACTIVATE_STATUS.concat(processId);
					String statusFileName = fileName.concat(StringPool.PERIOD).concat(ExcelHeaderConstant.XLSX);
					File statusFile = new File(statusFileName);
					out = new FileOutputStream(statusFile);
					workbookDownload.write(out);
					out.close();
					workbookDownload.close();

					backgroundProcessUtil.getProcessIdAndUploadFile(processId, Customer.class.getName(), lcoCode, statusFile, ProcessConstant.BULK_CUSTOMER_ACTIVATE_DEACTIVATE_STATUS, successCount, errorCount);

					if (statusFile.exists()) {
						statusFile.delete();
					}
				} catch (IOException e) {
					LOGGER.error("IOException :: " + e.toString());
				} finally {
					try {
						if (workbookDownload != null)
							workbookDownload.close();
					} catch (IOException e) {
					}
					try {
						if (out != null)
							out.close();
					} catch (IOException e) {
					}
				}

				workbook.close();

				in.close();

			} catch (FileNotFoundException e) {
				LOGGER.error("FileNotFoundException :: " + e.toString());
			} catch (IOException e) {
				LOGGER.error("IOException :: " + e.toString());
			} finally {
				try {
					if (workbook != null)
						workbook.close();
				} catch (IOException e) {
				}
				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
				}
			}

		} catch (Exception e1) {
			LOGGER.error("Excel import error");
		}
	}

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private ProcessLocalService processLocalService;

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private CustomerService customerService;

	private static final Log LOGGER = LogFactoryUtil.getLog(ActivateDeactivateListnerImpl.class.getName());
}
