package com.jio.bulk.management.actdact.constants;

/**
 * @author Vinay.Kahar
 */
public class BulkActivateDeactivatePortletKeys {

	public static final String PORTLET_NAME = "com_jio_bulk_management_actdact_portlet_BulkActivateDeactivatePortlet";

	public static final String CONFIGURATION_NAME = "com_jio_bulk_management_actdact_configuration_ActivateDeactivateConfiguration";
}