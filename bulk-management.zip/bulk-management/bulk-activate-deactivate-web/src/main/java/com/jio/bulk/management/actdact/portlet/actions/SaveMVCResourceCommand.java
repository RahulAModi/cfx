package com.jio.bulk.management.actdact.portlet.actions;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.agent.service.AgentService;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.bulk.management.actdact.constants.BulkActivateDeactivatePortletKeys;
import com.jio.bulk.management.actdact.constants.ExcelHeaderConstant;
import com.jio.bulk.management.actdact.constants.MVCCommandNames;
import com.jio.customer.service.CustomerService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.KeyValuePair;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkActivateDeactivatePortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.UPLOAD_EXCEL_BULK }, service = MVCResourceCommand.class)
public class SaveMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(SaveMVCResourceCommand.class);

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AgentService agentService;

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		PortletPreferences portletPreferences = resourceRequest.getPreferences();
		boolean isScheduler = GetterUtil.getBoolean(portletPreferences.getValue("isScheduler", "false"));
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		Date processStartDate = null;
		if (isScheduler) {
			String startDate = ParamUtil.getString(resourceRequest, "startDate");
			String startTime = ParamUtil.getString(resourceRequest, "startTime");
			String startDateTime = StringBundler.concat(startDate, StringPool.SPACE, startTime, ":00");
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			try {
				processStartDate = dateFormat.parse(startDateTime);
			} catch (ParseException e) {
				LOGGER.error("ParseException : " + e.getMessage());
			}
		}

		try {
			long groupId = PortalUtil.getScopeGroupId(resourceRequest);
			User loggedInUser = PortalUtil.getUser(resourceRequest);
			String lcoCode = agentService.getPrimaryAgentScreenName(companyId, loggedInUser.getScreenName());

			UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(resourceRequest);
			File file = uploadRequest.getFile("file");

			List<KeyValuePair> errorList = validateExcel(file, resourceRequest, lcoCode, companyId);
			if (errorList.isEmpty()) {
				String processId = readExcelAndSave(file, companyId, groupId, loggedInUser, lcoCode, processStartDate);
				Message message = new Message();
				message.put("processId", processId);
				MessageBusUtil.sendMessage(ProcessConstant.BULK_CUSTOMER_ACTIVATE_DEACTIVATE_DESTINATION, message);
				SessionMessages.add(resourceRequest, "start-process");
			} else {
				SessionErrors.add(resourceRequest, "validation-error");
				try {
					downloadErrorCSV(resourceRequest, resourceResponse, errorList);
				} catch (IOException e) {
					LOGGER.error("Error while generating csv file: " + e.getMessage());
				}
			}

		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException : " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		return false;
	}

	public static final String[] CSV_HEADER_NDC = { "Row No", "Error" };

	private void downloadErrorCSV(ResourceRequest resourceRequest, ResourceResponse resourceResponse, List<KeyValuePair> errorList) throws IOException {
		String errorFile = "errorReport.csv";
		StringBundler sb = new StringBundler();
		for (String columnName : CSV_HEADER_NDC) {
			sb.append(columnName);
			sb.append(CharPool.COMMA);
		}

		sb.setIndex(sb.index() - 1);
		sb.append(CharPool.NEW_LINE);

		for (KeyValuePair obj : errorList) {
			sb.append(GetterUtil.getString(obj.getKey(), StringPool.BLANK));
			sb.append(CharPool.COMMA);
			sb.append(GetterUtil.getString(obj.getValue(), StringPool.BLANK));
			sb.append(CharPool.PIPE);
			sb.setIndex(sb.index() - 1);
			sb.append(CharPool.NEW_LINE);
		}
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, errorFile, sb.toString().getBytes(), ContentTypes.APPLICATION_TEXT);
	}

	private List<KeyValuePair> validateExcel(File file, ResourceRequest resourceRequest, String primaryLcoCode, long companyId) {
		List<KeyValuePair> list = new ArrayList<KeyValuePair>();
		FileInputStream excelFileInputStream = null;
		Workbook workbook = null;
		int count = 0;
		try {
			excelFileInputStream = new FileInputStream(file);
			workbook = new XSSFWorkbook(excelFileInputStream);
			Iterator<Row> iterator = workbook.getSheetAt(0).iterator();
			Row currentRow = null;
			String accountNo = null;
			String vcId = null;
			String lcoCode = null;
			Cell cell = null;
			while (iterator.hasNext()) {
				count = count++;
				currentRow = iterator.next();
				if (currentRow.getRowNum() == 0) {
					if (((Validator.isNotNull(currentRow.getCell(0)) && !currentRow.getCell(0).toString().equals(ExcelHeaderConstant.ACNO)) || Validator.isNull(currentRow.getCell(0)))
							|| ((Validator.isNotNull(currentRow.getCell(1)) && !currentRow.getCell(1).toString().equals(ExcelHeaderConstant.VCID)) || Validator.isNull(currentRow.getCell(1)))
							|| ((Validator.isNotNull(currentRow.getCell(2)) && !currentRow.getCell(2).toString().equals(ExcelHeaderConstant.REASON)) || Validator.isNull(currentRow.getCell(2)))
							|| ((Validator.isNotNull(currentRow.getCell(3)) && !currentRow.getCell(3).toString().equals(ExcelHeaderConstant.LCO_CODE)) || Validator.isNull(currentRow.getCell(3)))
							|| ((Validator.isNotNull(currentRow.getCell(4)) && !currentRow.getCell(4).toString().equals(ExcelHeaderConstant.ACTION)) || Validator.isNull(currentRow.getCell(4)))) {
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Header of the file has been changed"));
					}

				} else if (Validator.isNotNull(currentRow.getCell(0)) && Validator.isNotNull(currentRow.getCell(1)) && Validator.isNotNull(currentRow.getCell(2)) && Validator.isNotNull(currentRow.getCell(4)) && Validator.isNotNull(currentRow.getCell(3))) {

					if (Validator.isNotNull(currentRow.getCell(3))) {
						cell = currentRow.getCell(3);
						cell.setCellType(CellType.STRING);
						lcoCode = cell.getStringCellValue().trim();
						if (AccountUtil.isNotAdmin(primaryLcoCode, String.valueOf(companyId))) {
							if (!lcoCode.equalsIgnoreCase(primaryLcoCode)) {
								list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "LCO code mismatch with uploaded file user"));
							}
						}
					}

					if (Validator.isNotNull(currentRow.getCell(0))) {
						cell = currentRow.getCell(0);
						cell.setCellType(CellType.STRING);
						accountNo = cell.getStringCellValue().trim();
					}

					if (Validator.isNotNull(currentRow.getCell(1))) {
						cell = currentRow.getCell(1);
						cell.setCellType(CellType.STRING);
						vcId = cell.getStringCellValue().trim();
					}

					try {
						customerLocalService.getCustomerByVcId(accountNo, vcId, lcoCode, companyId);
					} catch (Exception e) {
						LOGGER.error(e.getMessage());
						list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Account no, VC ID and LCO Code mismatch error"));
					}

				} else {
					list.add(new KeyValuePair(String.valueOf(currentRow.getRowNum() + 1), "Account no | VC ID | User ID | Reason and Action must not be empty"));
				}

			}

			workbook.close();
			excelFileInputStream.close();

		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException :: " + e.toString());
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
		} finally {

			try {
				if (workbook != null)
					workbook.close();
			} catch (IOException e) {
			}
			try {
				if (excelFileInputStream != null)
					excelFileInputStream.close();
			} catch (IOException e) {
			}

		}
		if (count == 1) {
			SessionErrors.add(resourceRequest, "empty-values");
			list.add(new KeyValuePair(String.valueOf(StringPool.BLANK), "Account no | VC ID | LCO Code | Reason and Action must not be empty"));
		}
		return list;
	}

	private String readExcelAndSave(File file, long companyId, long groupId, User loggedInUser, String lcoCode, Date processStartDate) {
		String processId = "";
		try {
			processId = backgroundProcessUtil.getProcessIdAndUploadFile(companyId, groupId, loggedInUser.getUserId(), Customer.class.getName(), lcoCode, file, ProcessConstant.BULK_CUSTOMER_ACTIVATE_DEACTIVATE, ProcessConstant.BULK_CUSTOMER_ACTIVATE_DEACTIVATE_DESTINATION, processStartDate);
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.getMessage());
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e.getMessage());
		}
		return processId;

	}

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private CustomerService customerService;

	public final String XLSX = "xlsx";

}
