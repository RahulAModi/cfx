package com.jio.bulk.management.actdact.portlet.actions;

import com.jio.bulk.management.actdact.constants.BulkActivateDeactivatePortletKeys;
import com.jio.bulk.management.actdact.constants.MVCCommandNames;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "javax.portlet.name=" + BulkActivateDeactivatePortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadExcelMVCResourceCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		return "/view.jsp";
	}

}