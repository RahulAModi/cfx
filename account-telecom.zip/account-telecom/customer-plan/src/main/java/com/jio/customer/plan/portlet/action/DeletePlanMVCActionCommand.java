/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.util.AccountUtil;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DELETE_PLAN }, service = MVCActionCommand.class)
public class DeletePlanMVCActionCommand extends BaseMVCActionCommand {

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private CustomerPlanService customerPlanService;

	private static final Log LOGGER = LogFactoryUtil.getLog(DeletePlanMVCActionCommand.class);

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		long groupId = PortalUtil.getScopeGroupId(actionRequest);
		long companyId = PortalUtil.getCompanyId(actionRequest);
		User userAgent = PortalUtil.getUser(actionRequest); // Loggedin Agent

		String accountNo = ParamUtil.getString(actionRequest, "accountNo"); // Customer ScreenName

		String cpId = ParamUtil.getString(actionRequest, "cpId");
		String reason = ParamUtil.getString(actionRequest, "reason");
		String receiptNo = customerPlanUtil.getReceiptNo();
		String txRefNo = AccountUtil.getTxRefNo();

		try {
			Map<String, String> map = customerPlanService.cancelCustomerPlans(new String[] { cpId }, reason, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
			if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
				SessionMessages.add(actionRequest, "success-messsage");
				actionRequest.setAttribute("successMessage", map.get("MESSAGE"));
			} else {
				SessionErrors.add(actionRequest, "error-message");
				actionRequest.setAttribute("errorMessage", map.get("MESSAGE"));
			}
		} catch (NoSuchAgentException e) {
			SessionErrors.add(actionRequest, NoSuchAgentException.class);
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (NoSuchAgentBalanceException e) {
			SessionErrors.add(actionRequest, NoSuchAgentBalanceException.class);
			LOGGER.error("NoSuchAgentBalanceException :: " + e.toString());
		} catch (BlockAgentBalanceException e) {
			SessionErrors.add(actionRequest, BlockAgentBalanceException.class);
			LOGGER.error("BlockAgentBalanceException :: " + e.toString());
		} catch (InSufficientAgentBalanceException e) {
			SessionErrors.add(actionRequest, InSufficientAgentBalanceException.class);
			LOGGER.error("InSufficientAgentBalanceException :: " + e.toString());
		} catch (NoSuchCustomerException e) {
			SessionErrors.add(actionRequest, NoSuchCustomerException.class);
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
		}
		hideDefaultErrorMessage(actionRequest);
		hideDefaultSuccessMessage(actionRequest);
	}

}