package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.util.AccountUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.service.CustomerService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.RETRACT }, service = MVCActionCommand.class)
public class RetractMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(RetractMVCActionCommand.class);

	@Reference
	CustomerService customerService;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		long companyId = PortalUtil.getCompanyId(actionRequest);
		long groupId = PortalUtil.getScopeGroupId(actionRequest);
		String accountNo = ParamUtil.getString(actionRequest, "accountNo");
		String screenName = ParamUtil.getString(actionRequest, "screenName");
		String txRefNo = AccountUtil.getTxRefNo();
		User userAgent = PortalUtil.getUser(actionRequest);
		try {
			Map<String, String> map = customerService.retractCustomer(accountNo, screenName, txRefNo, userAgent, companyId, groupId);
			if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
				actionRequest.setAttribute("successMessage", map.get("MESSAGE"));
			} else {
				actionRequest.setAttribute("errorMessage", map.get("MESSAGE"));
			}
		} catch (NoSuchCustomerException e) {
			LOGGER.error("NoSuchCustomerException : " + e.toString());
		}

	}

}
