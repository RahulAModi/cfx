package com.jio.customer.plan.row.checker;

import com.jio.master.telecom.model.Plan;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.search.RowChecker;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.Validator;

import javax.portlet.RenderResponse;

public class PlanRowChecker extends RowChecker {
	String selectedRowIds;

	public PlanRowChecker(RenderResponse renderResponse, String selectedRowIds) {
		super(renderResponse);
		this.selectedRowIds = selectedRowIds;
	}

	@Override
	public boolean isChecked(Object obj) {
		if (Validator.isNotNull(selectedRowIds)) {
			Plan plan = (Plan) obj;
			String rowId = String.valueOf(plan.getPlanId());
			String[] rowIds = selectedRowIds.split(StringPool.COMMA);
			return ArrayUtil.contains(rowIds, rowId);
		} else {
			return super.isChecked(obj);
		}

	}

}
