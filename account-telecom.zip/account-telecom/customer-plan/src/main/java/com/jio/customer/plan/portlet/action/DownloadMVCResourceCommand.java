package com.jio.customer.plan.portlet.action;

import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD }, service = MVCResourceCommand.class)
public class DownloadMVCResourceCommand implements MVCResourceCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(DownloadMVCResourceCommand.class);
	public final String XLSX = "xlsx";

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean resource = true;

		long companyId = PortalUtil.getCompanyId(resourceRequest);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("CustomerPlan");

		try {
			User user = PortalUtil.getUser(resourceRequest);

			boolean isAdmin = AccountUtil.isAdmin(user.getUserId());
			List<Agent> agents = new ArrayList<Agent>();
			if (isAdmin) {
				agents = agentLocalService.getAgents(companyId);
			} else {
				agents = agentLocalService.getAgents(companyId, user.getScreenName());
			}

			for (Agent agent : agents) {
				List<Customer> customers = customerLocalService.getCustomerByLogInAgent(agent.getScreenName(), companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
				for (Customer customer : customers) {
					List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), companyId);
					createRow(sheet, customer, cps);
				}
			}
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}

		try {
			String fileName = "CustomerPlan".concat(StringPool.PERIOD).concat(XLSX);
			File file = new File(fileName);
			FileOutputStream out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
			workbook.close();
			InputStream inputStream = new FileInputStream(file);
			PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, inputStream, ContentTypes.APPLICATION_VND_MS_EXCEL);

			inputStream.close();
			if (file.exists()) {
				file.delete();
			}
		} catch (IOException e) {
			LOGGER.error("IOException :: " + e.toString());
			resource = false;
		}

		return resource;
	}

	protected XSSFSheet createRow(XSSFSheet sheet, Customer customer, List<CP> cps) {
		int rowNum = 0;
		int colNum = 0;

		Row row = sheet.createRow(rowNum++);

		Cell cell = row.createCell(colNum++);
		cell.setCellValue("Customer Account No");
		cell = row.createCell(colNum++);
		cell.setCellValue("Agent Screen Name");
		cell = row.createCell(colNum++);
		cell.setCellValue("Plan Code");
		cell = row.createCell(colNum++);
		cell.setCellValue("Active/Deactive");

		for (CP cp : cps) {
			row = sheet.createRow(rowNum++);
			colNum = 0;
			cell = row.createCell(colNum++);
			cell.setCellValue(customer.getAccountNo());
			cell = row.createCell(colNum++);
			cell.setCellValue(customer.getAgentScreenName());
			cell = row.createCell(colNum++);
			cell.setCellValue(cp.getPlanCode());
			cell = row.createCell(colNum++);
			cell.setCellValue(cp.getActive() ? "TRUE" : "FALSE");
		}

		return sheet;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CPLocalService cpLocalService;

}