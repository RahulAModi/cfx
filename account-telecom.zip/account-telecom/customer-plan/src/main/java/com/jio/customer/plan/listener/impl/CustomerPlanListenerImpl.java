package com.jio.customer.plan.listener.impl;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentCustomerMappingException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.AgentCustomerMapping;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentCustomerMappingLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.balance.service.AgentBalanceLocalService;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.service.LanguageLocalService;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=" + ProcessConstant.CUSTOMER_PLAN_DESTINATION }, service = MessageListener.class)
public class CustomerPlanListenerImpl implements MessageListener {

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	/**
	 * Customer Plan operation details get from message
	 * 
	 * @param message
	 */
	private void doReceive(Message msg) {

		String screenName = GetterUtil.getString(msg.get("screenName"));
		String processId = GetterUtil.getString(msg.get("processId"));
		long groupId = GetterUtil.getLong(msg.get("groupId"));
		long companyId = GetterUtil.getLong(msg.get("companyId"));
		String receiptNo = customerPlanUtil.getReceiptNo();
		String txRefNo = AccountUtil.getTxRefNo();
		try {
			InputStream in = backgroundProcessUtil.getDocumentByProcessId(processId);

			int message = 0;
			if (Validator.isNotNull(in)) {

				// FileInputStream excelFile = new FileInputStream(file);
				Workbook workbook = new XSSFWorkbook(in);
				Sheet sheet = workbook.getSheetAt(0);

				Workbook workbookDownload = new XSSFWorkbook();
				Sheet sheetDownload = workbookDownload.createSheet("CustomerPlan");

				Iterator<Row> iterator = sheet.iterator();
				List<CP> cps = new ArrayList<CP>();
				List<String> successPlans = new ArrayList<String>();
				List<String> errorPlans = new ArrayList<String>();
				while (iterator.hasNext()) {

					Row currentRow = iterator.next();
					Row row = sheetDownload.createRow(currentRow.getRowNum());
					if (currentRow.getRowNum() != 0) {

						String accountNo = currentRow.getCell(0).toString();
						String agentScreenName = currentRow.getCell(1).toString();
						String planCode = currentRow.getCell(2).toString();
						boolean active = GetterUtil.getBoolean(currentRow.getCell(3).toString());
						String finalStatus = "FAIL";
						String remkars = StringPool.BLANK;
						Cell cell = row.createCell(0);
						cell.setCellValue(accountNo);
						cell = row.createCell(1);
						cell.setCellValue(agentScreenName);
						cell = row.createCell(2);
						cell.setCellValue(planCode);
						cell = row.createCell(3);
						cell.setCellValue(active);

						String packageId = StringPool.BLANK;
						String purchasedProductPoId = StringPool.BLANK;

						try {
							Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
							User userAgent = userLocalService.getUserByScreenName(companyId, agent.getScreenName());

							Customer customer = customerLocalService.getCustomer(accountNo, companyId);

							boolean autoRenew = customerPlanService.isAutoRenew(agent, customer);

							List<String> agentScreenNames = new ArrayList<String>();
							agentScreenNames.add(agent.getScreenName().toLowerCase());
							try {
								AgentCustomerMapping agentCustomerMapping = agentCustomerMappingLocalService.findByCustomerScreenName(companyId, customer.getScreenName());
								agentScreenNames.add(agentCustomerMapping.getAgentScreenName().toLowerCase());
							} catch (NoSuchAgentCustomerMappingException e) {
								LOGGER.warn("NoSuchAgentCustomerMappingException :: " + e.toString());
							}
							String[] _agentScreenNames = agentScreenNames.stream().toArray(String[]::new);
							if (ArrayUtil.contains(_agentScreenNames, customer.getAgentScreenName().toLowerCase())) {

								Address address = addressLocalService.getAddress(companyId, customer.getScreenName());
								String cityCode = address.getCityCode();
								Plan plan = planLocalService.getPlanByCode(planCode, companyId, cityCode);

								if (customerPlanService.isAgentBalanceBlockOrInsufficentAmount(userAgent.getScreenName(), companyId)) {

									if (active) {
										// Add and Renew with Active Plan

										if (address.getCityCode().equalsIgnoreCase(plan.getCityCode())) {

											Date currentTime = new Date();
											Date endTime = customerPlanService.getEndTime(customerPlanUtil.getEndDate(currentTime), customer, companyId);
											boolean addPlan = false;
											boolean renewPlan = false;
											try {
												CP cp = null;
												try {
													cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), plan.getCode(), companyId);
													if (!cp.isActive()) {
														// RENEW

														cp = cpLocalService.saveOrUpdateCP(groupId, companyId, userAgent.getScreenName(), customer.getScreenName(), customer.getAccountNo(), customer.getCustomerId(), false, plan.getCode(), "Add Plan - " + planCode, address.getCityCode(), autoRenew,
																packageId, purchasedProductPoId, currentTime, endTime);
														cps.add(cp);
														renewPlan = true;
														LOGGER.info("Customer plan renew as deactive :: " + planCode);
													} else {
														LOGGER.info("Customer plan already exist :: " + planCode);
													}
												} catch (NoSuchCPException e) {
													// ADD
													cp = cpLocalService.saveOrUpdateCP(groupId, companyId, userAgent.getScreenName(), customer.getScreenName(), customer.getAccountNo(), customer.getCustomerId(), false, plan.getCode(), "Add Plan - " + planCode, address.getCityCode(), autoRenew,
															packageId, purchasedProductPoId, currentTime, endTime);
													cps.add(cp);
													addPlan = true;
													LOGGER.info("Customer plan added as deactive :: " + planCode);
												}

												if (!cp.isActive()) {

													if (addPlan) {

														Map<String, String> map = customerPlanService.addCustomerPlans(new String[] { String.valueOf(plan.getPlanId()) }, autoRenew, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
														finalStatus = map.get("STATUS");
														remkars = map.get("MESSAGE");
													}

													if (renewPlan) {

														Map<String, String> map = customerPlanService.renewCustomerPlans(new String[] { String.valueOf(cp.getCpId()) }, true, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
														finalStatus = map.get("STATUS");
														remkars = map.get("MESSAGE");

													}

												} else {
													LOGGER.info("Plan already active :: " + planCode);
												}

											} catch (PortalException e) {
												remkars = "PortalException :: " + e.toString();
												LOGGER.error("PortalException :: " + e.toString());
											}
										} else {
											remkars = "Customer address and Plan city code is different :: " + plan.getCode();
											LOGGER.error("Customer address and Plan city code is different :: " + plan.getCode());
										}

									} else {
										// Deactive Plan
										try {

											CP cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), plan.getCode(), companyId);

											Map<String, String> map = customerPlanService.cancelCustomerPlans(new String[] { String.valueOf(cp.getCpId()) }, StringPool.BLANK, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
											finalStatus = map.get("STATUS");
											remkars = map.get("MESSAGE");

										} catch (NoSuchCPException e) {
											remkars = "NoSuchCPException :: " + e.toString();
											LOGGER.error("NoSuchCPException :: " + e.toString());
										}

									}

								}

							} else {
								remkars = "Customer is associate with agent :: " + customer.getAgentScreenName() + ". Get different agents :: " + Arrays.toString(_agentScreenNames);
								LOGGER.error("Customer is associate with agent :: " + customer.getAgentScreenName() + ". Get different agents :: " + Arrays.toString(_agentScreenNames));
							}
						} catch (NoSuchAgentBalanceException e) {
							remkars = "NoSuchAgentBalanceException :: " + e.toString();
							LOGGER.error("NoSuchAgentBalanceException :: " + e.toString());
						} catch (BlockAgentBalanceException e) {
							remkars = "BlockAgentBalanceException :: " + e.toString();
							LOGGER.error("BlockAgentBalanceException :: " + e.toString());
						} catch (InSufficientAgentBalanceException e) {
							remkars = "InSufficientAgentBalanceException :: " + e.toString();
							LOGGER.error("InSufficientAgentBalanceException :: " + e.toString());
						} catch (NoSuchAddressException e) {
							remkars = "NoSuchAddressException :: " + e.toString();
							LOGGER.error("NoSuchAddressException :: " + e.toString());
						} catch (NoSuchAgentException e) {
							remkars = "NoSuchAgentException :: " + e.toString();
							LOGGER.error("NoSuchAgentException :: " + e.toString());
						} catch (NoSuchCustomerException e) {
							remkars = "NoSuchCustomerException :: " + e.toString();
							LOGGER.error("NoSuchCustomerException :: " + e.toString());
						} catch (PortalException e) {
							remkars = "PortalException :: " + e.toString();
							LOGGER.error("PortalException :: " + e.toString());
						}

						cell = row.createCell(4);
						cell.setCellValue(finalStatus);
						cell = row.createCell(5);
						cell.setCellValue(remkars);

					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue("Customer Account No");
						cell = row.createCell(1);
						cell.setCellValue("Agent Screen Name");
						cell = row.createCell(2);
						cell.setCellValue("Plan Code");
						cell = row.createCell(3);
						cell.setCellValue("Active/Deactive");
						cell = row.createCell(4);
						cell.setCellValue("Status");
						cell = row.createCell(5);
						cell.setCellValue("Remarks");
					}
				}

				try {
					String fileName = "CUSTOMER_PLAN_STATUS_".concat(processId);
					String statusFileName = fileName.concat(StringPool.PERIOD).concat(XLSX);
					File statusFile = new File(statusFileName);
					FileOutputStream out = new FileOutputStream(statusFile);
					workbookDownload.write(out);
					out.close();

					backgroundProcessUtil.getProcessIdAndUploadFile(processId, CP.class.getName(), screenName, statusFile, ProcessConstant.CUSTOMER_PLAN_STATUS, successPlans.size(), errorPlans.size());

					if (statusFile.exists()) {
						statusFile.delete();
					}
				} catch (IOException e) {
					LOGGER.error("IOException :: " + e.toString());
					message = 4;
				}

				workbook.close();
				workbookDownload.close();
			} else {
				message = 2;
			}
			if (message == 1) {
				LOGGER.info("Excel import start");
			} else if (message == 2) {
				LOGGER.error("Excel import error");
			} else if (message == 0) {
				LOGGER.error("Invalid file extension");
			}
		} catch (Exception e1) {
			LOGGER.error("Excel import error");
		}
	}

	private final Log LOGGER = LogFactoryUtil.getLog(CustomerPlanListenerImpl.class);

	public final String XLSX = "xlsx";

	@Reference
	private LanguageLocalService languageLocalService;

	@Reference
	private AgentBalanceLocalService agentBalanceLocalService;

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private AgentCustomerMappingLocalService agentCustomerMappingLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

}
