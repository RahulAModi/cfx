package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.util.AccountUtil;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_ADD_PLAN }, service = MVCResourceCommand.class)
public class SaveAddPlanMVCResourceCommand implements MVCResourceCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(SaveAddPlanMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean resource = true;

		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String txRefNo = AccountUtil.getTxRefNo();

		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		try {
			long groupId = PortalUtil.getScopeGroupId(resourceRequest);
			User userAgent = PortalUtil.getUser(resourceRequest); // Loggedin Agent
			String accountNo = ParamUtil.getString(resourceRequest, "accountNo"); // Customer ScreenName
			String[] planIds = ParamUtil.getParameterValues(resourceRequest, "planIds");
			String receiptNo = customerPlanUtil.getReceiptNo();

			Map<String, String> map = customerPlanService.addCustomerPlans(planIds, false, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
			jsonObject.put("STATUS", map.get("STATUS"));
			jsonObject.put("MESSAGE", map.get("MESSAGE"));

		} catch (NoSuchAgentException e) {
			jsonObject.put("STATUS", "FAIL");
			jsonObject.put("MESSAGE", "NoSuchAgentException :: " + e.toString());
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		} catch (NoSuchAgentBalanceException e) {
			jsonObject.put("STATUS", "FAIL");
			jsonObject.put("MESSAGE", "NoSuchAgentBalanceException :: " + e.toString());
			LOGGER.error("NoSuchAgentBalanceException :: " + e.toString());
		} catch (BlockAgentBalanceException e) {
			jsonObject.put("STATUS", "FAIL");
			jsonObject.put("MESSAGE", "BlockAgentBalanceException :: " + e.toString());
			LOGGER.error("BlockAgentBalanceException :: " + e.toString());
		} catch (InSufficientAgentBalanceException e) {
			jsonObject.put("STATUS", "FAIL");
			jsonObject.put("MESSAGE", "InSufficientAgentBalanceException :: " + e.toString());
			LOGGER.error("InSufficientAgentBalanceException :: " + e.toString());
		} catch (NoSuchCustomerException e) {
			jsonObject.put("STATUS", "FAIL");
			jsonObject.put("MESSAGE", "NoSuchCustomerException :: " + e.toString());
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
		} catch (PortalException e) {
			jsonObject.put("STATUS", "FAIL");
			jsonObject.put("MESSAGE", "PortalException :: " + e.toString());
			LOGGER.error("PortalException :: " + e.toString());
		}

		try {
			resourceResponse.getWriter().println(jsonObject.toString());
		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		}

		return resource;
	}

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

}