package com.jio.customer.plan.portlet.action;

import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.customer.util.ConvertUtil;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_CANCEL }, service = MVCResourceCommand.class)
public class GetCancelPlanMVCResourceCommand implements MVCResourceCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(GetCancelPlanMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean response = true;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		try {
			String accountNo = ParamUtil.getString(resourceRequest, "accountNo"); // Customer ScreenName
			String[] cpIds = ParamUtil.getParameterValues(resourceRequest, "cpIds[]");
			Customer customer = customerLocalService.getCustomer(accountNo, companyId);
			double finalPrice = 0.00;
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
			DateFormat dateFormat = new SimpleDateFormat(JioPropsUtil.get(ConfigConstant.DATE_PATTERN, companyId));
			for (String cpId : cpIds) {
				CP cp = cpLocalService.getCP(cpId, companyId);
				JSONObject cpObject = getCPJsonObject(cp, dateFormat);
				jsonArray.put(cpObject);
				finalPrice = finalPrice + cpObject.getDouble("cpAmount");
				// MANDATORY PLAN - NCF 1
				if (cp.isMandatory()) {
					try {
						CP ncfCp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId);
						cpObject = getCPJsonObject(ncfCp, dateFormat);
						jsonArray.put(cpObject);
						finalPrice = finalPrice + cpObject.getDouble("cpAmount");
					} catch (NoSuchCPException e) {
						LOGGER.error("NoSuchCPException : " + e.toString());
					}
				}
			}
			jsonObject.put("cps", jsonArray);
			jsonObject.put("finalPrice", finalPrice);
			jsonObject.put("reasons", ConvertUtil.getJsonArrayFromKeyPropertyJsonObjectValue(ConfigConstant.CANCEL_PLAN_REASON, companyId));
		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		try {
			resourceResponse.getWriter().println(jsonObject.toString());
		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		}

		return response;
	}

	private JSONObject getCPJsonObject(CP cp, DateFormat dateFormat) {
		Date startDate = cp.getStartDate();
		Date currentDate = new Date();
		Date endDate = cp.getEndDate();
		long actualDiffInDays = customerPlanUtil.getDiffInDays(startDate, endDate);
		long diffInDays = customerPlanUtil.getDiffInDays(startDate, currentDate); // Current Date as End Date
		double cpLcoPrice = customerPlanService.getLcoPrice(cp);
		double cpAmount = customerPlanUtil.getCreditPrice(actualDiffInDays, diffInDays, cpLcoPrice);
		cp.setEndDate(currentDate);
		cp.setCpLcoPrice(cpLcoPrice);
		cp.setCpDuration(diffInDays);
		cp.setCpAmount(cpAmount);

		JSONObject cpObject = JSONFactoryUtil.createJSONObject();
		cpObject.put("planName", cp.getPlanName());
		cpObject.put("lcoPrice", cp.getCpLcoPrice());
		cpObject.put("cpAmount", cp.getCpAmount());
		cpObject.put("cpDuration", cp.getCpDuration());
		cpObject.put("startDate", dateFormat.format(cp.getStartDate()));
		cpObject.put("endDate", dateFormat.format(cp.getEndDate()));

		return cpObject;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private CPLocalService cpLocalService;

}