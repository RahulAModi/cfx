package com.jio.customer.plan.row.checker;

import com.jio.account.telecom.model.CP;
import com.jio.master.telecom.exception.NoSuchPlanCategoryException;
import com.jio.master.telecom.model.PlanCategory;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.liferay.portal.kernel.dao.search.RowChecker;
import com.liferay.portal.kernel.util.Validator;

import javax.portlet.RenderResponse;

public class CPRowChecker extends RowChecker {

	private PlanCategoryLocalService planCategoryLocalService;

	public CPRowChecker(RenderResponse renderResponse, PlanCategoryLocalService planCategoryLocalService) {
		super(renderResponse);
		this.planCategoryLocalService = planCategoryLocalService;
	}

	@Override
	public boolean isDisabled(Object obj) {
		if (Validator.isNotNull(planCategoryLocalService)) {
			CP cp = (CP) obj;
			try {
				PlanCategory planCategory = planCategoryLocalService.getPlanCategoryByCode(cp.getCategoryCode(), cp.getCompanyId());
				return !planCategory.isVisible();
			} catch (NoSuchPlanCategoryException e) {
			}
			return super.isDisabled(obj);
		} else {
			return super.isDisabled(obj);
		}

	}

}
