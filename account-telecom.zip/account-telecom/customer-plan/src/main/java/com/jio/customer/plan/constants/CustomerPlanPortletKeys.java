package com.jio.customer.plan.constants;

/**
 * @author Vishal7.Shah
 */
public class CustomerPlanPortletKeys {

	public static final String PORTLET_NAME = "com_jio_customer_plan_portlet_CustomerPlanPortlet";

}