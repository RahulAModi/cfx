package com.jio.customer.plan.portlet.action;

import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.exception.NoSuchPlanCategoryException;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.model.PlanCategory;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_ADD }, service = MVCResourceCommand.class)
public class GetAddPlanMVCResourceCommand implements MVCResourceCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(GetAddPlanMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean response = true;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		try {
			String accountNo = ParamUtil.getString(resourceRequest, "accountNo"); // Customer ScreenName
			String[] planIds = ParamUtil.getParameterValues(resourceRequest, "planIds[]");
			Customer customer = customerLocalService.getCustomer(accountNo, companyId);
			double finalPrice = 0.00;
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
			DateFormat dateFormat = new SimpleDateFormat(JioPropsUtil.get(ConfigConstant.DATE_PATTERN, companyId));

			Date currentTime = new Date();
			Date endTime = customerPlanService.getEndTime(customerPlanUtil.getEndDate(currentTime), customer, companyId);

			long diffInDays = customerPlanUtil.getDiffInDays(currentTime, endTime);

			List<JSONObject> jsonObjects = new ArrayList<JSONObject>();
			for (String planId : planIds) {
				Plan plan = planLocalService.getPlan(GetterUtil.get(planId, 0L), companyId);
				jsonObjects = addPlan(plan, companyId, dateFormat, currentTime, endTime, diffInDays);
				for (JSONObject planObject : jsonObjects) {
					jsonArray.put(planObject);
					finalPrice = finalPrice + planObject.getDouble("cpAmount");
				}

				if (Validator.isNotNull(plan.getMappingCode())) {
					plan = planLocalService.getPlanByCode(plan.getMappingCode(), companyId, plan.getCityCode());
					jsonObjects = addPlan(plan, companyId, dateFormat, currentTime, endTime, diffInDays);
					for (JSONObject planObject : jsonObjects) {
						jsonArray.put(planObject);
						finalPrice = finalPrice + planObject.getDouble("cpAmount");
					}
				}

			}
			jsonObject.put("cps", jsonArray);
			jsonObject.put("finalPrice", finalPrice);

		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		try {
			resourceResponse.getWriter().println(jsonObject.toString());
		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		}

		return response;
	}

	private List<JSONObject> addPlan(Plan plan, long companyId, DateFormat dateFormat, Date startDate, Date endDate, long diffInDays) {
		List<JSONObject> jsonObjects = new ArrayList<JSONObject>();
		double amount = customerPlanUtil.getDebitPrice(diffInDays, plan.getLcoPrice());
		jsonObjects.add(getPlanJsonObject(plan, amount, diffInDays, startDate, endDate, dateFormat));
		try {
			// MANDATORY PLAN - NCF 1
			PlanCategory planCategory = planCategoryLocalService.getPlanCategory(plan.getCategoryId(), companyId);
			if (planCategory.isMandatory()) {
				try {
					plan = planLocalService.getPlanByCode(JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId, plan.getCityCode());
					amount = customerPlanUtil.getDebitPrice(diffInDays, plan.getLcoPrice());
					jsonObjects.add(getPlanJsonObject(plan, amount, diffInDays, startDate, endDate, dateFormat));
				} catch (NoSuchPlanException e) {
					LOGGER.error("NoSuchPlanException : " + e.toString());
				}
			}
		} catch (NoSuchPlanCategoryException e) {
			LOGGER.error("NoSuchPlanCategoryException : " + e.toString());
		}

		return jsonObjects;
	}

	private JSONObject getPlanJsonObject(Plan plan, double amount, long duration, Date startDate, Date endDate, DateFormat dateFormat) {
		JSONObject cpObject = JSONFactoryUtil.createJSONObject();
		cpObject.put("planName", plan.getName());
		cpObject.put("lcoPrice", plan.getLcoPrice());
		cpObject.put("cpAmount", amount);
		cpObject.put("cpDuration", duration);
		cpObject.put("startDate", dateFormat.format(startDate));
		cpObject.put("endDate", dateFormat.format(endDate));
		return cpObject;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

}