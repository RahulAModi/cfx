/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.master.telecom.exception.NoSuchPlanCategoryGroupException;
import com.jio.master.telecom.exception.NoSuchServiceTypeException;
import com.jio.master.telecom.model.PlanCategoryGroup;
import com.jio.master.telecom.model.ServiceType;
import com.jio.master.telecom.service.PlanCategoryGroupLocalService;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.EDIT, "mvc.command.name=" + MVCCommandNames.DELETE_PLAN, "mvc.command.name=" + MVCCommandNames.SAVE_RENEW, "mvc.command.name=" + MVCCommandNames.RENEW_PLAN,
		"mvc.command.name=" + MVCCommandNames.SAVE_CANCEL, "mvc.command.name=" + MVCCommandNames.AUTO_RENEW_PLAN }, service = MVCRenderCommand.class)
public class EditMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private PlanCategoryGroupLocalService planCategoryGroupLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CPLocalService cpLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(EditMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);
		String accountNo = ParamUtil.getString(renderRequest, "accountNo");
		try {
			Customer customer = customerLocalService.getCustomer(accountNo, companyId);

			ServiceType serviceType = serviceTypeLocalService.getServiceTypeByCode(customer.getServiceType(), companyId);

			List<PlanCategoryGroup> planCategoryGroups = planCategoryGroupLocalService.getVisiblePlanCategoryGroups(true, serviceType.getServiceTypeId(), companyId);

			List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, companyId);

			Map<PlanCategoryGroup, List<CP>> customerPlans = cps.stream().collect(Collectors.groupingBy(new Function<CP, PlanCategoryGroup>() {
				public PlanCategoryGroup apply(CP cp) {
					PlanCategoryGroup planCategoryGroup = null;
					try {
						planCategoryGroup = planCategoryGroupLocalService.getPlanCategoryGroupByCode(cp.getCategoryGroupCode(), cp.getCompanyId());
					} catch (NoSuchPlanCategoryGroupException e) {
						LOGGER.error("NoSuchPlanCategoryGroupException : " + e.toString());
						planCategoryGroup = null;
					}
					return planCategoryGroup;
				};
			}, Collectors.toList()));

			renderRequest.setAttribute("planCategoryGroups", planCategoryGroups);
			renderRequest.setAttribute("customerPlans", customerPlans);
			renderRequest.setAttribute("customer", customer);

		} catch (NoSuchCustomerException e) {
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
		} catch (NoSuchServiceTypeException e) {
			LOGGER.error("NoSuchServiceTypeException :: " + e.toString());
		}

		return "/customerplan/edit_plan.jsp";
	}
}