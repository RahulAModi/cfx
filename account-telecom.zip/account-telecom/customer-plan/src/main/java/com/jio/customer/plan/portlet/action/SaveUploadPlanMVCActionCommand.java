package com.jio.customer.plan.portlet.action;

import com.jio.account.telecom.model.CP;
import com.jio.background.process.constant.ProcessConstant;
import com.jio.background.process.util.BackgroundProcessUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.nas.api.NASHelper;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.File;
import java.io.FileNotFoundException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD }, service = MVCActionCommand.class)

public class SaveUploadPlanMVCActionCommand extends BaseMVCActionCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(SaveUploadPlanMVCActionCommand.class);

	public final String XLSX = "xlsx";

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);

		try {
			UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
			File file = request.getFile("file");

			String processId = backgroundProcessUtil.getProcessIdAndUploadFile(themeDisplay.getCompanyId(), themeDisplay.getScopeGroupId(), themeDisplay.getUserId(), CP.class.getName(), themeDisplay.getUser().getScreenName(), file, ProcessConstant.CUSTOMER_PLAN,
					ProcessConstant.CUSTOMER_PLAN_DESTINATION, null);

			processMessage(processId, themeDisplay.getCompanyId(), themeDisplay.getScopeGroupId(), themeDisplay.getUser().getScreenName());

		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e.getMessage());
		}
	}

	private static void processMessage(String processId, long companyId, long groupId, String screenName) {

		Message message = new Message();
		message.put("processId", processId);
		message.put("groupId", groupId);
		message.put("companyId", companyId);
		message.put("screenName", screenName);
		MessageBusUtil.sendMessage(ProcessConstant.CUSTOMER_PLAN_DESTINATION, message);
	}

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private NASHelper nasHelper;

	@Reference
	private BackgroundProcessUtil backgroundProcessUtil;
}