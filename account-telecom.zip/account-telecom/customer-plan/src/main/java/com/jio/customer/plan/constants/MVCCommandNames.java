package com.jio.customer.plan.constants;

public class MVCCommandNames {

	public static final String VIEW = "/customerplan/view";

	public static final String VIEW_CHANNEL = "/customerplan/view_channel";

	public static final String EDIT = "/customerplan/edit";

	public static final String ADD_PLAN = "/customerplan/add_plan";

	public static final String VALIDATE_PLAN = "/customerplan/validate_plan";

	public static final String SAVE_PLAN = "/customerplan/save_plan";

	public static final String SEARCH_PLAN = "/customerplan/search_plan";

	public static final String DELETE_PLAN = "/customerplan/delete_plan";

	public static final String AUTO_RENEW = "/customerplan/auto_renew";

	public static final String AUTO_RENEW_PLAN = "/customerplan/auto_renew_plan";

	public static final String RENEW_PLAN = "/customerplan/renew_plan";

	public static final String SAVE_RENEW = "/customerplan/save_renew";

	public static final String SAVE_CANCEL = "/customerplan/save_cancel";

	public static final String RENEW = "/customerplan/renew";

	public static final String CANCEL_PLAN = "/customerplan/cancel_plan";

	public static final String DELETE = "/customerplan/delete";

	public static final String SEARCH = "/customerplan/search";

	public static final String DOWNLOAD = "/customerplan/download";

	public static final String DOWNLOAD_PLAN = "/customerplan/download_plan";

	public static final String DOWNLOAD_RECEIPT = "/customerplan/download_receipt";

	public static final String UPLOAD = "/customerplan/upload";

	public static final String SAVE_UPLOAD = "/customerplan/save_upload";

	public static final String TERMINATE = "/customerplan/terminate";

	public static final String SAVE_TERMINATE = "/customerplan/save_terminate";

	public static final String SUSPEND = "/customerplan/suspend";

	public static final String SAVE_SUSPEND = "/customerplan/save_suspend";

	public static final String SWAP_VC = "/customerplan/swap_vc";

	public static final String SAVE_SWAP_VC = "/customerplan/save_swap_vc";

	public static final String SWAP_STB = "/customerplan/swap_stb";

	public static final String SAVE_SWAP_STB = "/customerplan/save_swap_stb";

	public static final String RETRACT = "/customerplan/retract";

	public static final String REACTIVE = "/customerplan/reactive";

	public static final String SAVE_REACTIVE = "/customerplan/save_reactive";

	public static final String GET_ADD = "/customerplan/get_add";

	public static final String GET_RENEW = "/customerplan/get_renew";

	public static final String GET_CANCEL = "/customerplan/get_cancel";

	public static final String SAVE_ADD_PLAN = "/customerplan/save_add_plan";

	public static final String SAVE_RENEW_PLAN = "/customerplan/save_renew_plan";

	public static final String SAVE_CANCEL_PLAN = "/customerplan/save_cancel_plan";

}
