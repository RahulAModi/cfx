package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.service.CustomerLocalService;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.AUTO_RENEW }, service = MVCActionCommand.class)
public class AutoRenewMVCActionCommand extends BaseMVCActionCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(AutoRenewMVCActionCommand.class);

	@Reference
	CustomerLocalService customerLocalService;

	@Reference
	CustomerPlanService customerPlanService;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		String accountNo = ParamUtil.getString(actionRequest, "accountNo");
		String screenName = ParamUtil.getString(actionRequest, "screenName");
		long companyId = PortalUtil.getCompanyId(actionRequest);
		try {
			Customer customer = customerLocalService.getCustomer(accountNo, screenName, companyId);

			String message = "customer-account-auto-renwal";
			if (customer.isAutoRenew()) {
				customer.setAutoRenew(false);
				message = "customer-account-auto-renwal-off";
			} else {
				customer.setAutoRenew(true);
				message = "customer-account-auto-renwal-on";
			}

			customer = customerLocalService.updateCustomer(customer);

			// Update All Customer -> Attached Plan AutoRenew Flag
			setAutoRenewal(accountNo, screenName, companyId, customer.getAutoRenew());

			SessionMessages.add(actionRequest, message);
		} catch (NoSuchCustomerException e) {
			SessionErrors.add(actionRequest, NoSuchCustomerException.class);
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
		}

	}

	private void setAutoRenewal(String accountNo, String customerScreeenName, long companyId, boolean autoRenewal) {
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				customerPlanService.setAutoRenewalCustomerPlan(accountNo, customerScreeenName, companyId, autoRenewal);
			}
		};
		Thread thread = new Thread(runnable);
		thread.start();
	}

}
