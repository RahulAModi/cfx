/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.cache.util.CacheUtil;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.exception.NoSuchConnectionTypeException;
import com.jio.master.telecom.exception.NoSuchServiceTypeException;
import com.jio.master.telecom.model.ConnectionType;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.model.PlanCategory;
import com.jio.master.telecom.model.PlanCategoryGroup;
import com.jio.master.telecom.model.ServiceType;
import com.jio.master.telecom.service.ConnectionTypeLocalService;
import com.jio.master.telecom.service.PlanCategoryGroupLocalService;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.ADD_PLAN, "mvc.command.name=" + MVCCommandNames.SEARCH_PLAN }, service = MVCRenderCommand.class)
public class AddPlanMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private ConnectionTypeLocalService connectionTypeLocalService;

	@Reference
	private PlanCategoryGroupLocalService planCategoryGroupLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private CacheUtil cacheUtil;

	private static final Log LOGGER = LogFactoryUtil.getLog(AddPlanMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);
		String accountNo = ParamUtil.getString(renderRequest, "accountNo");

		try {
			String payTerm = JioPropsUtil.get(ConfigConstant.DEFAULT_PLAN_DURATION, companyId);

			Customer customer = customerLocalService.getCustomer(accountNo, companyId);
			Address address = addressLocalService.getAddress(companyId, customer.getScreenName());
			String cityCode = address.getCityCode();
			String serviceTypeCode = customer.getServiceType();
			String connectionTypeCode = customer.getConnectionType();
			String lcoCode = customer.getAgentScreenName();
			PortletURL iteratorURL = renderResponse.createRenderURL();
			iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
			try {
				iteratorURL.setWindowState(WindowState.NORMAL);
			} catch (WindowStateException e) {
				LOGGER.error(e.toString());
			}
			List<Plan> plans = new ArrayList<Plan>();

			try {

				List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, companyId);
				String selectedPlanCodes = cps.stream().map(cp -> cp.getPlanCode()).collect(Collectors.joining(StringPool.COMMA));
				renderRequest.setAttribute("selectedPlanCodes", selectedPlanCodes);

				int selectedPlanCount = customerPlanService.getCPCount(cps);
				renderRequest.setAttribute("selectedPlanCount", selectedPlanCount);

				String selectedPlanNames = cps.stream().map(cp -> cp.getPlanName()).collect(Collectors.joining(StringPool.COMMA_AND_SPACE));
				renderRequest.setAttribute("selectedPlanNames", selectedPlanNames);

				ServiceType serviceType = serviceTypeLocalService.getServiceTypeByCode(serviceTypeCode, companyId);
				long serviceTypeId = serviceType.getServiceTypeId();

				ConnectionType connectionType = connectionTypeLocalService.getConnectionTypeByCode(connectionTypeCode, companyId);
				long connectionTypeId = connectionType.getConnectionTypeId();

				if (cps.isEmpty()) {

					List<PlanCategoryGroup> planCategoryGroups = planCategoryGroupLocalService.getPlanCategoryGroups(true, true, serviceTypeId, companyId);
					long[] categoryGroupIds = planCategoryGroups.stream().map(planCategoryGroup -> planCategoryGroup.getCategoryGroupId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();
					renderRequest.setAttribute("planCategoryGroups", planCategoryGroups);

					List<PlanCategory> planCategories = planCategoryLocalService.getPlanCategories(true, serviceTypeId, categoryGroupIds, companyId);
					long[] categoryIds = planCategories.stream().map(planCategory -> planCategory.getCategoryId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();

					// plans = cacheUtil.getBasicPlans(connectionTypeCode, categoryIds, serviceTypeId, connectionTypeId, new String[] { cityCode }, lcoCode, true, companyId);
					if (connectionTypeCode.equalsIgnoreCase("SD")) {
						plans = planLocalService.getPlans(categoryIds, serviceTypeId, connectionTypeId, new String[] { cityCode }, lcoCode, true, companyId);
						if (plans.isEmpty()) {
							plans = planLocalService.getPlans(categoryIds, serviceTypeId, connectionTypeId, new String[] { cityCode }, true, companyId);
						}
					} else if (connectionTypeCode.equalsIgnoreCase("HD")) {
						plans = planLocalService.getPlansByCategory(categoryIds, serviceTypeId, new String[] { cityCode }, lcoCode, true, companyId);
						if (plans.isEmpty()) {
							plans = planLocalService.getPlansByCategory(categoryIds, serviceTypeId, new String[] { cityCode }, true, companyId);
						}
					}

				} else {

					Date startTime = new Date();
					Date endTime = customerPlanService.getEndTime(customerPlanUtil.getEndDate(startTime), customer, companyId);

					payTerm = String.valueOf(customerPlanUtil.getDiffInDays(startTime, endTime));

					List<PlanCategoryGroup> planCategoryGroups = null;
					Optional<CP> mappingCP = cps.stream().filter(cp -> (cp.isOnce() && cp.isMapping())).findAny();
					if (mappingCP.isPresent()) {
						planCategoryGroups = planCategoryGroupLocalService.getPlanCategoryGroups(true, false, false, serviceTypeId, companyId);
					} else {
						planCategoryGroups = planCategoryGroupLocalService.getPlanCategoryGroups(true, false, serviceTypeId, companyId);
					}
					long[] categoryGroupIds = planCategoryGroups.stream().map(planCategoryGroup -> planCategoryGroup.getCategoryGroupId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();
					renderRequest.setAttribute("planCategoryGroups", planCategoryGroups);

					List<PlanCategory> planCategories = planCategoryLocalService.getPlanCategories(false, serviceTypeId, categoryGroupIds, companyId);
					long[] categoryIds = planCategories.stream().map(planCategory -> planCategory.getCategoryId()).collect(Collectors.toList()).stream().mapToLong(i -> i).toArray();

					Map<Long, Boolean> oncePlanCategoryGroups = planCategoryGroups.stream().collect(Collectors.toMap(PlanCategoryGroup::getCategoryGroupId, PlanCategoryGroup::isOnce));
					renderRequest.setAttribute("oncePlanCategoryGroups", oncePlanCategoryGroups);

					// plans = cacheUtil.getPlans(connectionTypeCode, categoryIds, serviceTypeId, connectionTypeId, new String[] { cityCode }, lcoCode, companyId);
					if (connectionTypeCode.equalsIgnoreCase("SD")) {
						plans = planLocalService.getPlans(categoryIds, serviceTypeId, connectionTypeId, new String[] { cityCode }, lcoCode, companyId);
						if (plans.isEmpty()) {
							plans = planLocalService.getPlans(categoryIds, serviceTypeId, connectionTypeId, new String[] { cityCode }, companyId);
						}
					} else if (connectionTypeCode.equalsIgnoreCase("HD")) {
						plans = planLocalService.getPlansByCategory(categoryIds, serviceTypeId, new String[] { cityCode }, lcoCode, companyId);
						if (plans.isEmpty()) {
							plans = planLocalService.getPlansByCategory(categoryIds, serviceTypeId, new String[] { cityCode }, companyId);
						}
					}

				}

			} catch (NoSuchConnectionTypeException e) {
				LOGGER.error("NoSuchConnectionTypeException :: " + e.toString());
			} catch (NoSuchServiceTypeException e) {
				LOGGER.error("NoSuchServiceTypeException :: " + e.toString());
			}

			renderRequest.setAttribute("plans", plans);
			renderRequest.setAttribute("customer", customer);
			renderRequest.setAttribute("defaultPayTerm", JioPropsUtil.get(ConfigConstant.DEFAULT_PLAN_DURATION, companyId));
			renderRequest.setAttribute("payTerm", payTerm);
			renderRequest.setAttribute("ncfCodes", JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_CODE, companyId));
		} catch (NoSuchAddressException e) {
			LOGGER.error("NoSuchAddressException :: " + e.toString());
		} catch (NoSuchCustomerException e) {
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
		}

		return "/customerplan/add_plan.jsp";
	}
}