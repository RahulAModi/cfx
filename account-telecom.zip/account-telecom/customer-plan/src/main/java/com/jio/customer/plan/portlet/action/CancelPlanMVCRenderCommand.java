/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.customer.plan.portlet.action;

import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.Date;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.CANCEL_PLAN }, service = MVCRenderCommand.class)
public class CancelPlanMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	private static final Log LOGGER = LogFactoryUtil.getLog(CancelPlanMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);
		String accountNo = ParamUtil.getString(renderRequest, "accountNo");
		try {

			Customer customer = customerLocalService.getCustomer(accountNo, companyId);
			List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, true, companyId);

			Date startTime = new Date();
			Date endTime = customerPlanService.getEndTime(customerPlanUtil.getEndDate(startTime), customer, companyId);
			String payTerm = String.valueOf(customerPlanUtil.getDiffInDays(startTime, endTime));

			renderRequest.setAttribute("customer", customer);
			renderRequest.setAttribute("cps", cps);
			renderRequest.setAttribute("payTerm", payTerm);
			renderRequest.setAttribute("defaultPayTerm", JioPropsUtil.get(ConfigConstant.DEFAULT_PLAN_DURATION, companyId));

		} catch (NoSuchCustomerException e) {
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
		}

		return "/customerplan/cancel_plan.jsp";
	}
}