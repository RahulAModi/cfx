package com.jio.customer.plan.portlet.action;

import com.jio.account.model.Customer;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.GET_RENEW }, service = MVCResourceCommand.class)
public class GetRenewPlanMVCResourceCommand implements MVCResourceCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(GetRenewPlanMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean response = true;
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		try {
			String accountNo = ParamUtil.getString(resourceRequest, "accountNo"); // Customer ScreenName
			String[] cpIds = ParamUtil.getParameterValues(resourceRequest, "cpIds[]");
			Customer customer = customerLocalService.getCustomer(accountNo, companyId);
			double finalPrice = 0.00;
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
			DateFormat dateFormat = new SimpleDateFormat(JioPropsUtil.get(ConfigConstant.DATE_PATTERN, companyId));
			long diffInDays = GetterUtil.getLong(JioPropsUtil.get(ConfigConstant.DEFAULT_PLAN_DURATION, companyId));
			Date startTime = new Date();
			Date endTime = customerPlanService.getEndTime(customerPlanUtil.getEndDate(startTime), customer, companyId);
			if (customerPlanService.visibleRenewalCustomerPlan(endTime, companyId)) {
				startTime = endTime;
				endTime = customerPlanUtil.getEndDate(endTime);
			} else {
				startTime = customerPlanUtil.getStartDate(endTime);
			}
			List<JSONObject> jsonObjects = new ArrayList<JSONObject>();
			for (String cpId : cpIds) {
				CP cp = cpLocalService.getCP(cpId, companyId);

				if (!cp.isMandatory()) {
					CP mandatoryCP = customerPlanService.getMandatoryCP(customer, companyId);
					if (Validator.isNotNull(mandatoryCP) && mandatoryCP.getEndDate().compareTo(cp.getEndDate()) == 0) {
						jsonObjects = renewCP(mandatoryCP, customer, companyId, dateFormat, startTime, endTime, diffInDays);
						for (JSONObject cpObject : jsonObjects) {
							jsonArray.put(cpObject);
							finalPrice = finalPrice + cpObject.getDouble("cpAmount");
						}
					}
				}

				jsonObjects = renewCP(cp, customer, companyId, dateFormat, startTime, endTime, diffInDays);
				for (JSONObject cpObject : jsonObjects) {
					jsonArray.put(cpObject);
					finalPrice = finalPrice + cpObject.getDouble("cpAmount");
				}

				Plan plan = planLocalService.getPlanByCode(cp.getPlanCode(), companyId, cp.getCityCode());
				if (Validator.isNotNull(plan.getMappingCode())) {
					CP mappingCP = cpLocalService.getCP(accountNo, customer.getScreenName(), plan.getCode(), companyId);
					jsonObjects = renewCP(mappingCP, customer, companyId, dateFormat, startTime, endTime, diffInDays);
					for (JSONObject cpObject : jsonObjects) {
						jsonArray.put(cpObject);
						finalPrice = finalPrice + cpObject.getDouble("cpAmount");
					}
				}

			}
			jsonObject.put("cps", jsonArray);
			jsonObject.put("finalPrice", finalPrice);

		} catch (PortalException e) {
			LOGGER.error("PortalException : " + e.toString());
		}

		try {
			resourceResponse.getWriter().println(jsonObject.toString());
		} catch (IOException e) {
			LOGGER.error("IOException : " + e.toString());
		}

		return response;
	}

	private List<JSONObject> renewCP(CP cp, Customer customer, long companyId, DateFormat dateFormat, Date startDate, Date endDate, long diffInDays) {
		List<JSONObject> jsonObjects = new ArrayList<JSONObject>();
		try {
			Plan plan = planLocalService.getPlanByCode(cp.getPlanCode(), companyId, cp.getCityCode());
			double cpAmount = customerPlanUtil.getDebitPrice(diffInDays, plan.getLcoPrice());

			cp.setStartDate(startDate);
			cp.setEndDate(endDate);
			cp.setCpLcoPrice(plan.getLcoPrice());
			cp.setCpDuration(diffInDays);
			cp.setCpAmount(cpAmount);

			jsonObjects.add(getCPJsonObject(cp, dateFormat));

			// MANDATORY PLAN - NCF 1
			if (cp.isMandatory()) {
				try {
					plan = planLocalService.getPlanByCode(JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId, cp.getCityCode());
					cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId);
					cpAmount = customerPlanUtil.getDebitPrice(diffInDays, plan.getLcoPrice());

					cp.setStartDate(startDate);
					cp.setEndDate(endDate);
					cp.setCpLcoPrice(plan.getLcoPrice());
					cp.setCpDuration(diffInDays);
					cp.setCpAmount(cpAmount);

					jsonObjects.add(getCPJsonObject(cp, dateFormat));

				} catch (NoSuchPlanException e) {
					LOGGER.error("NoSuchPlanException : " + e.toString());
				} catch (NoSuchCPException e) {
					LOGGER.error("NoSuchPlanException : " + e.toString());
				}
			}
		} catch (NoSuchPlanException e) {
			LOGGER.error("NoSuchPlanException : " + e.toString());
		}

		return jsonObjects;
	}

	private JSONObject getCPJsonObject(CP cp, DateFormat dateFormat) {
		JSONObject cpObject = JSONFactoryUtil.createJSONObject();
		cpObject.put("planName", cp.getPlanName());
		cpObject.put("lcoPrice", cp.getCpLcoPrice());
		cpObject.put("cpAmount", cp.getCpAmount());
		cpObject.put("cpDuration", cp.getCpDuration());
		cpObject.put("startDate", dateFormat.format(cp.getStartDate()));
		cpObject.put("endDate", dateFormat.format(cp.getEndDate()));
		return cpObject;
	}

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private CPLocalService cpLocalService;

}