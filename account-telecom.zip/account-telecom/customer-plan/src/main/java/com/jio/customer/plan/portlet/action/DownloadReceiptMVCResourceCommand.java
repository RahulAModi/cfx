package com.jio.customer.plan.portlet.action;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchContactException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Contact;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.ContactLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.config.props.JioPropsValues;
import com.jio.currency.util.CurrencyUtil;
import com.jio.customer.plan.constants.CustomerPlanPortletKeys;
import com.jio.customer.plan.constants.MVCCommandNames;
import com.jio.master.location.constant.LocationConstant;
import com.jio.master.location.exception.NoSuchLocationException;
import com.jio.master.location.model.Location;
import com.jio.master.location.service.LocationLocalService;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + CustomerPlanPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD_RECEIPT }, service = MVCResourceCommand.class)
public class DownloadReceiptMVCResourceCommand implements MVCResourceCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(DownloadReceiptMVCResourceCommand.class);
	private final String PDF = "pdf";

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {

		boolean resource = true;

		long companyId = PortalUtil.getCompanyId(resourceRequest);
		String accountNo = ParamUtil.getString(resourceRequest, "accountNo");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			if (Validator.isNotNull(accountNo)) {
				Customer customer = customerLocalService.getCustomer(accountNo, companyId);
				Agent agent = agentLocalService.getAgent(companyId, customer.getAgentScreenName());

				Contact lcoContact = contactLocalService.getContact(companyId, agent.getScreenName());
				Contact customerContact = contactLocalService.getContact(companyId, customer.getScreenName());

				String lcoAddress = getAddress(companyId, agent.getScreenName());
				String customerAddress = getAddress(companyId, customer.getScreenName());
				String currentDate = dateFormat.format(new Date());
				String cin = StringPool.BLANK; // from which table this value is coming
				String receiptNo = AccountUtil.getRefNo("RC"); // from which table this value is coming
				String custFullName = customer.getFirstName().concat(StringPool.BLANK).concat(customer.getLastName());

				String registeredAddress = StringPool.BLANK; // from which table this value is coming

				List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, companyId);

				String productDetails = getCustomerPlans(cps);
				double total = getTotal(cps);
				double cgst = getCgst(cps);
				double sgst = getSgst(cps);
				String amountInWords = CurrencyUtil.getWordCurrency(total);

				try {
					String body = FileUtil.read(new File(JioPropsValues.CUSTOMER_RECEIPT_TMPL));
					body = StringUtil.replace(body,
							new String[] { "[$CURRENT_DATE$]", "[$LCO_NAME$]", "[$CIN$]", "[$PAN$]", "[$GSTIN$]", "[$HELPDESK_EMAIL$]", "[$LCO_PHONE$]", "[$RECEIPT_NO$]", "[$CUST_ACC_NO$]", "[$VC_ID$]", "[$CUST_NAME$]", "[$CUST_MOBILE$]", "[$CUST_EMAIL$]", "[$CUST_ADDRESS$]", "[$PRODUCT_DETAILS$]",
									"[$AMOUNT_IN_WORDS$]", "[$REGISTERED_OFFICE$]", "[$BRANCH_ADDRESS$]", "[$TOTAL$]", "[$CGST$]", "[$SGST$]" },
							new String[] { currentDate, agent.getName(), cin, agent.getPanNo(), agent.getGstinNo(), lcoContact.getEmail(), lcoContact.getMobileNo(), receiptNo, customer.getAccountNo(), customer.getVcId(), custFullName, customerContact.getMobileNo(), customerContact.getEmail(),
									customerAddress, productDetails, amountInWords, registeredAddress, lcoAddress, String.valueOf(total), String.valueOf(cgst), String.valueOf(sgst) });

					String fileName = receiptNo.concat(StringPool.PERIOD).concat(PDF);
					String filePath = JioPropsValues.RECEIPT_FOLDER_PATH.concat(File.separator).concat(fileName);
					File file = new File(filePath);

					Document document = new Document();
					PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));

					document.open();
					XMLWorkerHelper helper = XMLWorkerHelper.getInstance();
					helper.parseXHtml(writer, document, new ByteArrayInputStream(body.getBytes()));
					document.close();

					PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, new FileInputStream(file), ContentTypes.APPLICATION_PDF);

					if (file.exists()) {
						file.delete();
					}

				} catch (Exception e) {
					LOGGER.error("Exception :: " + e.toString());
					resource = false;
				}
			} else {
				resource = false;
			}
		} catch (NoSuchContactException e) {
			LOGGER.error("NoSuchContactException :: " + e.toString());
		} catch (NoSuchCustomerException e) {
			LOGGER.error("NoSuchCustomerException :: " + e.toString());
			resource = false;
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
			resource = false;
		}
		return resource;
	}

	private String getAddress(long companyId, String screenName) {
		String fullAddress = StringPool.BLANK;
		try {
			Address address = addressLocalService.getAddress(companyId, screenName);
			Map<String, Location> map = locationLocalService.getLocationByPinCode(address.getPincode(), companyId);
			String city = map.get(LocationConstant.CITY).getName();
			String state = map.get(LocationConstant.STATE).getName();
			fullAddress = new StringBundler().append("Building: " + address.getBuilding()).append(StringPool.SPACE).append("Flat No: " + address.getFlatNo()).append(StringPool.SPACE).append("Address: " + address.getAddress()).append(StringPool.SPACE).append("City: " + city).append(StringPool.SPACE)
					.append("State: " + state).toString();
		} catch (NoSuchLocationException e) {
			LOGGER.error("NoSuchLocationException :: " + e.toString());
		} catch (NoSuchAddressException e) {
			LOGGER.error("NoSuchAddressException :: " + e.toString());
		}
		return fullAddress;
	}

	private String getCustomerPlans(List<CP> cps) {
		StringBuilder sb = new StringBuilder();
		cps.parallelStream().forEach(cp -> {
			sb.append("<tr><td>" + cp.getPlanName() + "</td>" + "<td>" + cp.getPrice() + "</td></tr><tr><td>&nbsp;</td></tr>");
		});
		return sb.toString();
	}

	private double getTotal(List<CP> cps) {
		return cps.parallelStream().mapToDouble(cp -> cp.getPrice()).sum();
	}

	private double getCgst(List<CP> cps) {
		return cps.parallelStream().mapToDouble(cp -> cp.getCgstPrice()).sum();
	}

	private double getSgst(List<CP> cps) {
		return cps.parallelStream().mapToDouble(cp -> cp.getSgstPrice()).sum();
	}

	

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private ContactLocalService contactLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private LocationLocalService locationLocalService;

}