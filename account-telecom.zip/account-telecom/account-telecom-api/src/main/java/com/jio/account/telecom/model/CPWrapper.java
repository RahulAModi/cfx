/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link CP}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CP
 * @generated
 */
@ProviderType
public class CPWrapper
	extends BaseModelWrapper<CP> implements CP, ModelWrapper<CP> {

	public CPWrapper(CP cp) {
		super(cp);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("cpId", getCpId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("customerScreenName", getCustomerScreenName());
		attributes.put("accountNo", getAccountNo());
		attributes.put("vcId", getVcId());
		attributes.put("customerId", getCustomerId());
		attributes.put("active", isActive());
		attributes.put("startDate", getStartDate());
		attributes.put("endDate", getEndDate());
		attributes.put("planCode", getPlanCode());
		attributes.put("categoryCode", getCategoryCode());
		attributes.put("categoryGroupCode", getCategoryGroupCode());
		attributes.put("planMappingCode", getPlanMappingCode());
		attributes.put("planName", getPlanName());
		attributes.put("categoryName", getCategoryName());
		attributes.put("categoryGroupName", getCategoryGroupName());
		attributes.put("price", getPrice());
		attributes.put("basicPrice", getBasicPrice());
		attributes.put("cgstPrice", getCgstPrice());
		attributes.put("sgstPrice", getSgstPrice());
		attributes.put("lcoPrice", getLcoPrice());
		attributes.put("lcoBasicPrice", getLcoBasicPrice());
		attributes.put("lcoCgstPrice", getLcoCgstPrice());
		attributes.put("lcoSgstPrice", getLcoSgstPrice());
		attributes.put("bcPrice", getBcPrice());
		attributes.put("bcBasicPrice", getBcBasicPrice());
		attributes.put("bcCgstPrice", getBcCgstPrice());
		attributes.put("bcSgstPrice", getBcSgstPrice());
		attributes.put("sdCount", getSdCount());
		attributes.put("hdCount", getHdCount());
		attributes.put("ncfCount", getNcfCount());
		attributes.put("priority", getPriority());
		attributes.put("reason", getReason());
		attributes.put("autoRenew", isAutoRenew());
		attributes.put("mandatory", isMandatory());
		attributes.put("visible", isVisible());
		attributes.put("once", isOnce());
		attributes.put("mapping", isMapping());
		attributes.put("cityCode", getCityCode());
		attributes.put("planPoId", getPlanPoId());
		attributes.put("dealPoId", getDealPoId());
		attributes.put("packageId", getPackageId());
		attributes.put("purchasedProductPoId", getPurchasedProductPoId());
		attributes.put("productPoId", getProductPoId());
		attributes.put("agentBalanceId", getAgentBalanceId());
		attributes.put("cpLcoPrice", getCpLcoPrice());
		attributes.put("cpAmount", getCpAmount());
		attributes.put("cpDuration", getCpDuration());
		attributes.put("cpEndDate", getCpEndDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String cpId = (String)attributes.get("cpId");

		if (cpId != null) {
			setCpId(cpId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String customerScreenName = (String)attributes.get(
			"customerScreenName");

		if (customerScreenName != null) {
			setCustomerScreenName(customerScreenName);
		}

		String accountNo = (String)attributes.get("accountNo");

		if (accountNo != null) {
			setAccountNo(accountNo);
		}

		String vcId = (String)attributes.get("vcId");

		if (vcId != null) {
			setVcId(vcId);
		}

		String customerId = (String)attributes.get("customerId");

		if (customerId != null) {
			setCustomerId(customerId);
		}

		Boolean active = (Boolean)attributes.get("active");

		if (active != null) {
			setActive(active);
		}

		Date startDate = (Date)attributes.get("startDate");

		if (startDate != null) {
			setStartDate(startDate);
		}

		Date endDate = (Date)attributes.get("endDate");

		if (endDate != null) {
			setEndDate(endDate);
		}

		String planCode = (String)attributes.get("planCode");

		if (planCode != null) {
			setPlanCode(planCode);
		}

		String categoryCode = (String)attributes.get("categoryCode");

		if (categoryCode != null) {
			setCategoryCode(categoryCode);
		}

		String categoryGroupCode = (String)attributes.get("categoryGroupCode");

		if (categoryGroupCode != null) {
			setCategoryGroupCode(categoryGroupCode);
		}

		String planMappingCode = (String)attributes.get("planMappingCode");

		if (planMappingCode != null) {
			setPlanMappingCode(planMappingCode);
		}

		String planName = (String)attributes.get("planName");

		if (planName != null) {
			setPlanName(planName);
		}

		String categoryName = (String)attributes.get("categoryName");

		if (categoryName != null) {
			setCategoryName(categoryName);
		}

		String categoryGroupName = (String)attributes.get("categoryGroupName");

		if (categoryGroupName != null) {
			setCategoryGroupName(categoryGroupName);
		}

		Double price = (Double)attributes.get("price");

		if (price != null) {
			setPrice(price);
		}

		Double basicPrice = (Double)attributes.get("basicPrice");

		if (basicPrice != null) {
			setBasicPrice(basicPrice);
		}

		Double cgstPrice = (Double)attributes.get("cgstPrice");

		if (cgstPrice != null) {
			setCgstPrice(cgstPrice);
		}

		Double sgstPrice = (Double)attributes.get("sgstPrice");

		if (sgstPrice != null) {
			setSgstPrice(sgstPrice);
		}

		Double lcoPrice = (Double)attributes.get("lcoPrice");

		if (lcoPrice != null) {
			setLcoPrice(lcoPrice);
		}

		Double lcoBasicPrice = (Double)attributes.get("lcoBasicPrice");

		if (lcoBasicPrice != null) {
			setLcoBasicPrice(lcoBasicPrice);
		}

		Double lcoCgstPrice = (Double)attributes.get("lcoCgstPrice");

		if (lcoCgstPrice != null) {
			setLcoCgstPrice(lcoCgstPrice);
		}

		Double lcoSgstPrice = (Double)attributes.get("lcoSgstPrice");

		if (lcoSgstPrice != null) {
			setLcoSgstPrice(lcoSgstPrice);
		}

		Double bcPrice = (Double)attributes.get("bcPrice");

		if (bcPrice != null) {
			setBcPrice(bcPrice);
		}

		Double bcBasicPrice = (Double)attributes.get("bcBasicPrice");

		if (bcBasicPrice != null) {
			setBcBasicPrice(bcBasicPrice);
		}

		Double bcCgstPrice = (Double)attributes.get("bcCgstPrice");

		if (bcCgstPrice != null) {
			setBcCgstPrice(bcCgstPrice);
		}

		Double bcSgstPrice = (Double)attributes.get("bcSgstPrice");

		if (bcSgstPrice != null) {
			setBcSgstPrice(bcSgstPrice);
		}

		Integer sdCount = (Integer)attributes.get("sdCount");

		if (sdCount != null) {
			setSdCount(sdCount);
		}

		Integer hdCount = (Integer)attributes.get("hdCount");

		if (hdCount != null) {
			setHdCount(hdCount);
		}

		Integer ncfCount = (Integer)attributes.get("ncfCount");

		if (ncfCount != null) {
			setNcfCount(ncfCount);
		}

		Integer priority = (Integer)attributes.get("priority");

		if (priority != null) {
			setPriority(priority);
		}

		String reason = (String)attributes.get("reason");

		if (reason != null) {
			setReason(reason);
		}

		Boolean autoRenew = (Boolean)attributes.get("autoRenew");

		if (autoRenew != null) {
			setAutoRenew(autoRenew);
		}

		Boolean mandatory = (Boolean)attributes.get("mandatory");

		if (mandatory != null) {
			setMandatory(mandatory);
		}

		Boolean visible = (Boolean)attributes.get("visible");

		if (visible != null) {
			setVisible(visible);
		}

		Boolean once = (Boolean)attributes.get("once");

		if (once != null) {
			setOnce(once);
		}

		Boolean mapping = (Boolean)attributes.get("mapping");

		if (mapping != null) {
			setMapping(mapping);
		}

		String cityCode = (String)attributes.get("cityCode");

		if (cityCode != null) {
			setCityCode(cityCode);
		}

		String planPoId = (String)attributes.get("planPoId");

		if (planPoId != null) {
			setPlanPoId(planPoId);
		}

		String dealPoId = (String)attributes.get("dealPoId");

		if (dealPoId != null) {
			setDealPoId(dealPoId);
		}

		String packageId = (String)attributes.get("packageId");

		if (packageId != null) {
			setPackageId(packageId);
		}

		String purchasedProductPoId = (String)attributes.get(
			"purchasedProductPoId");

		if (purchasedProductPoId != null) {
			setPurchasedProductPoId(purchasedProductPoId);
		}

		String productPoId = (String)attributes.get("productPoId");

		if (productPoId != null) {
			setProductPoId(productPoId);
		}

		Long agentBalanceId = (Long)attributes.get("agentBalanceId");

		if (agentBalanceId != null) {
			setAgentBalanceId(agentBalanceId);
		}

		Double cpLcoPrice = (Double)attributes.get("cpLcoPrice");

		if (cpLcoPrice != null) {
			setCpLcoPrice(cpLcoPrice);
		}

		Double cpAmount = (Double)attributes.get("cpAmount");

		if (cpAmount != null) {
			setCpAmount(cpAmount);
		}

		Long cpDuration = (Long)attributes.get("cpDuration");

		if (cpDuration != null) {
			setCpDuration(cpDuration);
		}

		Date cpEndDate = (Date)attributes.get("cpEndDate");

		if (cpEndDate != null) {
			setCpEndDate(cpEndDate);
		}
	}

	/**
	 * Returns the account no of this cp.
	 *
	 * @return the account no of this cp
	 */
	@Override
	public String getAccountNo() {
		return model.getAccountNo();
	}

	/**
	 * Returns the active of this cp.
	 *
	 * @return the active of this cp
	 */
	@Override
	public boolean getActive() {
		return model.getActive();
	}

	/**
	 * Returns the agent balance ID of this cp.
	 *
	 * @return the agent balance ID of this cp
	 */
	@Override
	public long getAgentBalanceId() {
		return model.getAgentBalanceId();
	}

	/**
	 * Returns the auto renew of this cp.
	 *
	 * @return the auto renew of this cp
	 */
	@Override
	public boolean getAutoRenew() {
		return model.getAutoRenew();
	}

	/**
	 * Returns the basic price of this cp.
	 *
	 * @return the basic price of this cp
	 */
	@Override
	public double getBasicPrice() {
		return model.getBasicPrice();
	}

	/**
	 * Returns the bc basic price of this cp.
	 *
	 * @return the bc basic price of this cp
	 */
	@Override
	public double getBcBasicPrice() {
		return model.getBcBasicPrice();
	}

	/**
	 * Returns the bc cgst price of this cp.
	 *
	 * @return the bc cgst price of this cp
	 */
	@Override
	public double getBcCgstPrice() {
		return model.getBcCgstPrice();
	}

	/**
	 * Returns the bc price of this cp.
	 *
	 * @return the bc price of this cp
	 */
	@Override
	public double getBcPrice() {
		return model.getBcPrice();
	}

	/**
	 * Returns the bc sgst price of this cp.
	 *
	 * @return the bc sgst price of this cp
	 */
	@Override
	public double getBcSgstPrice() {
		return model.getBcSgstPrice();
	}

	/**
	 * Returns the category code of this cp.
	 *
	 * @return the category code of this cp
	 */
	@Override
	public String getCategoryCode() {
		return model.getCategoryCode();
	}

	/**
	 * Returns the category group code of this cp.
	 *
	 * @return the category group code of this cp
	 */
	@Override
	public String getCategoryGroupCode() {
		return model.getCategoryGroupCode();
	}

	/**
	 * Returns the category group name of this cp.
	 *
	 * @return the category group name of this cp
	 */
	@Override
	public String getCategoryGroupName() {
		return model.getCategoryGroupName();
	}

	/**
	 * Returns the category name of this cp.
	 *
	 * @return the category name of this cp
	 */
	@Override
	public String getCategoryName() {
		return model.getCategoryName();
	}

	/**
	 * Returns the cgst price of this cp.
	 *
	 * @return the cgst price of this cp
	 */
	@Override
	public double getCgstPrice() {
		return model.getCgstPrice();
	}

	/**
	 * Returns the city code of this cp.
	 *
	 * @return the city code of this cp
	 */
	@Override
	public String getCityCode() {
		return model.getCityCode();
	}

	/**
	 * Returns the company ID of this cp.
	 *
	 * @return the company ID of this cp
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the cp amount of this cp.
	 *
	 * @return the cp amount of this cp
	 */
	@Override
	public double getCpAmount() {
		return model.getCpAmount();
	}

	/**
	 * Returns the cp duration of this cp.
	 *
	 * @return the cp duration of this cp
	 */
	@Override
	public long getCpDuration() {
		return model.getCpDuration();
	}

	/**
	 * Returns the cp end date of this cp.
	 *
	 * @return the cp end date of this cp
	 */
	@Override
	public Date getCpEndDate() {
		return model.getCpEndDate();
	}

	/**
	 * Returns the cp ID of this cp.
	 *
	 * @return the cp ID of this cp
	 */
	@Override
	public String getCpId() {
		return model.getCpId();
	}

	/**
	 * Returns the cp lco price of this cp.
	 *
	 * @return the cp lco price of this cp
	 */
	@Override
	public double getCpLcoPrice() {
		return model.getCpLcoPrice();
	}

	/**
	 * Returns the create by of this cp.
	 *
	 * @return the create by of this cp
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this cp.
	 *
	 * @return the create date of this cp
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the customer ID of this cp.
	 *
	 * @return the customer ID of this cp
	 */
	@Override
	public String getCustomerId() {
		return model.getCustomerId();
	}

	/**
	 * Returns the customer screen name of this cp.
	 *
	 * @return the customer screen name of this cp
	 */
	@Override
	public String getCustomerScreenName() {
		return model.getCustomerScreenName();
	}

	/**
	 * Returns the deal po ID of this cp.
	 *
	 * @return the deal po ID of this cp
	 */
	@Override
	public String getDealPoId() {
		return model.getDealPoId();
	}

	/**
	 * Returns the end date of this cp.
	 *
	 * @return the end date of this cp
	 */
	@Override
	public Date getEndDate() {
		return model.getEndDate();
	}

	/**
	 * Returns the group ID of this cp.
	 *
	 * @return the group ID of this cp
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the hd count of this cp.
	 *
	 * @return the hd count of this cp
	 */
	@Override
	public int getHdCount() {
		return model.getHdCount();
	}

	/**
	 * Returns the lco basic price of this cp.
	 *
	 * @return the lco basic price of this cp
	 */
	@Override
	public double getLcoBasicPrice() {
		return model.getLcoBasicPrice();
	}

	/**
	 * Returns the lco cgst price of this cp.
	 *
	 * @return the lco cgst price of this cp
	 */
	@Override
	public double getLcoCgstPrice() {
		return model.getLcoCgstPrice();
	}

	/**
	 * Returns the lco price of this cp.
	 *
	 * @return the lco price of this cp
	 */
	@Override
	public double getLcoPrice() {
		return model.getLcoPrice();
	}

	/**
	 * Returns the lco sgst price of this cp.
	 *
	 * @return the lco sgst price of this cp
	 */
	@Override
	public double getLcoSgstPrice() {
		return model.getLcoSgstPrice();
	}

	/**
	 * Returns the mandatory of this cp.
	 *
	 * @return the mandatory of this cp
	 */
	@Override
	public boolean getMandatory() {
		return model.getMandatory();
	}

	/**
	 * Returns the mapping of this cp.
	 *
	 * @return the mapping of this cp
	 */
	@Override
	public boolean getMapping() {
		return model.getMapping();
	}

	/**
	 * Returns the modified date of this cp.
	 *
	 * @return the modified date of this cp
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the ncf count of this cp.
	 *
	 * @return the ncf count of this cp
	 */
	@Override
	public int getNcfCount() {
		return model.getNcfCount();
	}

	/**
	 * Returns the once of this cp.
	 *
	 * @return the once of this cp
	 */
	@Override
	public boolean getOnce() {
		return model.getOnce();
	}

	/**
	 * Returns the package ID of this cp.
	 *
	 * @return the package ID of this cp
	 */
	@Override
	public String getPackageId() {
		return model.getPackageId();
	}

	/**
	 * Returns the plan code of this cp.
	 *
	 * @return the plan code of this cp
	 */
	@Override
	public String getPlanCode() {
		return model.getPlanCode();
	}

	/**
	 * Returns the plan mapping code of this cp.
	 *
	 * @return the plan mapping code of this cp
	 */
	@Override
	public String getPlanMappingCode() {
		return model.getPlanMappingCode();
	}

	/**
	 * Returns the plan name of this cp.
	 *
	 * @return the plan name of this cp
	 */
	@Override
	public String getPlanName() {
		return model.getPlanName();
	}

	/**
	 * Returns the plan po ID of this cp.
	 *
	 * @return the plan po ID of this cp
	 */
	@Override
	public String getPlanPoId() {
		return model.getPlanPoId();
	}

	/**
	 * Returns the price of this cp.
	 *
	 * @return the price of this cp
	 */
	@Override
	public double getPrice() {
		return model.getPrice();
	}

	/**
	 * Returns the primary key of this cp.
	 *
	 * @return the primary key of this cp
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the priority of this cp.
	 *
	 * @return the priority of this cp
	 */
	@Override
	public int getPriority() {
		return model.getPriority();
	}

	/**
	 * Returns the product po ID of this cp.
	 *
	 * @return the product po ID of this cp
	 */
	@Override
	public String getProductPoId() {
		return model.getProductPoId();
	}

	/**
	 * Returns the purchased product po ID of this cp.
	 *
	 * @return the purchased product po ID of this cp
	 */
	@Override
	public String getPurchasedProductPoId() {
		return model.getPurchasedProductPoId();
	}

	/**
	 * Returns the reason of this cp.
	 *
	 * @return the reason of this cp
	 */
	@Override
	public String getReason() {
		return model.getReason();
	}

	/**
	 * Returns the sd count of this cp.
	 *
	 * @return the sd count of this cp
	 */
	@Override
	public int getSdCount() {
		return model.getSdCount();
	}

	/**
	 * Returns the sgst price of this cp.
	 *
	 * @return the sgst price of this cp
	 */
	@Override
	public double getSgstPrice() {
		return model.getSgstPrice();
	}

	/**
	 * Returns the start date of this cp.
	 *
	 * @return the start date of this cp
	 */
	@Override
	public Date getStartDate() {
		return model.getStartDate();
	}

	/**
	 * Returns the vc ID of this cp.
	 *
	 * @return the vc ID of this cp
	 */
	@Override
	public String getVcId() {
		return model.getVcId();
	}

	/**
	 * Returns the visible of this cp.
	 *
	 * @return the visible of this cp
	 */
	@Override
	public boolean getVisible() {
		return model.getVisible();
	}

	/**
	 * Returns <code>true</code> if this cp is active.
	 *
	 * @return <code>true</code> if this cp is active; <code>false</code> otherwise
	 */
	@Override
	public boolean isActive() {
		return model.isActive();
	}

	/**
	 * Returns <code>true</code> if this cp is auto renew.
	 *
	 * @return <code>true</code> if this cp is auto renew; <code>false</code> otherwise
	 */
	@Override
	public boolean isAutoRenew() {
		return model.isAutoRenew();
	}

	/**
	 * Returns <code>true</code> if this cp is mandatory.
	 *
	 * @return <code>true</code> if this cp is mandatory; <code>false</code> otherwise
	 */
	@Override
	public boolean isMandatory() {
		return model.isMandatory();
	}

	/**
	 * Returns <code>true</code> if this cp is mapping.
	 *
	 * @return <code>true</code> if this cp is mapping; <code>false</code> otherwise
	 */
	@Override
	public boolean isMapping() {
		return model.isMapping();
	}

	/**
	 * Returns <code>true</code> if this cp is once.
	 *
	 * @return <code>true</code> if this cp is once; <code>false</code> otherwise
	 */
	@Override
	public boolean isOnce() {
		return model.isOnce();
	}

	/**
	 * Returns <code>true</code> if this cp is visible.
	 *
	 * @return <code>true</code> if this cp is visible; <code>false</code> otherwise
	 */
	@Override
	public boolean isVisible() {
		return model.isVisible();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the account no of this cp.
	 *
	 * @param accountNo the account no of this cp
	 */
	@Override
	public void setAccountNo(String accountNo) {
		model.setAccountNo(accountNo);
	}

	/**
	 * Sets whether this cp is active.
	 *
	 * @param active the active of this cp
	 */
	@Override
	public void setActive(boolean active) {
		model.setActive(active);
	}

	/**
	 * Sets the agent balance ID of this cp.
	 *
	 * @param agentBalanceId the agent balance ID of this cp
	 */
	@Override
	public void setAgentBalanceId(long agentBalanceId) {
		model.setAgentBalanceId(agentBalanceId);
	}

	/**
	 * Sets whether this cp is auto renew.
	 *
	 * @param autoRenew the auto renew of this cp
	 */
	@Override
	public void setAutoRenew(boolean autoRenew) {
		model.setAutoRenew(autoRenew);
	}

	/**
	 * Sets the basic price of this cp.
	 *
	 * @param basicPrice the basic price of this cp
	 */
	@Override
	public void setBasicPrice(double basicPrice) {
		model.setBasicPrice(basicPrice);
	}

	/**
	 * Sets the bc basic price of this cp.
	 *
	 * @param bcBasicPrice the bc basic price of this cp
	 */
	@Override
	public void setBcBasicPrice(double bcBasicPrice) {
		model.setBcBasicPrice(bcBasicPrice);
	}

	/**
	 * Sets the bc cgst price of this cp.
	 *
	 * @param bcCgstPrice the bc cgst price of this cp
	 */
	@Override
	public void setBcCgstPrice(double bcCgstPrice) {
		model.setBcCgstPrice(bcCgstPrice);
	}

	/**
	 * Sets the bc price of this cp.
	 *
	 * @param bcPrice the bc price of this cp
	 */
	@Override
	public void setBcPrice(double bcPrice) {
		model.setBcPrice(bcPrice);
	}

	/**
	 * Sets the bc sgst price of this cp.
	 *
	 * @param bcSgstPrice the bc sgst price of this cp
	 */
	@Override
	public void setBcSgstPrice(double bcSgstPrice) {
		model.setBcSgstPrice(bcSgstPrice);
	}

	/**
	 * Sets the category code of this cp.
	 *
	 * @param categoryCode the category code of this cp
	 */
	@Override
	public void setCategoryCode(String categoryCode) {
		model.setCategoryCode(categoryCode);
	}

	/**
	 * Sets the category group code of this cp.
	 *
	 * @param categoryGroupCode the category group code of this cp
	 */
	@Override
	public void setCategoryGroupCode(String categoryGroupCode) {
		model.setCategoryGroupCode(categoryGroupCode);
	}

	/**
	 * Sets the category group name of this cp.
	 *
	 * @param categoryGroupName the category group name of this cp
	 */
	@Override
	public void setCategoryGroupName(String categoryGroupName) {
		model.setCategoryGroupName(categoryGroupName);
	}

	/**
	 * Sets the category name of this cp.
	 *
	 * @param categoryName the category name of this cp
	 */
	@Override
	public void setCategoryName(String categoryName) {
		model.setCategoryName(categoryName);
	}

	/**
	 * Sets the cgst price of this cp.
	 *
	 * @param cgstPrice the cgst price of this cp
	 */
	@Override
	public void setCgstPrice(double cgstPrice) {
		model.setCgstPrice(cgstPrice);
	}

	/**
	 * Sets the city code of this cp.
	 *
	 * @param cityCode the city code of this cp
	 */
	@Override
	public void setCityCode(String cityCode) {
		model.setCityCode(cityCode);
	}

	/**
	 * Sets the company ID of this cp.
	 *
	 * @param companyId the company ID of this cp
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the cp amount of this cp.
	 *
	 * @param cpAmount the cp amount of this cp
	 */
	@Override
	public void setCpAmount(double cpAmount) {
		model.setCpAmount(cpAmount);
	}

	/**
	 * Sets the cp duration of this cp.
	 *
	 * @param cpDuration the cp duration of this cp
	 */
	@Override
	public void setCpDuration(long cpDuration) {
		model.setCpDuration(cpDuration);
	}

	/**
	 * Sets the cp end date of this cp.
	 *
	 * @param cpEndDate the cp end date of this cp
	 */
	@Override
	public void setCpEndDate(Date cpEndDate) {
		model.setCpEndDate(cpEndDate);
	}

	/**
	 * Sets the cp ID of this cp.
	 *
	 * @param cpId the cp ID of this cp
	 */
	@Override
	public void setCpId(String cpId) {
		model.setCpId(cpId);
	}

	/**
	 * Sets the cp lco price of this cp.
	 *
	 * @param cpLcoPrice the cp lco price of this cp
	 */
	@Override
	public void setCpLcoPrice(double cpLcoPrice) {
		model.setCpLcoPrice(cpLcoPrice);
	}

	/**
	 * Sets the create by of this cp.
	 *
	 * @param createBy the create by of this cp
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this cp.
	 *
	 * @param createDate the create date of this cp
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the customer ID of this cp.
	 *
	 * @param customerId the customer ID of this cp
	 */
	@Override
	public void setCustomerId(String customerId) {
		model.setCustomerId(customerId);
	}

	/**
	 * Sets the customer screen name of this cp.
	 *
	 * @param customerScreenName the customer screen name of this cp
	 */
	@Override
	public void setCustomerScreenName(String customerScreenName) {
		model.setCustomerScreenName(customerScreenName);
	}

	/**
	 * Sets the deal po ID of this cp.
	 *
	 * @param dealPoId the deal po ID of this cp
	 */
	@Override
	public void setDealPoId(String dealPoId) {
		model.setDealPoId(dealPoId);
	}

	/**
	 * Sets the end date of this cp.
	 *
	 * @param endDate the end date of this cp
	 */
	@Override
	public void setEndDate(Date endDate) {
		model.setEndDate(endDate);
	}

	/**
	 * Sets the group ID of this cp.
	 *
	 * @param groupId the group ID of this cp
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the hd count of this cp.
	 *
	 * @param hdCount the hd count of this cp
	 */
	@Override
	public void setHdCount(int hdCount) {
		model.setHdCount(hdCount);
	}

	/**
	 * Sets the lco basic price of this cp.
	 *
	 * @param lcoBasicPrice the lco basic price of this cp
	 */
	@Override
	public void setLcoBasicPrice(double lcoBasicPrice) {
		model.setLcoBasicPrice(lcoBasicPrice);
	}

	/**
	 * Sets the lco cgst price of this cp.
	 *
	 * @param lcoCgstPrice the lco cgst price of this cp
	 */
	@Override
	public void setLcoCgstPrice(double lcoCgstPrice) {
		model.setLcoCgstPrice(lcoCgstPrice);
	}

	/**
	 * Sets the lco price of this cp.
	 *
	 * @param lcoPrice the lco price of this cp
	 */
	@Override
	public void setLcoPrice(double lcoPrice) {
		model.setLcoPrice(lcoPrice);
	}

	/**
	 * Sets the lco sgst price of this cp.
	 *
	 * @param lcoSgstPrice the lco sgst price of this cp
	 */
	@Override
	public void setLcoSgstPrice(double lcoSgstPrice) {
		model.setLcoSgstPrice(lcoSgstPrice);
	}

	/**
	 * Sets whether this cp is mandatory.
	 *
	 * @param mandatory the mandatory of this cp
	 */
	@Override
	public void setMandatory(boolean mandatory) {
		model.setMandatory(mandatory);
	}

	/**
	 * Sets whether this cp is mapping.
	 *
	 * @param mapping the mapping of this cp
	 */
	@Override
	public void setMapping(boolean mapping) {
		model.setMapping(mapping);
	}

	/**
	 * Sets the modified date of this cp.
	 *
	 * @param modifiedDate the modified date of this cp
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the ncf count of this cp.
	 *
	 * @param ncfCount the ncf count of this cp
	 */
	@Override
	public void setNcfCount(int ncfCount) {
		model.setNcfCount(ncfCount);
	}

	/**
	 * Sets whether this cp is once.
	 *
	 * @param once the once of this cp
	 */
	@Override
	public void setOnce(boolean once) {
		model.setOnce(once);
	}

	/**
	 * Sets the package ID of this cp.
	 *
	 * @param packageId the package ID of this cp
	 */
	@Override
	public void setPackageId(String packageId) {
		model.setPackageId(packageId);
	}

	/**
	 * Sets the plan code of this cp.
	 *
	 * @param planCode the plan code of this cp
	 */
	@Override
	public void setPlanCode(String planCode) {
		model.setPlanCode(planCode);
	}

	/**
	 * Sets the plan mapping code of this cp.
	 *
	 * @param planMappingCode the plan mapping code of this cp
	 */
	@Override
	public void setPlanMappingCode(String planMappingCode) {
		model.setPlanMappingCode(planMappingCode);
	}

	/**
	 * Sets the plan name of this cp.
	 *
	 * @param planName the plan name of this cp
	 */
	@Override
	public void setPlanName(String planName) {
		model.setPlanName(planName);
	}

	/**
	 * Sets the plan po ID of this cp.
	 *
	 * @param planPoId the plan po ID of this cp
	 */
	@Override
	public void setPlanPoId(String planPoId) {
		model.setPlanPoId(planPoId);
	}

	/**
	 * Sets the price of this cp.
	 *
	 * @param price the price of this cp
	 */
	@Override
	public void setPrice(double price) {
		model.setPrice(price);
	}

	/**
	 * Sets the primary key of this cp.
	 *
	 * @param primaryKey the primary key of this cp
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the priority of this cp.
	 *
	 * @param priority the priority of this cp
	 */
	@Override
	public void setPriority(int priority) {
		model.setPriority(priority);
	}

	/**
	 * Sets the product po ID of this cp.
	 *
	 * @param productPoId the product po ID of this cp
	 */
	@Override
	public void setProductPoId(String productPoId) {
		model.setProductPoId(productPoId);
	}

	/**
	 * Sets the purchased product po ID of this cp.
	 *
	 * @param purchasedProductPoId the purchased product po ID of this cp
	 */
	@Override
	public void setPurchasedProductPoId(String purchasedProductPoId) {
		model.setPurchasedProductPoId(purchasedProductPoId);
	}

	/**
	 * Sets the reason of this cp.
	 *
	 * @param reason the reason of this cp
	 */
	@Override
	public void setReason(String reason) {
		model.setReason(reason);
	}

	/**
	 * Sets the sd count of this cp.
	 *
	 * @param sdCount the sd count of this cp
	 */
	@Override
	public void setSdCount(int sdCount) {
		model.setSdCount(sdCount);
	}

	/**
	 * Sets the sgst price of this cp.
	 *
	 * @param sgstPrice the sgst price of this cp
	 */
	@Override
	public void setSgstPrice(double sgstPrice) {
		model.setSgstPrice(sgstPrice);
	}

	/**
	 * Sets the start date of this cp.
	 *
	 * @param startDate the start date of this cp
	 */
	@Override
	public void setStartDate(Date startDate) {
		model.setStartDate(startDate);
	}

	/**
	 * Sets the vc ID of this cp.
	 *
	 * @param vcId the vc ID of this cp
	 */
	@Override
	public void setVcId(String vcId) {
		model.setVcId(vcId);
	}

	/**
	 * Sets whether this cp is visible.
	 *
	 * @param visible the visible of this cp
	 */
	@Override
	public void setVisible(boolean visible) {
		model.setVisible(visible);
	}

	@Override
	protected CPWrapper wrap(CP cp) {
		return new CPWrapper(cp);
	}

}