/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.persistence;

import com.jio.account.telecom.exception.NoSuchCPTransactionException;
import com.jio.account.telecom.model.CPTransaction;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the cp transaction service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPTransactionUtil
 * @generated
 */
@ProviderType
public interface CPTransactionPersistence
	extends BasePersistence<CPTransaction> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link CPTransactionUtil} to access the cp transaction persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the cp transactions where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns an ordered range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public CPTransaction findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the first cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public CPTransaction fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns the last cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public CPTransaction findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the last cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public CPTransaction fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public CPTransaction[] findByCompanyId_PrevAndNext(
			String cptId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Removes all the cp transactions where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of cp transactions where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching cp transactions
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Returns all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @return the matching cp transactions
	 */
	public java.util.List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId);

	/**
	 * Returns a range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns an ordered range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public CPTransaction findByAN_PC_SD_ED_C_First(
			String accountNo, String planCode, Date startDate, Date endDate,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the first cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public CPTransaction fetchByAN_PC_SD_ED_C_First(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns the last cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public CPTransaction findByAN_PC_SD_ED_C_Last(
			String accountNo, String planCode, Date startDate, Date endDate,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the last cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public CPTransaction fetchByAN_PC_SD_ED_C_Last(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public CPTransaction[] findByAN_PC_SD_ED_C_PrevAndNext(
			String cptId, String accountNo, String planCode, Date startDate,
			Date endDate, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Removes all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 */
	public void removeByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId);

	/**
	 * Returns the number of cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @return the number of matching cp transactions
	 */
	public int countByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId);

	/**
	 * Returns all the cp transactions where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @return the matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCPId(String cpId);

	/**
	 * Returns a range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCPId(
		String cpId, int start, int end);

	/**
	 * Returns an ordered range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCPId(
		String cpId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns an ordered range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	public java.util.List<CPTransaction> findByCPId(
		String cpId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public CPTransaction findByCPId_First(
			String cpId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the first cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public CPTransaction fetchByCPId_First(
		String cpId,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns the last cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public CPTransaction findByCPId_Last(
			String cpId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the last cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public CPTransaction fetchByCPId_Last(
		String cpId,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public CPTransaction[] findByCPId_PrevAndNext(
			String cptId, String cpId,
			com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
				orderByComparator)
		throws NoSuchCPTransactionException;

	/**
	 * Removes all the cp transactions where cpId = &#63; from the database.
	 *
	 * @param cpId the cp ID
	 */
	public void removeByCPId(String cpId);

	/**
	 * Returns the number of cp transactions where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @return the number of matching cp transactions
	 */
	public int countByCPId(String cpId);

	/**
	 * Caches the cp transaction in the entity cache if it is enabled.
	 *
	 * @param cpTransaction the cp transaction
	 */
	public void cacheResult(CPTransaction cpTransaction);

	/**
	 * Caches the cp transactions in the entity cache if it is enabled.
	 *
	 * @param cpTransactions the cp transactions
	 */
	public void cacheResult(java.util.List<CPTransaction> cpTransactions);

	/**
	 * Creates a new cp transaction with the primary key. Does not add the cp transaction to the database.
	 *
	 * @param cptId the primary key for the new cp transaction
	 * @return the new cp transaction
	 */
	public CPTransaction create(String cptId);

	/**
	 * Removes the cp transaction with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction that was removed
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public CPTransaction remove(String cptId)
		throws NoSuchCPTransactionException;

	public CPTransaction updateImpl(CPTransaction cpTransaction);

	/**
	 * Returns the cp transaction with the primary key or throws a <code>NoSuchCPTransactionException</code> if it could not be found.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public CPTransaction findByPrimaryKey(String cptId)
		throws NoSuchCPTransactionException;

	/**
	 * Returns the cp transaction with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction, or <code>null</code> if a cp transaction with the primary key could not be found
	 */
	public CPTransaction fetchByPrimaryKey(String cptId);

	/**
	 * Returns all the cp transactions.
	 *
	 * @return the cp transactions
	 */
	public java.util.List<CPTransaction> findAll();

	/**
	 * Returns a range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of cp transactions
	 */
	public java.util.List<CPTransaction> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of cp transactions
	 */
	public java.util.List<CPTransaction> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator);

	/**
	 * Returns an ordered range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of cp transactions
	 */
	public java.util.List<CPTransaction> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CPTransaction>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the cp transactions from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of cp transactions.
	 *
	 * @return the number of cp transactions
	 */
	public int countAll();

}