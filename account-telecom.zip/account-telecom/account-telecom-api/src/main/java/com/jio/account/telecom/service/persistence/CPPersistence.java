/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.persistence;

import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the cp service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPUtil
 * @generated
 */
@ProviderType
public interface CPPersistence extends BasePersistence<CP> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link CPUtil} to access the cp persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByCPId(String cpId, long companyId) throws NoSuchCPException;

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByCPId(String cpId, long companyId);

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByCPId(
		String cpId, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the cp where cpId = &#63; and companyId = &#63; from the database.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	public CP removeByCPId(String cpId, long companyId)
		throws NoSuchCPException;

	/**
	 * Returns the number of cps where cpId = &#63; and companyId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByCPId(String cpId, long companyId);

	/**
	 * Returns all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAutoRenew(
		boolean autoRenew, long companyId);

	/**
	 * Returns a range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAutoRenew_First(
			boolean autoRenew, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAutoRenew_First(
		boolean autoRenew, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAutoRenew_Last(
			boolean autoRenew, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAutoRenew_Last(
		boolean autoRenew, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAutoRenew_PrevAndNext(
			String cpId, boolean autoRenew, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Removes all the cps where autoRenew = &#63; and companyId = &#63; from the database.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 */
	public void removeByAutoRenew(boolean autoRenew, long companyId);

	/**
	 * Returns the number of cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAutoRenew(boolean autoRenew, long companyId);

	/**
	 * Returns all the cps where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByCompanyId_PrevAndNext(
			String cpId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Removes all the cps where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of cps where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_First(
			String accountNo, String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_First(
		String accountNo, String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_Last(
			String accountNo, String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_Last(
		String accountNo, String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAN_CSN_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public void removeByAN_CSN(
		String accountNo, String customerScreenName, long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN(
		String accountNo, String customerScreenName, long companyId);

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_P(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws NoSuchCPException;

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId);

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId, boolean retrieveFromCache);

	/**
	 * Removes the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	public CP removeByAN_CSN_P(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws NoSuchCPException;

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId);

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_P_A(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws NoSuchCPException;

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId);

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	public CP removeByAN_CSN_P_A(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws NoSuchCPException;

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId);

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_C_First(
			String accountNo, String customerScreenName, String categoryCode,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_C_First(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_C_Last(
			String accountNo, String customerScreenName, String categoryCode,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_C_Last(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAN_CSN_C_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			String categoryCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 */
	public void removeByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId);

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_C_A_First(
			String accountNo, String customerScreenName, String categoryCode,
			boolean active, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_C_A_First(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_C_A_Last(
			String accountNo, String customerScreenName, String categoryCode,
			boolean active, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_C_A_Last(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAN_CSN_C_A_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			String categoryCode, boolean active, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 */
	public void removeByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId);

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_A_First(
			String accountNo, String customerScreenName, boolean active,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_A_First(
		String accountNo, String customerScreenName, boolean active,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_A_Last(
			String accountNo, String customerScreenName, boolean active,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_A_Last(
		String accountNo, String customerScreenName, boolean active,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAN_CSN_A_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 */
	public void removeByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId);

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_A_V_First(
			String accountNo, String customerScreenName, boolean active,
			boolean visible, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_A_V_First(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_A_V_Last(
			String accountNo, String customerScreenName, boolean active,
			boolean visible, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_A_V_Last(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAN_CSN_A_V_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, boolean visible, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 */
	public void removeByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId);

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId);

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public java.util.List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_A_M_First(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_A_M_First(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public CP findByAN_CSN_A_M_Last(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public CP fetchByAN_CSN_A_M_Last(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP[] findByAN_CSN_A_M_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, boolean mandatory, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<CP>
				orderByComparator)
		throws NoSuchCPException;

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 */
	public void removeByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId);

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public int countByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId);

	/**
	 * Caches the cp in the entity cache if it is enabled.
	 *
	 * @param cp the cp
	 */
	public void cacheResult(CP cp);

	/**
	 * Caches the cps in the entity cache if it is enabled.
	 *
	 * @param cps the cps
	 */
	public void cacheResult(java.util.List<CP> cps);

	/**
	 * Creates a new cp with the primary key. Does not add the cp to the database.
	 *
	 * @param cpId the primary key for the new cp
	 * @return the new cp
	 */
	public CP create(String cpId);

	/**
	 * Removes the cp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp that was removed
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP remove(String cpId) throws NoSuchCPException;

	public CP updateImpl(CP cp);

	/**
	 * Returns the cp with the primary key or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public CP findByPrimaryKey(String cpId) throws NoSuchCPException;

	/**
	 * Returns the cp with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp, or <code>null</code> if a cp with the primary key could not be found
	 */
	public CP fetchByPrimaryKey(String cpId);

	/**
	 * Returns all the cps.
	 *
	 * @return the cps
	 */
	public java.util.List<CP> findAll();

	/**
	 * Returns a range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of cps
	 */
	public java.util.List<CP> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of cps
	 */
	public java.util.List<CP> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator);

	/**
	 * Returns an ordered range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of cps
	 */
	public java.util.List<CP> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the cps from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of cps.
	 *
	 * @return the number of cps
	 */
	public int countAll();

}