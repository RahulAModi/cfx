/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.persistence;

import com.jio.account.telecom.model.CPTransaction;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the cp transaction service. This utility wraps <code>com.jio.account.telecom.service.persistence.impl.CPTransactionPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPTransactionPersistence
 * @generated
 */
@ProviderType
public class CPTransactionUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(CPTransaction cpTransaction) {
		getPersistence().clearCache(cpTransaction);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, CPTransaction> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<CPTransaction> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<CPTransaction> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<CPTransaction> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static CPTransaction update(CPTransaction cpTransaction) {
		return getPersistence().update(cpTransaction);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static CPTransaction update(
		CPTransaction cpTransaction, ServiceContext serviceContext) {

		return getPersistence().update(cpTransaction, serviceContext);
	}

	/**
	 * Returns all the cp transactions where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching cp transactions
	 */
	public static List<CPTransaction> findByCompanyId(long companyId) {
		return getPersistence().findByCompanyId(companyId);
	}

	/**
	 * Returns a range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	public static List<CPTransaction> findByCompanyId(
		long companyId, int start, int end) {

		return getPersistence().findByCompanyId(companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	public static List<CPTransaction> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	public static List<CPTransaction> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public static CPTransaction findByCompanyId_First(
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the first cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public static CPTransaction fetchByCompanyId_First(
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().fetchByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public static CPTransaction findByCompanyId_Last(
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public static CPTransaction fetchByCompanyId_Last(
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().fetchByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public static CPTransaction[] findByCompanyId_PrevAndNext(
			String cptId, long companyId,
			OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByCompanyId_PrevAndNext(
			cptId, companyId, orderByComparator);
	}

	/**
	 * Removes all the cp transactions where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public static void removeByCompanyId(long companyId) {
		getPersistence().removeByCompanyId(companyId);
	}

	/**
	 * Returns the number of cp transactions where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching cp transactions
	 */
	public static int countByCompanyId(long companyId) {
		return getPersistence().countByCompanyId(companyId);
	}

	/**
	 * Returns all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @return the matching cp transactions
	 */
	public static List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId) {

		return getPersistence().findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId);
	}

	/**
	 * Returns a range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	public static List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end) {

		return getPersistence().findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	public static List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	public static List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public static CPTransaction findByAN_PC_SD_ED_C_First(
			String accountNo, String planCode, Date startDate, Date endDate,
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByAN_PC_SD_ED_C_First(
			accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public static CPTransaction fetchByAN_PC_SD_ED_C_First(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().fetchByAN_PC_SD_ED_C_First(
			accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public static CPTransaction findByAN_PC_SD_ED_C_Last(
			String accountNo, String planCode, Date startDate, Date endDate,
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByAN_PC_SD_ED_C_Last(
			accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public static CPTransaction fetchByAN_PC_SD_ED_C_Last(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().fetchByAN_PC_SD_ED_C_Last(
			accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);
	}

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public static CPTransaction[] findByAN_PC_SD_ED_C_PrevAndNext(
			String cptId, String accountNo, String planCode, Date startDate,
			Date endDate, long companyId,
			OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByAN_PC_SD_ED_C_PrevAndNext(
			cptId, accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 */
	public static void removeByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId) {

		getPersistence().removeByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId);
	}

	/**
	 * Returns the number of cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @return the number of matching cp transactions
	 */
	public static int countByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId) {

		return getPersistence().countByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId);
	}

	/**
	 * Returns all the cp transactions where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @return the matching cp transactions
	 */
	public static List<CPTransaction> findByCPId(String cpId) {
		return getPersistence().findByCPId(cpId);
	}

	/**
	 * Returns a range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	public static List<CPTransaction> findByCPId(
		String cpId, int start, int end) {

		return getPersistence().findByCPId(cpId, start, end);
	}

	/**
	 * Returns an ordered range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	public static List<CPTransaction> findByCPId(
		String cpId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().findByCPId(cpId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	public static List<CPTransaction> findByCPId(
		String cpId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCPId(
			cpId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public static CPTransaction findByCPId_First(
			String cpId, OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByCPId_First(cpId, orderByComparator);
	}

	/**
	 * Returns the first cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public static CPTransaction fetchByCPId_First(
		String cpId, OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().fetchByCPId_First(cpId, orderByComparator);
	}

	/**
	 * Returns the last cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	public static CPTransaction findByCPId_Last(
			String cpId, OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByCPId_Last(cpId, orderByComparator);
	}

	/**
	 * Returns the last cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	public static CPTransaction fetchByCPId_Last(
		String cpId, OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().fetchByCPId_Last(cpId, orderByComparator);
	}

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public static CPTransaction[] findByCPId_PrevAndNext(
			String cptId, String cpId,
			OrderByComparator<CPTransaction> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByCPId_PrevAndNext(
			cptId, cpId, orderByComparator);
	}

	/**
	 * Removes all the cp transactions where cpId = &#63; from the database.
	 *
	 * @param cpId the cp ID
	 */
	public static void removeByCPId(String cpId) {
		getPersistence().removeByCPId(cpId);
	}

	/**
	 * Returns the number of cp transactions where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @return the number of matching cp transactions
	 */
	public static int countByCPId(String cpId) {
		return getPersistence().countByCPId(cpId);
	}

	/**
	 * Caches the cp transaction in the entity cache if it is enabled.
	 *
	 * @param cpTransaction the cp transaction
	 */
	public static void cacheResult(CPTransaction cpTransaction) {
		getPersistence().cacheResult(cpTransaction);
	}

	/**
	 * Caches the cp transactions in the entity cache if it is enabled.
	 *
	 * @param cpTransactions the cp transactions
	 */
	public static void cacheResult(List<CPTransaction> cpTransactions) {
		getPersistence().cacheResult(cpTransactions);
	}

	/**
	 * Creates a new cp transaction with the primary key. Does not add the cp transaction to the database.
	 *
	 * @param cptId the primary key for the new cp transaction
	 * @return the new cp transaction
	 */
	public static CPTransaction create(String cptId) {
		return getPersistence().create(cptId);
	}

	/**
	 * Removes the cp transaction with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction that was removed
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public static CPTransaction remove(String cptId)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().remove(cptId);
	}

	public static CPTransaction updateImpl(CPTransaction cpTransaction) {
		return getPersistence().updateImpl(cpTransaction);
	}

	/**
	 * Returns the cp transaction with the primary key or throws a <code>NoSuchCPTransactionException</code> if it could not be found.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	public static CPTransaction findByPrimaryKey(String cptId)
		throws com.jio.account.telecom.exception.NoSuchCPTransactionException {

		return getPersistence().findByPrimaryKey(cptId);
	}

	/**
	 * Returns the cp transaction with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction, or <code>null</code> if a cp transaction with the primary key could not be found
	 */
	public static CPTransaction fetchByPrimaryKey(String cptId) {
		return getPersistence().fetchByPrimaryKey(cptId);
	}

	/**
	 * Returns all the cp transactions.
	 *
	 * @return the cp transactions
	 */
	public static List<CPTransaction> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of cp transactions
	 */
	public static List<CPTransaction> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of cp transactions
	 */
	public static List<CPTransaction> findAll(
		int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of cp transactions
	 */
	public static List<CPTransaction> findAll(
		int start, int end, OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the cp transactions from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of cp transactions.
	 *
	 * @return the number of cp transactions
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static CPTransactionPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker
		<CPTransactionPersistence, CPTransactionPersistence> _serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(CPTransactionPersistence.class);

		ServiceTracker<CPTransactionPersistence, CPTransactionPersistence>
			serviceTracker =
				new ServiceTracker
					<CPTransactionPersistence, CPTransactionPersistence>(
						bundle.getBundleContext(),
						CPTransactionPersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}