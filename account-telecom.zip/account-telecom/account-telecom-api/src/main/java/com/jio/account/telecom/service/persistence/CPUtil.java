/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.persistence;

import com.jio.account.telecom.model.CP;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the cp service. This utility wraps <code>com.jio.account.telecom.service.persistence.impl.CPPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPPersistence
 * @generated
 */
@ProviderType
public class CPUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(CP cp) {
		getPersistence().clearCache(cp);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, CP> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<CP> findWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<CP> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<CP> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static CP update(CP cp) {
		return getPersistence().update(cp);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static CP update(CP cp, ServiceContext serviceContext) {
		return getPersistence().update(cp, serviceContext);
	}

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByCPId(String cpId, long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByCPId(cpId, companyId);
	}

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByCPId(String cpId, long companyId) {
		return getPersistence().fetchByCPId(cpId, companyId);
	}

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByCPId(
		String cpId, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByCPId(cpId, companyId, retrieveFromCache);
	}

	/**
	 * Removes the cp where cpId = &#63; and companyId = &#63; from the database.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	public static CP removeByCPId(String cpId, long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().removeByCPId(cpId, companyId);
	}

	/**
	 * Returns the number of cps where cpId = &#63; and companyId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByCPId(String cpId, long companyId) {
		return getPersistence().countByCPId(cpId, companyId);
	}

	/**
	 * Returns all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAutoRenew(boolean autoRenew, long companyId) {
		return getPersistence().findByAutoRenew(autoRenew, companyId);
	}

	/**
	 * Returns a range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end) {

		return getPersistence().findByAutoRenew(
			autoRenew, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAutoRenew(
			autoRenew, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAutoRenew(
			autoRenew, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAutoRenew_First(
			boolean autoRenew, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAutoRenew_First(
			autoRenew, companyId, orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAutoRenew_First(
		boolean autoRenew, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAutoRenew_First(
			autoRenew, companyId, orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAutoRenew_Last(
			boolean autoRenew, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAutoRenew_Last(
			autoRenew, companyId, orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAutoRenew_Last(
		boolean autoRenew, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAutoRenew_Last(
			autoRenew, companyId, orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAutoRenew_PrevAndNext(
			String cpId, boolean autoRenew, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAutoRenew_PrevAndNext(
			cpId, autoRenew, companyId, orderByComparator);
	}

	/**
	 * Removes all the cps where autoRenew = &#63; and companyId = &#63; from the database.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 */
	public static void removeByAutoRenew(boolean autoRenew, long companyId) {
		getPersistence().removeByAutoRenew(autoRenew, companyId);
	}

	/**
	 * Returns the number of cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAutoRenew(boolean autoRenew, long companyId) {
		return getPersistence().countByAutoRenew(autoRenew, companyId);
	}

	/**
	 * Returns all the cps where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByCompanyId(long companyId) {
		return getPersistence().findByCompanyId(companyId);
	}

	/**
	 * Returns a range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByCompanyId(long companyId, int start, int end) {
		return getPersistence().findByCompanyId(companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByCompanyId_First(
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByCompanyId_First(
		long companyId, OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByCompanyId_Last(
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByCompanyId_Last(
		long companyId, OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByCompanyId_PrevAndNext(
			String cpId, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByCompanyId_PrevAndNext(
			cpId, companyId, orderByComparator);
	}

	/**
	 * Removes all the cps where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public static void removeByCompanyId(long companyId) {
		getPersistence().removeByCompanyId(companyId);
	}

	/**
	 * Returns the number of cps where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByCompanyId(long companyId) {
		return getPersistence().countByCompanyId(companyId);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId) {

		return getPersistence().findByAN_CSN(
			accountNo, customerScreenName, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end) {

		return getPersistence().findByAN_CSN(
			accountNo, customerScreenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end, OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN(
			accountNo, customerScreenName, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end, OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN(
			accountNo, customerScreenName, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_First(
			String accountNo, String customerScreenName, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_First(
			accountNo, customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_First(
		String accountNo, String customerScreenName, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_First(
			accountNo, customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_Last(
			String accountNo, String customerScreenName, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_Last(
			accountNo, customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_Last(
		String accountNo, String customerScreenName, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_Last(
			accountNo, customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAN_CSN_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_PrevAndNext(
			cpId, accountNo, customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public static void removeByAN_CSN(
		String accountNo, String customerScreenName, long companyId) {

		getPersistence().removeByAN_CSN(
			accountNo, customerScreenName, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN(
		String accountNo, String customerScreenName, long companyId) {

		return getPersistence().countByAN_CSN(
			accountNo, customerScreenName, companyId);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_P(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId) {

		return getPersistence().fetchByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId,
			retrieveFromCache);
	}

	/**
	 * Removes the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	public static CP removeByAN_CSN_P(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().removeByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId) {

		return getPersistence().countByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_P_A(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId) {

		return getPersistence().fetchByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId, boolean retrieveFromCache) {

		return getPersistence().fetchByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId,
			retrieveFromCache);
	}

	/**
	 * Removes the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	public static CP removeByAN_CSN_P_A(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().removeByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId) {

		return getPersistence().countByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_C_First(
			String accountNo, String customerScreenName, String categoryCode,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_C_First(
			accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_C_First(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_C_First(
			accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_C_Last(
			String accountNo, String customerScreenName, String categoryCode,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_C_Last(
			accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_C_Last(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_C_Last(
			accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAN_CSN_C_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			String categoryCode, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_C_PrevAndNext(
			cpId, accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId, start,
			end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 */
	public static void removeByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId) {

		getPersistence().removeByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId) {

		return getPersistence().countByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId) {

		return getPersistence().countByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			start, end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_C_A_First(
			String accountNo, String customerScreenName, String categoryCode,
			boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_C_A_First(
			accountNo, customerScreenName, categoryCode, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_C_A_First(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_C_A_First(
			accountNo, customerScreenName, categoryCode, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_C_A_Last(
			String accountNo, String customerScreenName, String categoryCode,
			boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_C_A_Last(
			accountNo, customerScreenName, categoryCode, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_C_A_Last(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_C_A_Last(
			accountNo, customerScreenName, categoryCode, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAN_CSN_C_A_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			String categoryCode, boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_C_A_PrevAndNext(
			cpId, accountNo, customerScreenName, categoryCode, active,
			companyId, orderByComparator);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			start, end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 */
	public static void removeByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId) {

		getPersistence().removeByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId) {

		return getPersistence().countByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId) {

		return getPersistence().countByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		return getPersistence().findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_A_First(
			String accountNo, String customerScreenName, boolean active,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_First(
			accountNo, customerScreenName, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_A_First(
		String accountNo, String customerScreenName, boolean active,
		long companyId, OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_A_First(
			accountNo, customerScreenName, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_A_Last(
			String accountNo, String customerScreenName, boolean active,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_Last(
			accountNo, customerScreenName, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_A_Last(
		String accountNo, String customerScreenName, boolean active,
		long companyId, OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_A_Last(
			accountNo, customerScreenName, active, companyId,
			orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAN_CSN_A_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_PrevAndNext(
			cpId, accountNo, customerScreenName, active, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 */
	public static void removeByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		getPersistence().removeByAN_CSN_A(
			accountNo, customerScreenName, active, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		return getPersistence().countByAN_CSN_A(
			accountNo, customerScreenName, active, companyId);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		return getPersistence().findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId, start,
			end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId, start,
			end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId, start,
			end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_A_V_First(
			String accountNo, String customerScreenName, boolean active,
			boolean visible, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_V_First(
			accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_A_V_First(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_A_V_First(
			accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_A_V_Last(
			String accountNo, String customerScreenName, boolean active,
			boolean visible, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_V_Last(
			accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_A_V_Last(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_A_V_Last(
			accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAN_CSN_A_V_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, boolean visible, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_V_PrevAndNext(
			cpId, accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 */
	public static void removeByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		getPersistence().removeByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		return getPersistence().countByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId);
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	public static List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		return getPersistence().findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	public static List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end) {

		return getPersistence().findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId, start,
			end);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId, start,
			end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	public static List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		return getPersistence().findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId, start,
			end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_A_M_First(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_M_First(
			accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_A_M_First(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_A_M_First(
			accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	public static CP findByAN_CSN_A_M_Last(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_M_Last(
			accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	public static CP fetchByAN_CSN_A_M_Last(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId,
		OrderByComparator<CP> orderByComparator) {

		return getPersistence().fetchByAN_CSN_A_M_Last(
			accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP[] findByAN_CSN_A_M_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, boolean mandatory, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByAN_CSN_A_M_PrevAndNext(
			cpId, accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 */
	public static void removeByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		getPersistence().removeByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	public static int countByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		return getPersistence().countByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId);
	}

	/**
	 * Caches the cp in the entity cache if it is enabled.
	 *
	 * @param cp the cp
	 */
	public static void cacheResult(CP cp) {
		getPersistence().cacheResult(cp);
	}

	/**
	 * Caches the cps in the entity cache if it is enabled.
	 *
	 * @param cps the cps
	 */
	public static void cacheResult(List<CP> cps) {
		getPersistence().cacheResult(cps);
	}

	/**
	 * Creates a new cp with the primary key. Does not add the cp to the database.
	 *
	 * @param cpId the primary key for the new cp
	 * @return the new cp
	 */
	public static CP create(String cpId) {
		return getPersistence().create(cpId);
	}

	/**
	 * Removes the cp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp that was removed
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP remove(String cpId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().remove(cpId);
	}

	public static CP updateImpl(CP cp) {
		return getPersistence().updateImpl(cp);
	}

	/**
	 * Returns the cp with the primary key or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	public static CP findByPrimaryKey(String cpId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getPersistence().findByPrimaryKey(cpId);
	}

	/**
	 * Returns the cp with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp, or <code>null</code> if a cp with the primary key could not be found
	 */
	public static CP fetchByPrimaryKey(String cpId) {
		return getPersistence().fetchByPrimaryKey(cpId);
	}

	/**
	 * Returns all the cps.
	 *
	 * @return the cps
	 */
	public static List<CP> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of cps
	 */
	public static List<CP> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of cps
	 */
	public static List<CP> findAll(
		int start, int end, OrderByComparator<CP> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of cps
	 */
	public static List<CP> findAll(
		int start, int end, OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the cps from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of cps.
	 *
	 * @return the number of cps
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static CPPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<CPPersistence, CPPersistence> _serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(CPPersistence.class);

		ServiceTracker<CPPersistence, CPPersistence> serviceTracker =
			new ServiceTracker<CPPersistence, CPPersistence>(
				bundle.getBundleContext(), CPPersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}