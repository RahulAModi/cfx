/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the local service utility for CP. This utility wraps
 * <code>com.jio.account.telecom.service.impl.CPLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see CPLocalService
 * @generated
 */
@ProviderType
public class CPLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.jio.account.telecom.service.impl.CPLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the cp to the database. Also notifies the appropriate model listeners.
	 *
	 * @param cp the cp
	 * @return the cp that was added
	 */
	public static com.jio.account.telecom.model.CP addCP(
		com.jio.account.telecom.model.CP cp) {

		return getService().addCP(cp);
	}

	public static long countCP(
		boolean autoRenew, long companyId, java.util.Date date1,
		java.util.Date date2) {

		return getService().countCP(autoRenew, companyId, date1, date2);
	}

	public static long countCP(
		String accountNo, String customerScreenName, boolean autoRenew,
		long companyId, java.util.Date date1, java.util.Date date2) {

		return getService().countCP(
			accountNo, customerScreenName, autoRenew, companyId, date1, date2);
	}

	/**
	 * Creates a new cp with the primary key. Does not add the cp to the database.
	 *
	 * @param cpId the primary key for the new cp
	 * @return the new cp
	 */
	public static com.jio.account.telecom.model.CP createCP(String cpId) {
		return getService().createCP(cpId);
	}

	/**
	 * Deletes the cp from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cp the cp
	 * @return the cp that was removed
	 */
	public static com.jio.account.telecom.model.CP deleteCP(
		com.jio.account.telecom.model.CP cp) {

		return getService().deleteCP(cp);
	}

	/**
	 * Deletes the cp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp that was removed
	 * @throws PortalException if a cp with the primary key could not be found
	 */
	public static com.jio.account.telecom.model.CP deleteCP(String cpId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deleteCP(cpId);
	}

	/**
	 * @throws PortalException
	 */
	public static com.liferay.portal.kernel.model.PersistedModel
			deletePersistedModel(
				com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery
		dynamicQuery() {

		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.telecom.model.impl.CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.telecom.model.impl.CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.account.telecom.model.CP fetchCP(String cpId) {
		return getService().fetchCP(cpId);
	}

	public static java.util.List<Object[]> getBulkRenewalList(
		String primaryLcoCode, String vcId, String startDate, String endDate,
		boolean autorenew, boolean active, String categoryGroupCode, int start,
		int end) {

		return getService().getBulkRenewalList(
			primaryLcoCode, vcId, startDate, endDate, autorenew, active,
			categoryGroupCode, start, end);
	}

	public static int getBulkRenewalListCount(
		String primaryLcoCode, String vcId, String startDate, String endDate,
		boolean autorenew, boolean active, String categoryGroupCode) {

		return getService().getBulkRenewalListCount(
			primaryLcoCode, vcId, startDate, endDate, autorenew, active,
			categoryGroupCode);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCP(
		boolean autoRenew, long companyId, java.util.Date date1,
		java.util.Date date2) {

		return getService().getCP(autoRenew, companyId, date1, date2);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCP(
		boolean autoRenew, long companyId, java.util.Date date1,
		java.util.Date date2, int start, int end) {

		return getService().getCP(
			autoRenew, companyId, date1, date2, start, end);
	}

	/**
	 * Returns the cp with the primary key.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp
	 * @throws PortalException if a cp with the primary key could not be found
	 */
	public static com.jio.account.telecom.model.CP getCP(String cpId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getCP(cpId);
	}

	public static com.jio.account.telecom.model.CP getCP(
			String cpId, long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getService().getCP(cpId, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCP(
		String accountNo, String customerScreenName, boolean autoRenew,
		long companyId, java.util.Date date1, java.util.Date date2) {

		return getService().getCP(
			accountNo, customerScreenName, autoRenew, companyId, date1, date2);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCP(
		String accountNo, String customerScreenName, boolean autoRenew,
		long companyId, java.util.Date date1, java.util.Date date2, int start,
		int end) {

		return getService().getCP(
			accountNo, customerScreenName, autoRenew, companyId, date1, date2,
			start, end);
	}

	public static com.jio.account.telecom.model.CP getCP(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getService().getCP(
			accountNo, customerScreenName, planCode, active, companyId);
	}

	public static com.jio.account.telecom.model.CP getCP(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws com.jio.account.telecom.exception.NoSuchCPException {

		return getService().getCP(
			accountNo, customerScreenName, planCode, companyId);
	}

	public static java.util.List<String> getCPDistictAccountNo(
		boolean autoRenew, long companyId, java.util.Date date1,
		java.util.Date date2) {

		return getService().getCPDistictAccountNo(
			autoRenew, companyId, date1, date2);
	}

	public static java.util.List<String> getCPDistictAccountNo(
		boolean autoRenew, long companyId, java.util.Date date1,
		java.util.Date date2, int start, int end) {

		return getService().getCPDistictAccountNo(
			autoRenew, companyId, date1, date2, start, end);
	}

	/**
	 * Returns a range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.telecom.model.impl.CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of cps
	 */
	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		int start, int end) {

		return getService().getCPs(start, end);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		long companyId, int start, int end) {

		return getService().getCPs(companyId, start, end);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		return getService().getCPs(
			accountNo, customerScreenName, active, visible, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end) {

		return getService().getCPs(
			accountNo, customerScreenName, active, visible, companyId, start,
			end);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		return getService().getCPs(
			accountNo, customerScreenName, active, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end) {

		return getService().getCPs(
			accountNo, customerScreenName, active, companyId, start, end);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, long companyId) {

		return getService().getCPs(accountNo, customerScreenName, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, long companyId, int start,
		int end) {

		return getService().getCPs(
			accountNo, customerScreenName, companyId, start, end);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId) {

		return getService().getCPs(
			accountNo, customerScreenName, categoryCodes, active, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP> getCPs(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end) {

		return getService().getCPs(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			start, end);
	}

	/**
	 * Returns the number of cps.
	 *
	 * @return the number of cps
	 */
	public static int getCPsCount() {
		return getService().getCPsCount();
	}

	public static int getCPsCount(long companyId) {
		return getService().getCPsCount(companyId);
	}

	public static int getCPsCount(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		return getService().getCPsCount(
			accountNo, customerScreenName, active, visible, companyId);
	}

	public static int getCPsCount(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		return getService().getCPsCount(
			accountNo, customerScreenName, active, companyId);
	}

	public static int getCPsCount(
		String accountNo, String customerScreenName, long companyId) {

		return getService().getCPsCount(
			accountNo, customerScreenName, companyId);
	}

	public static int getCPsCount(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId) {

		return getService().getCPsCount(
			accountNo, customerScreenName, categoryCodes, active, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP>
		getMandatoryCPs(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId) {

		return getService().getMandatoryCPs(
			accountNo, customerScreenName, active, mandatory, companyId);
	}

	public static java.util.List<com.jio.account.telecom.model.CP>
		getMandatoryCPs(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId, int start, int end) {

		return getService().getMandatoryCPs(
			accountNo, customerScreenName, active, mandatory, companyId, start,
			end);
	}

	public static int getMandatoryCPsCount(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		return getService().getMandatoryCPsCount(
			accountNo, customerScreenName, active, mandatory, companyId);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	public static com.liferay.portal.kernel.model.PersistedModel
			getPersistedModel(java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	public static com.jio.account.telecom.model.CP saveOrUpdateCP(
		com.jio.account.telecom.model.CP cp, long agentBalanceId,
		double cpLcoPrice, double cpAmount, long cpDuration,
		java.util.Date cpEndDate) {

		return getService().saveOrUpdateCP(
			cp, agentBalanceId, cpLcoPrice, cpAmount, cpDuration, cpEndDate);
	}

	public static com.jio.account.telecom.model.CP saveOrUpdateCP(
		com.jio.account.telecom.model.CP cp, String packageId,
		String purchasedProductPoId) {

		return getService().saveOrUpdateCP(cp, packageId, purchasedProductPoId);
	}

	public static com.jio.account.telecom.model.CP saveOrUpdateCP(
			long groupId, long companyId, String createBy,
			String customerScreenName, String accountNo, String customerId,
			boolean active, String planCode, String reason, String cityCode,
			boolean autoRenew, String packageId, String purchasedProductPoId,
			java.util.Date startDate, java.util.Date endDate)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().saveOrUpdateCP(
			groupId, companyId, createBy, customerScreenName, accountNo,
			customerId, active, planCode, reason, cityCode, autoRenew,
			packageId, purchasedProductPoId, startDate, endDate);
	}

	/**
	 * Updates the cp in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param cp the cp
	 * @return the cp that was updated
	 */
	public static com.jio.account.telecom.model.CP updateCP(
		com.jio.account.telecom.model.CP cp) {

		return getService().updateCP(cp);
	}

	public static CPLocalService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<CPLocalService, CPLocalService>
		_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(CPLocalService.class);

		ServiceTracker<CPLocalService, CPLocalService> serviceTracker =
			new ServiceTracker<CPLocalService, CPLocalService>(
				bundle.getBundleContext(), CPLocalService.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}