/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link CPTransaction}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPTransaction
 * @generated
 */
@ProviderType
public class CPTransactionWrapper
	extends BaseModelWrapper<CPTransaction>
	implements CPTransaction, ModelWrapper<CPTransaction> {

	public CPTransactionWrapper(CPTransaction cpTransaction) {
		super(cpTransaction);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("cptId", getCptId());
		attributes.put("groupId", getGroupId());
		attributes.put("cpId", getCpId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("customerScreenName", getCustomerScreenName());
		attributes.put("accountNo", getAccountNo());
		attributes.put("vcId", getVcId());
		attributes.put("customerId", getCustomerId());
		attributes.put("active", isActive());
		attributes.put("startDate", getStartDate());
		attributes.put("endDate", getEndDate());
		attributes.put("planCode", getPlanCode());
		attributes.put("categoryCode", getCategoryCode());
		attributes.put("categoryGroupCode", getCategoryGroupCode());
		attributes.put("planMappingCode", getPlanMappingCode());
		attributes.put("planName", getPlanName());
		attributes.put("categoryName", getCategoryName());
		attributes.put("categoryGroupName", getCategoryGroupName());
		attributes.put("price", getPrice());
		attributes.put("basicPrice", getBasicPrice());
		attributes.put("cgstPrice", getCgstPrice());
		attributes.put("sgstPrice", getSgstPrice());
		attributes.put("lcoPrice", getLcoPrice());
		attributes.put("lcoBasicPrice", getLcoBasicPrice());
		attributes.put("lcoCgstPrice", getLcoCgstPrice());
		attributes.put("lcoSgstPrice", getLcoSgstPrice());
		attributes.put("bcPrice", getBcPrice());
		attributes.put("bcBasicPrice", getBcBasicPrice());
		attributes.put("bcCgstPrice", getBcCgstPrice());
		attributes.put("bcSgstPrice", getBcSgstPrice());
		attributes.put("sdCount", getSdCount());
		attributes.put("hdCount", getHdCount());
		attributes.put("ncfCount", getNcfCount());
		attributes.put("priority", getPriority());
		attributes.put("reason", getReason());
		attributes.put("autoRenew", isAutoRenew());
		attributes.put("mandatory", isMandatory());
		attributes.put("visible", isVisible());
		attributes.put("once", isOnce());
		attributes.put("mapping", isMapping());
		attributes.put("cityCode", getCityCode());
		attributes.put("planPoId", getPlanPoId());
		attributes.put("dealPoId", getDealPoId());
		attributes.put("packageId", getPackageId());
		attributes.put("purchasedProductPoId", getPurchasedProductPoId());
		attributes.put("productPoId", getProductPoId());
		attributes.put("agentBalanceId", getAgentBalanceId());
		attributes.put("cpLcoPrice", getCpLcoPrice());
		attributes.put("cpAmount", getCpAmount());
		attributes.put("cpDuration", getCpDuration());
		attributes.put("cpEndDate", getCpEndDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String cptId = (String)attributes.get("cptId");

		if (cptId != null) {
			setCptId(cptId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		String cpId = (String)attributes.get("cpId");

		if (cpId != null) {
			setCpId(cpId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String customerScreenName = (String)attributes.get(
			"customerScreenName");

		if (customerScreenName != null) {
			setCustomerScreenName(customerScreenName);
		}

		String accountNo = (String)attributes.get("accountNo");

		if (accountNo != null) {
			setAccountNo(accountNo);
		}

		String vcId = (String)attributes.get("vcId");

		if (vcId != null) {
			setVcId(vcId);
		}

		String customerId = (String)attributes.get("customerId");

		if (customerId != null) {
			setCustomerId(customerId);
		}

		Boolean active = (Boolean)attributes.get("active");

		if (active != null) {
			setActive(active);
		}

		Date startDate = (Date)attributes.get("startDate");

		if (startDate != null) {
			setStartDate(startDate);
		}

		Date endDate = (Date)attributes.get("endDate");

		if (endDate != null) {
			setEndDate(endDate);
		}

		String planCode = (String)attributes.get("planCode");

		if (planCode != null) {
			setPlanCode(planCode);
		}

		String categoryCode = (String)attributes.get("categoryCode");

		if (categoryCode != null) {
			setCategoryCode(categoryCode);
		}

		String categoryGroupCode = (String)attributes.get("categoryGroupCode");

		if (categoryGroupCode != null) {
			setCategoryGroupCode(categoryGroupCode);
		}

		String planMappingCode = (String)attributes.get("planMappingCode");

		if (planMappingCode != null) {
			setPlanMappingCode(planMappingCode);
		}

		String planName = (String)attributes.get("planName");

		if (planName != null) {
			setPlanName(planName);
		}

		String categoryName = (String)attributes.get("categoryName");

		if (categoryName != null) {
			setCategoryName(categoryName);
		}

		String categoryGroupName = (String)attributes.get("categoryGroupName");

		if (categoryGroupName != null) {
			setCategoryGroupName(categoryGroupName);
		}

		Double price = (Double)attributes.get("price");

		if (price != null) {
			setPrice(price);
		}

		Double basicPrice = (Double)attributes.get("basicPrice");

		if (basicPrice != null) {
			setBasicPrice(basicPrice);
		}

		Double cgstPrice = (Double)attributes.get("cgstPrice");

		if (cgstPrice != null) {
			setCgstPrice(cgstPrice);
		}

		Double sgstPrice = (Double)attributes.get("sgstPrice");

		if (sgstPrice != null) {
			setSgstPrice(sgstPrice);
		}

		Double lcoPrice = (Double)attributes.get("lcoPrice");

		if (lcoPrice != null) {
			setLcoPrice(lcoPrice);
		}

		Double lcoBasicPrice = (Double)attributes.get("lcoBasicPrice");

		if (lcoBasicPrice != null) {
			setLcoBasicPrice(lcoBasicPrice);
		}

		Double lcoCgstPrice = (Double)attributes.get("lcoCgstPrice");

		if (lcoCgstPrice != null) {
			setLcoCgstPrice(lcoCgstPrice);
		}

		Double lcoSgstPrice = (Double)attributes.get("lcoSgstPrice");

		if (lcoSgstPrice != null) {
			setLcoSgstPrice(lcoSgstPrice);
		}

		Double bcPrice = (Double)attributes.get("bcPrice");

		if (bcPrice != null) {
			setBcPrice(bcPrice);
		}

		Double bcBasicPrice = (Double)attributes.get("bcBasicPrice");

		if (bcBasicPrice != null) {
			setBcBasicPrice(bcBasicPrice);
		}

		Double bcCgstPrice = (Double)attributes.get("bcCgstPrice");

		if (bcCgstPrice != null) {
			setBcCgstPrice(bcCgstPrice);
		}

		Double bcSgstPrice = (Double)attributes.get("bcSgstPrice");

		if (bcSgstPrice != null) {
			setBcSgstPrice(bcSgstPrice);
		}

		Integer sdCount = (Integer)attributes.get("sdCount");

		if (sdCount != null) {
			setSdCount(sdCount);
		}

		Integer hdCount = (Integer)attributes.get("hdCount");

		if (hdCount != null) {
			setHdCount(hdCount);
		}

		Integer ncfCount = (Integer)attributes.get("ncfCount");

		if (ncfCount != null) {
			setNcfCount(ncfCount);
		}

		Integer priority = (Integer)attributes.get("priority");

		if (priority != null) {
			setPriority(priority);
		}

		String reason = (String)attributes.get("reason");

		if (reason != null) {
			setReason(reason);
		}

		Boolean autoRenew = (Boolean)attributes.get("autoRenew");

		if (autoRenew != null) {
			setAutoRenew(autoRenew);
		}

		Boolean mandatory = (Boolean)attributes.get("mandatory");

		if (mandatory != null) {
			setMandatory(mandatory);
		}

		Boolean visible = (Boolean)attributes.get("visible");

		if (visible != null) {
			setVisible(visible);
		}

		Boolean once = (Boolean)attributes.get("once");

		if (once != null) {
			setOnce(once);
		}

		Boolean mapping = (Boolean)attributes.get("mapping");

		if (mapping != null) {
			setMapping(mapping);
		}

		String cityCode = (String)attributes.get("cityCode");

		if (cityCode != null) {
			setCityCode(cityCode);
		}

		String planPoId = (String)attributes.get("planPoId");

		if (planPoId != null) {
			setPlanPoId(planPoId);
		}

		String dealPoId = (String)attributes.get("dealPoId");

		if (dealPoId != null) {
			setDealPoId(dealPoId);
		}

		String packageId = (String)attributes.get("packageId");

		if (packageId != null) {
			setPackageId(packageId);
		}

		String purchasedProductPoId = (String)attributes.get(
			"purchasedProductPoId");

		if (purchasedProductPoId != null) {
			setPurchasedProductPoId(purchasedProductPoId);
		}

		String productPoId = (String)attributes.get("productPoId");

		if (productPoId != null) {
			setProductPoId(productPoId);
		}

		Long agentBalanceId = (Long)attributes.get("agentBalanceId");

		if (agentBalanceId != null) {
			setAgentBalanceId(agentBalanceId);
		}

		Double cpLcoPrice = (Double)attributes.get("cpLcoPrice");

		if (cpLcoPrice != null) {
			setCpLcoPrice(cpLcoPrice);
		}

		Double cpAmount = (Double)attributes.get("cpAmount");

		if (cpAmount != null) {
			setCpAmount(cpAmount);
		}

		Long cpDuration = (Long)attributes.get("cpDuration");

		if (cpDuration != null) {
			setCpDuration(cpDuration);
		}

		Date cpEndDate = (Date)attributes.get("cpEndDate");

		if (cpEndDate != null) {
			setCpEndDate(cpEndDate);
		}
	}

	/**
	 * Returns the account no of this cp transaction.
	 *
	 * @return the account no of this cp transaction
	 */
	@Override
	public String getAccountNo() {
		return model.getAccountNo();
	}

	/**
	 * Returns the active of this cp transaction.
	 *
	 * @return the active of this cp transaction
	 */
	@Override
	public boolean getActive() {
		return model.getActive();
	}

	/**
	 * Returns the agent balance ID of this cp transaction.
	 *
	 * @return the agent balance ID of this cp transaction
	 */
	@Override
	public long getAgentBalanceId() {
		return model.getAgentBalanceId();
	}

	/**
	 * Returns the auto renew of this cp transaction.
	 *
	 * @return the auto renew of this cp transaction
	 */
	@Override
	public boolean getAutoRenew() {
		return model.getAutoRenew();
	}

	/**
	 * Returns the basic price of this cp transaction.
	 *
	 * @return the basic price of this cp transaction
	 */
	@Override
	public double getBasicPrice() {
		return model.getBasicPrice();
	}

	/**
	 * Returns the bc basic price of this cp transaction.
	 *
	 * @return the bc basic price of this cp transaction
	 */
	@Override
	public double getBcBasicPrice() {
		return model.getBcBasicPrice();
	}

	/**
	 * Returns the bc cgst price of this cp transaction.
	 *
	 * @return the bc cgst price of this cp transaction
	 */
	@Override
	public double getBcCgstPrice() {
		return model.getBcCgstPrice();
	}

	/**
	 * Returns the bc price of this cp transaction.
	 *
	 * @return the bc price of this cp transaction
	 */
	@Override
	public double getBcPrice() {
		return model.getBcPrice();
	}

	/**
	 * Returns the bc sgst price of this cp transaction.
	 *
	 * @return the bc sgst price of this cp transaction
	 */
	@Override
	public double getBcSgstPrice() {
		return model.getBcSgstPrice();
	}

	/**
	 * Returns the category code of this cp transaction.
	 *
	 * @return the category code of this cp transaction
	 */
	@Override
	public String getCategoryCode() {
		return model.getCategoryCode();
	}

	/**
	 * Returns the category group code of this cp transaction.
	 *
	 * @return the category group code of this cp transaction
	 */
	@Override
	public String getCategoryGroupCode() {
		return model.getCategoryGroupCode();
	}

	/**
	 * Returns the category group name of this cp transaction.
	 *
	 * @return the category group name of this cp transaction
	 */
	@Override
	public String getCategoryGroupName() {
		return model.getCategoryGroupName();
	}

	/**
	 * Returns the category name of this cp transaction.
	 *
	 * @return the category name of this cp transaction
	 */
	@Override
	public String getCategoryName() {
		return model.getCategoryName();
	}

	/**
	 * Returns the cgst price of this cp transaction.
	 *
	 * @return the cgst price of this cp transaction
	 */
	@Override
	public double getCgstPrice() {
		return model.getCgstPrice();
	}

	/**
	 * Returns the city code of this cp transaction.
	 *
	 * @return the city code of this cp transaction
	 */
	@Override
	public String getCityCode() {
		return model.getCityCode();
	}

	/**
	 * Returns the company ID of this cp transaction.
	 *
	 * @return the company ID of this cp transaction
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the cp amount of this cp transaction.
	 *
	 * @return the cp amount of this cp transaction
	 */
	@Override
	public double getCpAmount() {
		return model.getCpAmount();
	}

	/**
	 * Returns the cp duration of this cp transaction.
	 *
	 * @return the cp duration of this cp transaction
	 */
	@Override
	public long getCpDuration() {
		return model.getCpDuration();
	}

	/**
	 * Returns the cp end date of this cp transaction.
	 *
	 * @return the cp end date of this cp transaction
	 */
	@Override
	public Date getCpEndDate() {
		return model.getCpEndDate();
	}

	/**
	 * Returns the cp ID of this cp transaction.
	 *
	 * @return the cp ID of this cp transaction
	 */
	@Override
	public String getCpId() {
		return model.getCpId();
	}

	/**
	 * Returns the cp lco price of this cp transaction.
	 *
	 * @return the cp lco price of this cp transaction
	 */
	@Override
	public double getCpLcoPrice() {
		return model.getCpLcoPrice();
	}

	/**
	 * Returns the cpt ID of this cp transaction.
	 *
	 * @return the cpt ID of this cp transaction
	 */
	@Override
	public String getCptId() {
		return model.getCptId();
	}

	/**
	 * Returns the create by of this cp transaction.
	 *
	 * @return the create by of this cp transaction
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this cp transaction.
	 *
	 * @return the create date of this cp transaction
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the customer ID of this cp transaction.
	 *
	 * @return the customer ID of this cp transaction
	 */
	@Override
	public String getCustomerId() {
		return model.getCustomerId();
	}

	/**
	 * Returns the customer screen name of this cp transaction.
	 *
	 * @return the customer screen name of this cp transaction
	 */
	@Override
	public String getCustomerScreenName() {
		return model.getCustomerScreenName();
	}

	/**
	 * Returns the deal po ID of this cp transaction.
	 *
	 * @return the deal po ID of this cp transaction
	 */
	@Override
	public String getDealPoId() {
		return model.getDealPoId();
	}

	/**
	 * Returns the end date of this cp transaction.
	 *
	 * @return the end date of this cp transaction
	 */
	@Override
	public Date getEndDate() {
		return model.getEndDate();
	}

	/**
	 * Returns the group ID of this cp transaction.
	 *
	 * @return the group ID of this cp transaction
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the hd count of this cp transaction.
	 *
	 * @return the hd count of this cp transaction
	 */
	@Override
	public int getHdCount() {
		return model.getHdCount();
	}

	/**
	 * Returns the lco basic price of this cp transaction.
	 *
	 * @return the lco basic price of this cp transaction
	 */
	@Override
	public double getLcoBasicPrice() {
		return model.getLcoBasicPrice();
	}

	/**
	 * Returns the lco cgst price of this cp transaction.
	 *
	 * @return the lco cgst price of this cp transaction
	 */
	@Override
	public double getLcoCgstPrice() {
		return model.getLcoCgstPrice();
	}

	/**
	 * Returns the lco price of this cp transaction.
	 *
	 * @return the lco price of this cp transaction
	 */
	@Override
	public double getLcoPrice() {
		return model.getLcoPrice();
	}

	/**
	 * Returns the lco sgst price of this cp transaction.
	 *
	 * @return the lco sgst price of this cp transaction
	 */
	@Override
	public double getLcoSgstPrice() {
		return model.getLcoSgstPrice();
	}

	/**
	 * Returns the mandatory of this cp transaction.
	 *
	 * @return the mandatory of this cp transaction
	 */
	@Override
	public boolean getMandatory() {
		return model.getMandatory();
	}

	/**
	 * Returns the mapping of this cp transaction.
	 *
	 * @return the mapping of this cp transaction
	 */
	@Override
	public boolean getMapping() {
		return model.getMapping();
	}

	/**
	 * Returns the modified date of this cp transaction.
	 *
	 * @return the modified date of this cp transaction
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the ncf count of this cp transaction.
	 *
	 * @return the ncf count of this cp transaction
	 */
	@Override
	public int getNcfCount() {
		return model.getNcfCount();
	}

	/**
	 * Returns the once of this cp transaction.
	 *
	 * @return the once of this cp transaction
	 */
	@Override
	public boolean getOnce() {
		return model.getOnce();
	}

	/**
	 * Returns the package ID of this cp transaction.
	 *
	 * @return the package ID of this cp transaction
	 */
	@Override
	public String getPackageId() {
		return model.getPackageId();
	}

	/**
	 * Returns the plan code of this cp transaction.
	 *
	 * @return the plan code of this cp transaction
	 */
	@Override
	public String getPlanCode() {
		return model.getPlanCode();
	}

	/**
	 * Returns the plan mapping code of this cp transaction.
	 *
	 * @return the plan mapping code of this cp transaction
	 */
	@Override
	public String getPlanMappingCode() {
		return model.getPlanMappingCode();
	}

	/**
	 * Returns the plan name of this cp transaction.
	 *
	 * @return the plan name of this cp transaction
	 */
	@Override
	public String getPlanName() {
		return model.getPlanName();
	}

	/**
	 * Returns the plan po ID of this cp transaction.
	 *
	 * @return the plan po ID of this cp transaction
	 */
	@Override
	public String getPlanPoId() {
		return model.getPlanPoId();
	}

	/**
	 * Returns the price of this cp transaction.
	 *
	 * @return the price of this cp transaction
	 */
	@Override
	public double getPrice() {
		return model.getPrice();
	}

	/**
	 * Returns the primary key of this cp transaction.
	 *
	 * @return the primary key of this cp transaction
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the priority of this cp transaction.
	 *
	 * @return the priority of this cp transaction
	 */
	@Override
	public int getPriority() {
		return model.getPriority();
	}

	/**
	 * Returns the product po ID of this cp transaction.
	 *
	 * @return the product po ID of this cp transaction
	 */
	@Override
	public String getProductPoId() {
		return model.getProductPoId();
	}

	/**
	 * Returns the purchased product po ID of this cp transaction.
	 *
	 * @return the purchased product po ID of this cp transaction
	 */
	@Override
	public String getPurchasedProductPoId() {
		return model.getPurchasedProductPoId();
	}

	/**
	 * Returns the reason of this cp transaction.
	 *
	 * @return the reason of this cp transaction
	 */
	@Override
	public String getReason() {
		return model.getReason();
	}

	/**
	 * Returns the sd count of this cp transaction.
	 *
	 * @return the sd count of this cp transaction
	 */
	@Override
	public int getSdCount() {
		return model.getSdCount();
	}

	/**
	 * Returns the sgst price of this cp transaction.
	 *
	 * @return the sgst price of this cp transaction
	 */
	@Override
	public double getSgstPrice() {
		return model.getSgstPrice();
	}

	/**
	 * Returns the start date of this cp transaction.
	 *
	 * @return the start date of this cp transaction
	 */
	@Override
	public Date getStartDate() {
		return model.getStartDate();
	}

	/**
	 * Returns the vc ID of this cp transaction.
	 *
	 * @return the vc ID of this cp transaction
	 */
	@Override
	public String getVcId() {
		return model.getVcId();
	}

	/**
	 * Returns the visible of this cp transaction.
	 *
	 * @return the visible of this cp transaction
	 */
	@Override
	public boolean getVisible() {
		return model.getVisible();
	}

	/**
	 * Returns <code>true</code> if this cp transaction is active.
	 *
	 * @return <code>true</code> if this cp transaction is active; <code>false</code> otherwise
	 */
	@Override
	public boolean isActive() {
		return model.isActive();
	}

	/**
	 * Returns <code>true</code> if this cp transaction is auto renew.
	 *
	 * @return <code>true</code> if this cp transaction is auto renew; <code>false</code> otherwise
	 */
	@Override
	public boolean isAutoRenew() {
		return model.isAutoRenew();
	}

	/**
	 * Returns <code>true</code> if this cp transaction is mandatory.
	 *
	 * @return <code>true</code> if this cp transaction is mandatory; <code>false</code> otherwise
	 */
	@Override
	public boolean isMandatory() {
		return model.isMandatory();
	}

	/**
	 * Returns <code>true</code> if this cp transaction is mapping.
	 *
	 * @return <code>true</code> if this cp transaction is mapping; <code>false</code> otherwise
	 */
	@Override
	public boolean isMapping() {
		return model.isMapping();
	}

	/**
	 * Returns <code>true</code> if this cp transaction is once.
	 *
	 * @return <code>true</code> if this cp transaction is once; <code>false</code> otherwise
	 */
	@Override
	public boolean isOnce() {
		return model.isOnce();
	}

	/**
	 * Returns <code>true</code> if this cp transaction is visible.
	 *
	 * @return <code>true</code> if this cp transaction is visible; <code>false</code> otherwise
	 */
	@Override
	public boolean isVisible() {
		return model.isVisible();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the account no of this cp transaction.
	 *
	 * @param accountNo the account no of this cp transaction
	 */
	@Override
	public void setAccountNo(String accountNo) {
		model.setAccountNo(accountNo);
	}

	/**
	 * Sets whether this cp transaction is active.
	 *
	 * @param active the active of this cp transaction
	 */
	@Override
	public void setActive(boolean active) {
		model.setActive(active);
	}

	/**
	 * Sets the agent balance ID of this cp transaction.
	 *
	 * @param agentBalanceId the agent balance ID of this cp transaction
	 */
	@Override
	public void setAgentBalanceId(long agentBalanceId) {
		model.setAgentBalanceId(agentBalanceId);
	}

	/**
	 * Sets whether this cp transaction is auto renew.
	 *
	 * @param autoRenew the auto renew of this cp transaction
	 */
	@Override
	public void setAutoRenew(boolean autoRenew) {
		model.setAutoRenew(autoRenew);
	}

	/**
	 * Sets the basic price of this cp transaction.
	 *
	 * @param basicPrice the basic price of this cp transaction
	 */
	@Override
	public void setBasicPrice(double basicPrice) {
		model.setBasicPrice(basicPrice);
	}

	/**
	 * Sets the bc basic price of this cp transaction.
	 *
	 * @param bcBasicPrice the bc basic price of this cp transaction
	 */
	@Override
	public void setBcBasicPrice(double bcBasicPrice) {
		model.setBcBasicPrice(bcBasicPrice);
	}

	/**
	 * Sets the bc cgst price of this cp transaction.
	 *
	 * @param bcCgstPrice the bc cgst price of this cp transaction
	 */
	@Override
	public void setBcCgstPrice(double bcCgstPrice) {
		model.setBcCgstPrice(bcCgstPrice);
	}

	/**
	 * Sets the bc price of this cp transaction.
	 *
	 * @param bcPrice the bc price of this cp transaction
	 */
	@Override
	public void setBcPrice(double bcPrice) {
		model.setBcPrice(bcPrice);
	}

	/**
	 * Sets the bc sgst price of this cp transaction.
	 *
	 * @param bcSgstPrice the bc sgst price of this cp transaction
	 */
	@Override
	public void setBcSgstPrice(double bcSgstPrice) {
		model.setBcSgstPrice(bcSgstPrice);
	}

	/**
	 * Sets the category code of this cp transaction.
	 *
	 * @param categoryCode the category code of this cp transaction
	 */
	@Override
	public void setCategoryCode(String categoryCode) {
		model.setCategoryCode(categoryCode);
	}

	/**
	 * Sets the category group code of this cp transaction.
	 *
	 * @param categoryGroupCode the category group code of this cp transaction
	 */
	@Override
	public void setCategoryGroupCode(String categoryGroupCode) {
		model.setCategoryGroupCode(categoryGroupCode);
	}

	/**
	 * Sets the category group name of this cp transaction.
	 *
	 * @param categoryGroupName the category group name of this cp transaction
	 */
	@Override
	public void setCategoryGroupName(String categoryGroupName) {
		model.setCategoryGroupName(categoryGroupName);
	}

	/**
	 * Sets the category name of this cp transaction.
	 *
	 * @param categoryName the category name of this cp transaction
	 */
	@Override
	public void setCategoryName(String categoryName) {
		model.setCategoryName(categoryName);
	}

	/**
	 * Sets the cgst price of this cp transaction.
	 *
	 * @param cgstPrice the cgst price of this cp transaction
	 */
	@Override
	public void setCgstPrice(double cgstPrice) {
		model.setCgstPrice(cgstPrice);
	}

	/**
	 * Sets the city code of this cp transaction.
	 *
	 * @param cityCode the city code of this cp transaction
	 */
	@Override
	public void setCityCode(String cityCode) {
		model.setCityCode(cityCode);
	}

	/**
	 * Sets the company ID of this cp transaction.
	 *
	 * @param companyId the company ID of this cp transaction
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the cp amount of this cp transaction.
	 *
	 * @param cpAmount the cp amount of this cp transaction
	 */
	@Override
	public void setCpAmount(double cpAmount) {
		model.setCpAmount(cpAmount);
	}

	/**
	 * Sets the cp duration of this cp transaction.
	 *
	 * @param cpDuration the cp duration of this cp transaction
	 */
	@Override
	public void setCpDuration(long cpDuration) {
		model.setCpDuration(cpDuration);
	}

	/**
	 * Sets the cp end date of this cp transaction.
	 *
	 * @param cpEndDate the cp end date of this cp transaction
	 */
	@Override
	public void setCpEndDate(Date cpEndDate) {
		model.setCpEndDate(cpEndDate);
	}

	/**
	 * Sets the cp ID of this cp transaction.
	 *
	 * @param cpId the cp ID of this cp transaction
	 */
	@Override
	public void setCpId(String cpId) {
		model.setCpId(cpId);
	}

	/**
	 * Sets the cp lco price of this cp transaction.
	 *
	 * @param cpLcoPrice the cp lco price of this cp transaction
	 */
	@Override
	public void setCpLcoPrice(double cpLcoPrice) {
		model.setCpLcoPrice(cpLcoPrice);
	}

	/**
	 * Sets the cpt ID of this cp transaction.
	 *
	 * @param cptId the cpt ID of this cp transaction
	 */
	@Override
	public void setCptId(String cptId) {
		model.setCptId(cptId);
	}

	/**
	 * Sets the create by of this cp transaction.
	 *
	 * @param createBy the create by of this cp transaction
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this cp transaction.
	 *
	 * @param createDate the create date of this cp transaction
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the customer ID of this cp transaction.
	 *
	 * @param customerId the customer ID of this cp transaction
	 */
	@Override
	public void setCustomerId(String customerId) {
		model.setCustomerId(customerId);
	}

	/**
	 * Sets the customer screen name of this cp transaction.
	 *
	 * @param customerScreenName the customer screen name of this cp transaction
	 */
	@Override
	public void setCustomerScreenName(String customerScreenName) {
		model.setCustomerScreenName(customerScreenName);
	}

	/**
	 * Sets the deal po ID of this cp transaction.
	 *
	 * @param dealPoId the deal po ID of this cp transaction
	 */
	@Override
	public void setDealPoId(String dealPoId) {
		model.setDealPoId(dealPoId);
	}

	/**
	 * Sets the end date of this cp transaction.
	 *
	 * @param endDate the end date of this cp transaction
	 */
	@Override
	public void setEndDate(Date endDate) {
		model.setEndDate(endDate);
	}

	/**
	 * Sets the group ID of this cp transaction.
	 *
	 * @param groupId the group ID of this cp transaction
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the hd count of this cp transaction.
	 *
	 * @param hdCount the hd count of this cp transaction
	 */
	@Override
	public void setHdCount(int hdCount) {
		model.setHdCount(hdCount);
	}

	/**
	 * Sets the lco basic price of this cp transaction.
	 *
	 * @param lcoBasicPrice the lco basic price of this cp transaction
	 */
	@Override
	public void setLcoBasicPrice(double lcoBasicPrice) {
		model.setLcoBasicPrice(lcoBasicPrice);
	}

	/**
	 * Sets the lco cgst price of this cp transaction.
	 *
	 * @param lcoCgstPrice the lco cgst price of this cp transaction
	 */
	@Override
	public void setLcoCgstPrice(double lcoCgstPrice) {
		model.setLcoCgstPrice(lcoCgstPrice);
	}

	/**
	 * Sets the lco price of this cp transaction.
	 *
	 * @param lcoPrice the lco price of this cp transaction
	 */
	@Override
	public void setLcoPrice(double lcoPrice) {
		model.setLcoPrice(lcoPrice);
	}

	/**
	 * Sets the lco sgst price of this cp transaction.
	 *
	 * @param lcoSgstPrice the lco sgst price of this cp transaction
	 */
	@Override
	public void setLcoSgstPrice(double lcoSgstPrice) {
		model.setLcoSgstPrice(lcoSgstPrice);
	}

	/**
	 * Sets whether this cp transaction is mandatory.
	 *
	 * @param mandatory the mandatory of this cp transaction
	 */
	@Override
	public void setMandatory(boolean mandatory) {
		model.setMandatory(mandatory);
	}

	/**
	 * Sets whether this cp transaction is mapping.
	 *
	 * @param mapping the mapping of this cp transaction
	 */
	@Override
	public void setMapping(boolean mapping) {
		model.setMapping(mapping);
	}

	/**
	 * Sets the modified date of this cp transaction.
	 *
	 * @param modifiedDate the modified date of this cp transaction
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the ncf count of this cp transaction.
	 *
	 * @param ncfCount the ncf count of this cp transaction
	 */
	@Override
	public void setNcfCount(int ncfCount) {
		model.setNcfCount(ncfCount);
	}

	/**
	 * Sets whether this cp transaction is once.
	 *
	 * @param once the once of this cp transaction
	 */
	@Override
	public void setOnce(boolean once) {
		model.setOnce(once);
	}

	/**
	 * Sets the package ID of this cp transaction.
	 *
	 * @param packageId the package ID of this cp transaction
	 */
	@Override
	public void setPackageId(String packageId) {
		model.setPackageId(packageId);
	}

	/**
	 * Sets the plan code of this cp transaction.
	 *
	 * @param planCode the plan code of this cp transaction
	 */
	@Override
	public void setPlanCode(String planCode) {
		model.setPlanCode(planCode);
	}

	/**
	 * Sets the plan mapping code of this cp transaction.
	 *
	 * @param planMappingCode the plan mapping code of this cp transaction
	 */
	@Override
	public void setPlanMappingCode(String planMappingCode) {
		model.setPlanMappingCode(planMappingCode);
	}

	/**
	 * Sets the plan name of this cp transaction.
	 *
	 * @param planName the plan name of this cp transaction
	 */
	@Override
	public void setPlanName(String planName) {
		model.setPlanName(planName);
	}

	/**
	 * Sets the plan po ID of this cp transaction.
	 *
	 * @param planPoId the plan po ID of this cp transaction
	 */
	@Override
	public void setPlanPoId(String planPoId) {
		model.setPlanPoId(planPoId);
	}

	/**
	 * Sets the price of this cp transaction.
	 *
	 * @param price the price of this cp transaction
	 */
	@Override
	public void setPrice(double price) {
		model.setPrice(price);
	}

	/**
	 * Sets the primary key of this cp transaction.
	 *
	 * @param primaryKey the primary key of this cp transaction
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the priority of this cp transaction.
	 *
	 * @param priority the priority of this cp transaction
	 */
	@Override
	public void setPriority(int priority) {
		model.setPriority(priority);
	}

	/**
	 * Sets the product po ID of this cp transaction.
	 *
	 * @param productPoId the product po ID of this cp transaction
	 */
	@Override
	public void setProductPoId(String productPoId) {
		model.setProductPoId(productPoId);
	}

	/**
	 * Sets the purchased product po ID of this cp transaction.
	 *
	 * @param purchasedProductPoId the purchased product po ID of this cp transaction
	 */
	@Override
	public void setPurchasedProductPoId(String purchasedProductPoId) {
		model.setPurchasedProductPoId(purchasedProductPoId);
	}

	/**
	 * Sets the reason of this cp transaction.
	 *
	 * @param reason the reason of this cp transaction
	 */
	@Override
	public void setReason(String reason) {
		model.setReason(reason);
	}

	/**
	 * Sets the sd count of this cp transaction.
	 *
	 * @param sdCount the sd count of this cp transaction
	 */
	@Override
	public void setSdCount(int sdCount) {
		model.setSdCount(sdCount);
	}

	/**
	 * Sets the sgst price of this cp transaction.
	 *
	 * @param sgstPrice the sgst price of this cp transaction
	 */
	@Override
	public void setSgstPrice(double sgstPrice) {
		model.setSgstPrice(sgstPrice);
	}

	/**
	 * Sets the start date of this cp transaction.
	 *
	 * @param startDate the start date of this cp transaction
	 */
	@Override
	public void setStartDate(Date startDate) {
		model.setStartDate(startDate);
	}

	/**
	 * Sets the vc ID of this cp transaction.
	 *
	 * @param vcId the vc ID of this cp transaction
	 */
	@Override
	public void setVcId(String vcId) {
		model.setVcId(vcId);
	}

	/**
	 * Sets whether this cp transaction is visible.
	 *
	 * @param visible the visible of this cp transaction
	 */
	@Override
	public void setVisible(boolean visible) {
		model.setVisible(visible);
	}

	@Override
	protected CPTransactionWrapper wrap(CPTransaction cpTransaction) {
		return new CPTransactionWrapper(cpTransaction);
	}

}