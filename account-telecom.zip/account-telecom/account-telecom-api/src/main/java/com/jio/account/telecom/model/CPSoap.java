/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class CPSoap implements Serializable {

	public static CPSoap toSoapModel(CP model) {
		CPSoap soapModel = new CPSoap();

		soapModel.setCpId(model.getCpId());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateBy(model.getCreateBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setCustomerScreenName(model.getCustomerScreenName());
		soapModel.setAccountNo(model.getAccountNo());
		soapModel.setVcId(model.getVcId());
		soapModel.setCustomerId(model.getCustomerId());
		soapModel.setActive(model.isActive());
		soapModel.setStartDate(model.getStartDate());
		soapModel.setEndDate(model.getEndDate());
		soapModel.setPlanCode(model.getPlanCode());
		soapModel.setCategoryCode(model.getCategoryCode());
		soapModel.setCategoryGroupCode(model.getCategoryGroupCode());
		soapModel.setPlanMappingCode(model.getPlanMappingCode());
		soapModel.setPlanName(model.getPlanName());
		soapModel.setCategoryName(model.getCategoryName());
		soapModel.setCategoryGroupName(model.getCategoryGroupName());
		soapModel.setPrice(model.getPrice());
		soapModel.setBasicPrice(model.getBasicPrice());
		soapModel.setCgstPrice(model.getCgstPrice());
		soapModel.setSgstPrice(model.getSgstPrice());
		soapModel.setLcoPrice(model.getLcoPrice());
		soapModel.setLcoBasicPrice(model.getLcoBasicPrice());
		soapModel.setLcoCgstPrice(model.getLcoCgstPrice());
		soapModel.setLcoSgstPrice(model.getLcoSgstPrice());
		soapModel.setBcPrice(model.getBcPrice());
		soapModel.setBcBasicPrice(model.getBcBasicPrice());
		soapModel.setBcCgstPrice(model.getBcCgstPrice());
		soapModel.setBcSgstPrice(model.getBcSgstPrice());
		soapModel.setSdCount(model.getSdCount());
		soapModel.setHdCount(model.getHdCount());
		soapModel.setNcfCount(model.getNcfCount());
		soapModel.setPriority(model.getPriority());
		soapModel.setReason(model.getReason());
		soapModel.setAutoRenew(model.isAutoRenew());
		soapModel.setMandatory(model.isMandatory());
		soapModel.setVisible(model.isVisible());
		soapModel.setOnce(model.isOnce());
		soapModel.setMapping(model.isMapping());
		soapModel.setCityCode(model.getCityCode());
		soapModel.setPlanPoId(model.getPlanPoId());
		soapModel.setDealPoId(model.getDealPoId());
		soapModel.setPackageId(model.getPackageId());
		soapModel.setPurchasedProductPoId(model.getPurchasedProductPoId());
		soapModel.setProductPoId(model.getProductPoId());
		soapModel.setAgentBalanceId(model.getAgentBalanceId());
		soapModel.setCpLcoPrice(model.getCpLcoPrice());
		soapModel.setCpAmount(model.getCpAmount());
		soapModel.setCpDuration(model.getCpDuration());
		soapModel.setCpEndDate(model.getCpEndDate());

		return soapModel;
	}

	public static CPSoap[] toSoapModels(CP[] models) {
		CPSoap[] soapModels = new CPSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static CPSoap[][] toSoapModels(CP[][] models) {
		CPSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new CPSoap[models.length][models[0].length];
		}
		else {
			soapModels = new CPSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static CPSoap[] toSoapModels(List<CP> models) {
		List<CPSoap> soapModels = new ArrayList<CPSoap>(models.size());

		for (CP model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new CPSoap[soapModels.size()]);
	}

	public CPSoap() {
	}

	public String getPrimaryKey() {
		return _cpId;
	}

	public void setPrimaryKey(String pk) {
		setCpId(pk);
	}

	public String getCpId() {
		return _cpId;
	}

	public void setCpId(String cpId) {
		_cpId = cpId;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public String getCreateBy() {
		return _createBy;
	}

	public void setCreateBy(String createBy) {
		_createBy = createBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public String getCustomerScreenName() {
		return _customerScreenName;
	}

	public void setCustomerScreenName(String customerScreenName) {
		_customerScreenName = customerScreenName;
	}

	public String getAccountNo() {
		return _accountNo;
	}

	public void setAccountNo(String accountNo) {
		_accountNo = accountNo;
	}

	public String getVcId() {
		return _vcId;
	}

	public void setVcId(String vcId) {
		_vcId = vcId;
	}

	public String getCustomerId() {
		return _customerId;
	}

	public void setCustomerId(String customerId) {
		_customerId = customerId;
	}

	public boolean getActive() {
		return _active;
	}

	public boolean isActive() {
		return _active;
	}

	public void setActive(boolean active) {
		_active = active;
	}

	public Date getStartDate() {
		return _startDate;
	}

	public void setStartDate(Date startDate) {
		_startDate = startDate;
	}

	public Date getEndDate() {
		return _endDate;
	}

	public void setEndDate(Date endDate) {
		_endDate = endDate;
	}

	public String getPlanCode() {
		return _planCode;
	}

	public void setPlanCode(String planCode) {
		_planCode = planCode;
	}

	public String getCategoryCode() {
		return _categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		_categoryCode = categoryCode;
	}

	public String getCategoryGroupCode() {
		return _categoryGroupCode;
	}

	public void setCategoryGroupCode(String categoryGroupCode) {
		_categoryGroupCode = categoryGroupCode;
	}

	public String getPlanMappingCode() {
		return _planMappingCode;
	}

	public void setPlanMappingCode(String planMappingCode) {
		_planMappingCode = planMappingCode;
	}

	public String getPlanName() {
		return _planName;
	}

	public void setPlanName(String planName) {
		_planName = planName;
	}

	public String getCategoryName() {
		return _categoryName;
	}

	public void setCategoryName(String categoryName) {
		_categoryName = categoryName;
	}

	public String getCategoryGroupName() {
		return _categoryGroupName;
	}

	public void setCategoryGroupName(String categoryGroupName) {
		_categoryGroupName = categoryGroupName;
	}

	public double getPrice() {
		return _price;
	}

	public void setPrice(double price) {
		_price = price;
	}

	public double getBasicPrice() {
		return _basicPrice;
	}

	public void setBasicPrice(double basicPrice) {
		_basicPrice = basicPrice;
	}

	public double getCgstPrice() {
		return _cgstPrice;
	}

	public void setCgstPrice(double cgstPrice) {
		_cgstPrice = cgstPrice;
	}

	public double getSgstPrice() {
		return _sgstPrice;
	}

	public void setSgstPrice(double sgstPrice) {
		_sgstPrice = sgstPrice;
	}

	public double getLcoPrice() {
		return _lcoPrice;
	}

	public void setLcoPrice(double lcoPrice) {
		_lcoPrice = lcoPrice;
	}

	public double getLcoBasicPrice() {
		return _lcoBasicPrice;
	}

	public void setLcoBasicPrice(double lcoBasicPrice) {
		_lcoBasicPrice = lcoBasicPrice;
	}

	public double getLcoCgstPrice() {
		return _lcoCgstPrice;
	}

	public void setLcoCgstPrice(double lcoCgstPrice) {
		_lcoCgstPrice = lcoCgstPrice;
	}

	public double getLcoSgstPrice() {
		return _lcoSgstPrice;
	}

	public void setLcoSgstPrice(double lcoSgstPrice) {
		_lcoSgstPrice = lcoSgstPrice;
	}

	public double getBcPrice() {
		return _bcPrice;
	}

	public void setBcPrice(double bcPrice) {
		_bcPrice = bcPrice;
	}

	public double getBcBasicPrice() {
		return _bcBasicPrice;
	}

	public void setBcBasicPrice(double bcBasicPrice) {
		_bcBasicPrice = bcBasicPrice;
	}

	public double getBcCgstPrice() {
		return _bcCgstPrice;
	}

	public void setBcCgstPrice(double bcCgstPrice) {
		_bcCgstPrice = bcCgstPrice;
	}

	public double getBcSgstPrice() {
		return _bcSgstPrice;
	}

	public void setBcSgstPrice(double bcSgstPrice) {
		_bcSgstPrice = bcSgstPrice;
	}

	public int getSdCount() {
		return _sdCount;
	}

	public void setSdCount(int sdCount) {
		_sdCount = sdCount;
	}

	public int getHdCount() {
		return _hdCount;
	}

	public void setHdCount(int hdCount) {
		_hdCount = hdCount;
	}

	public int getNcfCount() {
		return _ncfCount;
	}

	public void setNcfCount(int ncfCount) {
		_ncfCount = ncfCount;
	}

	public int getPriority() {
		return _priority;
	}

	public void setPriority(int priority) {
		_priority = priority;
	}

	public String getReason() {
		return _reason;
	}

	public void setReason(String reason) {
		_reason = reason;
	}

	public boolean getAutoRenew() {
		return _autoRenew;
	}

	public boolean isAutoRenew() {
		return _autoRenew;
	}

	public void setAutoRenew(boolean autoRenew) {
		_autoRenew = autoRenew;
	}

	public boolean getMandatory() {
		return _mandatory;
	}

	public boolean isMandatory() {
		return _mandatory;
	}

	public void setMandatory(boolean mandatory) {
		_mandatory = mandatory;
	}

	public boolean getVisible() {
		return _visible;
	}

	public boolean isVisible() {
		return _visible;
	}

	public void setVisible(boolean visible) {
		_visible = visible;
	}

	public boolean getOnce() {
		return _once;
	}

	public boolean isOnce() {
		return _once;
	}

	public void setOnce(boolean once) {
		_once = once;
	}

	public boolean getMapping() {
		return _mapping;
	}

	public boolean isMapping() {
		return _mapping;
	}

	public void setMapping(boolean mapping) {
		_mapping = mapping;
	}

	public String getCityCode() {
		return _cityCode;
	}

	public void setCityCode(String cityCode) {
		_cityCode = cityCode;
	}

	public String getPlanPoId() {
		return _planPoId;
	}

	public void setPlanPoId(String planPoId) {
		_planPoId = planPoId;
	}

	public String getDealPoId() {
		return _dealPoId;
	}

	public void setDealPoId(String dealPoId) {
		_dealPoId = dealPoId;
	}

	public String getPackageId() {
		return _packageId;
	}

	public void setPackageId(String packageId) {
		_packageId = packageId;
	}

	public String getPurchasedProductPoId() {
		return _purchasedProductPoId;
	}

	public void setPurchasedProductPoId(String purchasedProductPoId) {
		_purchasedProductPoId = purchasedProductPoId;
	}

	public String getProductPoId() {
		return _productPoId;
	}

	public void setProductPoId(String productPoId) {
		_productPoId = productPoId;
	}

	public long getAgentBalanceId() {
		return _agentBalanceId;
	}

	public void setAgentBalanceId(long agentBalanceId) {
		_agentBalanceId = agentBalanceId;
	}

	public double getCpLcoPrice() {
		return _cpLcoPrice;
	}

	public void setCpLcoPrice(double cpLcoPrice) {
		_cpLcoPrice = cpLcoPrice;
	}

	public double getCpAmount() {
		return _cpAmount;
	}

	public void setCpAmount(double cpAmount) {
		_cpAmount = cpAmount;
	}

	public long getCpDuration() {
		return _cpDuration;
	}

	public void setCpDuration(long cpDuration) {
		_cpDuration = cpDuration;
	}

	public Date getCpEndDate() {
		return _cpEndDate;
	}

	public void setCpEndDate(Date cpEndDate) {
		_cpEndDate = cpEndDate;
	}

	private String _cpId;
	private long _groupId;
	private long _companyId;
	private String _createBy;
	private Date _createDate;
	private Date _modifiedDate;
	private String _customerScreenName;
	private String _accountNo;
	private String _vcId;
	private String _customerId;
	private boolean _active;
	private Date _startDate;
	private Date _endDate;
	private String _planCode;
	private String _categoryCode;
	private String _categoryGroupCode;
	private String _planMappingCode;
	private String _planName;
	private String _categoryName;
	private String _categoryGroupName;
	private double _price;
	private double _basicPrice;
	private double _cgstPrice;
	private double _sgstPrice;
	private double _lcoPrice;
	private double _lcoBasicPrice;
	private double _lcoCgstPrice;
	private double _lcoSgstPrice;
	private double _bcPrice;
	private double _bcBasicPrice;
	private double _bcCgstPrice;
	private double _bcSgstPrice;
	private int _sdCount;
	private int _hdCount;
	private int _ncfCount;
	private int _priority;
	private String _reason;
	private boolean _autoRenew;
	private boolean _mandatory;
	private boolean _visible;
	private boolean _once;
	private boolean _mapping;
	private String _cityCode;
	private String _planPoId;
	private String _dealPoId;
	private String _packageId;
	private String _purchasedProductPoId;
	private String _productPoId;
	private long _agentBalanceId;
	private double _cpLcoPrice;
	private double _cpAmount;
	private long _cpDuration;
	private Date _cpEndDate;

}