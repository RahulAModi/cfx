/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.impl;

import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPTransactionLocalService;
import com.jio.account.telecom.service.base.CPLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.model.PlanCategory;
import com.jio.master.telecom.model.PlanCategoryGroup;
import com.jio.master.telecom.service.PlanCategoryGroupLocalService;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Projection;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionList;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * The implementation of the cp local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.telecom.service.CPLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.telecom.model.CP", service = AopService.class)
public class CPLocalServiceImpl extends CPLocalServiceBaseImpl {

	private static final Log LOGGER = LogFactoryUtil.getLog(CPLocalServiceImpl.class);

	public CP saveOrUpdateCP(long groupId, long companyId, String createBy, String customerScreenName, String accountNo, String customerId, boolean active, String planCode, String reason, String cityCode, boolean autoRenew, String packageId, String purchasedProductPoId, Date startDate, Date endDate)
			throws PortalException {

		CP cp = null;
		try {
			cp = getCP(accountNo, customerScreenName, planCode, companyId);
		} catch (PortalException e) {
			cp = createCP(String.valueOf(counterLocalService.increment(CP.class.getName())));
		}

		cp.setGroupId(groupId);
		cp.setCompanyId(companyId);
		cp.setCreateBy(createBy);
		cp.setCustomerScreenName(customerScreenName);
		cp.setPlanCode(planCode);
		cp.setActive(active);

		Plan plan = planLocalService.getPlanByCode(planCode, companyId, cityCode);
		PlanCategory planCategory = planCategoryLocalService.getPlanCategory(plan.getCategoryId());
		PlanCategoryGroup planCategoryGroup = planCategoryGroupLocalService.getPlanCategoryGroup(planCategory.getCategoryGroupId());

		cp.setPrice(plan.getPrice());
		cp.setBasicPrice(plan.getBasicPrice());
		cp.setCgstPrice(plan.getCgstPrice());
		cp.setSgstPrice(plan.getSgstPrice());

		cp.setLcoPrice(plan.getLcoPrice());
		cp.setLcoBasicPrice(plan.getLcoBasicPrice());
		cp.setLcoCgstPrice(plan.getLcoCgstPrice());
		cp.setLcoSgstPrice(plan.getLcoSgstPrice());

		cp.setBcPrice(plan.getBcPrice());
		cp.setBcBasicPrice(plan.getBcBasicPrice());
		cp.setBcCgstPrice(plan.getBcCgstPrice());
		cp.setBcSgstPrice(plan.getBcSgstPrice());

		cp.setSdCount(plan.getSdCount());
		cp.setHdCount(plan.getHdCount());
		cp.setNcfCount(plan.getNcfCount());
		cp.setPriority(plan.getPriority());

		cp.setPlanName(plan.getName());
		cp.setPlanPoId(plan.getPlanPoId());
		cp.setCategoryCode(planCategory.getCode());
		cp.setCategoryName(planCategory.getName());
		cp.setVisible(planCategory.getVisible());
		cp.setMandatory(planCategory.getMandatory());
		cp.setCategoryGroupCode(planCategoryGroup.getCode());
		cp.setCategoryGroupName(planCategoryGroup.getName());

		cp.setPlanMappingCode(plan.getMappingCode());
		cp.setOnce(planCategory.getOnce());
		cp.setMapping(planCategory.getMapping());
		cp.setReason(reason);
		cp.setCityCode(cityCode);
		cp.setAccountNo(accountNo);
		cp.setCustomerId(customerId);
		cp.setAutoRenew(autoRenew);

		if (Validator.isNotNull(startDate) && Validator.isNotNull(endDate)) {
			cp.setStartDate(startDate);
			cp.setEndDate(endDate);
		} else if (Validator.isNotNull(startDate) && Validator.isNull(endDate)) {
			cp.setStartDate(startDate);
			if (Validator.isNull(endDate)) {
				endDate = getEndDate(cp);
			}
			cp.setEndDate(endDate);
		} else if (Validator.isNull(startDate) && Validator.isNotNull(endDate)) {
			// No change in date
		} else if (Validator.isNull(startDate) && Validator.isNull(endDate)) {
			// No change in date
		}

		cp.setDealPoId(plan.getDealPoId());
		cp.setPackageId(packageId);
		cp.setPurchasedProductPoId(purchasedProductPoId);
		cp.setProductPoId(plan.getProductPoId());

		if (cp.isNew()) {
			cp = addCP(cp);
		} else {
			cp = updateCP(cp);
		}

		return cp;
	}

	public CP saveOrUpdateCP(CP cp, String packageId, String purchasedProductPoId) {
		cp.setPackageId(packageId);
		cp.setPurchasedProductPoId(purchasedProductPoId);
		return updateCP(cp);
	}

	public CP saveOrUpdateCP(CP cp, long agentBalanceId, double cpLcoPrice, double cpAmount, long cpDuration, Date cpEndDate) {
		cp.setAgentBalanceId(agentBalanceId);
		cp.setCpLcoPrice(cpLcoPrice);
		cp.setCpAmount(cpAmount);
		cp.setCpDuration(cpDuration);
		cp.setCpEndDate(cpEndDate);
		return updateCP(cp);
	}

	@Override
	public CP addCP(CP cp) {
		cp.setCreateDate(new Date());
		cp.setModifiedDate(new Date());
		cp = super.addCP(cp);
		AuditUtil.audit(cp, AuditConstants.SAVE);
		try {
			cpTransactionLocalService.saveCPTransaction(cp);
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}
		return cp;
	}

	@Override
	public CP updateCP(CP cp) {
		cp.setModifiedDate(new Date());
		cp = super.updateCP(cp);
		AuditUtil.audit(cp, AuditConstants.UPDATE);
		try {
			cpTransactionLocalService.saveCPTransaction(cp);
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}
		return cp;
	}

	@Override
	public CP deleteCP(CP cp) {
		cp = super.deleteCP(cp);
		AuditUtil.audit(cp, AuditConstants.DELETE);
		return cp;
	}

	@Override
	public CP deleteCP(String cpId) throws PortalException {
		return deleteCP(getCP(cpId));
	}

	public CP getCP(String cpId, long companyId) throws NoSuchCPException {
		return this.cpPersistence.findByCPId(cpId, companyId);
	}

	public CP getCP(String accountNo, String customerScreenName, String planCode, long companyId) throws NoSuchCPException {
		return this.cpPersistence.findByAN_CSN_P(accountNo, customerScreenName, planCode, companyId);
	}

	public CP getCP(String accountNo, String customerScreenName, String planCode, boolean active, long companyId) throws NoSuchCPException {
		return this.cpPersistence.findByAN_CSN_P_A(accountNo, customerScreenName, planCode, active, companyId);
	}

	public List<CP> getCPs(long companyId, int start, int end) {
		return this.cpPersistence.findByCompanyId(companyId, start, end);
	}

	public int getCPsCount(long companyId) {
		return this.cpPersistence.countByCompanyId(companyId);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, long companyId, int start, int end) {
		return this.cpPersistence.findByAN_CSN(accountNo, customerScreenName, companyId, start, end);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, long companyId) {
		return this.cpPersistence.findByAN_CSN(accountNo, customerScreenName, companyId);
	}

	public int getCPsCount(String accountNo, String customerScreenName, long companyId) {
		return this.cpPersistence.countByAN_CSN(accountNo, customerScreenName, companyId);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, boolean active, long companyId, int start, int end) {
		return this.cpPersistence.findByAN_CSN_A(accountNo, customerScreenName, active, companyId, start, end);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, boolean active, long companyId) {
		return this.cpPersistence.findByAN_CSN_A(accountNo, customerScreenName, active, companyId);
	}

	public int getCPsCount(String accountNo, String customerScreenName, boolean active, long companyId) {
		return this.cpPersistence.countByAN_CSN_A(accountNo, customerScreenName, active, companyId);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, boolean active, boolean visible, long companyId, int start, int end) {
		return this.cpPersistence.findByAN_CSN_A_V(accountNo, customerScreenName, active, visible, companyId, start, end);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, boolean active, boolean visible, long companyId) {
		return this.cpPersistence.findByAN_CSN_A_V(accountNo, customerScreenName, active, visible, companyId);
	}

	public int getCPsCount(String accountNo, String customerScreenName, boolean active, boolean visible, long companyId) {
		return this.cpPersistence.countByAN_CSN_A_V(accountNo, customerScreenName, active, visible, companyId);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, String[] categoryCodes, boolean active, long companyId, int start, int end) {
		return this.cpPersistence.findByAN_CSN_C_A(accountNo, customerScreenName, categoryCodes, active, companyId, start, end);
	}

	public List<CP> getCPs(String accountNo, String customerScreenName, String[] categoryCodes, boolean active, long companyId) {
		return this.cpPersistence.findByAN_CSN_C_A(accountNo, customerScreenName, categoryCodes, active, companyId);
	}

	public int getCPsCount(String accountNo, String customerScreenName, String[] categoryCodes, boolean active, long companyId) {
		return this.cpPersistence.countByAN_CSN_C_A(accountNo, customerScreenName, categoryCodes, active, companyId);
	}

	public List<CP> getMandatoryCPs(String accountNo, String customerScreenName, boolean active, boolean mandatory, long companyId, int start, int end) {
		return this.cpPersistence.findByAN_CSN_A_M(accountNo, customerScreenName, active, mandatory, companyId, start, end);
	}

	public List<CP> getMandatoryCPs(String accountNo, String customerScreenName, boolean active, boolean mandatory, long companyId) {
		return this.cpPersistence.findByAN_CSN_A_M(accountNo, customerScreenName, active, mandatory, companyId);
	}

	public int getMandatoryCPsCount(String accountNo, String customerScreenName, boolean active, boolean mandatory, long companyId) {
		return this.cpPersistence.countByAN_CSN_A_M(accountNo, customerScreenName, active, mandatory, companyId);
	}

	private Date getEndDate(CP cp) {
		Calendar calendar = Calendar.getInstance();
		if (Validator.isNotNull(cp.getStartDate())) {
			calendar.setTime(cp.getStartDate());
		}
		calendar.add(Calendar.DAY_OF_MONTH, DEFAULT_DURATION);
		return calendar.getTime();
	}

	public List<CP> getCP(boolean autoRenew, long companyId, Date date1, Date date2, int start, int end) {
		DynamicQuery query = buildCPDynamicQuery(autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQuery(query, start, end);
	}

	public List<CP> getCP(boolean autoRenew, long companyId, Date date1, Date date2) {
		DynamicQuery query = buildCPDynamicQuery(autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQuery(query);
	}

	public long countCP(boolean autoRenew, long companyId, Date date1, Date date2) {
		ProjectionList projection = ProjectionFactoryUtil.projectionList();
		projection.add(ProjectionFactoryUtil.rowCount());
		DynamicQuery query = buildCPDynamicQuery(autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQueryCount(query, projection);
	}

	public List<CP> getCP(String accountNo, String customerScreenName, boolean autoRenew, long companyId, Date date1, Date date2, int start, int end) {
		DynamicQuery query = buildCPDynamicQuery(accountNo, customerScreenName, autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQuery(query, start, end);
	}

	public List<CP> getCP(String accountNo, String customerScreenName, boolean autoRenew, long companyId, Date date1, Date date2) {
		DynamicQuery query = buildCPDynamicQuery(accountNo, customerScreenName, autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQuery(query);
	}

	public long countCP(String accountNo, String customerScreenName, boolean autoRenew, long companyId, Date date1, Date date2) {
		ProjectionList projection = ProjectionFactoryUtil.projectionList();
		projection.add(ProjectionFactoryUtil.rowCount());
		DynamicQuery query = buildCPDynamicQuery(accountNo, customerScreenName, autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQueryCount(query, projection);
	}

	public List<String> getCPDistictAccountNo(boolean autoRenew, long companyId, Date date1, Date date2, int start, int end) {
		DynamicQuery query = buildDistictCPDynamicQuery(autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQuery(query, start, end);
	}

	public List<String> getCPDistictAccountNo(boolean autoRenew, long companyId, Date date1, Date date2) {
		DynamicQuery query = buildDistictCPDynamicQuery(autoRenew, companyId, date1, date2);
		return this.cpLocalService.dynamicQuery(query);
	}

	protected DynamicQuery buildDistictCPDynamicQuery(boolean autoRenew, long companyId, Date date1, Date date2) {
		DynamicQuery query = buildCPDynamicQuery(autoRenew, companyId, date1, date2);
		Projection projection = ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property("accountNo"));
		query.setProjection(projection);
		return query;
	}

	protected DynamicQuery buildCPDynamicQuery(boolean autoRenew, long companyId, Date date1, Date date2) {
		return buildCPDynamicQuery(StringPool.BLANK, StringPool.BLANK, autoRenew, companyId, date1, date2);
	}

	protected DynamicQuery buildCPDynamicQuery(String accountNo, String customerScreenName, boolean autoRenew, long companyId, Date date1, Date date2) {

		Junction junction = RestrictionsFactoryUtil.conjunction();

		if (Validator.isNotNull(accountNo)) {
			Property property = PropertyFactoryUtil.forName("accountNo");
			junction.add(property.eq(accountNo));
		}

		if (Validator.isNotNull(customerScreenName)) {
			Property property = PropertyFactoryUtil.forName("customerScreenName");
			junction.add(property.eq(accountNo));
		}

		Property property1 = PropertyFactoryUtil.forName("autoRenew");
		junction.add(property1.eq(autoRenew));

		Property property2 = PropertyFactoryUtil.forName("endDate");
		junction.add(property2.between(date1, date2));

		Property property3 = PropertyFactoryUtil.forName("companyId");
		junction.add(property3.eq(companyId));

		DynamicQuery query = DynamicQueryFactoryUtil.forClass(CP.class, getClassLoader());
		query.add(junction);

		return query;
	}

	public List<Object[]> getBulkRenewalList(String primaryLcoCode, String vcId, String startDate, String endDate, boolean autorenew, boolean active, String categoryGroupCode, int start, int end) {
		return this.cpFinder.getBulkRenewalList(primaryLcoCode, vcId, startDate, endDate, autorenew, active, categoryGroupCode, start, end);
	}

	public int getBulkRenewalListCount(String primaryLcoCode, String vcId, String startDate, String endDate, boolean autorenew, boolean active, String categoryGroupCode) {
		return this.cpFinder.getBulkRenewalListCount(primaryLcoCode, vcId, startDate, endDate, autorenew, active, categoryGroupCode);
	}

	private static final int DEFAULT_DURATION = 30; // Get from Configuration Key Poperty

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private PlanCategoryGroupLocalService planCategoryGroupLocalService;

	@Reference
	private CPTransactionLocalService cpTransactionLocalService;
}