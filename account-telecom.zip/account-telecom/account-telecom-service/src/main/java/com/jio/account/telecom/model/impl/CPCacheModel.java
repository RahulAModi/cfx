/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.model.impl;

import com.jio.account.telecom.model.CP;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The cache model class for representing CP in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class CPCacheModel implements CacheModel<CP>, Externalizable {

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CPCacheModel)) {
			return false;
		}

		CPCacheModel cpCacheModel = (CPCacheModel)obj;

		if (cpId.equals(cpCacheModel.cpId)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, cpId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(107);

		sb.append("{cpId=");
		sb.append(cpId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createBy=");
		sb.append(createBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", customerScreenName=");
		sb.append(customerScreenName);
		sb.append(", accountNo=");
		sb.append(accountNo);
		sb.append(", vcId=");
		sb.append(vcId);
		sb.append(", customerId=");
		sb.append(customerId);
		sb.append(", active=");
		sb.append(active);
		sb.append(", startDate=");
		sb.append(startDate);
		sb.append(", endDate=");
		sb.append(endDate);
		sb.append(", planCode=");
		sb.append(planCode);
		sb.append(", categoryCode=");
		sb.append(categoryCode);
		sb.append(", categoryGroupCode=");
		sb.append(categoryGroupCode);
		sb.append(", planMappingCode=");
		sb.append(planMappingCode);
		sb.append(", planName=");
		sb.append(planName);
		sb.append(", categoryName=");
		sb.append(categoryName);
		sb.append(", categoryGroupName=");
		sb.append(categoryGroupName);
		sb.append(", price=");
		sb.append(price);
		sb.append(", basicPrice=");
		sb.append(basicPrice);
		sb.append(", cgstPrice=");
		sb.append(cgstPrice);
		sb.append(", sgstPrice=");
		sb.append(sgstPrice);
		sb.append(", lcoPrice=");
		sb.append(lcoPrice);
		sb.append(", lcoBasicPrice=");
		sb.append(lcoBasicPrice);
		sb.append(", lcoCgstPrice=");
		sb.append(lcoCgstPrice);
		sb.append(", lcoSgstPrice=");
		sb.append(lcoSgstPrice);
		sb.append(", bcPrice=");
		sb.append(bcPrice);
		sb.append(", bcBasicPrice=");
		sb.append(bcBasicPrice);
		sb.append(", bcCgstPrice=");
		sb.append(bcCgstPrice);
		sb.append(", bcSgstPrice=");
		sb.append(bcSgstPrice);
		sb.append(", sdCount=");
		sb.append(sdCount);
		sb.append(", hdCount=");
		sb.append(hdCount);
		sb.append(", ncfCount=");
		sb.append(ncfCount);
		sb.append(", priority=");
		sb.append(priority);
		sb.append(", reason=");
		sb.append(reason);
		sb.append(", autoRenew=");
		sb.append(autoRenew);
		sb.append(", mandatory=");
		sb.append(mandatory);
		sb.append(", visible=");
		sb.append(visible);
		sb.append(", once=");
		sb.append(once);
		sb.append(", mapping=");
		sb.append(mapping);
		sb.append(", cityCode=");
		sb.append(cityCode);
		sb.append(", planPoId=");
		sb.append(planPoId);
		sb.append(", dealPoId=");
		sb.append(dealPoId);
		sb.append(", packageId=");
		sb.append(packageId);
		sb.append(", purchasedProductPoId=");
		sb.append(purchasedProductPoId);
		sb.append(", productPoId=");
		sb.append(productPoId);
		sb.append(", agentBalanceId=");
		sb.append(agentBalanceId);
		sb.append(", cpLcoPrice=");
		sb.append(cpLcoPrice);
		sb.append(", cpAmount=");
		sb.append(cpAmount);
		sb.append(", cpDuration=");
		sb.append(cpDuration);
		sb.append(", cpEndDate=");
		sb.append(cpEndDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public CP toEntityModel() {
		CPImpl cpImpl = new CPImpl();

		if (cpId == null) {
			cpImpl.setCpId("");
		}
		else {
			cpImpl.setCpId(cpId);
		}

		cpImpl.setGroupId(groupId);
		cpImpl.setCompanyId(companyId);

		if (createBy == null) {
			cpImpl.setCreateBy("");
		}
		else {
			cpImpl.setCreateBy(createBy);
		}

		if (createDate == Long.MIN_VALUE) {
			cpImpl.setCreateDate(null);
		}
		else {
			cpImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			cpImpl.setModifiedDate(null);
		}
		else {
			cpImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (customerScreenName == null) {
			cpImpl.setCustomerScreenName("");
		}
		else {
			cpImpl.setCustomerScreenName(customerScreenName);
		}

		if (accountNo == null) {
			cpImpl.setAccountNo("");
		}
		else {
			cpImpl.setAccountNo(accountNo);
		}

		if (vcId == null) {
			cpImpl.setVcId("");
		}
		else {
			cpImpl.setVcId(vcId);
		}

		if (customerId == null) {
			cpImpl.setCustomerId("");
		}
		else {
			cpImpl.setCustomerId(customerId);
		}

		cpImpl.setActive(active);

		if (startDate == Long.MIN_VALUE) {
			cpImpl.setStartDate(null);
		}
		else {
			cpImpl.setStartDate(new Date(startDate));
		}

		if (endDate == Long.MIN_VALUE) {
			cpImpl.setEndDate(null);
		}
		else {
			cpImpl.setEndDate(new Date(endDate));
		}

		if (planCode == null) {
			cpImpl.setPlanCode("");
		}
		else {
			cpImpl.setPlanCode(planCode);
		}

		if (categoryCode == null) {
			cpImpl.setCategoryCode("");
		}
		else {
			cpImpl.setCategoryCode(categoryCode);
		}

		if (categoryGroupCode == null) {
			cpImpl.setCategoryGroupCode("");
		}
		else {
			cpImpl.setCategoryGroupCode(categoryGroupCode);
		}

		if (planMappingCode == null) {
			cpImpl.setPlanMappingCode("");
		}
		else {
			cpImpl.setPlanMappingCode(planMappingCode);
		}

		if (planName == null) {
			cpImpl.setPlanName("");
		}
		else {
			cpImpl.setPlanName(planName);
		}

		if (categoryName == null) {
			cpImpl.setCategoryName("");
		}
		else {
			cpImpl.setCategoryName(categoryName);
		}

		if (categoryGroupName == null) {
			cpImpl.setCategoryGroupName("");
		}
		else {
			cpImpl.setCategoryGroupName(categoryGroupName);
		}

		cpImpl.setPrice(price);
		cpImpl.setBasicPrice(basicPrice);
		cpImpl.setCgstPrice(cgstPrice);
		cpImpl.setSgstPrice(sgstPrice);
		cpImpl.setLcoPrice(lcoPrice);
		cpImpl.setLcoBasicPrice(lcoBasicPrice);
		cpImpl.setLcoCgstPrice(lcoCgstPrice);
		cpImpl.setLcoSgstPrice(lcoSgstPrice);
		cpImpl.setBcPrice(bcPrice);
		cpImpl.setBcBasicPrice(bcBasicPrice);
		cpImpl.setBcCgstPrice(bcCgstPrice);
		cpImpl.setBcSgstPrice(bcSgstPrice);
		cpImpl.setSdCount(sdCount);
		cpImpl.setHdCount(hdCount);
		cpImpl.setNcfCount(ncfCount);
		cpImpl.setPriority(priority);

		if (reason == null) {
			cpImpl.setReason("");
		}
		else {
			cpImpl.setReason(reason);
		}

		cpImpl.setAutoRenew(autoRenew);
		cpImpl.setMandatory(mandatory);
		cpImpl.setVisible(visible);
		cpImpl.setOnce(once);
		cpImpl.setMapping(mapping);

		if (cityCode == null) {
			cpImpl.setCityCode("");
		}
		else {
			cpImpl.setCityCode(cityCode);
		}

		if (planPoId == null) {
			cpImpl.setPlanPoId("");
		}
		else {
			cpImpl.setPlanPoId(planPoId);
		}

		if (dealPoId == null) {
			cpImpl.setDealPoId("");
		}
		else {
			cpImpl.setDealPoId(dealPoId);
		}

		if (packageId == null) {
			cpImpl.setPackageId("");
		}
		else {
			cpImpl.setPackageId(packageId);
		}

		if (purchasedProductPoId == null) {
			cpImpl.setPurchasedProductPoId("");
		}
		else {
			cpImpl.setPurchasedProductPoId(purchasedProductPoId);
		}

		if (productPoId == null) {
			cpImpl.setProductPoId("");
		}
		else {
			cpImpl.setProductPoId(productPoId);
		}

		cpImpl.setAgentBalanceId(agentBalanceId);
		cpImpl.setCpLcoPrice(cpLcoPrice);
		cpImpl.setCpAmount(cpAmount);
		cpImpl.setCpDuration(cpDuration);

		if (cpEndDate == Long.MIN_VALUE) {
			cpImpl.setCpEndDate(null);
		}
		else {
			cpImpl.setCpEndDate(new Date(cpEndDate));
		}

		cpImpl.resetOriginalValues();

		return cpImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		cpId = objectInput.readUTF();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();
		createBy = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		customerScreenName = objectInput.readUTF();
		accountNo = objectInput.readUTF();
		vcId = objectInput.readUTF();
		customerId = objectInput.readUTF();

		active = objectInput.readBoolean();
		startDate = objectInput.readLong();
		endDate = objectInput.readLong();
		planCode = objectInput.readUTF();
		categoryCode = objectInput.readUTF();
		categoryGroupCode = objectInput.readUTF();
		planMappingCode = objectInput.readUTF();
		planName = objectInput.readUTF();
		categoryName = objectInput.readUTF();
		categoryGroupName = objectInput.readUTF();

		price = objectInput.readDouble();

		basicPrice = objectInput.readDouble();

		cgstPrice = objectInput.readDouble();

		sgstPrice = objectInput.readDouble();

		lcoPrice = objectInput.readDouble();

		lcoBasicPrice = objectInput.readDouble();

		lcoCgstPrice = objectInput.readDouble();

		lcoSgstPrice = objectInput.readDouble();

		bcPrice = objectInput.readDouble();

		bcBasicPrice = objectInput.readDouble();

		bcCgstPrice = objectInput.readDouble();

		bcSgstPrice = objectInput.readDouble();

		sdCount = objectInput.readInt();

		hdCount = objectInput.readInt();

		ncfCount = objectInput.readInt();

		priority = objectInput.readInt();
		reason = objectInput.readUTF();

		autoRenew = objectInput.readBoolean();

		mandatory = objectInput.readBoolean();

		visible = objectInput.readBoolean();

		once = objectInput.readBoolean();

		mapping = objectInput.readBoolean();
		cityCode = objectInput.readUTF();
		planPoId = objectInput.readUTF();
		dealPoId = objectInput.readUTF();
		packageId = objectInput.readUTF();
		purchasedProductPoId = objectInput.readUTF();
		productPoId = objectInput.readUTF();

		agentBalanceId = objectInput.readLong();

		cpLcoPrice = objectInput.readDouble();

		cpAmount = objectInput.readDouble();

		cpDuration = objectInput.readLong();
		cpEndDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (cpId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(cpId);
		}

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		if (createBy == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(createBy);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (customerScreenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerScreenName);
		}

		if (accountNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(accountNo);
		}

		if (vcId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(vcId);
		}

		if (customerId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerId);
		}

		objectOutput.writeBoolean(active);
		objectOutput.writeLong(startDate);
		objectOutput.writeLong(endDate);

		if (planCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(planCode);
		}

		if (categoryCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(categoryCode);
		}

		if (categoryGroupCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(categoryGroupCode);
		}

		if (planMappingCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(planMappingCode);
		}

		if (planName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(planName);
		}

		if (categoryName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(categoryName);
		}

		if (categoryGroupName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(categoryGroupName);
		}

		objectOutput.writeDouble(price);

		objectOutput.writeDouble(basicPrice);

		objectOutput.writeDouble(cgstPrice);

		objectOutput.writeDouble(sgstPrice);

		objectOutput.writeDouble(lcoPrice);

		objectOutput.writeDouble(lcoBasicPrice);

		objectOutput.writeDouble(lcoCgstPrice);

		objectOutput.writeDouble(lcoSgstPrice);

		objectOutput.writeDouble(bcPrice);

		objectOutput.writeDouble(bcBasicPrice);

		objectOutput.writeDouble(bcCgstPrice);

		objectOutput.writeDouble(bcSgstPrice);

		objectOutput.writeInt(sdCount);

		objectOutput.writeInt(hdCount);

		objectOutput.writeInt(ncfCount);

		objectOutput.writeInt(priority);

		if (reason == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(reason);
		}

		objectOutput.writeBoolean(autoRenew);

		objectOutput.writeBoolean(mandatory);

		objectOutput.writeBoolean(visible);

		objectOutput.writeBoolean(once);

		objectOutput.writeBoolean(mapping);

		if (cityCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(cityCode);
		}

		if (planPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(planPoId);
		}

		if (dealPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(dealPoId);
		}

		if (packageId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(packageId);
		}

		if (purchasedProductPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(purchasedProductPoId);
		}

		if (productPoId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(productPoId);
		}

		objectOutput.writeLong(agentBalanceId);

		objectOutput.writeDouble(cpLcoPrice);

		objectOutput.writeDouble(cpAmount);

		objectOutput.writeLong(cpDuration);
		objectOutput.writeLong(cpEndDate);
	}

	public String cpId;
	public long groupId;
	public long companyId;
	public String createBy;
	public long createDate;
	public long modifiedDate;
	public String customerScreenName;
	public String accountNo;
	public String vcId;
	public String customerId;
	public boolean active;
	public long startDate;
	public long endDate;
	public String planCode;
	public String categoryCode;
	public String categoryGroupCode;
	public String planMappingCode;
	public String planName;
	public String categoryName;
	public String categoryGroupName;
	public double price;
	public double basicPrice;
	public double cgstPrice;
	public double sgstPrice;
	public double lcoPrice;
	public double lcoBasicPrice;
	public double lcoCgstPrice;
	public double lcoSgstPrice;
	public double bcPrice;
	public double bcBasicPrice;
	public double bcCgstPrice;
	public double bcSgstPrice;
	public int sdCount;
	public int hdCount;
	public int ncfCount;
	public int priority;
	public String reason;
	public boolean autoRenew;
	public boolean mandatory;
	public boolean visible;
	public boolean once;
	public boolean mapping;
	public String cityCode;
	public String planPoId;
	public String dealPoId;
	public String packageId;
	public String purchasedProductPoId;
	public String productPoId;
	public long agentBalanceId;
	public double cpLcoPrice;
	public double cpAmount;
	public long cpDuration;
	public long cpEndDate;

}