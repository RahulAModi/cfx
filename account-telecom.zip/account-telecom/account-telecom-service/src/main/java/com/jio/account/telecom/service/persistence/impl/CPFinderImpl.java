package com.jio.account.telecom.service.persistence.impl;

import com.jio.account.telecom.service.persistence.CPFinder;
import com.liferay.portal.dao.orm.custom.sql.CustomSQL;
import com.liferay.portal.kernel.dao.orm.ORMException;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
@Component(service = CPFinder.class)
public class CPFinderImpl extends CPFinderBaseImpl implements CPFinder {
	
	private static final Log LOGGER = LogFactoryUtil.getLog(CPFinderImpl.class);
	
	public static final String GET_LIST_FOR_BULK_RENEWAL =
			CPFinder.class.getName() +
		        ".getListForBulkRenewal";
	
	public static final String GET_COUNT_FOR_BULK_RENEWAL =
			CPFinder.class.getName() +
		        ".getListForBulkRenewalCount";
	
	@Reference
	private CustomSQL _customSQL;
	
	@SuppressWarnings("unchecked")
	public List<Object[]> getBulkRenewalList(String primaryLcoCode, String vcId, String startDate, String endDate, boolean autorenew, boolean active, String categoryGroupCode, int start, int end) {
		
		Session session = null;
		SQLQuery queryObject = null;
		try {
			session = openSession();

			queryObject = createBulkRenewalSQL(primaryLcoCode, session, GET_LIST_FOR_BULK_RENEWAL, vcId, startDate, endDate, autorenew, active, categoryGroupCode);
			return (List<Object[]>) QueryUtil.list(queryObject, getDialect(), start, end);
		} catch (ORMException e) {
			throw new ORMException(e);
		} finally {
			if (session != null) {
				closeSession(session);
			}
		}
	}
	
	protected SQLQuery createBulkRenewalSQL(String primaryLcoCode, Session session, String query, String vcId, String startDate, 
			String endDate, boolean autorenew, boolean active, String categoryGroupCode) {
		String sql = _customSQL.get(getClass(), query);
		
		
		if(Validator.isNotNull(categoryGroupCode) && categoryGroupCode.equalsIgnoreCase("ALL")) {
			sql = StringUtil.replace(sql, "[$CAT_CLAUSE$]", "");
		}else {
			sql = StringUtil.replace(sql, "[$CAT_CLAUSE$]", " cp.categoryGroupCode=? AND ");
		}
		
		if (Validator.isNotNull(vcId)) {
			sql = StringUtil.replace(sql, "[$VCID_CLAUSE$]", " c.vcId = ? AND ");
		} else {
			sql = StringUtil.replace(sql, "[$VCID_CLAUSE$]", "");
		}

		LOGGER.info("sql finder"+sql);
		
		SQLQuery queryObject = session.createSQLQuery(sql);
		queryObject.setCacheable(false);

		QueryPos queryPos = QueryPos.getInstance(queryObject);
		queryPos.add(active);
		queryPos.add(autorenew);
		
		if(Validator.isNotNull(categoryGroupCode) && !categoryGroupCode.equalsIgnoreCase("ALL")) {
			queryPos.add(categoryGroupCode);
		}

		if (Validator.isNotNull(vcId)) {
			queryPos.add(vcId);
		} 
		queryPos.add(startDate);
		queryPos.add(endDate);
		queryPos.add(primaryLcoCode);
		return queryObject;
	}
	
	
	@SuppressWarnings("unchecked")
	public int getBulkRenewalListCount(String primaryLcoCode, String vcId, String startDate, String endDate, boolean autorenew, 
			boolean active, String categoryGroupCode) {
		
		Session session = null;
		SQLQuery queryObject = null;
		try {
			session = openSession();

			queryObject = createBulkRenewalSQL(primaryLcoCode, session, GET_LIST_FOR_BULK_RENEWAL, vcId, startDate, endDate, autorenew, active, categoryGroupCode);

			return QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS).size();
		} catch (ORMException e) {
			throw new ORMException(e);
		} finally {
			if (session != null) {
				closeSession(session);
			}
		}
	}
	
	
	
	
	
	

}

