/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.persistence.impl;

import com.jio.account.telecom.exception.NoSuchCPTransactionException;
import com.jio.account.telecom.model.CPTransaction;
import com.jio.account.telecom.model.impl.CPTransactionImpl;
import com.jio.account.telecom.model.impl.CPTransactionModelImpl;
import com.jio.account.telecom.service.persistence.CPTransactionPersistence;
import com.jio.account.telecom.service.persistence.impl.constants.ATMPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.sql.Timestamp;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the cp transaction service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = CPTransactionPersistence.class)
@ProviderType
public class CPTransactionPersistenceImpl
	extends BasePersistenceImpl<CPTransaction>
	implements CPTransactionPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>CPTransactionUtil</code> to access the cp transaction persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		CPTransactionImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the cp transactions where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCompanyId(
		long companyId, int start, int end) {

		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cp transactions where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<CPTransaction> list = null;

		if (retrieveFromCache) {
			list = (List<CPTransaction>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CPTransaction cpTransaction : list) {
					if ((companyId != cpTransaction.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_CPTRANSACTION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPTransactionModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction findByCompanyId_First(
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByCompanyId_First(
			companyId, orderByComparator);

		if (cpTransaction != null) {
			return cpTransaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPTransactionException(msg.toString());
	}

	/**
	 * Returns the first cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction fetchByCompanyId_First(
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		List<CPTransaction> list = findByCompanyId(
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction findByCompanyId_Last(
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByCompanyId_Last(
			companyId, orderByComparator);

		if (cpTransaction != null) {
			return cpTransaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPTransactionException(msg.toString());
	}

	/**
	 * Returns the last cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction fetchByCompanyId_Last(
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<CPTransaction> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where companyId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction[] findByCompanyId_PrevAndNext(
			String cptId, long companyId,
			OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = findByPrimaryKey(cptId);

		Session session = null;

		try {
			session = openSession();

			CPTransaction[] array = new CPTransactionImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, cpTransaction, companyId, orderByComparator, true);

			array[1] = cpTransaction;

			array[2] = getByCompanyId_PrevAndNext(
				session, cpTransaction, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CPTransaction getByCompanyId_PrevAndNext(
		Session session, CPTransaction cpTransaction, long companyId,
		OrderByComparator<CPTransaction> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_CPTRANSACTION_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPTransactionModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						cpTransaction)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CPTransaction> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cp transactions where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (CPTransaction cpTransaction :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cpTransaction);
		}
	}

	/**
	 * Returns the number of cp transactions where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching cp transactions
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_CPTRANSACTION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"cpTransaction.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_PC_SD_ED_C;
	private FinderPath _finderPathWithoutPaginationFindByAN_PC_SD_ED_C;
	private FinderPath _finderPathCountByAN_PC_SD_ED_C;

	/**
	 * Returns all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @return the matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId) {

		return findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end) {

		return findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		planCode = Objects.toString(planCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_PC_SD_ED_C;
			finderArgs = new Object[] {
				accountNo, planCode, _getTime(startDate), _getTime(endDate),
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_PC_SD_ED_C;
			finderArgs = new Object[] {
				accountNo, planCode, _getTime(startDate), _getTime(endDate),
				companyId, start, end, orderByComparator
			};
		}

		List<CPTransaction> list = null;

		if (retrieveFromCache) {
			list = (List<CPTransaction>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CPTransaction cpTransaction : list) {
					if (!accountNo.equals(cpTransaction.getAccountNo()) ||
						!planCode.equals(cpTransaction.getPlanCode()) ||
						!Objects.equals(
							startDate, cpTransaction.getStartDate()) ||
						!Objects.equals(endDate, cpTransaction.getEndDate()) ||
						(companyId != cpTransaction.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					7 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(7);
			}

			query.append(_SQL_SELECT_CPTRANSACTION_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_2);
			}

			boolean bindPlanCode = false;

			if (planCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_3);
			}
			else {
				bindPlanCode = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_2);
			}

			boolean bindStartDate = false;

			if (startDate == null) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_1);
			}
			else {
				bindStartDate = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_2);
			}

			boolean bindEndDate = false;

			if (endDate == null) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_1);
			}
			else {
				bindEndDate = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_2);
			}

			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPTransactionModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindPlanCode) {
					qPos.add(planCode);
				}

				if (bindStartDate) {
					qPos.add(new Timestamp(startDate.getTime()));
				}

				if (bindEndDate) {
					qPos.add(new Timestamp(endDate.getTime()));
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction findByAN_PC_SD_ED_C_First(
			String accountNo, String planCode, Date startDate, Date endDate,
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByAN_PC_SD_ED_C_First(
			accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);

		if (cpTransaction != null) {
			return cpTransaction;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", planCode=");
		msg.append(planCode);

		msg.append(", startDate=");
		msg.append(startDate);

		msg.append(", endDate=");
		msg.append(endDate);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPTransactionException(msg.toString());
	}

	/**
	 * Returns the first cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction fetchByAN_PC_SD_ED_C_First(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		List<CPTransaction> list = findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction findByAN_PC_SD_ED_C_Last(
			String accountNo, String planCode, Date startDate, Date endDate,
			long companyId, OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByAN_PC_SD_ED_C_Last(
			accountNo, planCode, startDate, endDate, companyId,
			orderByComparator);

		if (cpTransaction != null) {
			return cpTransaction;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", planCode=");
		msg.append(planCode);

		msg.append(", startDate=");
		msg.append(startDate);

		msg.append(", endDate=");
		msg.append(endDate);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPTransactionException(msg.toString());
	}

	/**
	 * Returns the last cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction fetchByAN_PC_SD_ED_C_Last(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId, OrderByComparator<CPTransaction> orderByComparator) {

		int count = countByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId);

		if (count == 0) {
			return null;
		}

		List<CPTransaction> list = findByAN_PC_SD_ED_C(
			accountNo, planCode, startDate, endDate, companyId, count - 1,
			count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction[] findByAN_PC_SD_ED_C_PrevAndNext(
			String cptId, String accountNo, String planCode, Date startDate,
			Date endDate, long companyId,
			OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		accountNo = Objects.toString(accountNo, "");
		planCode = Objects.toString(planCode, "");

		CPTransaction cpTransaction = findByPrimaryKey(cptId);

		Session session = null;

		try {
			session = openSession();

			CPTransaction[] array = new CPTransactionImpl[3];

			array[0] = getByAN_PC_SD_ED_C_PrevAndNext(
				session, cpTransaction, accountNo, planCode, startDate, endDate,
				companyId, orderByComparator, true);

			array[1] = cpTransaction;

			array[2] = getByAN_PC_SD_ED_C_PrevAndNext(
				session, cpTransaction, accountNo, planCode, startDate, endDate,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CPTransaction getByAN_PC_SD_ED_C_PrevAndNext(
		Session session, CPTransaction cpTransaction, String accountNo,
		String planCode, Date startDate, Date endDate, long companyId,
		OrderByComparator<CPTransaction> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				8 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(7);
		}

		query.append(_SQL_SELECT_CPTRANSACTION_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_2);
		}

		boolean bindPlanCode = false;

		if (planCode.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_3);
		}
		else {
			bindPlanCode = true;

			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_2);
		}

		boolean bindStartDate = false;

		if (startDate == null) {
			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_1);
		}
		else {
			bindStartDate = true;

			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_2);
		}

		boolean bindEndDate = false;

		if (endDate == null) {
			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_1);
		}
		else {
			bindEndDate = true;

			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_2);
		}

		query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPTransactionModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindPlanCode) {
			qPos.add(planCode);
		}

		if (bindStartDate) {
			qPos.add(new Timestamp(startDate.getTime()));
		}

		if (bindEndDate) {
			qPos.add(new Timestamp(endDate.getTime()));
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						cpTransaction)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CPTransaction> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId) {

		for (CPTransaction cpTransaction :
				findByAN_PC_SD_ED_C(
					accountNo, planCode, startDate, endDate, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cpTransaction);
		}
	}

	/**
	 * Returns the number of cp transactions where accountNo = &#63; and planCode = &#63; and startDate = &#63; and endDate = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param planCode the plan code
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param companyId the company ID
	 * @return the number of matching cp transactions
	 */
	@Override
	public int countByAN_PC_SD_ED_C(
		String accountNo, String planCode, Date startDate, Date endDate,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		planCode = Objects.toString(planCode, "");

		FinderPath finderPath = _finderPathCountByAN_PC_SD_ED_C;

		Object[] finderArgs = new Object[] {
			accountNo, planCode, _getTime(startDate), _getTime(endDate),
			companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_CPTRANSACTION_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_2);
			}

			boolean bindPlanCode = false;

			if (planCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_3);
			}
			else {
				bindPlanCode = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_2);
			}

			boolean bindStartDate = false;

			if (startDate == null) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_1);
			}
			else {
				bindStartDate = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_2);
			}

			boolean bindEndDate = false;

			if (endDate == null) {
				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_1);
			}
			else {
				bindEndDate = true;

				query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_2);
			}

			query.append(_FINDER_COLUMN_AN_PC_SD_ED_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindPlanCode) {
					qPos.add(planCode);
				}

				if (bindStartDate) {
					qPos.add(new Timestamp(startDate.getTime()));
				}

				if (bindEndDate) {
					qPos.add(new Timestamp(endDate.getTime()));
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_2 =
		"cpTransaction.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_ACCOUNTNO_3 =
		"(cpTransaction.accountNo IS NULL OR cpTransaction.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_2 =
		"cpTransaction.planCode = ? AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_PLANCODE_3 =
		"(cpTransaction.planCode IS NULL OR cpTransaction.planCode = '') AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_1 =
		"cpTransaction.startDate IS NULL AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_STARTDATE_2 =
		"cpTransaction.startDate = ? AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_1 =
		"cpTransaction.endDate IS NULL AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_ENDDATE_2 =
		"cpTransaction.endDate = ? AND ";

	private static final String _FINDER_COLUMN_AN_PC_SD_ED_C_COMPANYID_2 =
		"cpTransaction.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCPId;
	private FinderPath _finderPathWithoutPaginationFindByCPId;
	private FinderPath _finderPathCountByCPId;

	/**
	 * Returns all the cp transactions where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @return the matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCPId(String cpId) {
		return findByCPId(cpId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCPId(String cpId, int start, int end) {
		return findByCPId(cpId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCPId(
		String cpId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return findByCPId(cpId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cp transactions where cpId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param cpId the cp ID
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cp transactions
	 */
	@Override
	public List<CPTransaction> findByCPId(
		String cpId, int start, int end,
		OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		cpId = Objects.toString(cpId, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCPId;
			finderArgs = new Object[] {cpId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCPId;
			finderArgs = new Object[] {cpId, start, end, orderByComparator};
		}

		List<CPTransaction> list = null;

		if (retrieveFromCache) {
			list = (List<CPTransaction>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CPTransaction cpTransaction : list) {
					if (!cpId.equals(cpTransaction.getCpId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_CPTRANSACTION_WHERE);

			boolean bindCpId = false;

			if (cpId.isEmpty()) {
				query.append(_FINDER_COLUMN_CPID_CPID_3);
			}
			else {
				bindCpId = true;

				query.append(_FINDER_COLUMN_CPID_CPID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPTransactionModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCpId) {
					qPos.add(cpId);
				}

				if (!pagination) {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction findByCPId_First(
			String cpId, OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByCPId_First(
			cpId, orderByComparator);

		if (cpTransaction != null) {
			return cpTransaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("cpId=");
		msg.append(cpId);

		msg.append("}");

		throw new NoSuchCPTransactionException(msg.toString());
	}

	/**
	 * Returns the first cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction fetchByCPId_First(
		String cpId, OrderByComparator<CPTransaction> orderByComparator) {

		List<CPTransaction> list = findByCPId(cpId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction
	 * @throws NoSuchCPTransactionException if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction findByCPId_Last(
			String cpId, OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByCPId_Last(cpId, orderByComparator);

		if (cpTransaction != null) {
			return cpTransaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("cpId=");
		msg.append(cpId);

		msg.append("}");

		throw new NoSuchCPTransactionException(msg.toString());
	}

	/**
	 * Returns the last cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp transaction, or <code>null</code> if a matching cp transaction could not be found
	 */
	@Override
	public CPTransaction fetchByCPId_Last(
		String cpId, OrderByComparator<CPTransaction> orderByComparator) {

		int count = countByCPId(cpId);

		if (count == 0) {
			return null;
		}

		List<CPTransaction> list = findByCPId(
			cpId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cp transactions before and after the current cp transaction in the ordered set where cpId = &#63;.
	 *
	 * @param cptId the primary key of the current cp transaction
	 * @param cpId the cp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction[] findByCPId_PrevAndNext(
			String cptId, String cpId,
			OrderByComparator<CPTransaction> orderByComparator)
		throws NoSuchCPTransactionException {

		cpId = Objects.toString(cpId, "");

		CPTransaction cpTransaction = findByPrimaryKey(cptId);

		Session session = null;

		try {
			session = openSession();

			CPTransaction[] array = new CPTransactionImpl[3];

			array[0] = getByCPId_PrevAndNext(
				session, cpTransaction, cpId, orderByComparator, true);

			array[1] = cpTransaction;

			array[2] = getByCPId_PrevAndNext(
				session, cpTransaction, cpId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CPTransaction getByCPId_PrevAndNext(
		Session session, CPTransaction cpTransaction, String cpId,
		OrderByComparator<CPTransaction> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_CPTRANSACTION_WHERE);

		boolean bindCpId = false;

		if (cpId.isEmpty()) {
			query.append(_FINDER_COLUMN_CPID_CPID_3);
		}
		else {
			bindCpId = true;

			query.append(_FINDER_COLUMN_CPID_CPID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPTransactionModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCpId) {
			qPos.add(cpId);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						cpTransaction)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CPTransaction> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cp transactions where cpId = &#63; from the database.
	 *
	 * @param cpId the cp ID
	 */
	@Override
	public void removeByCPId(String cpId) {
		for (CPTransaction cpTransaction :
				findByCPId(cpId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cpTransaction);
		}
	}

	/**
	 * Returns the number of cp transactions where cpId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @return the number of matching cp transactions
	 */
	@Override
	public int countByCPId(String cpId) {
		cpId = Objects.toString(cpId, "");

		FinderPath finderPath = _finderPathCountByCPId;

		Object[] finderArgs = new Object[] {cpId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_CPTRANSACTION_WHERE);

			boolean bindCpId = false;

			if (cpId.isEmpty()) {
				query.append(_FINDER_COLUMN_CPID_CPID_3);
			}
			else {
				bindCpId = true;

				query.append(_FINDER_COLUMN_CPID_CPID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCpId) {
					qPos.add(cpId);
				}

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CPID_CPID_2 =
		"cpTransaction.cpId = ?";

	private static final String _FINDER_COLUMN_CPID_CPID_3 =
		"(cpTransaction.cpId IS NULL OR cpTransaction.cpId = '')";

	public CPTransactionPersistenceImpl() {
		setModelClass(CPTransaction.class);

		setModelImplClass(CPTransactionImpl.class);
		setModelPKClass(String.class);

		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("active", "active_");

		setDBColumnNames(dbColumnNames);
	}

	/**
	 * Caches the cp transaction in the entity cache if it is enabled.
	 *
	 * @param cpTransaction the cp transaction
	 */
	@Override
	public void cacheResult(CPTransaction cpTransaction) {
		entityCache.putResult(
			entityCacheEnabled, CPTransactionImpl.class,
			cpTransaction.getPrimaryKey(), cpTransaction);

		cpTransaction.resetOriginalValues();
	}

	/**
	 * Caches the cp transactions in the entity cache if it is enabled.
	 *
	 * @param cpTransactions the cp transactions
	 */
	@Override
	public void cacheResult(List<CPTransaction> cpTransactions) {
		for (CPTransaction cpTransaction : cpTransactions) {
			if (entityCache.getResult(
					entityCacheEnabled, CPTransactionImpl.class,
					cpTransaction.getPrimaryKey()) == null) {

				cacheResult(cpTransaction);
			}
			else {
				cpTransaction.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all cp transactions.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(CPTransactionImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the cp transaction.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(CPTransaction cpTransaction) {
		entityCache.removeResult(
			entityCacheEnabled, CPTransactionImpl.class,
			cpTransaction.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<CPTransaction> cpTransactions) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (CPTransaction cpTransaction : cpTransactions) {
			entityCache.removeResult(
				entityCacheEnabled, CPTransactionImpl.class,
				cpTransaction.getPrimaryKey());
		}
	}

	/**
	 * Creates a new cp transaction with the primary key. Does not add the cp transaction to the database.
	 *
	 * @param cptId the primary key for the new cp transaction
	 * @return the new cp transaction
	 */
	@Override
	public CPTransaction create(String cptId) {
		CPTransaction cpTransaction = new CPTransactionImpl();

		cpTransaction.setNew(true);
		cpTransaction.setPrimaryKey(cptId);

		cpTransaction.setCompanyId(companyProvider.getCompanyId());

		return cpTransaction;
	}

	/**
	 * Removes the cp transaction with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction that was removed
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction remove(String cptId)
		throws NoSuchCPTransactionException {

		return remove((Serializable)cptId);
	}

	/**
	 * Removes the cp transaction with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the cp transaction
	 * @return the cp transaction that was removed
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction remove(Serializable primaryKey)
		throws NoSuchCPTransactionException {

		Session session = null;

		try {
			session = openSession();

			CPTransaction cpTransaction = (CPTransaction)session.get(
				CPTransactionImpl.class, primaryKey);

			if (cpTransaction == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchCPTransactionException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(cpTransaction);
		}
		catch (NoSuchCPTransactionException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected CPTransaction removeImpl(CPTransaction cpTransaction) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(cpTransaction)) {
				cpTransaction = (CPTransaction)session.get(
					CPTransactionImpl.class, cpTransaction.getPrimaryKeyObj());
			}

			if (cpTransaction != null) {
				session.delete(cpTransaction);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (cpTransaction != null) {
			clearCache(cpTransaction);
		}

		return cpTransaction;
	}

	@Override
	public CPTransaction updateImpl(CPTransaction cpTransaction) {
		boolean isNew = cpTransaction.isNew();

		if (!(cpTransaction instanceof CPTransactionModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(cpTransaction.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					cpTransaction);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in cpTransaction proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom CPTransaction implementation " +
					cpTransaction.getClass());
		}

		CPTransactionModelImpl cpTransactionModelImpl =
			(CPTransactionModelImpl)cpTransaction;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (cpTransaction.getCreateDate() == null)) {
			if (serviceContext == null) {
				cpTransaction.setCreateDate(now);
			}
			else {
				cpTransaction.setCreateDate(serviceContext.getCreateDate(now));
			}
		}

		if (!cpTransactionModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				cpTransaction.setModifiedDate(now);
			}
			else {
				cpTransaction.setModifiedDate(
					serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (cpTransaction.isNew()) {
				session.save(cpTransaction);

				cpTransaction.setNew(false);
			}
			else {
				cpTransaction = (CPTransaction)session.merge(cpTransaction);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {
				cpTransactionModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			args = new Object[] {
				cpTransactionModelImpl.getAccountNo(),
				cpTransactionModelImpl.getPlanCode(),
				cpTransactionModelImpl.getStartDate(),
				cpTransactionModelImpl.getEndDate(),
				cpTransactionModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_PC_SD_ED_C, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_PC_SD_ED_C, args);

			args = new Object[] {cpTransactionModelImpl.getCpId()};

			finderCache.removeResult(_finderPathCountByCPId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCPId, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((cpTransactionModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpTransactionModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {cpTransactionModelImpl.getCompanyId()};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}

			if ((cpTransactionModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_PC_SD_ED_C.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpTransactionModelImpl.getOriginalAccountNo(),
					cpTransactionModelImpl.getOriginalPlanCode(),
					cpTransactionModelImpl.getOriginalStartDate(),
					cpTransactionModelImpl.getOriginalEndDate(),
					cpTransactionModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_PC_SD_ED_C, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_PC_SD_ED_C, args);

				args = new Object[] {
					cpTransactionModelImpl.getAccountNo(),
					cpTransactionModelImpl.getPlanCode(),
					cpTransactionModelImpl.getStartDate(),
					cpTransactionModelImpl.getEndDate(),
					cpTransactionModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_PC_SD_ED_C, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_PC_SD_ED_C, args);
			}

			if ((cpTransactionModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCPId.getColumnBitmask()) !=
					 0) {

				Object[] args = new Object[] {
					cpTransactionModelImpl.getOriginalCpId()
				};

				finderCache.removeResult(_finderPathCountByCPId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCPId, args);

				args = new Object[] {cpTransactionModelImpl.getCpId()};

				finderCache.removeResult(_finderPathCountByCPId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCPId, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, CPTransactionImpl.class,
			cpTransaction.getPrimaryKey(), cpTransaction, false);

		cpTransaction.resetOriginalValues();

		return cpTransaction;
	}

	/**
	 * Returns the cp transaction with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the cp transaction
	 * @return the cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction findByPrimaryKey(Serializable primaryKey)
		throws NoSuchCPTransactionException {

		CPTransaction cpTransaction = fetchByPrimaryKey(primaryKey);

		if (cpTransaction == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchCPTransactionException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return cpTransaction;
	}

	/**
	 * Returns the cp transaction with the primary key or throws a <code>NoSuchCPTransactionException</code> if it could not be found.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction
	 * @throws NoSuchCPTransactionException if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction findByPrimaryKey(String cptId)
		throws NoSuchCPTransactionException {

		return findByPrimaryKey((Serializable)cptId);
	}

	/**
	 * Returns the cp transaction with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param cptId the primary key of the cp transaction
	 * @return the cp transaction, or <code>null</code> if a cp transaction with the primary key could not be found
	 */
	@Override
	public CPTransaction fetchByPrimaryKey(String cptId) {
		return fetchByPrimaryKey((Serializable)cptId);
	}

	/**
	 * Returns all the cp transactions.
	 *
	 * @return the cp transactions
	 */
	@Override
	public List<CPTransaction> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @return the range of cp transactions
	 */
	@Override
	public List<CPTransaction> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of cp transactions
	 */
	@Override
	public List<CPTransaction> findAll(
		int start, int end,
		OrderByComparator<CPTransaction> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cp transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPTransactionModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cp transactions
	 * @param end the upper bound of the range of cp transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of cp transactions
	 */
	@Override
	public List<CPTransaction> findAll(
		int start, int end, OrderByComparator<CPTransaction> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<CPTransaction> list = null;

		if (retrieveFromCache) {
			list = (List<CPTransaction>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_CPTRANSACTION);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_CPTRANSACTION;

				if (pagination) {
					sql = sql.concat(CPTransactionModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CPTransaction>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the cp transactions from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (CPTransaction cpTransaction : findAll()) {
			remove(cpTransaction);
		}
	}

	/**
	 * Returns the number of cp transactions.
	 *
	 * @return the number of cp transactions
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_CPTRANSACTION);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "cptId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_CPTRANSACTION;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return CPTransactionModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the cp transaction persistence.
	 */
	@Activate
	public void activate() {
		CPTransactionModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		CPTransactionModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			CPTransactionModelImpl.COMPANYID_COLUMN_BITMASK |
			CPTransactionModelImpl.CPID_COLUMN_BITMASK |
			CPTransactionModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});

		_finderPathWithPaginationFindByAN_PC_SD_ED_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_PC_SD_ED_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				Date.class.getName(), Date.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_PC_SD_ED_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_PC_SD_ED_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				Date.class.getName(), Date.class.getName(), Long.class.getName()
			},
			CPTransactionModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPTransactionModelImpl.PLANCODE_COLUMN_BITMASK |
			CPTransactionModelImpl.STARTDATE_COLUMN_BITMASK |
			CPTransactionModelImpl.ENDDATE_COLUMN_BITMASK |
			CPTransactionModelImpl.COMPANYID_COLUMN_BITMASK |
			CPTransactionModelImpl.CPID_COLUMN_BITMASK |
			CPTransactionModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_PC_SD_ED_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_PC_SD_ED_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				Date.class.getName(), Date.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByCPId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCPId",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCPId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPTransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCPId",
			new String[] {String.class.getName()},
			CPTransactionModelImpl.CPID_COLUMN_BITMASK |
			CPTransactionModelImpl.COMPANYID_COLUMN_BITMASK |
			CPTransactionModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCPId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCPId",
			new String[] {String.class.getName()});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(CPTransactionImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ATMPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.telecom.model.CPTransaction"),
			true);
	}

	@Override
	@Reference(
		target = ATMPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ATMPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private Long _getTime(Date date) {
		if (date == null) {
			return null;
		}

		return date.getTime();
	}

	private static final String _SQL_SELECT_CPTRANSACTION =
		"SELECT cpTransaction FROM CPTransaction cpTransaction";

	private static final String _SQL_SELECT_CPTRANSACTION_WHERE =
		"SELECT cpTransaction FROM CPTransaction cpTransaction WHERE ";

	private static final String _SQL_COUNT_CPTRANSACTION =
		"SELECT COUNT(cpTransaction) FROM CPTransaction cpTransaction";

	private static final String _SQL_COUNT_CPTRANSACTION_WHERE =
		"SELECT COUNT(cpTransaction) FROM CPTransaction cpTransaction WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "cpTransaction.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No CPTransaction exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No CPTransaction exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		CPTransactionPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"active"});

}