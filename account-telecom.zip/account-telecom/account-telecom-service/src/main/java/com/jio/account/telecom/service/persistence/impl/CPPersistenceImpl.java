/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.persistence.impl;

import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.model.impl.CPImpl;
import com.jio.account.telecom.model.impl.CPModelImpl;
import com.jio.account.telecom.service.persistence.CPPersistence;
import com.jio.account.telecom.service.persistence.impl.constants.ATMPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the cp service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = CPPersistence.class)
@ProviderType
public class CPPersistenceImpl
	extends BasePersistenceImpl<CP> implements CPPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>CPUtil</code> to access the cp persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		CPImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathFetchByCPId;
	private FinderPath _finderPathCountByCPId;

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByCPId(String cpId, long companyId) throws NoSuchCPException {
		CP cp = fetchByCPId(cpId, companyId);

		if (cp == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("cpId=");
			msg.append(cpId);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCPException(msg.toString());
		}

		return cp;
	}

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByCPId(String cpId, long companyId) {
		return fetchByCPId(cpId, companyId, true);
	}

	/**
	 * Returns the cp where cpId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByCPId(
		String cpId, long companyId, boolean retrieveFromCache) {

		cpId = Objects.toString(cpId, "");

		Object[] finderArgs = new Object[] {cpId, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByCPId, finderArgs, this);
		}

		if (result instanceof CP) {
			CP cp = (CP)result;

			if (!Objects.equals(cpId, cp.getCpId()) ||
				(companyId != cp.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindCpId = false;

			if (cpId.isEmpty()) {
				query.append(_FINDER_COLUMN_CPID_CPID_3);
			}
			else {
				bindCpId = true;

				query.append(_FINDER_COLUMN_CPID_CPID_2);
			}

			query.append(_FINDER_COLUMN_CPID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCpId) {
					qPos.add(cpId);
				}

				qPos.add(companyId);

				List<CP> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByCPId, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CPPersistenceImpl.fetchByCPId(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					CP cp = list.get(0);

					result = cp;

					cacheResult(cp);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByCPId, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (CP)result;
		}
	}

	/**
	 * Removes the cp where cpId = &#63; and companyId = &#63; from the database.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	@Override
	public CP removeByCPId(String cpId, long companyId)
		throws NoSuchCPException {

		CP cp = findByCPId(cpId, companyId);

		return remove(cp);
	}

	/**
	 * Returns the number of cps where cpId = &#63; and companyId = &#63;.
	 *
	 * @param cpId the cp ID
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByCPId(String cpId, long companyId) {
		cpId = Objects.toString(cpId, "");

		FinderPath finderPath = _finderPathCountByCPId;

		Object[] finderArgs = new Object[] {cpId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindCpId = false;

			if (cpId.isEmpty()) {
				query.append(_FINDER_COLUMN_CPID_CPID_3);
			}
			else {
				bindCpId = true;

				query.append(_FINDER_COLUMN_CPID_CPID_2);
			}

			query.append(_FINDER_COLUMN_CPID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCpId) {
					qPos.add(cpId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CPID_CPID_2 = "cp.cpId = ? AND ";

	private static final String _FINDER_COLUMN_CPID_CPID_3 =
		"(cp.cpId IS NULL OR cp.cpId = '') AND ";

	private static final String _FINDER_COLUMN_CPID_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAutoRenew;
	private FinderPath _finderPathWithoutPaginationFindByAutoRenew;
	private FinderPath _finderPathCountByAutoRenew;

	/**
	 * Returns all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAutoRenew(boolean autoRenew, long companyId) {
		return findByAutoRenew(
			autoRenew, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end) {

		return findByAutoRenew(autoRenew, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAutoRenew(
			autoRenew, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAutoRenew(
		boolean autoRenew, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAutoRenew;
			finderArgs = new Object[] {autoRenew, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAutoRenew;
			finderArgs = new Object[] {
				autoRenew, companyId, start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if ((autoRenew != cp.isAutoRenew()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			query.append(_FINDER_COLUMN_AUTORENEW_AUTORENEW_2);

			query.append(_FINDER_COLUMN_AUTORENEW_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(autoRenew);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAutoRenew_First(
			boolean autoRenew, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAutoRenew_First(autoRenew, companyId, orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("autoRenew=");
		msg.append(autoRenew);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAutoRenew_First(
		boolean autoRenew, long companyId,
		OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAutoRenew(
			autoRenew, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAutoRenew_Last(
			boolean autoRenew, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAutoRenew_Last(autoRenew, companyId, orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("autoRenew=");
		msg.append(autoRenew);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAutoRenew_Last(
		boolean autoRenew, long companyId,
		OrderByComparator<CP> orderByComparator) {

		int count = countByAutoRenew(autoRenew, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAutoRenew(
			autoRenew, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAutoRenew_PrevAndNext(
			String cpId, boolean autoRenew, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAutoRenew_PrevAndNext(
				session, cp, autoRenew, companyId, orderByComparator, true);

			array[1] = cp;

			array[2] = getByAutoRenew_PrevAndNext(
				session, cp, autoRenew, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAutoRenew_PrevAndNext(
		Session session, CP cp, boolean autoRenew, long companyId,
		OrderByComparator<CP> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		query.append(_FINDER_COLUMN_AUTORENEW_AUTORENEW_2);

		query.append(_FINDER_COLUMN_AUTORENEW_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(autoRenew);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cps where autoRenew = &#63; and companyId = &#63; from the database.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAutoRenew(boolean autoRenew, long companyId) {
		for (CP cp :
				findByAutoRenew(
					autoRenew, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where autoRenew = &#63; and companyId = &#63;.
	 *
	 * @param autoRenew the auto renew
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAutoRenew(boolean autoRenew, long companyId) {
		FinderPath finderPath = _finderPathCountByAutoRenew;

		Object[] finderArgs = new Object[] {autoRenew, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CP_WHERE);

			query.append(_FINDER_COLUMN_AUTORENEW_AUTORENEW_2);

			query.append(_FINDER_COLUMN_AUTORENEW_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(autoRenew);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AUTORENEW_AUTORENEW_2 =
		"cp.autoRenew = ? AND ";

	private static final String _FINDER_COLUMN_AUTORENEW_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the cps where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByCompanyId(long companyId, int start, int end) {
		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if ((companyId != cp.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByCompanyId_First(
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByCompanyId_First(companyId, orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByCompanyId_First(
		long companyId, OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByCompanyId(companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByCompanyId_Last(
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByCompanyId_Last(companyId, orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByCompanyId_Last(
		long companyId, OrderByComparator<CP> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByCompanyId_PrevAndNext(
			String cpId, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, cp, companyId, orderByComparator, true);

			array[1] = cp;

			array[2] = getByCompanyId_PrevAndNext(
				session, cp, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByCompanyId_PrevAndNext(
		Session session, CP cp, long companyId,
		OrderByComparator<CP> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cps where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (CP cp :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_CP_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_CSN;
	private FinderPath _finderPathWithoutPaginationFindByAN_CSN;
	private FinderPath _finderPathCountByAN_CSN;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId) {

		return findByAN_CSN(
			accountNo, customerScreenName, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end) {

		return findByAN_CSN(
			accountNo, customerScreenName, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end, OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN(
			accountNo, customerScreenName, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN(
		String accountNo, String customerScreenName, long companyId, int start,
		int end, OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_CSN;
			finderArgs = new Object[] {
				accountNo, customerScreenName, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_CSN;
			finderArgs = new Object[] {
				accountNo, customerScreenName, companyId, start, end,
				orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_First(
			String accountNo, String customerScreenName, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_First(
			accountNo, customerScreenName, companyId, orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_First(
		String accountNo, String customerScreenName, long companyId,
		OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAN_CSN(
			accountNo, customerScreenName, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_Last(
			String accountNo, String customerScreenName, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_Last(
			accountNo, customerScreenName, companyId, orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_Last(
		String accountNo, String customerScreenName, long companyId,
		OrderByComparator<CP> orderByComparator) {

		int count = countByAN_CSN(accountNo, customerScreenName, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAN_CSN(
			accountNo, customerScreenName, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAN_CSN_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAN_CSN_PrevAndNext(
				session, cp, accountNo, customerScreenName, companyId,
				orderByComparator, true);

			array[1] = cp;

			array[2] = getByAN_CSN_PrevAndNext(
				session, cp, accountNo, customerScreenName, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAN_CSN_PrevAndNext(
		Session session, CP cp, String accountNo, String customerScreenName,
		long companyId, OrderByComparator<CP> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_CSN_ACCOUNTNO_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_AN_CSN_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_CSN(
		String accountNo, String customerScreenName, long companyId) {

		for (CP cp :
				findByAN_CSN(
					accountNo, customerScreenName, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN(
		String accountNo, String customerScreenName, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_CSN;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathFetchByAN_CSN_P;
	private FinderPath _finderPathCountByAN_CSN_P;

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_P(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId);

		if (cp == null) {
			StringBundler msg = new StringBundler(10);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", customerScreenName=");
			msg.append(customerScreenName);

			msg.append(", planCode=");
			msg.append(planCode);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCPException(msg.toString());
		}

		return cp;
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId) {

		return fetchByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId, true);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		planCode = Objects.toString(planCode, "");

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, planCode, companyId
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAN_CSN_P, finderArgs, this);
		}

		if (result instanceof CP) {
			CP cp = (CP)result;

			if (!Objects.equals(accountNo, cp.getAccountNo()) ||
				!Objects.equals(
					customerScreenName, cp.getCustomerScreenName()) ||
				!Objects.equals(planCode, cp.getPlanCode()) ||
				(companyId != cp.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_CUSTOMERSCREENNAME_2);
			}

			boolean bindPlanCode = false;

			if (planCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_PLANCODE_3);
			}
			else {
				bindPlanCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_PLANCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_P_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindPlanCode) {
					qPos.add(planCode);
				}

				qPos.add(companyId);

				List<CP> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAN_CSN_P, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CPPersistenceImpl.fetchByAN_CSN_P(String, String, String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					CP cp = list.get(0);

					result = cp;

					cacheResult(cp);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAN_CSN_P, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (CP)result;
		}
	}

	/**
	 * Removes the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	@Override
	public CP removeByAN_CSN_P(
			String accountNo, String customerScreenName, String planCode,
			long companyId)
		throws NoSuchCPException {

		CP cp = findByAN_CSN_P(
			accountNo, customerScreenName, planCode, companyId);

		return remove(cp);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_P(
		String accountNo, String customerScreenName, String planCode,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		planCode = Objects.toString(planCode, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_P;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, planCode, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_CUSTOMERSCREENNAME_2);
			}

			boolean bindPlanCode = false;

			if (planCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_PLANCODE_3);
			}
			else {
				bindPlanCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_PLANCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_P_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindPlanCode) {
					qPos.add(planCode);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_P_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_PLANCODE_2 =
		"cp.planCode = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_PLANCODE_3 =
		"(cp.planCode IS NULL OR cp.planCode = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathFetchByAN_CSN_P_A;
	private FinderPath _finderPathCountByAN_CSN_P_A;

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_P_A(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId);

		if (cp == null) {
			StringBundler msg = new StringBundler(12);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("accountNo=");
			msg.append(accountNo);

			msg.append(", customerScreenName=");
			msg.append(customerScreenName);

			msg.append(", planCode=");
			msg.append(planCode);

			msg.append(", active=");
			msg.append(active);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchCPException(msg.toString());
		}

		return cp;
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId) {

		return fetchByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId, true);
	}

	/**
	 * Returns the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		planCode = Objects.toString(planCode, "");

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, planCode, active, companyId
		};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByAN_CSN_P_A, finderArgs, this);
		}

		if (result instanceof CP) {
			CP cp = (CP)result;

			if (!Objects.equals(accountNo, cp.getAccountNo()) ||
				!Objects.equals(
					customerScreenName, cp.getCustomerScreenName()) ||
				!Objects.equals(planCode, cp.getPlanCode()) ||
				(active != cp.isActive()) || (companyId != cp.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(7);

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_A_CUSTOMERSCREENNAME_2);
			}

			boolean bindPlanCode = false;

			if (planCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_A_PLANCODE_3);
			}
			else {
				bindPlanCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_A_PLANCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_P_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_P_A_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindPlanCode) {
					qPos.add(planCode);
				}

				qPos.add(active);

				qPos.add(companyId);

				List<CP> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByAN_CSN_P_A, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"CPPersistenceImpl.fetchByAN_CSN_P_A(String, String, String, boolean, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					CP cp = list.get(0);

					result = cp;

					cacheResult(cp);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByAN_CSN_P_A, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (CP)result;
		}
	}

	/**
	 * Removes the cp where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the cp that was removed
	 */
	@Override
	public CP removeByAN_CSN_P_A(
			String accountNo, String customerScreenName, String planCode,
			boolean active, long companyId)
		throws NoSuchCPException {

		CP cp = findByAN_CSN_P_A(
			accountNo, customerScreenName, planCode, active, companyId);

		return remove(cp);
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and planCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param planCode the plan code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_P_A(
		String accountNo, String customerScreenName, String planCode,
		boolean active, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		planCode = Objects.toString(planCode, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_P_A;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, planCode, active, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_A_CUSTOMERSCREENNAME_2);
			}

			boolean bindPlanCode = false;

			if (planCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_P_A_PLANCODE_3);
			}
			else {
				bindPlanCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_P_A_PLANCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_P_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_P_A_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindPlanCode) {
					qPos.add(planCode);
				}

				qPos.add(active);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_P_A_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_PLANCODE_2 =
		"cp.planCode = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_PLANCODE_3 =
		"(cp.planCode IS NULL OR cp.planCode = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_ACTIVE_2 =
		"cp.active = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_P_A_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_CSN_C;
	private FinderPath _finderPathWithoutPaginationFindByAN_CSN_C;
	private FinderPath _finderPathCountByAN_CSN_C;
	private FinderPath _finderPathWithPaginationCountByAN_CSN_C;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId) {

		return findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end) {

		return findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		categoryCode = Objects.toString(categoryCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_CSN_C;
			finderArgs = new Object[] {
				accountNo, customerScreenName, categoryCode, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_CSN_C;
			finderArgs = new Object[] {
				accountNo, customerScreenName, categoryCode, companyId, start,
				end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						!categoryCode.equals(cp.getCategoryCode()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_2);
			}

			boolean bindCategoryCode = false;

			if (categoryCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_3);
			}
			else {
				bindCategoryCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindCategoryCode) {
					qPos.add(categoryCode);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_C_First(
			String accountNo, String customerScreenName, String categoryCode,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_C_First(
			accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", categoryCode=");
		msg.append(categoryCode);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_C_First(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_C_Last(
			String accountNo, String customerScreenName, String categoryCode,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_C_Last(
			accountNo, customerScreenName, categoryCode, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", categoryCode=");
		msg.append(categoryCode);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_C_Last(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId, OrderByComparator<CP> orderByComparator) {

		int count = countByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAN_CSN_C(
			accountNo, customerScreenName, categoryCode, companyId, count - 1,
			count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAN_CSN_C_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			String categoryCode, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		categoryCode = Objects.toString(categoryCode, "");

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAN_CSN_C_PrevAndNext(
				session, cp, accountNo, customerScreenName, categoryCode,
				companyId, orderByComparator, true);

			array[1] = cp;

			array[2] = getByAN_CSN_C_PrevAndNext(
				session, cp, accountNo, customerScreenName, categoryCode,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAN_CSN_C_PrevAndNext(
		Session session, CP cp, String accountNo, String customerScreenName,
		String categoryCode, long companyId,
		OrderByComparator<CP> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_2);
		}

		boolean bindCategoryCode = false;

		if (categoryCode.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_3);
		}
		else {
			bindCategoryCode = true;

			query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_2);
		}

		query.append(_FINDER_COLUMN_AN_CSN_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (bindCategoryCode) {
			qPos.add(categoryCode);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId) {

		return findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end) {

		return findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_C(
			accountNo, customerScreenName, categoryCodes, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		if (categoryCodes == null) {
			categoryCodes = new String[0];
		}
		else if (categoryCodes.length > 1) {
			for (int i = 0; i < categoryCodes.length; i++) {
				categoryCodes[i] = Objects.toString(categoryCodes[i], "");
			}

			categoryCodes = ArrayUtil.sortedUnique(categoryCodes);
		}

		if (categoryCodes.length == 1) {
			return findByAN_CSN_C(
				accountNo, customerScreenName, categoryCodes[0], companyId,
				start, end, orderByComparator);
		}

		boolean pagination = true;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderArgs = new Object[] {
				accountNo, customerScreenName, StringUtil.merge(categoryCodes),
				companyId
			};
		}
		else {
			finderArgs = new Object[] {
				accountNo, customerScreenName, StringUtil.merge(categoryCodes),
				companyId, start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				_finderPathWithPaginationFindByAN_CSN_C, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						!ArrayUtil.contains(
							categoryCodes, cp.getCategoryCode()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_2);
			}

			if (categoryCodes.length > 0) {
				query.append("(");

				for (int i = 0; i < categoryCodes.length; i++) {
					String categoryCode = categoryCodes[i];

					if (categoryCode.isEmpty()) {
						query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_6);
					}
					else {
						query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_5);
					}

					if ((i + 1) < categoryCodes.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");

				query.append(WHERE_AND);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_COMPANYID_2);

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				for (String categoryCode : categoryCodes) {
					if (categoryCode != null && !categoryCode.isEmpty()) {
						qPos.add(categoryCode);
					}
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(
					_finderPathWithPaginationFindByAN_CSN_C, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationFindByAN_CSN_C, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId) {

		for (CP cp :
				findByAN_CSN_C(
					accountNo, customerScreenName, categoryCode, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_C(
		String accountNo, String customerScreenName, String categoryCode,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		categoryCode = Objects.toString(categoryCode, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_C;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, categoryCode, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_2);
			}

			boolean bindCategoryCode = false;

			if (categoryCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_3);
			}
			else {
				bindCategoryCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindCategoryCode) {
					qPos.add(categoryCode);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_C(
		String accountNo, String customerScreenName, String[] categoryCodes,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		if (categoryCodes == null) {
			categoryCodes = new String[0];
		}
		else if (categoryCodes.length > 1) {
			for (int i = 0; i < categoryCodes.length; i++) {
				categoryCodes[i] = Objects.toString(categoryCodes[i], "");
			}

			categoryCodes = ArrayUtil.sortedUnique(categoryCodes);
		}

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, StringUtil.merge(categoryCodes),
			companyId
		};

		Long count = (Long)finderCache.getResult(
			_finderPathWithPaginationCountByAN_CSN_C, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_2);
			}

			if (categoryCodes.length > 0) {
				query.append("(");

				for (int i = 0; i < categoryCodes.length; i++) {
					String categoryCode = categoryCodes[i];

					if (categoryCode.isEmpty()) {
						query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_6);
					}
					else {
						query.append(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_5);
					}

					if ((i + 1) < categoryCodes.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");

				query.append(WHERE_AND);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_COMPANYID_2);

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				for (String categoryCode : categoryCodes) {
					if (categoryCode != null && !categoryCode.isEmpty()) {
						qPos.add(categoryCode);
					}
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathWithPaginationCountByAN_CSN_C, finderArgs,
					count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationCountByAN_CSN_C, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_2 =
		"cp.categoryCode = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_3 =
		"(cp.categoryCode IS NULL OR cp.categoryCode = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_5 =
		"(" + removeConjunction(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_2) + ")";

	private static final String _FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_6 =
		"(" + removeConjunction(_FINDER_COLUMN_AN_CSN_C_CATEGORYCODE_3) + ")";

	private static final String _FINDER_COLUMN_AN_CSN_C_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_CSN_C_A;
	private FinderPath _finderPathWithoutPaginationFindByAN_CSN_C_A;
	private FinderPath _finderPathCountByAN_CSN_C_A;
	private FinderPath _finderPathWithPaginationCountByAN_CSN_C_A;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId) {

		return findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end) {

		return findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		categoryCode = Objects.toString(categoryCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_CSN_C_A;
			finderArgs = new Object[] {
				accountNo, customerScreenName, categoryCode, active, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_CSN_C_A;
			finderArgs = new Object[] {
				accountNo, customerScreenName, categoryCode, active, companyId,
				start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						!categoryCode.equals(cp.getCategoryCode()) ||
						(active != cp.isActive()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					7 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(7);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_2);
			}

			boolean bindCategoryCode = false;

			if (categoryCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_3);
			}
			else {
				bindCategoryCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_C_A_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindCategoryCode) {
					qPos.add(categoryCode);
				}

				qPos.add(active);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_C_A_First(
			String accountNo, String customerScreenName, String categoryCode,
			boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_C_A_First(
			accountNo, customerScreenName, categoryCode, active, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", categoryCode=");
		msg.append(categoryCode);

		msg.append(", active=");
		msg.append(active);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_C_A_First(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId,
		OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId, 0,
			1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_C_A_Last(
			String accountNo, String customerScreenName, String categoryCode,
			boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_C_A_Last(
			accountNo, customerScreenName, categoryCode, active, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", categoryCode=");
		msg.append(categoryCode);

		msg.append(", active=");
		msg.append(active);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_C_A_Last(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId,
		OrderByComparator<CP> orderByComparator) {

		int count = countByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCode, active, companyId,
			count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAN_CSN_C_A_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			String categoryCode, boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		categoryCode = Objects.toString(categoryCode, "");

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAN_CSN_C_A_PrevAndNext(
				session, cp, accountNo, customerScreenName, categoryCode,
				active, companyId, orderByComparator, true);

			array[1] = cp;

			array[2] = getByAN_CSN_C_A_PrevAndNext(
				session, cp, accountNo, customerScreenName, categoryCode,
				active, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAN_CSN_C_A_PrevAndNext(
		Session session, CP cp, String accountNo, String customerScreenName,
		String categoryCode, boolean active, long companyId,
		OrderByComparator<CP> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				8 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(7);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_2);
		}

		boolean bindCategoryCode = false;

		if (categoryCode.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_3);
		}
		else {
			bindCategoryCode = true;

			query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_2);
		}

		query.append(_FINDER_COLUMN_AN_CSN_C_A_ACTIVE_2);

		query.append(_FINDER_COLUMN_AN_CSN_C_A_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (bindCategoryCode) {
			qPos.add(categoryCode);
		}

		qPos.add(active);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId) {

		return findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end) {

		return findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_C_A(
			accountNo, customerScreenName, categoryCodes, active, companyId,
			start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;, optionally using the finder cache.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		if (categoryCodes == null) {
			categoryCodes = new String[0];
		}
		else if (categoryCodes.length > 1) {
			for (int i = 0; i < categoryCodes.length; i++) {
				categoryCodes[i] = Objects.toString(categoryCodes[i], "");
			}

			categoryCodes = ArrayUtil.sortedUnique(categoryCodes);
		}

		if (categoryCodes.length == 1) {
			return findByAN_CSN_C_A(
				accountNo, customerScreenName, categoryCodes[0], active,
				companyId, start, end, orderByComparator);
		}

		boolean pagination = true;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderArgs = new Object[] {
				accountNo, customerScreenName, StringUtil.merge(categoryCodes),
				active, companyId
			};
		}
		else {
			finderArgs = new Object[] {
				accountNo, customerScreenName, StringUtil.merge(categoryCodes),
				active, companyId, start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				_finderPathWithPaginationFindByAN_CSN_C_A, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						!ArrayUtil.contains(
							categoryCodes, cp.getCategoryCode()) ||
						(active != cp.isActive()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_2);
			}

			if (categoryCodes.length > 0) {
				query.append("(");

				for (int i = 0; i < categoryCodes.length; i++) {
					String categoryCode = categoryCodes[i];

					if (categoryCode.isEmpty()) {
						query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_6);
					}
					else {
						query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_5);
					}

					if ((i + 1) < categoryCodes.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");

				query.append(WHERE_AND);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_C_A_COMPANYID_2);

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				for (String categoryCode : categoryCodes) {
					if (categoryCode != null && !categoryCode.isEmpty()) {
						qPos.add(categoryCode);
					}
				}

				qPos.add(active);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(
					_finderPathWithPaginationFindByAN_CSN_C_A, finderArgs,
					list);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationFindByAN_CSN_C_A, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId) {

		for (CP cp :
				findByAN_CSN_C_A(
					accountNo, customerScreenName, categoryCode, active,
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCode the category code
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_C_A(
		String accountNo, String customerScreenName, String categoryCode,
		boolean active, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		categoryCode = Objects.toString(categoryCode, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_C_A;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, categoryCode, active, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_2);
			}

			boolean bindCategoryCode = false;

			if (categoryCode.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_3);
			}
			else {
				bindCategoryCode = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_C_A_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindCategoryCode) {
					qPos.add(categoryCode);
				}

				qPos.add(active);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and categoryCode = any &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param categoryCodes the category codes
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_C_A(
		String accountNo, String customerScreenName, String[] categoryCodes,
		boolean active, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		if (categoryCodes == null) {
			categoryCodes = new String[0];
		}
		else if (categoryCodes.length > 1) {
			for (int i = 0; i < categoryCodes.length; i++) {
				categoryCodes[i] = Objects.toString(categoryCodes[i], "");
			}

			categoryCodes = ArrayUtil.sortedUnique(categoryCodes);
		}

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, StringUtil.merge(categoryCodes),
			active, companyId
		};

		Long count = (Long)finderCache.getResult(
			_finderPathWithPaginationCountByAN_CSN_C_A, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler();

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_2);
			}

			if (categoryCodes.length > 0) {
				query.append("(");

				for (int i = 0; i < categoryCodes.length; i++) {
					String categoryCode = categoryCodes[i];

					if (categoryCode.isEmpty()) {
						query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_6);
					}
					else {
						query.append(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_5);
					}

					if ((i + 1) < categoryCodes.length) {
						query.append(WHERE_OR);
					}
				}

				query.append(")");

				query.append(WHERE_AND);
			}

			query.append(_FINDER_COLUMN_AN_CSN_C_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_C_A_COMPANYID_2);

			query.setStringAt(
				removeConjunction(query.stringAt(query.index() - 1)),
				query.index() - 1);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				for (String categoryCode : categoryCodes) {
					if (categoryCode != null && !categoryCode.isEmpty()) {
						qPos.add(categoryCode);
					}
				}

				qPos.add(active);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathWithPaginationCountByAN_CSN_C_A, finderArgs,
					count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathWithPaginationCountByAN_CSN_C_A, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_2 =
		"cp.categoryCode = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_3 =
		"(cp.categoryCode IS NULL OR cp.categoryCode = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_5 =
		"(" + removeConjunction(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_2) + ")";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_6 =
		"(" + removeConjunction(_FINDER_COLUMN_AN_CSN_C_A_CATEGORYCODE_3) + ")";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_ACTIVE_2 =
		"cp.active = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_C_A_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_CSN_A;
	private FinderPath _finderPathWithoutPaginationFindByAN_CSN_A;
	private FinderPath _finderPathCountByAN_CSN_A;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		return findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end) {

		return findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_CSN_A;
			finderArgs = new Object[] {
				accountNo, customerScreenName, active, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_CSN_A;
			finderArgs = new Object[] {
				accountNo, customerScreenName, active, companyId, start, end,
				orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						(active != cp.isActive()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(active);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_A_First(
			String accountNo, String customerScreenName, boolean active,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_A_First(
			accountNo, customerScreenName, active, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", active=");
		msg.append(active);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_A_First(
		String accountNo, String customerScreenName, boolean active,
		long companyId, OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_A_Last(
			String accountNo, String customerScreenName, boolean active,
			long companyId, OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_A_Last(
			accountNo, customerScreenName, active, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", active=");
		msg.append(active);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_A_Last(
		String accountNo, String customerScreenName, boolean active,
		long companyId, OrderByComparator<CP> orderByComparator) {

		int count = countByAN_CSN_A(
			accountNo, customerScreenName, active, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAN_CSN_A(
			accountNo, customerScreenName, active, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAN_CSN_A_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAN_CSN_A_PrevAndNext(
				session, cp, accountNo, customerScreenName, active, companyId,
				orderByComparator, true);

			array[1] = cp;

			array[2] = getByAN_CSN_A_PrevAndNext(
				session, cp, accountNo, customerScreenName, active, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAN_CSN_A_PrevAndNext(
		Session session, CP cp, String accountNo, String customerScreenName,
		boolean active, long companyId, OrderByComparator<CP> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_AN_CSN_A_ACTIVE_2);

		query.append(_FINDER_COLUMN_AN_CSN_A_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(active);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		for (CP cp :
				findByAN_CSN_A(
					accountNo, customerScreenName, active, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_A(
		String accountNo, String customerScreenName, boolean active,
		long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_A;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, active, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_A_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(active);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_ACTIVE_2 =
		"cp.active = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_CSN_A_V;
	private FinderPath _finderPathWithoutPaginationFindByAN_CSN_A_V;
	private FinderPath _finderPathCountByAN_CSN_A_V;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		return findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end) {

		return findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId, start,
			end, null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId, start,
			end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_CSN_A_V;
			finderArgs = new Object[] {
				accountNo, customerScreenName, active, visible, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_CSN_A_V;
			finderArgs = new Object[] {
				accountNo, customerScreenName, active, visible, companyId,
				start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						(active != cp.isActive()) ||
						(visible != cp.isVisible()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					7 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(7);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_A_V_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_V_VISIBLE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_V_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(active);

				qPos.add(visible);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_A_V_First(
			String accountNo, String customerScreenName, boolean active,
			boolean visible, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_A_V_First(
			accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", active=");
		msg.append(active);

		msg.append(", visible=");
		msg.append(visible);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_A_V_First(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId,
		OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_A_V_Last(
			String accountNo, String customerScreenName, boolean active,
			boolean visible, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_A_V_Last(
			accountNo, customerScreenName, active, visible, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", active=");
		msg.append(active);

		msg.append(", visible=");
		msg.append(visible);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_A_V_Last(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId,
		OrderByComparator<CP> orderByComparator) {

		int count = countByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAN_CSN_A_V(
			accountNo, customerScreenName, active, visible, companyId,
			count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAN_CSN_A_V_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, boolean visible, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAN_CSN_A_V_PrevAndNext(
				session, cp, accountNo, customerScreenName, active, visible,
				companyId, orderByComparator, true);

			array[1] = cp;

			array[2] = getByAN_CSN_A_V_PrevAndNext(
				session, cp, accountNo, customerScreenName, active, visible,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAN_CSN_A_V_PrevAndNext(
		Session session, CP cp, String accountNo, String customerScreenName,
		boolean active, boolean visible, long companyId,
		OrderByComparator<CP> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				8 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(7);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_AN_CSN_A_V_ACTIVE_2);

		query.append(_FINDER_COLUMN_AN_CSN_A_V_VISIBLE_2);

		query.append(_FINDER_COLUMN_AN_CSN_A_V_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(active);

		qPos.add(visible);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		for (CP cp :
				findByAN_CSN_A_V(
					accountNo, customerScreenName, active, visible, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and visible = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param visible the visible
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_A_V(
		String accountNo, String customerScreenName, boolean active,
		boolean visible, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_A_V;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, active, visible, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_A_V_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_V_VISIBLE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_V_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(active);

				qPos.add(visible);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_V_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_V_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_V_ACTIVE_2 =
		"cp.active = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_V_VISIBLE_2 =
		"cp.visible = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_V_COMPANYID_2 =
		"cp.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAN_CSN_A_M;
	private FinderPath _finderPathWithoutPaginationFindByAN_CSN_A_M;
	private FinderPath _finderPathCountByAN_CSN_A_M;

	/**
	 * Returns all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @return the matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		return findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end) {

		return findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId, start,
			end, null);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator) {

		return findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId, start,
			end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching cps
	 */
	@Override
	public List<CP> findByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId, int start, int end,
		OrderByComparator<CP> orderByComparator, boolean retrieveFromCache) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAN_CSN_A_M;
			finderArgs = new Object[] {
				accountNo, customerScreenName, active, mandatory, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAN_CSN_A_M;
			finderArgs = new Object[] {
				accountNo, customerScreenName, active, mandatory, companyId,
				start, end, orderByComparator
			};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (CP cp : list) {
					if (!accountNo.equals(cp.getAccountNo()) ||
						!customerScreenName.equals(
							cp.getCustomerScreenName()) ||
						(active != cp.isActive()) ||
						(mandatory != cp.isMandatory()) ||
						(companyId != cp.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					7 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(7);
			}

			query.append(_SQL_SELECT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_A_M_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_M_MANDATORY_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_M_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(CPModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(active);

				qPos.add(mandatory);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_A_M_First(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_A_M_First(
			accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", active=");
		msg.append(active);

		msg.append(", mandatory=");
		msg.append(mandatory);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the first cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_A_M_First(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId,
		OrderByComparator<CP> orderByComparator) {

		List<CP> list = findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp
	 * @throws NoSuchCPException if a matching cp could not be found
	 */
	@Override
	public CP findByAN_CSN_A_M_Last(
			String accountNo, String customerScreenName, boolean active,
			boolean mandatory, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		CP cp = fetchByAN_CSN_A_M_Last(
			accountNo, customerScreenName, active, mandatory, companyId,
			orderByComparator);

		if (cp != null) {
			return cp;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("accountNo=");
		msg.append(accountNo);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", active=");
		msg.append(active);

		msg.append(", mandatory=");
		msg.append(mandatory);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchCPException(msg.toString());
	}

	/**
	 * Returns the last cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching cp, or <code>null</code> if a matching cp could not be found
	 */
	@Override
	public CP fetchByAN_CSN_A_M_Last(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId,
		OrderByComparator<CP> orderByComparator) {

		int count = countByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId);

		if (count == 0) {
			return null;
		}

		List<CP> list = findByAN_CSN_A_M(
			accountNo, customerScreenName, active, mandatory, companyId,
			count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the cps before and after the current cp in the ordered set where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param cpId the primary key of the current cp
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP[] findByAN_CSN_A_M_PrevAndNext(
			String cpId, String accountNo, String customerScreenName,
			boolean active, boolean mandatory, long companyId,
			OrderByComparator<CP> orderByComparator)
		throws NoSuchCPException {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		CP cp = findByPrimaryKey(cpId);

		Session session = null;

		try {
			session = openSession();

			CP[] array = new CPImpl[3];

			array[0] = getByAN_CSN_A_M_PrevAndNext(
				session, cp, accountNo, customerScreenName, active, mandatory,
				companyId, orderByComparator, true);

			array[1] = cp;

			array[2] = getByAN_CSN_A_M_PrevAndNext(
				session, cp, accountNo, customerScreenName, active, mandatory,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CP getByAN_CSN_A_M_PrevAndNext(
		Session session, CP cp, String accountNo, String customerScreenName,
		boolean active, boolean mandatory, long companyId,
		OrderByComparator<CP> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				8 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(7);
		}

		query.append(_SQL_SELECT_CP_WHERE);

		boolean bindAccountNo = false;

		if (accountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_3);
		}
		else {
			bindAccountNo = true;

			query.append(_FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_AN_CSN_A_M_ACTIVE_2);

		query.append(_FINDER_COLUMN_AN_CSN_A_M_MANDATORY_2);

		query.append(_FINDER_COLUMN_AN_CSN_A_M_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CPModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAccountNo) {
			qPos.add(accountNo);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(active);

		qPos.add(mandatory);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(cp)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<CP> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63; from the database.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		for (CP cp :
				findByAN_CSN_A_M(
					accountNo, customerScreenName, active, mandatory, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(cp);
		}
	}

	/**
	 * Returns the number of cps where accountNo = &#63; and customerScreenName = &#63; and active = &#63; and mandatory = &#63; and companyId = &#63;.
	 *
	 * @param accountNo the account no
	 * @param customerScreenName the customer screen name
	 * @param active the active
	 * @param mandatory the mandatory
	 * @param companyId the company ID
	 * @return the number of matching cps
	 */
	@Override
	public int countByAN_CSN_A_M(
		String accountNo, String customerScreenName, boolean active,
		boolean mandatory, long companyId) {

		accountNo = Objects.toString(accountNo, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByAN_CSN_A_M;

		Object[] finderArgs = new Object[] {
			accountNo, customerScreenName, active, mandatory, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_CP_WHERE);

			boolean bindAccountNo = false;

			if (accountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_3);
			}
			else {
				bindAccountNo = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_AN_CSN_A_M_ACTIVE_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_M_MANDATORY_2);

			query.append(_FINDER_COLUMN_AN_CSN_A_M_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAccountNo) {
					qPos.add(accountNo);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(active);

				qPos.add(mandatory);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_2 =
		"cp.accountNo = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_M_ACCOUNTNO_3 =
		"(cp.accountNo IS NULL OR cp.accountNo = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_2 =
		"cp.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_M_CUSTOMERSCREENNAME_3 =
		"(cp.customerScreenName IS NULL OR cp.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_M_ACTIVE_2 =
		"cp.active = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_M_MANDATORY_2 =
		"cp.mandatory = ? AND ";

	private static final String _FINDER_COLUMN_AN_CSN_A_M_COMPANYID_2 =
		"cp.companyId = ?";

	public CPPersistenceImpl() {
		setModelClass(CP.class);

		setModelImplClass(CPImpl.class);
		setModelPKClass(String.class);

		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("active", "active_");

		setDBColumnNames(dbColumnNames);
	}

	/**
	 * Caches the cp in the entity cache if it is enabled.
	 *
	 * @param cp the cp
	 */
	@Override
	public void cacheResult(CP cp) {
		entityCache.putResult(
			entityCacheEnabled, CPImpl.class, cp.getPrimaryKey(), cp);

		finderCache.putResult(
			_finderPathFetchByCPId,
			new Object[] {cp.getCpId(), cp.getCompanyId()}, cp);

		finderCache.putResult(
			_finderPathFetchByAN_CSN_P,
			new Object[] {
				cp.getAccountNo(), cp.getCustomerScreenName(), cp.getPlanCode(),
				cp.getCompanyId()
			},
			cp);

		finderCache.putResult(
			_finderPathFetchByAN_CSN_P_A,
			new Object[] {
				cp.getAccountNo(), cp.getCustomerScreenName(), cp.getPlanCode(),
				cp.isActive(), cp.getCompanyId()
			},
			cp);

		cp.resetOriginalValues();
	}

	/**
	 * Caches the cps in the entity cache if it is enabled.
	 *
	 * @param cps the cps
	 */
	@Override
	public void cacheResult(List<CP> cps) {
		for (CP cp : cps) {
			if (entityCache.getResult(
					entityCacheEnabled, CPImpl.class, cp.getPrimaryKey()) ==
						null) {

				cacheResult(cp);
			}
			else {
				cp.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all cps.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(CPImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the cp.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(CP cp) {
		entityCache.removeResult(
			entityCacheEnabled, CPImpl.class, cp.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache((CPModelImpl)cp, true);
	}

	@Override
	public void clearCache(List<CP> cps) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (CP cp : cps) {
			entityCache.removeResult(
				entityCacheEnabled, CPImpl.class, cp.getPrimaryKey());

			clearUniqueFindersCache((CPModelImpl)cp, true);
		}
	}

	protected void cacheUniqueFindersCache(CPModelImpl cpModelImpl) {
		Object[] args = new Object[] {
			cpModelImpl.getCpId(), cpModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByCPId, args, Long.valueOf(1), false);
		finderCache.putResult(_finderPathFetchByCPId, args, cpModelImpl, false);

		args = new Object[] {
			cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
			cpModelImpl.getPlanCode(), cpModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAN_CSN_P, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAN_CSN_P, args, cpModelImpl, false);

		args = new Object[] {
			cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
			cpModelImpl.getPlanCode(), cpModelImpl.isActive(),
			cpModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByAN_CSN_P_A, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByAN_CSN_P_A, args, cpModelImpl, false);
	}

	protected void clearUniqueFindersCache(
		CPModelImpl cpModelImpl, boolean clearCurrent) {

		if (clearCurrent) {
			Object[] args = new Object[] {
				cpModelImpl.getCpId(), cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCPId, args);
			finderCache.removeResult(_finderPathFetchByCPId, args);
		}

		if ((cpModelImpl.getColumnBitmask() &
			 _finderPathFetchByCPId.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				cpModelImpl.getOriginalCpId(),
				cpModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCPId, args);
			finderCache.removeResult(_finderPathFetchByCPId, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.getPlanCode(), cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_P, args);
			finderCache.removeResult(_finderPathFetchByAN_CSN_P, args);
		}

		if ((cpModelImpl.getColumnBitmask() &
			 _finderPathFetchByAN_CSN_P.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				cpModelImpl.getOriginalAccountNo(),
				cpModelImpl.getOriginalCustomerScreenName(),
				cpModelImpl.getOriginalPlanCode(),
				cpModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_P, args);
			finderCache.removeResult(_finderPathFetchByAN_CSN_P, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.getPlanCode(), cpModelImpl.isActive(),
				cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_P_A, args);
			finderCache.removeResult(_finderPathFetchByAN_CSN_P_A, args);
		}

		if ((cpModelImpl.getColumnBitmask() &
			 _finderPathFetchByAN_CSN_P_A.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				cpModelImpl.getOriginalAccountNo(),
				cpModelImpl.getOriginalCustomerScreenName(),
				cpModelImpl.getOriginalPlanCode(),
				cpModelImpl.getOriginalActive(),
				cpModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_P_A, args);
			finderCache.removeResult(_finderPathFetchByAN_CSN_P_A, args);
		}
	}

	/**
	 * Creates a new cp with the primary key. Does not add the cp to the database.
	 *
	 * @param cpId the primary key for the new cp
	 * @return the new cp
	 */
	@Override
	public CP create(String cpId) {
		CP cp = new CPImpl();

		cp.setNew(true);
		cp.setPrimaryKey(cpId);

		cp.setCompanyId(companyProvider.getCompanyId());

		return cp;
	}

	/**
	 * Removes the cp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp that was removed
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP remove(String cpId) throws NoSuchCPException {
		return remove((Serializable)cpId);
	}

	/**
	 * Removes the cp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the cp
	 * @return the cp that was removed
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP remove(Serializable primaryKey) throws NoSuchCPException {
		Session session = null;

		try {
			session = openSession();

			CP cp = (CP)session.get(CPImpl.class, primaryKey);

			if (cp == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchCPException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(cp);
		}
		catch (NoSuchCPException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected CP removeImpl(CP cp) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(cp)) {
				cp = (CP)session.get(CPImpl.class, cp.getPrimaryKeyObj());
			}

			if (cp != null) {
				session.delete(cp);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (cp != null) {
			clearCache(cp);
		}

		return cp;
	}

	@Override
	public CP updateImpl(CP cp) {
		boolean isNew = cp.isNew();

		if (!(cp instanceof CPModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(cp.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(cp);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in cp proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom CP implementation " +
					cp.getClass());
		}

		CPModelImpl cpModelImpl = (CPModelImpl)cp;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (cp.getCreateDate() == null)) {
			if (serviceContext == null) {
				cp.setCreateDate(now);
			}
			else {
				cp.setCreateDate(serviceContext.getCreateDate(now));
			}
		}

		if (!cpModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				cp.setModifiedDate(now);
			}
			else {
				cp.setModifiedDate(serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (cp.isNew()) {
				session.save(cp);

				cp.setNew(false);
			}
			else {
				cp = (CP)session.merge(cp);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {
				cpModelImpl.isAutoRenew(), cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAutoRenew, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAutoRenew, args);

			args = new Object[] {cpModelImpl.getCompanyId()};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_CSN, args);

			args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.getCategoryCode(), cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_C, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_CSN_C, args);

			args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.getCategoryCode(), cpModelImpl.isActive(),
				cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_C_A, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_CSN_C_A, args);

			args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.isActive(), cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_A, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_CSN_A, args);

			args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.isActive(), cpModelImpl.isVisible(),
				cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_A_V, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_CSN_A_V, args);

			args = new Object[] {
				cpModelImpl.getAccountNo(), cpModelImpl.getCustomerScreenName(),
				cpModelImpl.isActive(), cpModelImpl.isMandatory(),
				cpModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAN_CSN_A_M, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAN_CSN_A_M, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAutoRenew.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAutoRenew(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAutoRenew, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAutoRenew, args);

				args = new Object[] {
					cpModelImpl.isAutoRenew(), cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAutoRenew, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAutoRenew, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {cpModelImpl.getCompanyId()};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_CSN.getColumnBitmask()) !=
					 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAccountNo(),
					cpModelImpl.getOriginalCustomerScreenName(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN, args);

				args = new Object[] {
					cpModelImpl.getAccountNo(),
					cpModelImpl.getCustomerScreenName(),
					cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_CSN_C.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAccountNo(),
					cpModelImpl.getOriginalCustomerScreenName(),
					cpModelImpl.getOriginalCategoryCode(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_C, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_C, args);

				args = new Object[] {
					cpModelImpl.getAccountNo(),
					cpModelImpl.getCustomerScreenName(),
					cpModelImpl.getCategoryCode(), cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_C, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_C, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_CSN_C_A.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAccountNo(),
					cpModelImpl.getOriginalCustomerScreenName(),
					cpModelImpl.getOriginalCategoryCode(),
					cpModelImpl.getOriginalActive(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_C_A, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_C_A, args);

				args = new Object[] {
					cpModelImpl.getAccountNo(),
					cpModelImpl.getCustomerScreenName(),
					cpModelImpl.getCategoryCode(), cpModelImpl.isActive(),
					cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_C_A, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_C_A, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_CSN_A.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAccountNo(),
					cpModelImpl.getOriginalCustomerScreenName(),
					cpModelImpl.getOriginalActive(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_A, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_A, args);

				args = new Object[] {
					cpModelImpl.getAccountNo(),
					cpModelImpl.getCustomerScreenName(), cpModelImpl.isActive(),
					cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_A, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_A, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_CSN_A_V.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAccountNo(),
					cpModelImpl.getOriginalCustomerScreenName(),
					cpModelImpl.getOriginalActive(),
					cpModelImpl.getOriginalVisible(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_A_V, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_A_V, args);

				args = new Object[] {
					cpModelImpl.getAccountNo(),
					cpModelImpl.getCustomerScreenName(), cpModelImpl.isActive(),
					cpModelImpl.isVisible(), cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_A_V, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_A_V, args);
			}

			if ((cpModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAN_CSN_A_M.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					cpModelImpl.getOriginalAccountNo(),
					cpModelImpl.getOriginalCustomerScreenName(),
					cpModelImpl.getOriginalActive(),
					cpModelImpl.getOriginalMandatory(),
					cpModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_A_M, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_A_M, args);

				args = new Object[] {
					cpModelImpl.getAccountNo(),
					cpModelImpl.getCustomerScreenName(), cpModelImpl.isActive(),
					cpModelImpl.isMandatory(), cpModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAN_CSN_A_M, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAN_CSN_A_M, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, CPImpl.class, cp.getPrimaryKey(), cp, false);

		clearUniqueFindersCache(cpModelImpl, false);
		cacheUniqueFindersCache(cpModelImpl);

		cp.resetOriginalValues();

		return cp;
	}

	/**
	 * Returns the cp with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the cp
	 * @return the cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP findByPrimaryKey(Serializable primaryKey)
		throws NoSuchCPException {

		CP cp = fetchByPrimaryKey(primaryKey);

		if (cp == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchCPException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return cp;
	}

	/**
	 * Returns the cp with the primary key or throws a <code>NoSuchCPException</code> if it could not be found.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp
	 * @throws NoSuchCPException if a cp with the primary key could not be found
	 */
	@Override
	public CP findByPrimaryKey(String cpId) throws NoSuchCPException {
		return findByPrimaryKey((Serializable)cpId);
	}

	/**
	 * Returns the cp with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param cpId the primary key of the cp
	 * @return the cp, or <code>null</code> if a cp with the primary key could not be found
	 */
	@Override
	public CP fetchByPrimaryKey(String cpId) {
		return fetchByPrimaryKey((Serializable)cpId);
	}

	/**
	 * Returns all the cps.
	 *
	 * @return the cps
	 */
	@Override
	public List<CP> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @return the range of cps
	 */
	@Override
	public List<CP> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of cps
	 */
	@Override
	public List<CP> findAll(
		int start, int end, OrderByComparator<CP> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the cps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>CPModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of cps
	 * @param end the upper bound of the range of cps (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of cps
	 */
	@Override
	public List<CP> findAll(
		int start, int end, OrderByComparator<CP> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<CP> list = null;

		if (retrieveFromCache) {
			list = (List<CP>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_CP);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_CP;

				if (pagination) {
					sql = sql.concat(CPModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<CP>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the cps from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (CP cp : findAll()) {
			remove(cp);
		}
	}

	/**
	 * Returns the number of cps.
	 *
	 * @return the number of cps
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_CP);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "cpId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_CP;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return CPModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the cp persistence.
	 */
	@Activate
	public void activate() {
		CPModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		CPModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathFetchByCPId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByCPId",
			new String[] {String.class.getName(), Long.class.getName()},
			CPModelImpl.CPID_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByCPId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCPId",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByAutoRenew = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAutoRenew",
			new String[] {
				Boolean.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAutoRenew = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAutoRenew",
			new String[] {Boolean.class.getName(), Long.class.getName()},
			CPModelImpl.AUTORENEW_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAutoRenew = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAutoRenew",
			new String[] {Boolean.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});

		_finderPathWithPaginationFindByAN_CSN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_CSN",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_CSN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_CSN",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_CSN = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathFetchByAN_CSN_P = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAN_CSN_P",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.PLANCODE_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_P = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_P",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathFetchByAN_CSN_P_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAN_CSN_P_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.PLANCODE_COLUMN_BITMASK |
			CPModelImpl.ACTIVE_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_P_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_P_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByAN_CSN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_CSN_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_CSN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_CSN_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.CATEGORYCODE_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationCountByAN_CSN_C = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByAN_CSN_C",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByAN_CSN_C_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_CSN_C_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_CSN_C_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_CSN_C_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.CATEGORYCODE_COLUMN_BITMASK |
			CPModelImpl.ACTIVE_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_C_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_C_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationCountByAN_CSN_C_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "countByAN_CSN_C_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByAN_CSN_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_CSN_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_CSN_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_CSN_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.ACTIVE_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_A = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_A",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByAN_CSN_A_V = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_CSN_A_V",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Boolean.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_CSN_A_V = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_CSN_A_V",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.ACTIVE_COLUMN_BITMASK |
			CPModelImpl.VISIBLE_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_A_V = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_A_V",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByAN_CSN_A_M = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAN_CSN_A_M",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Boolean.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAN_CSN_A_M = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, CPImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAN_CSN_A_M",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			},
			CPModelImpl.ACCOUNTNO_COLUMN_BITMASK |
			CPModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			CPModelImpl.ACTIVE_COLUMN_BITMASK |
			CPModelImpl.MANDATORY_COLUMN_BITMASK |
			CPModelImpl.COMPANYID_COLUMN_BITMASK |
			CPModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByAN_CSN_A_M = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAN_CSN_A_M",
			new String[] {
				String.class.getName(), String.class.getName(),
				Boolean.class.getName(), Boolean.class.getName(),
				Long.class.getName()
			});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(CPImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ATMPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.telecom.model.CP"),
			true);
	}

	@Override
	@Reference(
		target = ATMPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ATMPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_CP = "SELECT cp FROM CP cp";

	private static final String _SQL_SELECT_CP_WHERE =
		"SELECT cp FROM CP cp WHERE ";

	private static final String _SQL_COUNT_CP = "SELECT COUNT(cp) FROM CP cp";

	private static final String _SQL_COUNT_CP_WHERE =
		"SELECT COUNT(cp) FROM CP cp WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "cp.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No CP exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No CP exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		CPPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"active"});

}