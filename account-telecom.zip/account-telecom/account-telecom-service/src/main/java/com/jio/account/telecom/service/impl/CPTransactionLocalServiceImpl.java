/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.telecom.service.impl;

import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.model.CPTransaction;
import com.jio.account.telecom.service.base.CPTransactionLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the cp transaction local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.telecom.service.CPTransactionLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CPTransactionLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.telecom.model.CPTransaction", service = AopService.class)
public class CPTransactionLocalServiceImpl extends CPTransactionLocalServiceBaseImpl {

	public CPTransaction saveCPTransaction(CP cp) throws PortalException {

		CPTransaction cpTransaction = createCPTransaction(String.valueOf(counterLocalService.increment(CPTransaction.class.getName())));
		cpTransaction.setCpId(cp.getCpId());
		cpTransaction.setGroupId(cp.getGroupId());
		cpTransaction.setCompanyId(cp.getCompanyId());
		cpTransaction.setCreateBy(cp.getCreateBy());
		cpTransaction.setCustomerScreenName(cp.getCustomerScreenName());
		cpTransaction.setActive(cp.getActive());
		cpTransaction.setStartDate(cp.getStartDate());
		cpTransaction.setEndDate(cp.getEndDate());
		cpTransaction.setPlanCode(cp.getPlanCode());
		cpTransaction.setCustomerId(cp.getCustomerId());
		cpTransaction.setPlanName(cp.getPlanName());
		cpTransaction.setCategoryCode(cp.getCategoryCode());
		cpTransaction.setCategoryName(cp.getCategoryName());
		cpTransaction.setVisible(cp.getVisible());
		cpTransaction.setMandatory(cp.getMandatory());
		cpTransaction.setCategoryGroupCode(cp.getCategoryGroupCode());
		cpTransaction.setCategoryGroupName(cp.getCategoryGroupName());

		cpTransaction.setPrice(cp.getPrice());
		cpTransaction.setBasicPrice(cp.getBasicPrice());
		cpTransaction.setCgstPrice(cp.getCgstPrice());
		cpTransaction.setSgstPrice(cp.getSgstPrice());

		cpTransaction.setLcoPrice(cp.getLcoPrice());
		cpTransaction.setLcoBasicPrice(cp.getLcoBasicPrice());
		cpTransaction.setLcoCgstPrice(cp.getLcoCgstPrice());
		cpTransaction.setLcoSgstPrice(cp.getLcoSgstPrice());

		cpTransaction.setBcPrice(cp.getBcPrice());
		cpTransaction.setBcBasicPrice(cp.getBcBasicPrice());
		cpTransaction.setBcCgstPrice(cp.getBcCgstPrice());
		cpTransaction.setBcSgstPrice(cp.getBcSgstPrice());

		cpTransaction.setSdCount(cp.getSdCount());
		cpTransaction.setHdCount(cp.getHdCount());
		cpTransaction.setNcfCount(cp.getNcfCount());
		cpTransaction.setPriority(cp.getPriority());

		cpTransaction.setReason(cp.getReason());
		cpTransaction.setCityCode(cp.getCityCode());
		cpTransaction.setAccountNo(cp.getAccountNo());
		cpTransaction.setAutoRenew(cp.getAutoRenew());

		cpTransaction.setPlanPoId(cp.getPlanPoId());
		cpTransaction.setDealPoId(cp.getDealPoId());
		cpTransaction.setPackageId(cp.getPackageId());
		cpTransaction.setPurchasedProductPoId(cp.getPurchasedProductPoId());
		cpTransaction.setProductPoId(cp.getProductPoId());

		cpTransaction.setPlanMappingCode(cp.getPlanMappingCode());
		cpTransaction.setOnce(cp.getOnce());
		cpTransaction.setMapping(cp.getMapping());

		cpTransaction.setAgentBalanceId(cp.getAgentBalanceId());
		cpTransaction.setCpLcoPrice(cp.getCpLcoPrice());
		cpTransaction.setCpAmount(cp.getCpAmount());
		cpTransaction.setCpDuration(cp.getCpDuration());
		cpTransaction.setCpEndDate(cp.getCpEndDate());

		return addCPTransaction(cpTransaction);
	}

	@Override
	public CPTransaction addCPTransaction(CPTransaction cpTransaction) {
		cpTransaction.setCreateDate(new Date());
		cpTransaction.setModifiedDate(new Date());
		cpTransaction = super.addCPTransaction(cpTransaction);
		AuditUtil.audit(cpTransaction, AuditConstants.SAVE);
		return cpTransaction;
	}

	@Override
	public CPTransaction updateCPTransaction(CPTransaction cpTransaction) {
		cpTransaction.setModifiedDate(new Date());
		cpTransaction = super.updateCPTransaction(cpTransaction);
		AuditUtil.audit(cpTransaction, AuditConstants.UPDATE);
		return cpTransaction;
	}

	@Override
	public CPTransaction deleteCPTransaction(CPTransaction cpTransaction) {
		cpTransaction = super.deleteCPTransaction(cpTransaction);
		AuditUtil.audit(cpTransaction, AuditConstants.DELETE);
		return cpTransaction;
	}

	@Override
	public CPTransaction deleteCPTransaction(String cptId) throws PortalException {
		return deleteCPTransaction(getCPTransaction(cptId));
	}

	@Override
	public List<CPTransaction> getCPTransactions(String accountNo, String planCode, Date startDate, Date endDate, long companyId) {
		return this.cpTransactionPersistence.findByAN_PC_SD_ED_C(accountNo, planCode, startDate, endDate, companyId);
	}

	public List<CPTransaction> getCPTransactions(String cpId, int start, int end) {
		return this.cpTransactionPersistence.findByCPId(cpId, start, end);
	}

	public List<CPTransaction> getCPTransactions(String cpId) {
		return this.cpTransactionPersistence.findByCPId(cpId);
	}

	public int getCPTransactionsCount(String cpId) {
		return this.cpTransactionPersistence.countByCPId(cpId);
	}

}