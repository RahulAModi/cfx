package com.jio.account.telecom.function;

import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalServiceUtil;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 * @author Vishal7.Shah
 */
public class AccountTelecomFunction {

	private static final Log LOGGER = LogFactoryUtil.getLog(AccountTelecomFunction.class);

	public static boolean checkCustomerPlan(String accountNo, String customerScreenName, String planCode, String companyId) {
		boolean checked = false;
		try {
			CP cp = CPLocalServiceUtil.getCP(accountNo, customerScreenName, planCode, GetterUtil.get(companyId, 0L));
			checked = cp.getActive();
		} catch (NoSuchCPException e) {
			LOGGER.error("NoSuchCPException :: " + e.toString());
		}
		return checked;
	}

	public static boolean visibleRenewalCustomerPlan(Date endDate, String companyId) {
		ZoneId zoneId = ZoneId.systemDefault();
		LocalDateTime start = LocalDateTime.now(zoneId);
		LocalDateTime end = Instant.ofEpochMilli(endDate.getTime()).atZone(zoneId).toLocalDateTime();
		long day = ChronoUnit.DAYS.between(start, end);
		long visibleDay = GetterUtil.getLong(JioPropsUtil.get(ConfigConstant.PLAN_AUTO_RENEW_VISIBLE, GetterUtil.get(companyId, 0L)));
		return day < visibleDay;
	}

	public static CP getCP(String cpId, String companyId) {
		CP cp = null;
		try {
			cp = CPLocalServiceUtil.getCP(cpId, GetterUtil.getLong(companyId));
		} catch (NoSuchCPException e) {
			LOGGER.error("NoSuchCPException :: " + e.toString());
		}
		return cp;
	}
}