package com.jio.customer.plan.listner;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Customer;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.util.AccountUtil;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.DestinationNames;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.module.framework.ModuleServiceLifecycle;
import com.liferay.portal.kernel.scheduler.SchedulerEngineHelper;
import com.liferay.portal.kernel.scheduler.SchedulerEntry;
import com.liferay.portal.kernel.scheduler.SchedulerEntryImpl;
import com.liferay.portal.kernel.scheduler.Trigger;
import com.liferay.portal.kernel.scheduler.TriggerFactory;
import com.liferay.portal.kernel.service.CompanyLocalService;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Vishal7.Shah
 */
@Component(immediate = true, property = { "cron.expression=0 0 22 1/1 * ? *" }, service = CustomerPlanListner.class)
public class CustomerPlanListner extends BaseMessageListener {

	private static final Log LOGGER = LogFactoryUtil.getLog(CustomerPlanListner.class);

	@Reference
	private SchedulerEngineHelper schedulerEngineHelper;

	@Reference
	private CompanyLocalService companyLocalService;

	@Reference
	private TriggerFactory triggerFactory;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private CustomerPlanService customerPlanService;

	private final String defaultCronExpression = "0 0 22 1/1 * ? *";

	private final long defaultAfterMinutes = 5 * 24 * 60;

	@Reference(target = ModuleServiceLifecycle.PORTAL_INITIALIZED)
	private ModuleServiceLifecycle moduleServiceLifecycle;

	@Override
	protected void doReceive(Message message) {

		List<Company> companies = companyLocalService.getCompanies();
		companies.stream().forEach(company -> {

			long companyId = GetterUtil.getLong(message.get("companyId"));
			String txRefNo = AccountUtil.getTxRefNo();
			LOGGER.info("===== CUSTOMER PLAN AUTORENEW OF COMPANY " + companyId + " START =====");

			long minutes = GetterUtil.getLong(JioPropsUtil.get(ConfigConstant.PLAN_AUTO_RENEW_MINUTE, companyId), defaultAfterMinutes);
			ZoneId zoneId = ZoneId.systemDefault();
			LocalDateTime localDateTime = LocalDateTime.now(zoneId);
			Date startDate = Date.from(localDateTime.with(LocalTime.MIN).atZone(zoneId).toInstant());
			Date endDate = Date.from(localDateTime.plusMinutes(minutes).with(LocalTime.MAX).atZone(zoneId).toInstant());
			List<String> customerAccountNos = cpLocalService.getCPDistictAccountNo(Boolean.TRUE, companyId, startDate, endDate);
			customerAccountNos.parallelStream().forEach(customerAccountNo -> {
				try {
					Customer customer = customerLocalService.getCustomer(customerAccountNo, companyId);
					List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, companyId);
					String receiptNo = customerPlanUtil.getReceiptNo();
					try {
						User userAgent = userLocalService.getUserByScreenName(companyId, customer.getAgentScreenName());

						cps.parallelStream().forEach(cp -> {
							String cpId = cp.getCpId();
							try {
								Map<String, String> map = customerPlanService.renewCustomerPlans(new String[] { cpId }, true, cp.getAccountNo(), receiptNo, txRefNo, userAgent, companyId, cp.getGroupId());
								if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
									LOGGER.info(map.get("MESSAGE"));
								} else {
									LOGGER.error(map.get("MESSAGE"));
								}
							} catch (NoSuchAgentException e) {
								LOGGER.error("NoSuchAgentException :: " + e.toString());
							} catch (NoSuchAddressException e) {
								LOGGER.error("NoSuchAddressException :: " + e.toString());
							} catch (NoSuchAgentBalanceException e) {
								LOGGER.error("NoSuchAgentBalanceException :: " + e.toString());
							} catch (BlockAgentBalanceException e) {
								LOGGER.error("BlockAgentBalanceException :: " + e.toString());
							} catch (InSufficientAgentBalanceException e) {
								LOGGER.error("InSufficientAgentBalanceException :: " + e.toString());
							} catch (NoSuchCustomerException e) {
								LOGGER.error("NoSuchCustomerException :: " + e.toString());
							}
						});
					} catch (PortalException e) {
						LOGGER.error("PortalException : " + e.toString());
					}

				} catch (NoSuchCustomerException e) {
					LOGGER.error("NoSuchCustomerException : " + e.toString());
				}

			});

			LOGGER.info("===== CUSTOMER PLAN AUTORENEW OF COMPANY " + companyId + " END =====");

		});

	}

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		Class<?> clazz = getClass();
		String className = clazz.getName();
		Trigger trigger = triggerFactory.createTrigger(className, className, new Date(), null, defaultCronExpression);
		SchedulerEntry schedulerEntry = new SchedulerEntryImpl(className, trigger);
		schedulerEngineHelper.register(this, schedulerEntry, DestinationNames.SCHEDULER_DISPATCH);
	}

	@Deactivate
	protected void deactivate() {
		schedulerEngineHelper.unregister(this);
	}
}