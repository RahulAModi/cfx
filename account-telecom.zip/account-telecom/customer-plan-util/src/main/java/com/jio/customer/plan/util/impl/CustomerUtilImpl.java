package com.jio.customer.plan.util.impl;

import com.jio.account.util.AccountUtil;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.liferay.portal.kernel.util.GetterUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, service = CustomerPlanUtil.class)
public class CustomerUtilImpl implements CustomerPlanUtil {

	@Override
	public String getReceiptNo() {
		return AccountUtil.getRefNo("R");
	}

	@Override
	public Date getStartDate(Date endTime) {
		LocalDateTime localDateTime = endTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		localDateTime = localDateTime.minus(DEFAULT_DURATION, ChronoUnit.DAYS);
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	@Override
	public Date getEndDate(Date startTime) {
		LocalDateTime localDateTime = startTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		localDateTime = localDateTime.plus(DEFAULT_DURATION, ChronoUnit.DAYS);
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * @deprecated {@link #getEndDate(Date)}
	 * 
	 * @param startTime
	 * @return
	 */
	public Date _getEndDate(Date startTime) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startTime);
		calendar.add(Calendar.DAY_OF_MONTH, DEFAULT_DURATION);
		return calendar.getTime();
	}

	@Override
	public double getDebitPrice(long diffInDays, double lcoPrice) {
		double finalPrice = diffInDays * (lcoPrice / DEFAULT_DURATION); // total days used price debit from lco
		return convertAmount(finalPrice);
	}

	@Override
	public double getCreditPrice(long actualDiffInDays, long diffInDays, double lcoPrice) {
		double finalPrice = getDebitPrice(actualDiffInDays, lcoPrice) - (diffInDays * (lcoPrice / DEFAULT_DURATION)); // non used price credit to lco
		return convertAmount(finalPrice);
	}

	@Override
	public long getDiffInDays(Date startTime, Date endTime) {
		long duration = endTime.getTime() - startTime.getTime();
		return TimeUnit.MILLISECONDS.toDays(duration);
	}

	private double convertAmount(double value) {
		return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}

	@Override
	public int getDuration(long companyId) {
		return GetterUtil.get(JioPropsUtil.get(ConfigConstant.DEFAULT_PLAN_DURATION, companyId), DEFAULT_DURATION);
	}

	@Override
	public double getAmount(long companyId) {
		return GetterUtil.get(JioPropsUtil.get(ConfigConstant.DEFAULT_MINIMUM_BALANCE, companyId), DEFAULT_AMOUNT);
	}

}
