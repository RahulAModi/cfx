package com.jio.customer.plan.util;

import java.util.Date;

/**
 * @author Vishal7.Shah
 */
public interface CustomerPlanUtil {

	int DEFAULT_DURATION = 30;

	double DEFAULT_AMOUNT = 0;

	String getReceiptNo();
	
	Date getStartDate(Date endTime);

	Date getEndDate(Date startTime);

	double getDebitPrice(long diffInDays, double lcoPrice);

	double getCreditPrice(long actualDiffInDays, long diffInDays, double lcoPrice);

	long getDiffInDays(Date startTime, Date endTime);

	double getAmount(long companyId);

	int getDuration(long companyId);

}