package com.jio.customer.plan.service.impl;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.service.AddressLocalService;
import com.jio.account.service.AgentLocalService;
import com.jio.account.service.CustomerLocalService;
import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.telecom.model.CPTransaction;
import com.jio.account.telecom.service.CPLocalService;
import com.jio.account.telecom.service.CPTransactionLocalService;
import com.jio.balance.constant.BalanceConstant;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.balance.model.AgentBalance;
import com.jio.balance.service.AgentBalanceLocalService;
import com.jio.brm.customer.info.api.CustomerInfoResponse;
import com.jio.brm.customer.info.api.Product;
import com.jio.brm.customer.info.service.CustomerInfoService;
import com.jio.brm.plan.add.api.PlanAddResponse;
import com.jio.brm.plan.add.service.PlanAddService;
import com.jio.brm.plan.cancel.api.PlanCancelResponse;
import com.jio.brm.plan.cancel.service.PlanCancelService;
import com.jio.config.props.constant.ConfigConstant;
import com.jio.config.props.util.JioPropsUtil;
import com.jio.config.service.KeyPropertyLocalService;
import com.jio.config.service.LanguagePropertyLocalService;
import com.jio.customer.plan.constant.StatusConstant;
import com.jio.customer.plan.service.CustomerPlanService;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.exception.NoSuchPlanChannelException;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.jio.master.telecom.exception.NoSuchServiceTypeException;
import com.jio.master.telecom.model.Plan;
import com.jio.master.telecom.model.PlanCategory;
import com.jio.master.telecom.model.PlanChannel;
import com.jio.master.telecom.model.ServiceType;
import com.jio.master.telecom.service.ChannelLocalService;
import com.jio.master.telecom.service.PlanCategoryGroupLocalService;
import com.jio.master.telecom.service.PlanCategoryLocalService;
import com.jio.master.telecom.service.PlanChannelLocalService;
import com.jio.master.telecom.service.PlanLocalService;
import com.jio.master.telecom.service.ServiceTypeLocalService;
import com.liferay.petra.string.StringBundler;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, service = CustomerPlanService.class)
public class CustomerPlanServiceImpl implements CustomerPlanService {

	@Override
	public Map<String, String> getOrCreateCustomerPlans(CustomerInfoResponse customerInfoResponse, Customer customer, Address address, Agent agent, long companyId, long groupId, User userAgent) throws NoSuchAgentException {
		LOGGER.info("CustomerPlanServiceImpl::getOrCreateCustomerPlans");
		List<com.jio.brm.customer.info.api.Plan> plans = customerInfoService.getHwayOBRMCustInfoPlans(customerInfoResponse);

		String finalStatus = StringPool.BLANK;
		String finalMessage = StringPool.BLANK;

		List<CP> customerPlans = new ArrayList<CP>();
		List<String> successPlans = new ArrayList<String>();
		List<String> errorPlans = new ArrayList<String>();
		boolean autoRenew = isAutoRenew(agent, customer);

		plans.stream().forEach(plan -> {

			List<Product> products = plan.getProducts();
			String planCode = plan.getPlanObj().get("object_id");

			products.stream().forEach(product -> {
				if (Validator.isNotNull(product)) {
					// String dealPoId = product.getDealObj().get("object_id");
					String purchasedProductPoId = product.getPoId().get("object_id");
					String packageId = product.getPackageId();
					String productPoId = product.getProductObj().get("object_id");
					Date startTime = product.getPurchaseStartT();
					Date endTime = product.getPurchaseEndT();
					// Date currentTime = new Date();
					// boolean activePlan = currentTime.before(endTime);
					boolean activePlan = StatusConstant.getProductStatus(product.getStatus());
					CP cutomerPlan = saveOrUpdateCustomerPlan(customerPlans, planCode, productPoId, groupId, companyId, customer, userAgent, address, activePlan, successPlans, errorPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
					if (Validator.isNotNull(cutomerPlan)) {
						LOGGER.info("CP : " + cutomerPlan.toString());
					}
				}
			});

		});

		return getPlanStatusMessage(companyId, finalStatus, finalMessage, "add", errorPlans, successPlans, StringPool.BLANK, new ArrayList<Double>());
	}

	protected Map<String, String> getOrCreateCustomerPlans(Customer customer, Address address, Agent agent, String txRefNo, String referenceNumber, String transactionRefNo, User userAgent, long companyId, long groupId) throws NoSuchAgentException {
		LOGGER.info("CustomerPlanServiceImpl::getOrCreateCustomerPlans");
		CustomerInfoResponse customerInfoResponse = customerInfoService.getHwayOBRMCustInfo(customer.getAccountNo(), txRefNo, referenceNumber, transactionRefNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);
		if (Validator.isNotNull(customerInfoResponse)) {
			return getOrCreateCustomerPlans(customerInfoResponse, customer, address, agent, companyId, groupId, userAgent);
		} else {
			return getMap("FAIL", "customer-info-service-error");
		}
	}

	@Override
	public Map<String, String> validateCustomerPlans(String[] planIds, String accountNo, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException {
		LOGGER.info("CustomerPlanServiceImpl::validateCustomerPlans");
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		List<String> errorPlans = new ArrayList<String>();
		List<String> warningPlans = new ArrayList<String>();
		List<Plan> newPackagePlans = new ArrayList<Plan>();
		List<Plan> newSinglePlans = new ArrayList<Plan>();

		List<Plan> existingPackagePlans = new ArrayList<Plan>();
		List<Plan> existingSinglePlans = new ArrayList<Plan>();

		Arrays.asList(planIds).stream().forEach(planId -> {
			try {
				Plan plan = planLocalService.getPlan(GetterUtil.get(planId, 0L), companyId);
				if (plan.isPack()) {
					newPackagePlans.add(plan);
				} else {
					newSinglePlans.add(plan);
				}
			} catch (NoSuchPlanException e) {
			}
		});

		List<CP> cps = cpLocalService.getCPs(accountNo, customer.getScreenName(), true, true, companyId);
		cps.stream().forEach(cp -> {
			try {
				Plan plan = planLocalService.getPlanByCode(cp.getPlanCode(), cp.getCompanyId(), cp.getCityCode());
				if (plan.isPack()) {
					existingPackagePlans.add(plan);
				} else {
					existingSinglePlans.add(plan);
				}
			} catch (NoSuchPlanException e) {
			}
		});

		List<Plan> allPackagePlans = new ArrayList<Plan>();
		allPackagePlans.addAll(newPackagePlans);
		allPackagePlans.addAll(existingPackagePlans);

		List<Plan> allSinglePlans = new ArrayList<Plan>();
		allSinglePlans.addAll(newSinglePlans);
		allSinglePlans.addAll(existingSinglePlans);

		// NEW ALA-CART CHECK IN ALL PACKAGE
		newSinglePlans.stream().forEach(plan -> {
			getChannelIfExistInPlan(plan.getPlanPoId(), allPackagePlans, companyId).ifPresent(existPlan -> {
				errorPlans.add(getMessage(companyId, "plan-already-exist", plan.getName().concat(" : ").concat(existPlan.getName())));
			});
		});

		// EXISTING ALA-CART CHECK IN ALL PACKAGE
		existingSinglePlans.stream().forEach(plan -> {
			getChannelIfExistInPlan(plan.getPlanPoId(), allPackagePlans, companyId).ifPresent(existPlan -> {
				warningPlans.add(getMessage(companyId, "plan-already-exist", plan.getName().concat(" : ").concat(existPlan.getName())));
			});
		});

		// ALL PACKAGE PLAN CHECK IN ALL ALA-CART
		allPackagePlans.stream().forEach(packagePlan -> {
			List<PlanChannel> planChannels = planChannelLocalService.getPlanChannelsByPack(packagePlan.getPlanPoId(), companyId);
			planChannels.stream().forEach(planChannel -> {
				isChannelExist(planChannel.getChannelPoId(), allSinglePlans).ifPresent(optionalPlan -> {
					warningPlans.add(getMessage(companyId, "plan-already-exist", optionalPlan.getName().concat(" : ").concat(packagePlan.getName())));
				});
			});
		});
		LOGGER.info("WARNING : " + warningPlans + " ERROR : " + errorPlans);
		if (errorPlans.size() > 0) {
			return getMap("FAIL", errorPlans.stream().collect(Collectors.joining(StringPool.COMMA_AND_SPACE)));
		} else if (warningPlans.size() > 0) {
			return getMap("WARNING", warningPlans.stream().collect(Collectors.joining(StringPool.COMMA_AND_SPACE)));
		} else {
			return getMap("SUCCESS", StringPool.BLANK);
		}
	}

	private Optional<Plan> isChannelExist(String channelPoId, List<Plan> plans) {
		return plans.stream().filter(plan -> plan.getPlanPoId().equalsIgnoreCase(channelPoId)).findAny();
	}

	@Override
	public Map<String, String> addCustomerPlan(String planCode, String planName, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException {
		LOGGER.info("CustomerPlanServiceImpl::addCustomerPlan");
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		Address address = addressLocalService.getAddress(companyId, customer.getScreenName());
		if (Validator.isNotNull(planCode)) {
			Plan plan = planLocalService.getPlanByCode(planCode, companyId, address.getCityCode());
			return addCustomerPlans(new String[] { String.valueOf(plan.getPlanId()) }, autoRenew, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
		} else if (Validator.isNotNull(planName)) {
			Plan plan = planLocalService.getPlanByName(planName, companyId, address.getCityCode());
			return addCustomerPlans(new String[] { String.valueOf(plan.getPlanId()) }, autoRenew, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
		} else {
			throw new NoSuchPlanException("planCode-or-planName-required");
		}
	}

	@Override
	public Map<String, String> addCustomerPlans(String[] planIds, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException {
		LOGGER.info("CustomerPlanServiceImpl::addCustomerPlans");
		Map<String, String> validateMap = validateCustomerPlans(planIds, accountNo, txRefNo, userAgent, companyId, groupId);
		if (validateMap.get("STATUS").equalsIgnoreCase("FAIL")) {
			return validateMap;
		}
		List<CP> cps = new ArrayList<CP>();
		List<String> successPlans = new ArrayList<String>();
		List<String> errorPlans = new ArrayList<String>();
		List<Double> pricePlans = new ArrayList<Double>();
		String finalStatus = StringPool.BLANK;
		String finalMessage = StringPool.BLANK;
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		Address address = addressLocalService.getAddress(companyId, customer.getScreenName());

		Agent agent = agentLocalService.getAgent(companyId, userAgent.getScreenName());

		for (String planId : planIds) {
			try {
				Plan plan = planLocalService.getPlan(GetterUtil.get(planId, 0L), companyId);
				Map<String, String> map = addCustomerPlan(cps, plan, autoRenew, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
				finalStatus = map.get("STATUS");
				finalMessage = map.get("MESSAGE");
				if (Validator.isNotNull(plan.getMappingCode())) {
					plan = planLocalService.getPlanByCode(plan.getMappingCode(), companyId, plan.getCityCode());
					map = addCustomerPlan(cps, plan, autoRenew, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
					finalStatus = map.get("STATUS");
					finalMessage = map.get("MESSAGE");
				}
			} catch (NoSuchPlanException e) {
				LOGGER.error("NoSuchPlanException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchPlanException : " + e.toString();
				errorPlans.add(finalMessage);
			}
		}

		List<String> ncfPlanCodes = addNCFCodes(customer, companyId);
		for (String ncfPlanCode : ncfPlanCodes) {
			try {
				Plan plan = planLocalService.getPlanByCode(ncfPlanCode, companyId, address.getCityCode());
				Map<String, String> map = addCustomerPlan(cps, plan, autoRenew, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
				finalStatus = map.get("STATUS");
				finalMessage = map.get("MESSAGE");
			} catch (NoSuchPlanException e) {
				LOGGER.error("NoSuchPlanException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchPlanException : " + e.toString();
				errorPlans.add(finalMessage);
			}
		}

		return getPlanStatusMessage(companyId, finalStatus, finalMessage, "add", errorPlans, successPlans, "debit", pricePlans);
	}

	protected Map<String, String> addCustomerPlan(List<CP> cps, Plan plan, boolean autoRenew, Customer customer, Address address, String receiptNo, String txRefNo, User userAgent, Agent agent, List<String> successPlans, List<String> errorPlans, String finalStatus, String finalMessage,
			List<Double> pricePlans, long companyId, long groupId) throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException {
		LOGGER.info("CustomerPlanServiceImpl::addCustomerPlan");
		if (isAgentBalanceBlockOrInsufficentAmount(userAgent.getScreenName(), companyId)) {
			Optional<CP> existCP = getChannelIfExistInCP(plan.getPlanPoId(), customer, companyId);
			if (!existCP.isPresent()) {
				List<String> planPoIds = new ArrayList<String>();
				planPoIds.add(plan.getPlanPoId());
				int count = getPlanCount(plan);

				PlanAddResponse planAddResponse = planAddService.getHwayOBRMAddPlans(planPoIds, String.valueOf(count), customer.getPoId(), customer.getServicePoId(), txRefNo, customer.getCustomerId(), receiptNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);

				if (Validator.isNotNull(planAddResponse)) {
					String status = planAddResponse.getStatus();
					if (status.equals(StatusConstant.SUCCESS)) {
						autoRenew = isAutoRenew(agent, customer, autoRenew);

						CP cp = saveOrUpdateActivateCustomerPlan(cps, plan, autoRenew, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
						LOGGER.info("CP : " + cp.toString());

						// MANDATORY PLAN - NCF 1
						if (cp.isMandatory()) {
							try {
								plan = planLocalService.getPlanByCode(JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId, cp.getCityCode());
								cp = saveOrUpdateActivateCustomerPlan(cps, plan, autoRenew, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
								LOGGER.info("CP : " + cp.toString());
							} catch (NoSuchPlanException e) {
								LOGGER.error("NoSuchPlanException : " + e.toString());
							}
						}

						Map<String, String> map = getOrCreateCustomerPlans(customer, address, agent, txRefNo, customer.getCustomerId(), receiptNo, userAgent, companyId, groupId);
						if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
							LOGGER.info(map.get("MESSAGE"));
						} else {
							LOGGER.error(map.get("MESSAGE"));
						}

					} else {
						String errorCode = planAddResponse.getErrorCode();
						String errorDesc = planAddResponse.getErrorDescr();
						String message = errorCode.concat(" : ").concat(errorDesc);
						finalMessage = message;
						errorPlans.add(finalMessage.concat(" : ").concat(plan.getName()));
					}
				} else {
					finalStatus = "FAIL";
					finalMessage = "plan-add-service-error";
					errorPlans.add(finalMessage.concat(" : ").concat(plan.getName()));
				}
			} else {
				finalStatus = "FAIL";
				finalMessage = "plan-already-exist";
				errorPlans.add(finalMessage.concat(" : ").concat(plan.getName()).concat(" : ").concat(existCP.get().getPlanName()));
			}

		}
		return getMap(finalStatus, finalMessage);
	}

	protected CP saveOrUpdateActivateCustomerPlan(List<CP> cps, Plan plan, boolean autoRenew, Customer customer, Address address, String receiptNo, String txRefNo, User userAgent, Agent agent, List<String> successPlans, List<String> errorPlans, String finalStatus, String finalMessage,
			List<Double> pricePlans, long companyId, long groupId) {
		LOGGER.info("CustomerPlanServiceImpl::saveOrUpdateActivateCustomerPlan");
		Date currentTime = new Date();
		Date endTime = getEndTime(customerPlanUtil.getEndDate(currentTime), customer, companyId);

		CP cp = saveOrUpdateCustomerPlan(cps, plan.getPlanId(), groupId, companyId, customer, userAgent, address, successPlans, errorPlans, autoRenew, currentTime, endTime);

		return activateCustomerPlan(false, cp, customer, userAgent, address, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, currentTime, endTime);
	}

	@Override
	public Map<String, String> renewCustomerPlan(String planCode, String planName, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException, NoSuchCPException {
		LOGGER.info("CustomerPlanServiceImpl::renewCustomerPlan");
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		if (Validator.isNotNull(planCode)) {
			CP cp = cpLocalService.getCP(accountNo, customer.getScreenName(), planCode, companyId);
			return renewCustomerPlans(new String[] { cp.getCpId() }, autoRenew, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
		} else if (Validator.isNotNull(planName)) {
			Address address = addressLocalService.getAddress(companyId, customer.getScreenName());
			Plan plan = planLocalService.getPlanByName(planName, companyId, address.getCityCode());
			CP cp = cpLocalService.getCP(accountNo, customer.getScreenName(), plan.getCode(), companyId);
			return renewCustomerPlans(new String[] { cp.getCpId() }, autoRenew, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
		} else {
			throw new NoSuchPlanException("planCode-or-planName-required");
		}
	}

	@Override
	public Map<String, String> renewCustomerPlans(boolean autoRenew, String vcId, String receiptNo, String txRefNo, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, PortalException {
		LOGGER.info("CustomerPlanServiceImpl::renewCustomerPlans");
		Customer customer = customerLocalService.getCustomerByVcId(vcId, companyId);
		User userAgent = userLocalService.getUserByScreenName(companyId, customer.getAgentScreenName());
		List<CP> cps = getRenewalCustomerPlan(customer, companyId);
		String[] cpIds = cps.stream().map(cp -> cp.getCpId()).collect(Collectors.toList()).stream().toArray(String[]::new);
		return renewCustomerPlans(cpIds, autoRenew, customer.getAccountNo(), receiptNo, txRefNo, userAgent, companyId, groupId);
	}

	@Override
	public Map<String, String> renewCustomerPlans(String[] cpIds, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException {
		LOGGER.info("CustomerPlanServiceImpl::renewCustomerPlans");
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		Address address = addressLocalService.getAddress(companyId, customer.getScreenName());
		String finalStatus = StringPool.BLANK;
		String finalMessage = StringPool.BLANK;
		List<String> successPlans = new ArrayList<String>();
		List<String> errorPlans = new ArrayList<String>();
		List<Double> pricePlans = new ArrayList<Double>();
		Agent agent = agentLocalService.getAgent(companyId, userAgent.getScreenName());
		for (String cpId : cpIds) {
			try {
				CP cp = cpLocalService.getCP(cpId, companyId);
				if (!cp.isMandatory()) {
					CP mandatoryCP = getMandatoryCP(customer, companyId);
					if (Validator.isNotNull(mandatoryCP) && mandatoryCP.getEndDate().compareTo(cp.getEndDate()) == 0) {
						Map<String, String> map = renewCustomerPlan(mandatoryCP, customer, address, autoRenew, accountNo, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
						finalStatus = map.get("STATUS");
						finalMessage = map.get("MESSAGE");
					}
				}
				Map<String, String> map = renewCustomerPlan(cp, customer, address, autoRenew, accountNo, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
				finalStatus = map.get("STATUS");
				finalMessage = map.get("MESSAGE");
				Plan plan = planLocalService.getPlanByCode(cp.getPlanCode(), companyId, cp.getCityCode());
				if (Validator.isNotNull(plan.getMappingCode())) {
					cp = cpLocalService.getCP(accountNo, customer.getScreenName(), plan.getCode(), companyId);
					map = renewCustomerPlan(cp, customer, address, autoRenew, accountNo, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
					finalStatus = map.get("STATUS");
					finalMessage = map.get("MESSAGE");
				}

			} catch (NoSuchPlanException e) {
				LOGGER.error("NoSuchPlanException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchPlanException :: " + e.toString();
			} catch (NoSuchCPException e) {
				LOGGER.error("NoSuchCPException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchCPException :: " + e.toString();
			}
		}

		List<String> ncfPlanCodes = getActivedNCFCodes(customer, companyId);
		for (String ncfPlanCode : ncfPlanCodes) {
			try {
				CP cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), ncfPlanCode, companyId);
				Map<String, String> map = renewCustomerPlan(cp, customer, address, autoRenew, accountNo, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
				finalStatus = map.get("STATUS");
				finalMessage = map.get("MESSAGE");
			} catch (NoSuchPlanException e) {
				LOGGER.error("NoSuchPlanException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchPlanException :: " + e.toString();
			} catch (NoSuchCPException e) {
				LOGGER.error("NoSuchCPException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchCPException :: " + e.toString();
			}
		}

		return getPlanStatusMessage(companyId, finalStatus, finalMessage, "renew", errorPlans, successPlans, "debit", pricePlans);
	}

	protected Map<String, String> renewCustomerPlan(CP cp, Customer customer, Address address, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, Agent agent, List<String> successPlans, List<String> errorPlans, String finalStatus, String finalMessage,
			List<Double> pricePlans, long companyId, long groupId) throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException {
		LOGGER.info("CustomerPlanServiceImpl::renewCustomerPlan");
		if (isAgentBalanceBlockOrInsufficentAmount(userAgent.getScreenName(), companyId)) {
			Plan plan = planLocalService.getPlanByCode(cp.getPlanCode(), companyId, cp.getCityCode());
			String purchasedProductId = cp.getPurchasedProductPoId();
			List<String> planPoids = new ArrayList<String>();
			planPoids.add(plan.getPlanPoId());

			int count = getPlanCount(plan);

			PlanAddResponse planAddResponse = planAddService.getHwayOBRMRenewPlans(planPoids, String.valueOf(count), customer.getPoId(), customer.getServicePoId(), purchasedProductId, txRefNo, customer.getCustomerId(), receiptNo, userAgent.getScreenName(), userAgent.getUserId(), companyId, groupId);

			if (Validator.isNotNull(planAddResponse)) {
				String status = planAddResponse.getStatus();
				if (status.equals(StatusConstant.SUCCESS)) {

					Date startTime = new Date();
					Date endTime = getEndTime(customerPlanUtil.getEndDate(startTime), customer, companyId);

					cp = activateCustomerPlan(true, cp, customer, userAgent, address, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime);
					LOGGER.info("CP : " + cp.toString());

					// MANDATORY PLAN - NCF 1
					if (cp.isMandatory()) {
						try {
							plan = planLocalService.getPlanByCode(JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId, cp.getCityCode());
							cp = activateCustomerPlan(true, cp, customer, userAgent, address, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime);
							LOGGER.info("CP : " + cp.toString());
						} catch (NoSuchPlanException e) {
							LOGGER.error("NoSuchPlanException : " + e.toString());
						}
					}

					Map<String, String> map = getOrCreateCustomerPlans(customer, address, agent, txRefNo, customer.getCustomerId(), receiptNo, userAgent, companyId, groupId);
					if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
						LOGGER.info(map.get("MESSAGE"));
					} else {
						LOGGER.error(map.get("MESSAGE"));
					}

				} else {
					String errorCode = planAddResponse.getErrorCode();
					String errorDesc = planAddResponse.getErrorDescr();
					String message = errorCode.concat(" : ").concat(errorDesc);
					finalStatus = "FAIL";
					finalMessage = message;
					errorPlans.add(finalMessage.concat(" : ").concat(plan.getName()));
				}
			} else {
				finalStatus = "FAIL";
				finalMessage = "plan-renew-service-error";
				errorPlans.add(finalMessage.concat(" : ").concat(plan.getName()));
			}
		}
		return getMap(finalStatus, finalMessage);
	}

	@Override
	public Map<String, String> cancelCustomerPlan(String planCode, String planName, String reason, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException, NoSuchCPException {
		LOGGER.info("CustomerPlanServiceImpl::cancelCustomerPlan");
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		if (Validator.isNotNull(planCode)) {
			CP cp = cpLocalService.getCP(accountNo, customer.getScreenName(), planCode, companyId);
			return cancelCustomerPlans(new String[] { cp.getCpId() }, reason, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
		} else if (Validator.isNotNull(planName)) {
			Address address = addressLocalService.getAddress(companyId, customer.getScreenName());
			Plan plan = planLocalService.getPlanByName(planName, companyId, address.getCityCode());
			CP cp = cpLocalService.getCP(accountNo, customer.getScreenName(), plan.getCode(), companyId);
			return cancelCustomerPlans(new String[] { cp.getCpId() }, reason, accountNo, receiptNo, txRefNo, userAgent, companyId, groupId);
		} else {
			throw new NoSuchPlanException("planCode-or-planName-required");
		}
	}

	@Override
	public Map<String, String> cancelCustomerPlans(String[] cpIds, String reason, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException {
		LOGGER.info("CustomerPlanServiceImpl::cancelCustomerPlans");
		List<String> successPlans = new ArrayList<String>();
		List<String> errorPlans = new ArrayList<String>();
		List<Double> pricePlans = new ArrayList<Double>();
		Customer customer = customerLocalService.getCustomer(accountNo, companyId);
		Address address = addressLocalService.getAddress(companyId, customer.getScreenName());

		Agent agent = agentLocalService.getAgent(companyId, userAgent.getScreenName());
		String finalStatus = StringPool.BLANK;
		String finalMessage = StringPool.BLANK;

		for (String cpId : cpIds) {
			try {
				CP cp = cpLocalService.getCP(cpId, companyId);
				if (cp.isMandatory()) {
					List<CP> customerPlans = cpLocalService.getCPs(accountNo, customer.getScreenName(), true, companyId);
					for (CP customerPlan : customerPlans) {
						Map<String, String> map = cancelCustomerPlan(customerPlan, reason, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
						finalStatus = map.get("STATUS");
						finalMessage = map.get("MESSAGE");
					}
					break;
				} else {
					Map<String, String> map = cancelCustomerPlan(cp, reason, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
					finalStatus = map.get("STATUS");
					finalMessage = map.get("MESSAGE");
				}
			} catch (NoSuchCPException e) {
				LOGGER.error("NoSuchCPException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchCPException :: " + e.toString();
			}
		}

		List<String> ncfPlanCodes = removeNCFCodes(customer, companyId);
		for (String ncfPlanCode : ncfPlanCodes) {
			try {
				CP cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), ncfPlanCode, companyId);
				Map<String, String> map = cancelCustomerPlan(cp, reason, customer, address, receiptNo, txRefNo, userAgent, agent, successPlans, errorPlans, finalStatus, finalMessage, pricePlans, companyId, groupId);
				finalStatus = map.get("STATUS");
				finalMessage = map.get("MESSAGE");
			} catch (NoSuchCPException e) {
				LOGGER.error("NoSuchCPException : " + e.toString());
				finalStatus = "FAIL";
				finalMessage = "NoSuchCPException :: " + e.toString();
			}
		}

		return getPlanStatusMessage(companyId, finalStatus, finalMessage, "cancel", errorPlans, successPlans, "credit", pricePlans);
	}

	protected Map<String, String> cancelCustomerPlan(CP cp, String reason, Customer customer, Address address, String receiptNo, String txRefNo, User userAgent, Agent agent, List<String> successPlans, List<String> errorPlans, String finalStatus, String finalMessage, List<Double> pricePlans,
			long companyId, long groupId) throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException {
		LOGGER.info("CustomerPlanServiceImpl::cancelCustomerPlan");
		if (isAgentBalanceBlockOrInsufficentAmount(userAgent.getScreenName(), companyId)) {
			Plan plan = planLocalService.getPlanByCode(cp.getPlanCode(), cp.getCompanyId(), cp.getCityCode());

			int count = getPlanCount(plan);

			PlanCancelResponse planCancelResponse = planCancelService.getHwayOBRMCancelPlans(plan.getPlanPoId(), cp.getPackageId(), cp.getDealPoId(), String.valueOf(count), customer.getPoId(), customer.getServicePoId(), txRefNo, customer.getCustomerId(), receiptNo, userAgent.getScreenName(),
					userAgent.getUserId(), companyId, groupId);

			if (Validator.isNotNull(planCancelResponse)) {

				String status = planCancelResponse.getStatus();
				if (status.equals(StatusConstant.SUCCESS)) {
					cp = deActivateCustomerPlan(cp, reason, customer, userAgent, address, receiptNo, successPlans, errorPlans, pricePlans);

					LOGGER.info("CP : " + cp.toString());

					// MANDATORY PLAN - NCF 1
					if (cp.isMandatory()) {
						try {
							cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_1_CODE, companyId), companyId);
							cp = deActivateCustomerPlan(cp, reason, customer, userAgent, address, receiptNo, successPlans, errorPlans, pricePlans);
							LOGGER.info("CP : " + cp.toString());
						} catch (NoSuchCPException e) {
							LOGGER.error("NoSuchCPException : " + e.toString());
						}
					}

					Map<String, String> map = getOrCreateCustomerPlans(customer, address, agent, txRefNo, customer.getCustomerId(), receiptNo, userAgent, companyId, groupId);
					if (map.get("STATUS").equalsIgnoreCase("SUCCESS")) {
						LOGGER.info(map.get("MESSAGE"));
					} else {
						LOGGER.error(map.get("MESSAGE"));
					}

					finalStatus = "SUCCESS";
				} else {
					String errorCode = planCancelResponse.getErrorCode();
					String errorDesc = planCancelResponse.getErrorDescr();
					String message = errorCode.concat(" : ").concat(errorDesc);
					finalStatus = "FAIL";
					finalMessage = message;
					errorPlans.add(plan.getName());
				}

			} else {
				finalStatus = "FAIL";
				finalMessage = "plan-cancel-service-error";
				errorPlans.add(plan.getName());
			}
		}
		return getMap(finalStatus, finalMessage);
	}

	protected Map<String, String> getPlanStatusMessage(long companyId, String finalStatus, String finalMessage, String operation, List<String> errorPlans, List<String> successPlans, String amountOperation, List<Double> pricePlans) {
		LOGGER.info("CustomerPlanServiceImpl::getPlanStatusMessage");
		double finalPrice = pricePlans.stream().mapToDouble(price -> price.doubleValue()).sum();
		if (errorPlans.size() > 0 && successPlans.size() > 0) {
			String errorPlan = errorPlans.stream().distinct().collect(Collectors.joining(StringPool.COMMA_AND_SPACE, StringPool.OPEN_CURLY_BRACE, StringPool.CLOSE_CURLY_BRACE));
			String successPlan = successPlans.stream().distinct().collect(Collectors.joining(StringPool.COMMA_AND_SPACE, StringPool.OPEN_CURLY_BRACE, StringPool.CLOSE_CURLY_BRACE));
			finalStatus = "PARTIAL";
			finalMessage = getMessage(companyId, "plan-" + operation + "-error", errorPlan) + " : " + getMessage(companyId, "plan-" + operation + "-success", successPlan);
			if (Validator.isNotNull(amountOperation)) {
				finalMessage = finalMessage + " : " + getMessage(companyId, "plan-amount-" + amountOperation, String.valueOf(finalPrice));
			}
		} else if (errorPlans.size() > 0) {
			String errorPlan = errorPlans.stream().distinct().collect(Collectors.joining(StringPool.COMMA_AND_SPACE, StringPool.OPEN_CURLY_BRACE, StringPool.CLOSE_CURLY_BRACE));
			finalStatus = "FAIL";
			finalMessage = getMessage(companyId, "plan-" + operation + "-error", errorPlan);
		} else if (successPlans.size() > 0) {
			String successPlan = successPlans.stream().distinct().collect(Collectors.joining(StringPool.COMMA_AND_SPACE, StringPool.OPEN_CURLY_BRACE, StringPool.CLOSE_CURLY_BRACE));
			finalStatus = "SUCCESS";
			finalMessage = getMessage(companyId, "plan-" + operation + "-success", successPlan);
			if (Validator.isNotNull(amountOperation)) {
				finalMessage = finalMessage + " : " + getMessage(companyId, "plan-amount-" + amountOperation, String.valueOf(finalPrice));
			}
		}
		return getMap(finalStatus, finalMessage);
	}

	private String getMessage(long companyId, String propertyKey, String valueToReplace) {
		return languagePropertyLocalService.getFormatedLanguagePropertyByKey(propertyKey, valueToReplace, companyId);
	}

	@Override
	public boolean isAutoRenew(Agent agent, Customer customer) {
		LOGGER.info("CustomerPlanServiceImpl::isAutoRenew");
		boolean autoRenew = agent.isAutoRenew();
		if (!autoRenew) {
			autoRenew = customer.isAutoRenew();
		}
		return autoRenew;
	}

	@Override
	public boolean isAutoRenew(Agent agent, Customer customer, boolean autoRenewal) {
		LOGGER.info("CustomerPlanServiceImpl::isAutoRenew");
		boolean autoRenew = agent.isAutoRenew();
		if (!autoRenew) {
			autoRenew = customer.isAutoRenew();
		}
		if (!autoRenew) {
			autoRenew = autoRenewal;
		}
		return autoRenew;
	}

	@Override
	public boolean isAutoRenew(long companyId, String agentScreenName, String customerAccountNo) throws NoSuchAgentException, NoSuchCustomerException {
		LOGGER.info("CustomerPlanServiceImpl::isAutoRenew");
		Agent agent = agentLocalService.getAgent(companyId, agentScreenName);
		Customer customer = customerLocalService.getCustomer(customerAccountNo, companyId);
		return isAutoRenew(agent, customer);
	}

	@Override
	public Date getEndTime(Date endTime, Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getEndTime");
		CP cp = getMandatoryCP(customer, companyId);
		if (Validator.isNotNull(cp)) {
			endTime = cp.getEndDate();
		}
		return endTime;
	}

	/**
	 * @deprecated {@link #getEndTime(Date, Customer, long)}
	 * 
	 * @param endTime
	 * @param customer
	 * @param companyId
	 * @return
	 */
	private Date _getEndTime(Date endTime, Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::_getEndTime");
		try {
			ServiceType serviceType = serviceTypeLocalService.getServiceTypeByCode(customer.getServiceType(), companyId);
			List<PlanCategory> planCategories = planCategoryLocalService.getPlanCategories(true, serviceType.getServiceTypeId(), companyId);
			String[] categories = planCategories.stream().map(planCategory -> planCategory.getCode()).collect(Collectors.toList()).stream().toArray(String[]::new);
			List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), categories, true, companyId);
			Optional<CP> cp = cps.stream().findFirst();
			if (cp.isPresent()) {
				endTime = cp.get().getEndDate();
			}
		} catch (NoSuchServiceTypeException e) {
			LOGGER.error("NoSuchServiceTypeException :: " + e.toString());
		}
		return endTime;
	}

	@Override
	public CP getMandatoryCP(Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getMandatoryCP");
		List<CP> cps = cpLocalService.getMandatoryCPs(customer.getAccountNo(), customer.getScreenName(), true, true, companyId);
		if (!cps.isEmpty()) {
			return cps.get(0);
		}
		return null;
	}

	@Override
	public CP saveOrUpdateCustomerPlan(List<CP> cps, long planId, long groupId, long companyId, Customer customer, User userAgent, Address address, List<String> successPlans, List<String> errorPlans, boolean autoRenew, Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::saveOrUpdateCustomerPlan");
		return saveOrUpdateCustomerPlan(cps, planId, groupId, companyId, customer, userAgent, address, false, successPlans, errorPlans, autoRenew, StringPool.BLANK, StringPool.BLANK, startTime, endTime);
	}

	protected CP saveOrUpdateCustomerPlan(List<CP> cps, long planId, long groupId, long companyId, Customer customer, User userAgent, Address address, boolean activePlan, List<String> successPlans, List<String> errorPlans, boolean autoRenew, String packageId, String purchasedProductPoId,
			Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::saveOrUpdateCustomerPlan");
		CP cp = null;
		try {
			Plan plan = planLocalService.getPlan(planId, companyId);
			if (address.getCityCode().equalsIgnoreCase(plan.getCityCode())) {
				cp = saveOrUpdateCustomerPlan(cps, plan, groupId, companyId, customer, userAgent, address, activePlan, successPlans, errorPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
			} else {
				LOGGER.error("Customer address and Plan city code is different :: " + plan.getCode());
			}

		} catch (NoSuchPlanException e) {
			LOGGER.error("NoSuchPlanException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}
		return cp;
	}

	@Override
	public CP saveOrUpdateCustomerPlan(List<CP> cps, String planCode, String productCode, long groupId, long companyId, Customer customer, User userAgent, Address address, boolean activePlan, List<String> successPlans, List<String> errorPlans, boolean autoRenew, String packageId,
			String purchasedProductPoId, Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::saveOrUpdateCustomerPlan");
		CP cp = null;
		try {
			Plan plan = planLocalService.getPlanByProduct(productCode, companyId, address.getCityCode());

			if (Validator.isNotNull(plan)) {
				cp = saveOrUpdateCustomerPlan(cps, plan, groupId, companyId, customer, userAgent, address, activePlan, successPlans, errorPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
			} else {
				LOGGER.error("Customer address and Plan city code is different :: " + plan.getCode());
			}

		} catch (NoSuchPlanException e) {
			LOGGER.error("NoSuchPlanException :: " + e.toString());
		} catch (PortalException e) {
			LOGGER.error("PortalException :: " + e.toString());
		}
		return cp;
	}

	protected CP saveOrUpdateCustomerPlan(List<CP> cps, Plan plan, long groupId, long companyId, Customer customer, User userAgent, Address address, boolean activePlan, List<String> successPlans, List<String> errorPlans, boolean autoRenew, String packageId, String purchasedProductPoId,
			Date startTime, Date endTime) throws PortalException {
		LOGGER.info("CustomerPlanServiceImpl::saveOrUpdateCustomerPlan");
		CP cp = null;
		try {
			cp = cpLocalService.getCP(customer.getAccountNo(), customer.getScreenName(), plan.getCode(), companyId);
			if (!cp.isActive()) {
				cp = addCP(cps, plan.getPlanId(), groupId, companyId, customer, userAgent, address, plan, activePlan, successPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
			} else {
				if (!activePlan) {
					cp = addCP(cps, plan.getPlanId(), groupId, companyId, customer, userAgent, address, plan, activePlan, successPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
				} else {
					cp = updateCP(cps, plan.getPlanId(), groupId, companyId, customer, userAgent, address, plan, activePlan, successPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
					successPlans.add(plan.getName());
					LOGGER.info("Customer plan already exist as active :: " + plan.getCode());
				}
			}
		} catch (NoSuchCPException e) {
			cp = addCP(cps, plan.getPlanId(), groupId, companyId, customer, userAgent, address, plan, activePlan, successPlans, autoRenew, packageId, purchasedProductPoId, startTime, endTime);
		}
		return cp;
	}

	private CP addCP(List<CP> cps, long planId, long groupId, long companyId, Customer customer, User userAgent, Address address, Plan plan, boolean active, List<String> successPlans, boolean autoRenew, String packageId, String purchasedProductPoId, Date startTime, Date endTime)
			throws PortalException {
		LOGGER.info("CustomerPlanServiceImpl::addCP");
		CP cp = cpLocalService.saveOrUpdateCP(groupId, companyId, userAgent.getScreenName(), customer.getScreenName(), customer.getAccountNo(), customer.getCustomerId(), active, plan.getCode(), "Add Plan - " + plan.getCode(), address.getCityCode(), autoRenew, packageId, purchasedProductPoId,
				startTime, endTime);
		cps.add(cp);
		successPlans.add(plan.getName());
		LOGGER.info("Customer plan added as " + (active ? "active" : "deactive") + " :: " + plan.getCode());
		return cp;
	}

	private CP updateCP(List<CP> cps, long planId, long groupId, long companyId, Customer customer, User userAgent, Address address, Plan plan, boolean active, List<String> successPlans, boolean autoRenew, String packageId, String purchasedProductPoId, Date startTime, Date endTime)
			throws PortalException {
		LOGGER.info("CustomerPlanServiceImpl::updateCP");
		CP cp = cpLocalService.saveOrUpdateCP(groupId, companyId, userAgent.getScreenName(), customer.getScreenName(), customer.getAccountNo(), customer.getCustomerId(), active, plan.getCode(), "Update Plan - " + plan.getCode(), address.getCityCode(), autoRenew, packageId, purchasedProductPoId,
				startTime, endTime);
		cps.add(cp);
		LOGGER.info("Customer plan updated as " + (active ? "active" : "deactive") + " :: " + plan.getCode());
		return cp;
	}

	@Override
	public List<CP> activateCustomerPlans(boolean reActive, List<CP> cps, Customer customer, User userAgent, Address address, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::activateCustomerPlans");
		List<CP> _cps = new ArrayList<CP>();
		cps.stream().forEach(cp -> {
			CP _cp = activateCustomerPlan(reActive, cp, customer, userAgent, address, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime);
			if (Validator.isNotNull(_cp)) {
				_cps.add(cp);
			}
		});
		return _cps;
	}

	protected CP activateCustomerPlan(boolean reActive, CP cp, Customer customer, User userAgent, Address address, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::activateCustomerPlan");
		Map<String, String> map = getMessages(reActive, false);
		String reason = GetterUtil.getString(map.get("REASON"));
		String remark = GetterUtil.getString(map.get("REMARK"));
		String source = GetterUtil.getString(map.get("SOURCE"));
		String logMessage = GetterUtil.getString(map.get("LOG"));

		cp = activateCustomerPlan(reActive, cp, customer.getScreenName(), customer.getAccountNo(), customer.getCustomerId(), customer.getAgentScreenName(), userAgent.getScreenName(), address.getCityCode(), receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime, reason,
				remark, logMessage, source);

		return cp;
	}

	protected CP autoReActivateCustomerPlan(CP cp, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::autoReActivateCustomerPlan");
		Map<String, String> map = getMessages(true, true);
		String reason = GetterUtil.getString(map.get("REASON"));
		String remark = GetterUtil.getString(map.get("REMARK"));
		String source = GetterUtil.getString(map.get("SOURCE"));
		String logMessage = GetterUtil.getString(map.get("LOG"));

		cp = activateCustomerPlan(true, cp, cp.getCustomerScreenName(), cp.getAccountNo(), cp.getCustomerId(), cp.getCreateBy(), cp.getCreateBy(), cp.getCityCode(), receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime, reason, remark, logMessage, source);

		return cp;
	}

	@Override
	public List<CP> autoReActivateCustomerPlan(List<CP> cps, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime) {
		LOGGER.info("CustomerPlanServiceImpl::autoReActivateCustomerPlan");
		List<CP> cpList = new ArrayList<CP>();
		cps.parallelStream().forEach(cp -> {
			cpList.add(autoReActivateCustomerPlan(cp, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime));
		});
		return cpList;
	}

	protected CP activateCustomerPlan(boolean reActive, CP cp, String customerScreenName, String customerAccountNo, String customerId, String customerAgentScreenName, String userAgentScreenName, String cityCode, String receiptNo, List<String> successPlans, List<String> errorPlans,
			List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime, String reason, String remark, String logMessage, String source) {
		LOGGER.info("CustomerPlanServiceImpl::activateCustomerPlan");
		if (!cp.isActive()) {
			cp = activateCustomerPlan(cp, customerScreenName, customerAccountNo, customerId, customerAgentScreenName, userAgentScreenName, cityCode, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime, reason, remark, logMessage, source);
		} else {
			if (reActive) {
				cp = activateCustomerPlan(cp, customerScreenName, customerAccountNo, customerId, customerAgentScreenName, userAgentScreenName, cityCode, receiptNo, successPlans, errorPlans, pricePlans, autoRenew, startTime, endTime, reason, remark, logMessage, source);
			} else {
				LOGGER.info("Plan already active" + logMessage + " :: " + cp.getPlanCode());
			}

		}
		return cp;
	}

	protected CP activateCustomerPlan(CP cp, String customerScreenName, String customerAccountNo, String customerId, String customerAgentScreenName, String userAgentScreenName, String cityCode, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans,
			boolean autoRenew, Date startTime, Date endTime, String reason, String remark, String logMessage, String source) {
		LOGGER.info("CustomerPlanServiceImpl::activateCustomerPlan");
		String planCode = cp.getPlanCode();
		String planName = cp.getPlanName();
		try {
			Plan plan = planLocalService.getPlanByCode(planCode, cp.getCompanyId(), cityCode);
			planName = plan.getName();

			try {
				cp = cpLocalService.saveOrUpdateCP(cp.getGroupId(), cp.getCompanyId(), userAgentScreenName, customerScreenName, customerAccountNo, customerId, true, planCode, reason.concat(planName), cityCode, autoRenew, cp.getPackageId(), cp.getPurchasedProductPoId(), startTime, endTime);

				long diffInDays = customerPlanUtil.getDiffInDays(cp.getStartDate(), cp.getEndDate());

				double lcoPrice = customerPlanUtil.getDebitPrice(diffInDays, plan.getLcoPrice());

				AgentBalance agentBalance = agentBalanceLocalService.debitPlanBalanceFromAgent(cp.getGroupId(), cp.getCompanyId(), userAgentScreenName, lcoPrice, receiptNo, remark.concat(planName), source, customerScreenName, userAgentScreenName, customerAgentScreenName, source, cp.getEndDate(),
						diffInDays, cp.getCpId());

				cp = cpLocalService.saveOrUpdateCP(cp, agentBalance.getId(), plan.getLcoPrice(), lcoPrice, diffInDays, cp.getEndDate());

				pricePlans.add(lcoPrice);

				successPlans.add(planName);

				LOGGER.info("Plan already added as active" + logMessage + ":: " + planCode);
			} catch (PortalException e) {
				errorPlans.add(planName);
				LOGGER.error("PortalException :: " + e.toString());
			}

		} catch (NoSuchPlanException e) {
			LOGGER.error("NoSuchPlanException :: " + e.toString());
		}
		return cp;
	}

	protected CP deActivateCustomerPlan(CP cp, String reason, Customer customer, User userAgent, Address address, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans) {
		LOGGER.info("CustomerPlanServiceImpl::deActivateCustomerPlan");
		String planCode = cp.getPlanCode();
		String planName = cp.getPlanName();
		if (cp.isActive()) {
			try {
				Plan plan = planLocalService.getPlanByCode(planCode, cp.getCompanyId(), address.getCityCode());
				planName = plan.getName();

				Date startDate = cp.getStartDate();
				Date currentDate = new Date();
				Date endDate = cp.getEndDate();
				long actualDiffInDays = customerPlanUtil.getDiffInDays(startDate, endDate);
				long diffInDays = customerPlanUtil.getDiffInDays(startDate, currentDate); // Current Date as End Date

				double lcoPrice = customerPlanUtil.getCreditPrice(actualDiffInDays, diffInDays, getLcoPrice(cp));

				try {
					String cancelReason = new StringBundler("Cancel Plan - ").append(planName).append(" Due to - ").append(reason).toString();

					cp = cpLocalService.saveOrUpdateCP(cp.getGroupId(), cp.getCompanyId(), userAgent.getScreenName(), customer.getScreenName(), customer.getAccountNo(), customer.getCustomerId(), false, planCode, cancelReason, address.getCityCode(), false, cp.getPackageId(),
							cp.getPurchasedProductPoId(), startDate, currentDate);

					AgentBalance agentBalance = agentBalanceLocalService.creditPlanBalanceFromAgent(cp.getGroupId(), cp.getCompanyId(), userAgent.getScreenName(), lcoPrice, receiptNo, cancelReason, BalanceConstant.REIMBURSEMENT, customer.getScreenName(), userAgent.getScreenName(),
							customer.getAgentScreenName(), BalanceConstant.REIMBURSEMENT, currentDate, diffInDays, cp.getCpId());

					cp = cpLocalService.saveOrUpdateCP(cp, agentBalance.getId(), cp.getCpLcoPrice(), lcoPrice, diffInDays, cp.getEndDate());

					// finalPrice = finalPrice + lcoPrice;
					pricePlans.add(lcoPrice);
					// cpLocalService.deleteCP(cp);

					successPlans.add(planName);

					LOGGER.info("Plan already deleted as deactive :: " + planCode);
				} catch (PortalException e) {
					errorPlans.add(planName);
					LOGGER.error("PortalException :: " + e.toString());
				}

			} catch (NoSuchPlanException e) {
				LOGGER.error("NoSuchPlanException :: " + e.toString());
			}
		} else {
			LOGGER.info("Plan already deactive :: " + planCode);
		}
		return cp;
	}

	@Override
	public double getLcoPrice(CP cp) {
		double cpAmount = cp.getCpLcoPrice();
		if (cpAmount == 0) {
			Optional<CPTransaction> cpTransaction = cpTransactionLocalService.getCPTransactions(cp.getAccountNo(), cp.getPlanCode(), cp.getStartDate(), cp.getEndDate(), cp.getCompanyId()).stream().sorted((cpt1, cpt2) -> cpt1.getCreateDate().compareTo(cpt2.getCreateDate())).findFirst();
			cpAmount = cpTransaction.isPresent() ? cpTransaction.get().getLcoPrice() : cp.getLcoPrice();
		}
		return cpAmount;
	}

	private Map<String, String> getMessages(boolean reActive, boolean autoReActive) {
		String auto = StringPool.BLANK;
		String renew = StringPool.BLANK;
		if (autoReActive) {
			auto = "Auto".concat(StringPool.SPACE);
		}
		String reason = StringBundler.concat("Active", StringPool.SPACE, "Plan", StringPool.SPACE, StringPool.DASH, StringPool.SPACE);
		String remark = StringBundler.concat("Add", StringPool.SPACE, "Plan", StringPool.SPACE, StringPool.DASH, StringPool.SPACE);
		String source = BalanceConstant.ADD;
		String logMessage = StringPool.BLANK;
		if (reActive) {
			renew = "Renew".concat(StringPool.SPACE);
			source = BalanceConstant.RENEW;
			logMessage = " and renew set as true ";
		}

		reason = auto.concat(renew).concat(reason);
		remark = auto.concat(renew).concat(remark);

		Map<String, String> map = new HashMap<String, String>();
		map.put("REASON", reason);
		map.put("REMARK", remark);
		map.put("SOURCE", source);
		map.put("LOG", logMessage);

		return map;
	}

	@Override
	public boolean isAgentBalanceBlockOrInsufficentAmount(String userAgentScreenName, long companyId) throws NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException {
		LOGGER.info("CustomerPlanServiceImpl::isAgentBalanceBlockOrInsufficentAmount");
		boolean validAgentBalance = false;
		AgentBalance agentBalance = agentBalanceLocalService.getAgentBalance(userAgentScreenName, companyId);
		if (!agentBalance.isBlocked()) {
			if (agentBalance.getAmount() >= customerPlanUtil.getAmount(companyId)) {
				validAgentBalance = true;
			} else {
				throw new InSufficientAgentBalanceException("AgentBalance is insufficient :: " + userAgentScreenName + " :: " + agentBalance.getAmount());
			}
		} else {
			throw new BlockAgentBalanceException("AgentBalance Block :: " + userAgentScreenName);
		}
		return validAgentBalance;
	}

	@Override
	public List<CP> setAutoRenewalCustomerPlan(String accountNo, String customerScreenName, long companyId, boolean autoRenewal) {
		LOGGER.info("CustomerPlanServiceImpl::setAutoRenewalCustomerPlan");
		String content = getAutoRenealContent(autoRenewal);
		LOGGER.info("===== CUSTOMER " + customerScreenName.toUpperCase() + " ACCOUNT " + accountNo.toUpperCase() + " PLAN " + content.toUpperCase() + " START =====");
		List<CP> _cps = new ArrayList<CP>();
		List<CP> cps = cpLocalService.getCPs(accountNo, customerScreenName, companyId);
		cps.parallelStream().forEach(cp -> {
			cp.setAutoRenew(autoRenewal);
			cp = cpLocalService.updateCP(cp);
			_cps.add(cp);
		});
		LOGGER.info("===== CUSTOMER " + customerScreenName.toUpperCase() + " ACCOUNT " + accountNo.toUpperCase() + " PLAN " + content.toUpperCase() + " END =====");
		return _cps;
	}

	@Override
	public List<CP> setAutoRenewalAgentCustomerPlan(String agentScreenName, long companyId, boolean autoRenewal) {
		LOGGER.info("CustomerPlanServiceImpl::setAutoRenewalAgentCustomerPlan");
		String content = getAutoRenealContent(autoRenewal);
		List<CP> _cps = new ArrayList<CP>();
		LOGGER.info("===== AGENT " + agentScreenName.toUpperCase() + " CUSTOMER PLAN " + content.toUpperCase() + " START =====");
		try {
			List<Customer> customers = customerLocalService.getCustomerByLogInAgent(agentScreenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
			customers.parallelStream().forEach(customer -> {
				List<CP> cp = setAutoRenewalCustomerPlan(customer.getAccountNo(), customer.getScreenName(), companyId, autoRenewal);
				_cps.addAll(cp);
			});
		} catch (NoSuchAgentException e) {
			LOGGER.error("NoSuchAgentException :: " + e.toString());
		}
		LOGGER.info("===== AGENT " + agentScreenName.toUpperCase() + " CUSTOMER PLAN " + content.toUpperCase() + " END =====");
		return _cps;
	}

	private String getAutoRenealContent(boolean autoRenewal) {
		return autoRenewal ? "ACTIVATE" : "DEACTIVATE";
	}

	@Override
	public List<CP> getRenewalCustomerPlan(String customerAccountNo, String customerScreenName, long companyId) throws NoSuchCustomerException {
		LOGGER.info("CustomerPlanServiceImpl::getRenewalCustomerPlan");
		Customer customer = customerLocalService.getCustomer(customerAccountNo, customerScreenName, companyId);
		return getRenewalCustomerPlan(customer, companyId);
	}

	@Override
	public List<CP> getRenewalCustomerPlan(Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getRenewalCustomerPlan");
		List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, true, companyId);
		List<CP> visibleRenewalCPs = cps.stream().filter(cp -> visibleRenewalCustomerPlan(cp.getEndDate(), companyId)).collect(Collectors.toList());
		return visibleRenewalCPs;
	}

	@Override
	public boolean visibleRenewalCustomerPlan(Date endDate, long companyId) {
		ZoneId zoneId = ZoneId.systemDefault();
		LocalDateTime start = LocalDateTime.now(zoneId);
		LocalDateTime end = Instant.ofEpochMilli(endDate.getTime()).atZone(zoneId).toLocalDateTime();
		long day = ChronoUnit.DAYS.between(start, end);
		long visibleDay = GetterUtil.getLong(JioPropsUtil.get(ConfigConstant.PLAN_AUTO_RENEW_VISIBLE, companyId));
		return day < visibleDay;
	}

	/**
	 * 
	 * @param status
	 * @param message
	 * @return
	 */
	private Map<String, String> getMap(String status, String message) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("STATUS", status);
		map.put("MESSAGE", message);
		if (status.equalsIgnoreCase("FAIL")) {
			LOGGER.error(message);
		}
		return map;
	}

	/**
	 * 
	 * @param plan
	 * @return
	 */
	private int getPlanCount(Plan plan) {
		return getChannelCount(plan.getSdCount(), plan.getHdCount());
	}

	/**
	 * 
	 * @param plans
	 * @return
	 */
	private int getPlanCount(List<Plan> plans) {
		int count = plans.stream().mapToInt(plan -> {
			return getChannelCount(plan.getSdCount(), plan.getHdCount());
		}).sum();
		return count;
	}

	/**
	 * 
	 * @param cps
	 * @return
	 */
	public int getCPCount(Customer customer, long companyId) {
		List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, true, companyId);
		return getCPCount(cps);
	}

	/**
	 * 
	 * @param cps
	 * @return
	 */
	public int getCPCount(List<CP> cps) {
		int count = cps.stream().mapToInt(cp -> {
			return getChannelCount(cp.getSdCount(), cp.getHdCount());
		}).sum();
		return count;
	}

	private List<String> addNCFCodes(Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::addNCFCodes");
		List<String> active = getActivedNCFCodes(customer, companyId);
		List<String> require = getRequiredNCFCodes(customer, companyId);
		return require.stream().filter(code -> !active.contains(code)).collect(Collectors.toList());
	}

	private List<String> removeNCFCodes(Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::removeNCFCodes");
		List<String> active = getActivedNCFCodes(customer, companyId);
		List<String> require = getRequiredNCFCodes(customer, companyId);
		return active.stream().filter(code -> !require.contains(code)).collect(Collectors.toList());
	}

	private List<String> getActivedNCFCodes(Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getActivedNCFCodes");
		List<CP> cps = cpLocalService.getCPs(customer.getAccountNo(), customer.getScreenName(), true, false, companyId);
		return cps.stream().map(cp -> cp.getPlanCode()).collect(Collectors.toList());
	}

	private List<String> getRequiredNCFCodes(Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getRequiredNCFCodes");
		int count = getCPCount(customer, companyId);
		String ncfJson = JioPropsUtil.get(ConfigConstant.CHANNEL_NCF_CODE, companyId);
		List<String> ncfCodes = new ArrayList<String>();
		try {
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray(ncfJson);
			ncfCodes = IntStream.range(0, jsonArray.length()).mapToObj(i -> jsonArray.getJSONObject(i)).filter(jsonObject -> (jsonObject.getInt("min") < count)).map(jsonObject -> jsonObject.getString("code")).collect(Collectors.toList());
		} catch (JSONException e) {
			LOGGER.warn("JSONException : " + e.toString());
		}
		return ncfCodes;
	}

	/**
	 * 
	 * @param sdCount
	 * @param hdCount
	 * @return
	 */
	private Integer getChannelCount(int sdCount, int hdCount) {
		return sdCount + (2 * hdCount);
	}

	/**
	 * 
	 * @param channelPoId
	 * @param customer
	 * @param companyId
	 * @return
	 */
	public Optional<CP> getChannelIfExistInCP(String channelPoId, Customer customer, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getChannelIfExistInCP");
		return getChannelIfExistInCP(channelPoId, customer.getAccountNo(), customer.getScreenName(), companyId);
	}

	/**
	 * 
	 * @param channelPoId
	 * @param accountNo
	 * @param screenName
	 * @param companyId
	 * @return
	 */
	private Optional<CP> getChannelIfExistInCP(String channelPoId, String accountNo, String screenName, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getChannelIfExistInCP");
		List<CP> cps = cpLocalService.getCPs(accountNo, screenName, true, companyId);
		return getChannelIfExistInCP(channelPoId, cps, companyId);
	}

	/**
	 * 
	 * @param channelPoId
	 * @param cps
	 * @param companyId
	 * @return
	 */
	private Optional<CP> getChannelIfExistInCP(String channelPoId, List<CP> cps, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getChannelIfExistInCP");
		Predicate<CP> isExistInCP = cp -> channelPoId.equalsIgnoreCase(cp.getPlanPoId());
		Predicate<CP> isExistInPackage = cp -> isChannelExistInPackage(channelPoId, cp.getPlanPoId(), companyId);
		return cps.stream().filter(isExistInCP.or(isExistInPackage)).findAny();
	}

	/**
	 * 
	 * @param channelPoId
	 * @param plans
	 * @param companyId
	 * @return
	 */
	private Optional<Plan> getChannelIfExistInPlan(String channelPoId, List<Plan> plans, long companyId) {
		LOGGER.info("CustomerPlanServiceImpl::getChannelIfExistInPlan");
		Predicate<Plan> isExistInPlan = plan -> channelPoId.equalsIgnoreCase(plan.getPlanPoId());
		Predicate<Plan> isExistInPackage = plan -> isChannelExistInPackage(channelPoId, plan.getPlanPoId(), companyId);
		return plans.stream().filter(isExistInPlan.or(isExistInPackage)).findAny();
	}

	/**
	 * 
	 * @param channelPoId
	 * @param planPoId
	 * @param companyId
	 * @return
	 */
	private boolean isChannelExistInPackage(String channelPoId, String planPoId, long companyId) {
		boolean exist = false;
		try {
			planChannelLocalService.getPlanChannel(planPoId, channelPoId, companyId);
			exist = true;
		} catch (NoSuchPlanChannelException e) {
			exist = false;
		}
		return exist;
	}

	@Reference
	private PlanCancelService planCancelService;

	@Reference
	private AgentLocalService agentLocalService;

	@Reference
	private CustomerLocalService customerLocalService;

	@Reference
	private AddressLocalService addressLocalService;

	@Reference
	private ServiceTypeLocalService serviceTypeLocalService;

	@Reference
	private PlanCategoryLocalService planCategoryLocalService;

	@Reference
	private PlanCategoryGroupLocalService planCategoryGroupLocalService;

	@Reference
	private PlanLocalService planLocalService;

	@Reference
	private CPLocalService cpLocalService;

	@Reference
	private AgentBalanceLocalService agentBalanceLocalService;

	@Reference
	private CustomerPlanUtil customerPlanUtil;

	@Reference
	private PlanAddService planAddService;

	@Reference
	private CustomerInfoService customerInfoService;

	@Reference
	private UserLocalService userLocalService;

	@Reference
	private LanguagePropertyLocalService languagePropertyLocalService;

	@Reference
	private ChannelLocalService channelLocalService;

	@Reference
	private PlanChannelLocalService planChannelLocalService;

	@Reference
	private KeyPropertyLocalService keyPropertyLocalService;

	@Reference
	private CPTransactionLocalService cpTransactionLocalService;

	private static final Log LOGGER = LogFactoryUtil.getLog(CustomerPlanServiceImpl.class);

}
