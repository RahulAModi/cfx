package com.jio.customer.plan.constant;

public class StatusConstant {

	public static final String SUCCESS = "0";

	public static final String ERROR = "1";

	public static final String PRODUCT_ACTIVE = "1";

	public static final String PRODUCT_SUSPEND = "2";

	public static final String PRODUCT_INACTIVE = "3";

	public static boolean getProductStatus(String label) {
		if (label.equals(PRODUCT_ACTIVE)) {
			return true;
		} else if (label.equals(PRODUCT_SUSPEND)) {
			return false;
		} else if (label.equals(PRODUCT_INACTIVE)) {
			return false;
		}
		return true;
	}
}
