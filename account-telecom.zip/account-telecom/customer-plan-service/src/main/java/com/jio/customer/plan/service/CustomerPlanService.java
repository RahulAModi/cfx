package com.jio.customer.plan.service;

import com.jio.account.exception.NoSuchAddressException;
import com.jio.account.exception.NoSuchAgentException;
import com.jio.account.exception.NoSuchCustomerException;
import com.jio.account.model.Address;
import com.jio.account.model.Agent;
import com.jio.account.model.Customer;
import com.jio.account.telecom.exception.NoSuchCPException;
import com.jio.account.telecom.model.CP;
import com.jio.account.util.AccountUtil;
import com.jio.balance.exception.BlockAgentBalanceException;
import com.jio.balance.exception.InSufficientAgentBalanceException;
import com.jio.balance.exception.NoSuchAgentBalanceException;
import com.jio.brm.customer.info.api.CustomerInfoResponse;
import com.jio.customer.plan.util.CustomerPlanUtil;
import com.jio.master.telecom.exception.NoSuchPlanException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author Vishal7.Shah
 */
public interface CustomerPlanService {

	/**
	 * 
	 * @param customerInfoResponse
	 * @param customer
	 * @param address
	 * @param agent
	 * @param companyId
	 * @param groupId
	 * @param userAgent
	 * @return
	 * @throws NoSuchAgentException
	 */
	Map<String, String> getOrCreateCustomerPlans(CustomerInfoResponse customerInfoResponse, Customer customer, Address address, Agent agent, long companyId, long groupId, User userAgent) throws NoSuchAgentException;

	/**
	 * 
	 * @param planIds
	 * @param accountNo
	 * @param txRefNo
	 * @param userAgent
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchCustomerException
	 */
	Map<String, String> validateCustomerPlans(String[] planIds, String accountNo, String txRefNo, User userAgent, long companyId, long groupId) throws NoSuchCustomerException;

	/**
	 * 
	 * @param planCode  - If null then planName required
	 * @param planName  - If null then planCode required
	 * @param autoRenew -
	 * @param accountNo - Customer Account No
	 * @param receiptNo - Generate receipt number which invoice generate
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param userAgent - User object use for Agent Balance Validate
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 * @throws NoSuchPlanException
	 */
	Map<String, String> addCustomerPlan(String planCode, String planName, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException;

	/**
	 * 
	 * @param planIds   - Plan Ids from MT_Plan
	 * @param autoRenew
	 * @param accountNo - Customer Account No
	 * @param receiptNo - Generate receipt number which invoice generate {@link CustomerPlanUtil#getReceiptNo()}
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param userAgent - User object use for Agent Balance Validate
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 */
	Map<String, String> addCustomerPlans(String[] planIds, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException;

	/**
	 * 
	 * @param planCode  - If null then planName required
	 * @param planName  - If null then planCode required
	 * @param autoRenew
	 * @param accountNo - Customer Account No
	 * @param receiptNo - Generate receipt number which invoice generate {@link CustomerPlanUtil#getReceiptNo()}
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param userAgent
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 * @throws NoSuchPlanException
	 * @throws NoSuchCPException
	 */
	Map<String, String> renewCustomerPlan(String planCode, String planName, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException, NoSuchCPException;

	/**
	 * 
	 * @param autoRenew
	 * @param vcId      - Customer VCID
	 * @param receiptNo - Generate receipt number which invoice generate {@link CustomerPlanUtil#getReceiptNo()}
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 * @throws PortalException
	 */
	Map<String, String> renewCustomerPlans(boolean autoRenew, String vcId, String receiptNo, String txRefNo, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, PortalException;

	/**
	 * 
	 * @param cpIds     - Customer Plan Ids from ATM_CP
	 * @param autoRenew
	 * @param accountNo - Customer Account No
	 * @param receiptNo - Generate receipt number which invoice generate {@link CustomerPlanUtil#getReceiptNo()}
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param userAgent - User object use for Agent Balance Validate
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 */
	Map<String, String> renewCustomerPlans(String[] cpIds, boolean autoRenew, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException;

	/**
	 * 
	 * @param planCode  - If null then planName required
	 * @param planName  - If null then planCode required
	 * @param reason    - description of cancellation
	 * @param accountNo - Customer Account No
	 * @param receiptNo - Generate receipt number which invoice generate {@link CustomerPlanUtil#getReceiptNo()}
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param userAgent
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 * @throws NoSuchPlanException
	 * @throws NoSuchCPException
	 */
	Map<String, String> cancelCustomerPlan(String planCode, String planName, String reason, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException, NoSuchCPException;

	/**
	 * 
	 * @param cpIds     - Customer Plan Ids from ATM_CP
	 * @param reason    - description of cancellation
	 * @param accountNo - Customer Account No
	 * @param receiptNo - Generate receipt number which invoice generate {@link CustomerPlanUtil#getReceiptNo()}
	 * @param txRefNo   - Tracking Reference Number {@link AccountUtil#getTxRefNo}
	 * @param userAgent - User object use for Agent Balance Validate
	 * @param companyId
	 * @param groupId
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 * @throws NoSuchCustomerException
	 * @throws NoSuchAddressException
	 * @throws NoSuchPlanException
	 */
	Map<String, String> cancelCustomerPlans(String[] cpIds, String reason, String accountNo, String receiptNo, String txRefNo, User userAgent, long companyId, long groupId)
			throws NoSuchAgentException, NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException, NoSuchCustomerException, NoSuchAddressException, NoSuchPlanException;

	/**
	 * 
	 * @param agent
	 * @param customer
	 * @return
	 */
	boolean isAutoRenew(Agent agent, Customer customer);

	/**
	 * 
	 * @param agent
	 * @param customer
	 * @param autoRenewal
	 * @return
	 */
	boolean isAutoRenew(Agent agent, Customer customer, boolean autoRenewal);

	/**
	 * 
	 * @param companyId
	 * @param agentScreenName   - Agent ScreenName
	 * @param customerAccountNo - Customer Account No
	 * @return
	 * @throws NoSuchAgentException
	 * @throws NoSuchCustomerException
	 */
	boolean isAutoRenew(long companyId, String agentScreenName, String customerAccountNo) throws NoSuchAgentException, NoSuchCustomerException;

	/**
	 * 
	 * @param endTime
	 * @param customer
	 * @param companyId
	 * @return
	 */
	Date getEndTime(Date endTime, Customer customer, long companyId);

	/**
	 * 
	 * @param customer
	 * @param companyId
	 * @return
	 */
	CP getMandatoryCP(Customer customer, long companyId);

	/**
	 * 
	 * @param cps
	 * @param planId
	 * @param groupId
	 * @param companyId
	 * @param customer
	 * @param userAgent
	 * @param address
	 * @param successPlans
	 * @param errorPlans
	 * @param autoRenew
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	CP saveOrUpdateCustomerPlan(List<CP> cps, long planId, long groupId, long companyId, Customer customer, User userAgent, Address address, List<String> successPlans, List<String> errorPlans, boolean autoRenew, Date startTime, Date endTime);

	/**
	 * 
	 * @param cps
	 * @param planCode
	 * @param productCode
	 * @param groupId
	 * @param companyId
	 * @param customer
	 * @param userAgent
	 * @param address
	 * @param activePlan
	 * @param successPlans
	 * @param errorPlans
	 * @param autoRenew
	 * @param packageId
	 * @param purchasedProductPoId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	CP saveOrUpdateCustomerPlan(List<CP> cps, String planCode, String productCode, long groupId, long companyId, Customer customer, User userAgent, Address address, boolean activePlan, List<String> successPlans, List<String> errorPlans, boolean autoRenew, String packageId,
			String purchasedProductPoId, Date startTime, Date endTime);

	/**
	 * 
	 * @param reActive
	 * @param cps
	 * @param customer
	 * @param userAgent
	 * @param address
	 * @param receiptNo
	 * @param successPlans
	 * @param errorPlans
	 * @param finalPrice
	 * @param autoRenew
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	List<CP> activateCustomerPlans(boolean reActive, List<CP> cps, Customer customer, User userAgent, Address address, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime);

	/**
	 * 
	 * @param cps
	 * @param receiptNo
	 * @param successPlans
	 * @param errorPlans
	 * @param finalPrice
	 * @param autoRenew
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	List<CP> autoReActivateCustomerPlan(List<CP> cps, String receiptNo, List<String> successPlans, List<String> errorPlans, List<Double> pricePlans, boolean autoRenew, Date startTime, Date endTime);

	/**
	 * 
	 * @param cp
	 * @return
	 */
	double getLcoPrice(CP cp);

	/**
	 * 
	 * @param userAgentScreenName
	 * @param companyId
	 * @return
	 * @throws NoSuchAgentBalanceException
	 * @throws BlockAgentBalanceException
	 * @throws InSufficientAgentBalanceException
	 */
	boolean isAgentBalanceBlockOrInsufficentAmount(String userAgentScreenName, long companyId) throws NoSuchAgentBalanceException, BlockAgentBalanceException, InSufficientAgentBalanceException;

	/**
	 * 
	 * @param accountNo
	 * @param customerScreenName
	 * @param companyId
	 * @param autoRenewal
	 * @return
	 */
	List<CP> setAutoRenewalCustomerPlan(String accountNo, String customerScreenName, long companyId, boolean autoRenewal);

	/**
	 * 
	 * @param agentScreenName
	 * @param companyId
	 * @param autoRenewal
	 * @return
	 */
	List<CP> setAutoRenewalAgentCustomerPlan(String agentScreenName, long companyId, boolean autoRenewal);

	/**
	 * 
	 * @param customer
	 * @param companyId
	 * @return
	 * @throws NoSuchCustomerException
	 */
	List<CP> getRenewalCustomerPlan(Customer customer, long companyId);

	/**
	 * 
	 * @param endDate
	 * @param companyId
	 * @return
	 */
	boolean visibleRenewalCustomerPlan(Date endDate, long companyId);

	/**
	 * 
	 * @param customerAccountNo
	 * @param customerScreenName
	 * @param companyId
	 * @return
	 * @throws NoSuchCustomerException
	 */
	List<CP> getRenewalCustomerPlan(String customerAccountNo, String customerScreenName, long companyId) throws NoSuchCustomerException;

	/**
	 * 
	 * @param channelPoId
	 * @param customer
	 * @param companyId
	 * @return
	 */
	Optional<CP> getChannelIfExistInCP(String channelPoId, Customer customer, long companyId);

	/**
	 * 
	 * @param customer
	 * @param companyId
	 * @return
	 */
	int getCPCount(Customer customer, long companyId);

	/**
	 * 
	 * @param cps
	 * @return
	 */
	int getCPCount(List<CP> cps);

}