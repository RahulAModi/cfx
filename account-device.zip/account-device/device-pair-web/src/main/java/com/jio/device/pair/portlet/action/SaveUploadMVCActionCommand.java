/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.device.pair.portlet.action;

import com.jio.account.device.exception.NoSuchDeviceException;
import com.jio.account.device.model.Device;
import com.jio.account.device.service.DeviceLocalService;
import com.jio.device.pair.constants.DevicePairPortletKeys;
import com.jio.device.pair.constants.MVCCommandNames;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + DevicePairPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD }, service = MVCActionCommand.class)
public class SaveUploadMVCActionCommand extends BaseMVCActionCommand {

	private final Log LOGGER = LogFactoryUtil.getLog(SaveUploadMVCActionCommand.class);

	@Reference
	private CounterLocalService counterLocalService;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		final long userId = PortalUtil.getUserId(actionRequest);
		final long groupId = PortalUtil.getScopeGroupId(actionRequest);
		final long companyId = PortalUtil.getCompanyId(actionRequest);

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
		File file = request.getFile("file");
		String fileName = request.getFileName("file").trim();

		int message = 0;
		if (fileName != null && !fileName.isEmpty() && file != null) {
			if (!isCSVFile(file)) {
				message = 0;
			} else {
				final List<CSVRecord> csvRecords = getCSVRecords(file, CharPool.COMMA);
				if (Validator.isNotNull(csvRecords) && csvRecords.size() > 0) {
					message = 1;

					Runnable runnable = new Runnable() {
						@Override
						public void run() {
							addDevice(userId, groupId, companyId, csvRecords);
						}
					};

					Thread thread = new Thread(runnable);
					thread.start();

				} else {
					message = 2;
				}
			}
		} else {
			message = 2;
		}
		if (message == 1) {
			SessionMessages.add(request, "csv-start-importing-check-logs");
		} else if (message == 2) {
			SessionErrors.add(request, "csv-importing-error");
		} else if (message == 0) {
			SessionErrors.add(request, "invalid-file-extention");
		}
	}

	private List<Device> addDevice(long userId, long groupId, long companyId, List<CSVRecord> csvRecords) {
		List<Device> devices = new ArrayList<Device>();
		for (CSVRecord csvRecord : csvRecords) {
			Device device;
			try {
				device = addDevice(userId, groupId, companyId, csvRecord);
				if (Validator.isNotNull(device)) {
					devices.add(device);
				}
			} catch (Exception e) {
				LOGGER.error("Exception :: " + e.toString());
			}

		}
		return devices;
	}

	private Device addDevice(long userId, long groupId, long companyId, CSVRecord csvRecord) {
		String vcId = getValue(csvRecord, "VCID");
		String stbNo = getValue(csvRecord, "STBNO");
		String status = getValue(csvRecord, "STATUS");
		Device device = null;
		try {
			device = deviceLocalService.getDeviceByVcId(vcId, companyId);
		} catch (NoSuchDeviceException e) {
			device = deviceLocalService.createDevice(counterLocalService.increment(Device.class.getName()));
			device.setVcId(vcId);
		}

		device.setStbNo(stbNo);
		device.setStatus(getStatus(status));
		device.setCompanyId(companyId);
		device.setGroupId(groupId);
		device.setUserId(userId);

		if (device.isNew()) {
			device = deviceLocalService.addDevice(device);
		} else {
			device = deviceLocalService.updateDevice(device);
		}

		return device;
	}

	private int getStatus(String status) {
		if (status.equalsIgnoreCase("Free")) {
			return 1;
		} else if (status.equalsIgnoreCase("Used")) {
			return 2;
		} else if (status.equalsIgnoreCase("Faulty")) {
			return 3;
		} else if (status.equalsIgnoreCase("Repairing")) {
			return 4;
		} else if (status.equalsIgnoreCase("Blacklisted")) {
			return 7;
		} else if (status.equalsIgnoreCase("Repaired")) {
			return 9;
		} else {
			return 0;
		}

	}

	private String getValue(CSVRecord csvRecord, String key) {
		try {
			if (csvRecord.isSet(key)) {
				return csvRecord.get(key);
			}
		} catch (IllegalStateException | IllegalArgumentException e) {
		}
		return StringPool.BLANK;
	}

	private List<CSVRecord> getCSVRecords(File file, char delimiter) {
		List<CSVRecord> csvRecords = new ArrayList<>();
		CSVParser csvFileParser = null;
		try {
			CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(delimiter);
			FileReader fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			csvRecords = csvFileParser.getRecords();
		} catch (FileNotFoundException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} catch (IOException e) {
			LOGGER.debug("Issue processing File" + e.toString());
		} finally {
			if (null != csvFileParser) {
				try {
					csvFileParser.close();
				} catch (IOException e) {
					LOGGER.error("IOException : " + e.toString());
				}
			}
		}

		return csvRecords;
	}

	public final String CSV = ".csv";

	public boolean isCSVFile(File file) {
		if (CSV.equals(getFileExtension(file))) {
			return true;
		} else {
			return false;
		}
	}

	public String getFileExtension(File file) {
		String name = file.getName();
		try {
			return name.substring(name.lastIndexOf("."));
		} catch (Exception e) {
			return StringPool.BLANK;
		}
	}

	@Reference
	DeviceLocalService deviceLocalService;

}