package com.jio.device.pair.constants;

/**
 * @author Vishal7.Shah
 */
public class DevicePairPortletKeys {

	public static final String PORTLET_NAME = "com_jio_device_pair_portlet_DevicePairPortlet";

}