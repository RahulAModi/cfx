package com.jio.device.pair.constants;

public class MVCCommandNames {

	public static final String SEARCH = "/device/search";

	public static final String UPLOAD = "/device/upload";

	public static final String SAVE_UPLOAD = "/device/save_upload";

	public static final String DOWNLOAD = "/device/download";

	public static final String VIEW = "/device/view";

}
