/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.device.pair.portlet.action;

import com.jio.account.device.model.Device;
import com.jio.account.device.service.DeviceLocalService;
import com.jio.device.pair.constants.DevicePairPortletKeys;
import com.jio.device.pair.constants.MVCCommandNames;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + DevicePairPortletKeys.PORTLET_NAME, "mvc.command.name=/", "mvc.command.name=" + MVCCommandNames.VIEW, "mvc.command.name=" + MVCCommandNames.SAVE_UPLOAD, "mvc.command.name=" + MVCCommandNames.SEARCH }, service = MVCRenderCommand.class)
public class ViewMVCRenderCommand implements MVCRenderCommand {

	@Reference
	private DeviceLocalService deviceLocalService;

	private final Log LOGGER = LogFactoryUtil.getLog(ViewMVCRenderCommand.class);

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long companyId = PortalUtil.getCompanyId(renderRequest);

		// Search Container Logic

		PortletURL iteratorURL = renderResponse.createRenderURL();
		iteratorURL = PortletURLUtil.getCurrent(renderRequest, renderResponse);
		try {
			iteratorURL.setWindowState(WindowState.NORMAL);
		} catch (WindowStateException e) {
			LOGGER.error(e.toString());
		}
		SearchContainer<Device> searchContainer = new SearchContainer<Device>(renderRequest, iteratorURL, null, "there-are-no-devices");

		List<Device> devices = null;
		int broadCastersCount = GetterUtil.DEFAULT_INTEGER;
		try {
			devices = deviceLocalService.getDevices(companyId, searchContainer.getStart(), searchContainer.getEnd());
			broadCastersCount = deviceLocalService.getDevicesCount(companyId);
		} catch (SystemException e) {
			devices = new ArrayList<>();
			LOGGER.error("SystemException :: " + e.toString());
		}

		searchContainer.setDeltaConfigurable(true);
		searchContainer.setTotal(broadCastersCount);
		searchContainer.setResults(devices);
		renderRequest.setAttribute("deviceSearchContainer", searchContainer);

		return "/device/view.jsp";
	}

}