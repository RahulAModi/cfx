/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jio.device.pair.portlet.action;

import com.jio.account.device.model.Device;
import com.jio.account.device.service.DeviceLocalService;
import com.jio.device.pair.constants.DevicePairPortletKeys;
import com.jio.device.pair.constants.MVCCommandNames;
import com.liferay.petra.string.CharPool;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.PortalUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + DevicePairPortletKeys.PORTLET_NAME, "mvc.command.name=" + MVCCommandNames.DOWNLOAD }, service = MVCResourceCommand.class)
public class DownloadMVCResourceCommand implements MVCResourceCommand {

	private static final Log LOGGER = LogFactoryUtil.getLog(DownloadMVCResourceCommand.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws PortletException {
		long companyId = PortalUtil.getCompanyId(resourceRequest);
		boolean resource = true;
		try {

			StringBundler sb = new StringBundler();
			for (String columnName : CSV_HEADER) {
				sb.append(columnName);
				sb.append(CharPool.COMMA);
			}
			sb.setIndex(sb.index() - 1);
			sb.append(CharPool.NEW_LINE);

			List<Device> devices = deviceLocalService.getDevices(companyId);
			for (Device device : devices) {
				sb.append(device.getVcId());
				sb.append(CharPool.COMMA);
				sb.append(device.getStbNo());
				sb.append(CharPool.COMMA);
				sb.append(device.getStatus());
				sb.append(CharPool.COMMA);

				sb.setIndex(sb.index() - 1);
				sb.append(CharPool.NEW_LINE);

			}

			String fileName = "devices.csv";
			byte[] bytes = sb.toString().getBytes();
			String contentType = ContentTypes.APPLICATION_TEXT;
			try {
				PortletResponseUtil.sendFile(resourceRequest, resourceResponse, fileName, bytes, contentType);
			} catch (Exception e) {
				LOGGER.error("Exception :: " + e.toString());
				resource = false;
			}

			resource = false;
		} catch (

		SystemException e) {
			LOGGER.error("SystemException :: " + e.toString());
			resource = false;
		}

		return resource;
	}

	private static final String[] CSV_HEADER = new String[] { "VDID", "STBNO", "STATUS" };

	@Reference
	private DeviceLocalService deviceLocalService;

}