create index IX_19BF53D0 on AD_Device (companyId);
create index IX_656A8A4E on AD_Device (stbNo[$COLUMN_LENGTH:75$], companyId);
create index IX_BFD199B4 on AD_Device (vcId[$COLUMN_LENGTH:75$], companyId);
create index IX_5CBC9BEA on AD_Device (vcId[$COLUMN_LENGTH:75$], stbNo[$COLUMN_LENGTH:75$], companyId);