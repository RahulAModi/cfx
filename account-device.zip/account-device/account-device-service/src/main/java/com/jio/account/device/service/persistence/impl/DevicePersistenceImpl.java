/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.device.service.persistence.impl;

import com.jio.account.device.exception.NoSuchDeviceException;
import com.jio.account.device.model.Device;
import com.jio.account.device.model.impl.DeviceImpl;
import com.jio.account.device.model.impl.DeviceModelImpl;
import com.jio.account.device.service.persistence.DevicePersistence;
import com.jio.account.device.service.persistence.impl.constants.ADPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the device service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = DevicePersistence.class)
@ProviderType
public class DevicePersistenceImpl
	extends BasePersistenceImpl<Device> implements DevicePersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>DeviceUtil</code> to access the device persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		DeviceImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathFetchByVCId_StbNo;
	private FinderPath _finderPathCountByVCId_StbNo;

	/**
	 * Returns the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	@Override
	public Device findByVCId_StbNo(String vcId, String stbNo, long companyId)
		throws NoSuchDeviceException {

		Device device = fetchByVCId_StbNo(vcId, stbNo, companyId);

		if (device == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("vcId=");
			msg.append(vcId);

			msg.append(", stbNo=");
			msg.append(stbNo);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDeviceException(msg.toString());
		}

		return device;
	}

	/**
	 * Returns the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByVCId_StbNo(String vcId, String stbNo, long companyId) {
		return fetchByVCId_StbNo(vcId, stbNo, companyId, true);
	}

	/**
	 * Returns the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByVCId_StbNo(
		String vcId, String stbNo, long companyId, boolean retrieveFromCache) {

		vcId = Objects.toString(vcId, "");
		stbNo = Objects.toString(stbNo, "");

		Object[] finderArgs = new Object[] {vcId, stbNo, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByVCId_StbNo, finderArgs, this);
		}

		if (result instanceof Device) {
			Device device = (Device)result;

			if (!Objects.equals(vcId, device.getVcId()) ||
				!Objects.equals(stbNo, device.getStbNo()) ||
				(companyId != device.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_DEVICE_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_STBNO_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_STBNO_VCID_2);
			}

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_STBNO_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_VCID_STBNO_STBNO_2);
			}

			query.append(_FINDER_COLUMN_VCID_STBNO_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				List<Device> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByVCId_StbNo, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DevicePersistenceImpl.fetchByVCId_StbNo(String, String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Device device = list.get(0);

					result = device;

					cacheResult(device);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathFetchByVCId_StbNo, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Device)result;
		}
	}

	/**
	 * Removes the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the device that was removed
	 */
	@Override
	public Device removeByVCId_StbNo(String vcId, String stbNo, long companyId)
		throws NoSuchDeviceException {

		Device device = findByVCId_StbNo(vcId, stbNo, companyId);

		return remove(device);
	}

	/**
	 * Returns the number of devices where vcId = &#63; and stbNo = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	@Override
	public int countByVCId_StbNo(String vcId, String stbNo, long companyId) {
		vcId = Objects.toString(vcId, "");
		stbNo = Objects.toString(stbNo, "");

		FinderPath finderPath = _finderPathCountByVCId_StbNo;

		Object[] finderArgs = new Object[] {vcId, stbNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_DEVICE_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_STBNO_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_STBNO_VCID_2);
			}

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_STBNO_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_VCID_STBNO_STBNO_2);
			}

			query.append(_FINDER_COLUMN_VCID_STBNO_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VCID_STBNO_VCID_2 =
		"device.vcId = ? AND ";

	private static final String _FINDER_COLUMN_VCID_STBNO_VCID_3 =
		"(device.vcId IS NULL OR device.vcId = '') AND ";

	private static final String _FINDER_COLUMN_VCID_STBNO_STBNO_2 =
		"device.stbNo = ? AND ";

	private static final String _FINDER_COLUMN_VCID_STBNO_STBNO_3 =
		"(device.stbNo IS NULL OR device.stbNo = '') AND ";

	private static final String _FINDER_COLUMN_VCID_STBNO_COMPANYID_2 =
		"device.companyId = ?";

	private FinderPath _finderPathFetchByVCId;
	private FinderPath _finderPathCountByVCId;

	/**
	 * Returns the device where vcId = &#63; and companyId = &#63; or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	@Override
	public Device findByVCId(String vcId, long companyId)
		throws NoSuchDeviceException {

		Device device = fetchByVCId(vcId, companyId);

		if (device == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("vcId=");
			msg.append(vcId);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDeviceException(msg.toString());
		}

		return device;
	}

	/**
	 * Returns the device where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByVCId(String vcId, long companyId) {
		return fetchByVCId(vcId, companyId, true);
	}

	/**
	 * Returns the device where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByVCId(
		String vcId, long companyId, boolean retrieveFromCache) {

		vcId = Objects.toString(vcId, "");

		Object[] finderArgs = new Object[] {vcId, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByVCId, finderArgs, this);
		}

		if (result instanceof Device) {
			Device device = (Device)result;

			if (!Objects.equals(vcId, device.getVcId()) ||
				(companyId != device.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_DEVICE_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_VCID_2);
			}

			query.append(_FINDER_COLUMN_VCID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				List<Device> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByVCId, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DevicePersistenceImpl.fetchByVCId(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Device device = list.get(0);

					result = device;

					cacheResult(device);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByVCId, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Device)result;
		}
	}

	/**
	 * Removes the device where vcId = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the device that was removed
	 */
	@Override
	public Device removeByVCId(String vcId, long companyId)
		throws NoSuchDeviceException {

		Device device = findByVCId(vcId, companyId);

		return remove(device);
	}

	/**
	 * Returns the number of devices where vcId = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	@Override
	public int countByVCId(String vcId, long companyId) {
		vcId = Objects.toString(vcId, "");

		FinderPath finderPath = _finderPathCountByVCId;

		Object[] finderArgs = new Object[] {vcId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DEVICE_WHERE);

			boolean bindVcId = false;

			if (vcId.isEmpty()) {
				query.append(_FINDER_COLUMN_VCID_VCID_3);
			}
			else {
				bindVcId = true;

				query.append(_FINDER_COLUMN_VCID_VCID_2);
			}

			query.append(_FINDER_COLUMN_VCID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVcId) {
					qPos.add(vcId);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VCID_VCID_2 =
		"device.vcId = ? AND ";

	private static final String _FINDER_COLUMN_VCID_VCID_3 =
		"(device.vcId IS NULL OR device.vcId = '') AND ";

	private static final String _FINDER_COLUMN_VCID_COMPANYID_2 =
		"device.companyId = ?";

	private FinderPath _finderPathFetchByStbNo;
	private FinderPath _finderPathCountByStbNo;

	/**
	 * Returns the device where stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	@Override
	public Device findByStbNo(String stbNo, long companyId)
		throws NoSuchDeviceException {

		Device device = fetchByStbNo(stbNo, companyId);

		if (device == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("stbNo=");
			msg.append(stbNo);

			msg.append(", companyId=");
			msg.append(companyId);

			msg.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(msg.toString());
			}

			throw new NoSuchDeviceException(msg.toString());
		}

		return device;
	}

	/**
	 * Returns the device where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByStbNo(String stbNo, long companyId) {
		return fetchByStbNo(stbNo, companyId, true);
	}

	/**
	 * Returns the device where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByStbNo(
		String stbNo, long companyId, boolean retrieveFromCache) {

		stbNo = Objects.toString(stbNo, "");

		Object[] finderArgs = new Object[] {stbNo, companyId};

		Object result = null;

		if (retrieveFromCache) {
			result = finderCache.getResult(
				_finderPathFetchByStbNo, finderArgs, this);
		}

		if (result instanceof Device) {
			Device device = (Device)result;

			if (!Objects.equals(stbNo, device.getStbNo()) ||
				(companyId != device.getCompanyId())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_DEVICE_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STBNO_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STBNO_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				List<Device> list = q.list();

				if (list.isEmpty()) {
					finderCache.putResult(
						_finderPathFetchByStbNo, finderArgs, list);
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							_log.warn(
								"DevicePersistenceImpl.fetchByStbNo(String, long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					Device device = list.get(0);

					result = device;

					cacheResult(device);
				}
			}
			catch (Exception e) {
				finderCache.removeResult(_finderPathFetchByStbNo, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Device)result;
		}
	}

	/**
	 * Removes the device where stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the device that was removed
	 */
	@Override
	public Device removeByStbNo(String stbNo, long companyId)
		throws NoSuchDeviceException {

		Device device = findByStbNo(stbNo, companyId);

		return remove(device);
	}

	/**
	 * Returns the number of devices where stbNo = &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	@Override
	public int countByStbNo(String stbNo, long companyId) {
		stbNo = Objects.toString(stbNo, "");

		FinderPath finderPath = _finderPathCountByStbNo;

		Object[] finderArgs = new Object[] {stbNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DEVICE_WHERE);

			boolean bindStbNo = false;

			if (stbNo.isEmpty()) {
				query.append(_FINDER_COLUMN_STBNO_STBNO_3);
			}
			else {
				bindStbNo = true;

				query.append(_FINDER_COLUMN_STBNO_STBNO_2);
			}

			query.append(_FINDER_COLUMN_STBNO_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindStbNo) {
					qPos.add(stbNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STBNO_STBNO_2 =
		"device.stbNo = ? AND ";

	private static final String _FINDER_COLUMN_STBNO_STBNO_3 =
		"(device.stbNo IS NULL OR device.stbNo = '') AND ";

	private static final String _FINDER_COLUMN_STBNO_COMPANYID_2 =
		"device.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the devices where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching devices
	 */
	@Override
	public List<Device> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the devices where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @return the range of matching devices
	 */
	@Override
	public List<Device> findByCompanyId(long companyId, int start, int end) {
		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the devices where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching devices
	 */
	@Override
	public List<Device> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Device> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the devices where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching devices
	 */
	@Override
	public List<Device> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<Device> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<Device> list = null;

		if (retrieveFromCache) {
			list = (List<Device>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (Device device : list) {
					if ((companyId != device.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DEVICE_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(DeviceModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<Device>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Device>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	@Override
	public Device findByCompanyId_First(
			long companyId, OrderByComparator<Device> orderByComparator)
		throws NoSuchDeviceException {

		Device device = fetchByCompanyId_First(companyId, orderByComparator);

		if (device != null) {
			return device;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchDeviceException(msg.toString());
	}

	/**
	 * Returns the first device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByCompanyId_First(
		long companyId, OrderByComparator<Device> orderByComparator) {

		List<Device> list = findByCompanyId(companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	@Override
	public Device findByCompanyId_Last(
			long companyId, OrderByComparator<Device> orderByComparator)
		throws NoSuchDeviceException {

		Device device = fetchByCompanyId_Last(companyId, orderByComparator);

		if (device != null) {
			return device;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchDeviceException(msg.toString());
	}

	/**
	 * Returns the last device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching device, or <code>null</code> if a matching device could not be found
	 */
	@Override
	public Device fetchByCompanyId_Last(
		long companyId, OrderByComparator<Device> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<Device> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the devices before and after the current device in the ordered set where companyId = &#63;.
	 *
	 * @param deviceId the primary key of the current device
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next device
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	@Override
	public Device[] findByCompanyId_PrevAndNext(
			long deviceId, long companyId,
			OrderByComparator<Device> orderByComparator)
		throws NoSuchDeviceException {

		Device device = findByPrimaryKey(deviceId);

		Session session = null;

		try {
			session = openSession();

			Device[] array = new DeviceImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, device, companyId, orderByComparator, true);

			array[1] = device;

			array[2] = getByCompanyId_PrevAndNext(
				session, device, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Device getByCompanyId_PrevAndNext(
		Session session, Device device, long companyId,
		OrderByComparator<Device> orderByComparator, boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DEVICE_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DeviceModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(device)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<Device> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the devices where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (Device device :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(device);
		}
	}

	/**
	 * Returns the number of devices where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DEVICE_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"device.companyId = ?";

	public DevicePersistenceImpl() {
		setModelClass(Device.class);

		setModelImplClass(DeviceImpl.class);
		setModelPKClass(long.class);
	}

	/**
	 * Caches the device in the entity cache if it is enabled.
	 *
	 * @param device the device
	 */
	@Override
	public void cacheResult(Device device) {
		entityCache.putResult(
			entityCacheEnabled, DeviceImpl.class, device.getPrimaryKey(),
			device);

		finderCache.putResult(
			_finderPathFetchByVCId_StbNo,
			new Object[] {
				device.getVcId(), device.getStbNo(), device.getCompanyId()
			},
			device);

		finderCache.putResult(
			_finderPathFetchByVCId,
			new Object[] {device.getVcId(), device.getCompanyId()}, device);

		finderCache.putResult(
			_finderPathFetchByStbNo,
			new Object[] {device.getStbNo(), device.getCompanyId()}, device);

		device.resetOriginalValues();
	}

	/**
	 * Caches the devices in the entity cache if it is enabled.
	 *
	 * @param devices the devices
	 */
	@Override
	public void cacheResult(List<Device> devices) {
		for (Device device : devices) {
			if (entityCache.getResult(
					entityCacheEnabled, DeviceImpl.class,
					device.getPrimaryKey()) == null) {

				cacheResult(device);
			}
			else {
				device.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all devices.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(DeviceImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the device.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Device device) {
		entityCache.removeResult(
			entityCacheEnabled, DeviceImpl.class, device.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache((DeviceModelImpl)device, true);
	}

	@Override
	public void clearCache(List<Device> devices) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Device device : devices) {
			entityCache.removeResult(
				entityCacheEnabled, DeviceImpl.class, device.getPrimaryKey());

			clearUniqueFindersCache((DeviceModelImpl)device, true);
		}
	}

	protected void cacheUniqueFindersCache(DeviceModelImpl deviceModelImpl) {
		Object[] args = new Object[] {
			deviceModelImpl.getVcId(), deviceModelImpl.getStbNo(),
			deviceModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByVCId_StbNo, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByVCId_StbNo, args, deviceModelImpl, false);

		args = new Object[] {
			deviceModelImpl.getVcId(), deviceModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByVCId, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByVCId, args, deviceModelImpl, false);

		args = new Object[] {
			deviceModelImpl.getStbNo(), deviceModelImpl.getCompanyId()
		};

		finderCache.putResult(
			_finderPathCountByStbNo, args, Long.valueOf(1), false);
		finderCache.putResult(
			_finderPathFetchByStbNo, args, deviceModelImpl, false);
	}

	protected void clearUniqueFindersCache(
		DeviceModelImpl deviceModelImpl, boolean clearCurrent) {

		if (clearCurrent) {
			Object[] args = new Object[] {
				deviceModelImpl.getVcId(), deviceModelImpl.getStbNo(),
				deviceModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByVCId_StbNo, args);
			finderCache.removeResult(_finderPathFetchByVCId_StbNo, args);
		}

		if ((deviceModelImpl.getColumnBitmask() &
			 _finderPathFetchByVCId_StbNo.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				deviceModelImpl.getOriginalVcId(),
				deviceModelImpl.getOriginalStbNo(),
				deviceModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByVCId_StbNo, args);
			finderCache.removeResult(_finderPathFetchByVCId_StbNo, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				deviceModelImpl.getVcId(), deviceModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByVCId, args);
			finderCache.removeResult(_finderPathFetchByVCId, args);
		}

		if ((deviceModelImpl.getColumnBitmask() &
			 _finderPathFetchByVCId.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				deviceModelImpl.getOriginalVcId(),
				deviceModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByVCId, args);
			finderCache.removeResult(_finderPathFetchByVCId, args);
		}

		if (clearCurrent) {
			Object[] args = new Object[] {
				deviceModelImpl.getStbNo(), deviceModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByStbNo, args);
			finderCache.removeResult(_finderPathFetchByStbNo, args);
		}

		if ((deviceModelImpl.getColumnBitmask() &
			 _finderPathFetchByStbNo.getColumnBitmask()) != 0) {

			Object[] args = new Object[] {
				deviceModelImpl.getOriginalStbNo(),
				deviceModelImpl.getOriginalCompanyId()
			};

			finderCache.removeResult(_finderPathCountByStbNo, args);
			finderCache.removeResult(_finderPathFetchByStbNo, args);
		}
	}

	/**
	 * Creates a new device with the primary key. Does not add the device to the database.
	 *
	 * @param deviceId the primary key for the new device
	 * @return the new device
	 */
	@Override
	public Device create(long deviceId) {
		Device device = new DeviceImpl();

		device.setNew(true);
		device.setPrimaryKey(deviceId);

		device.setCompanyId(companyProvider.getCompanyId());

		return device;
	}

	/**
	 * Removes the device with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param deviceId the primary key of the device
	 * @return the device that was removed
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	@Override
	public Device remove(long deviceId) throws NoSuchDeviceException {
		return remove((Serializable)deviceId);
	}

	/**
	 * Removes the device with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the device
	 * @return the device that was removed
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	@Override
	public Device remove(Serializable primaryKey) throws NoSuchDeviceException {
		Session session = null;

		try {
			session = openSession();

			Device device = (Device)session.get(DeviceImpl.class, primaryKey);

			if (device == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDeviceException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(device);
		}
		catch (NoSuchDeviceException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Device removeImpl(Device device) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(device)) {
				device = (Device)session.get(
					DeviceImpl.class, device.getPrimaryKeyObj());
			}

			if (device != null) {
				session.delete(device);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (device != null) {
			clearCache(device);
		}

		return device;
	}

	@Override
	public Device updateImpl(Device device) {
		boolean isNew = device.isNew();

		if (!(device instanceof DeviceModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(device.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(device);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in device proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom Device implementation " +
					device.getClass());
		}

		DeviceModelImpl deviceModelImpl = (DeviceModelImpl)device;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date now = new Date();

		if (isNew && (device.getCreateDate() == null)) {
			if (serviceContext == null) {
				device.setCreateDate(now);
			}
			else {
				device.setCreateDate(serviceContext.getCreateDate(now));
			}
		}

		if (!deviceModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				device.setModifiedDate(now);
			}
			else {
				device.setModifiedDate(serviceContext.getModifiedDate(now));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (device.isNew()) {
				session.save(device);

				device.setNew(false);
			}
			else {
				device = (Device)session.merge(device);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {deviceModelImpl.getCompanyId()};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((deviceModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					deviceModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {deviceModelImpl.getCompanyId()};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, DeviceImpl.class, device.getPrimaryKey(),
			device, false);

		clearUniqueFindersCache(deviceModelImpl, false);
		cacheUniqueFindersCache(deviceModelImpl);

		device.resetOriginalValues();

		return device;
	}

	/**
	 * Returns the device with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the device
	 * @return the device
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	@Override
	public Device findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDeviceException {

		Device device = fetchByPrimaryKey(primaryKey);

		if (device == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDeviceException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return device;
	}

	/**
	 * Returns the device with the primary key or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param deviceId the primary key of the device
	 * @return the device
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	@Override
	public Device findByPrimaryKey(long deviceId) throws NoSuchDeviceException {
		return findByPrimaryKey((Serializable)deviceId);
	}

	/**
	 * Returns the device with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param deviceId the primary key of the device
	 * @return the device, or <code>null</code> if a device with the primary key could not be found
	 */
	@Override
	public Device fetchByPrimaryKey(long deviceId) {
		return fetchByPrimaryKey((Serializable)deviceId);
	}

	/**
	 * Returns all the devices.
	 *
	 * @return the devices
	 */
	@Override
	public List<Device> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the devices.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @return the range of devices
	 */
	@Override
	public List<Device> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the devices.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of devices
	 */
	@Override
	public List<Device> findAll(
		int start, int end, OrderByComparator<Device> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the devices.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of devices
	 */
	@Override
	public List<Device> findAll(
		int start, int end, OrderByComparator<Device> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<Device> list = null;

		if (retrieveFromCache) {
			list = (List<Device>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_DEVICE);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DEVICE;

				if (pagination) {
					sql = sql.concat(DeviceModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Device>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<Device>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the devices from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (Device device : findAll()) {
			remove(device);
		}
	}

	/**
	 * Returns the number of devices.
	 *
	 * @return the number of devices
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DEVICE);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "deviceId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_DEVICE;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return DeviceModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the device persistence.
	 */
	@Activate
	public void activate() {
		DeviceModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		DeviceModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathFetchByVCId_StbNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByVCId_StbNo",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			DeviceModelImpl.VCID_COLUMN_BITMASK |
			DeviceModelImpl.STBNO_COLUMN_BITMASK |
			DeviceModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByVCId_StbNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByVCId_StbNo",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathFetchByVCId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByVCId",
			new String[] {String.class.getName(), Long.class.getName()},
			DeviceModelImpl.VCID_COLUMN_BITMASK |
			DeviceModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByVCId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByVCId",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathFetchByStbNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByStbNo",
			new String[] {String.class.getName(), Long.class.getName()},
			DeviceModelImpl.STBNO_COLUMN_BITMASK |
			DeviceModelImpl.COMPANYID_COLUMN_BITMASK);

		_finderPathCountByStbNo = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByStbNo",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, DeviceImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			DeviceModelImpl.COMPANYID_COLUMN_BITMASK |
			DeviceModelImpl.MODIFIEDDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(DeviceImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ADPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.device.model.Device"),
			true);
	}

	@Override
	@Reference(
		target = ADPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ADPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_DEVICE =
		"SELECT device FROM Device device";

	private static final String _SQL_SELECT_DEVICE_WHERE =
		"SELECT device FROM Device device WHERE ";

	private static final String _SQL_COUNT_DEVICE =
		"SELECT COUNT(device) FROM Device device";

	private static final String _SQL_COUNT_DEVICE_WHERE =
		"SELECT COUNT(device) FROM Device device WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "device.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No Device exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No Device exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		DevicePersistenceImpl.class);

}