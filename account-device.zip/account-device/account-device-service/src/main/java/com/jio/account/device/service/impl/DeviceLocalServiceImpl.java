/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.device.service.impl;

import com.jio.account.device.exception.NoSuchDeviceException;
import com.jio.account.device.model.Device;
import com.jio.account.device.service.base.DeviceLocalServiceBaseImpl;
import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.AuditUtil;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the device local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.device.service.DeviceLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DeviceLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.device.model.Device", service = AopService.class)
public class DeviceLocalServiceImpl extends DeviceLocalServiceBaseImpl {

	@Override
	public Device addDevice(Device device) {
		device.setCreateDate(new Date());
		device.setModifiedDate(device.getCreateDate());
		device = super.addDevice(device);
		AuditUtil.audit(device, AuditConstants.SAVE);
		return device;
	}

	@Override
	public Device updateDevice(Device device) {
		device.setModifiedDate(new Date());
		device = super.updateDevice(device);
		AuditUtil.audit(device, AuditConstants.UPDATE);
		return device;
	}

	@Override
	public Device deleteDevice(Device device) {
		device = super.deleteDevice(device);
		AuditUtil.audit(device, AuditConstants.DELETE);
		return device;
	}

	@Override
	public Device deleteDevice(long deviceId) throws PortalException {
		return deleteDevice(getDevice(deviceId));
	}

	public Device getDeviceByVcId(String vcId, long companyId) throws NoSuchDeviceException {
		return this.devicePersistence.findByVCId(vcId, companyId);
	}

	public Device getDeviceByStbNo(String stbNo, long companyId) throws NoSuchDeviceException {
		return this.devicePersistence.findByStbNo(stbNo, companyId);
	}

	public Device getDevice(String vcId, String stbNo, long companyId) throws NoSuchDeviceException {
		return this.devicePersistence.findByVCId_StbNo(vcId, stbNo, companyId);
	}

	@Override
	public List<Device> getDevices(long companyId, int start, int end) {
		return this.devicePersistence.findByCompanyId(companyId, start, end);
	}

	@Override
	public List<Device> getDevices(long companyId) {
		return this.devicePersistence.findByCompanyId(companyId);
	}

	@Override
	public int getDevicesCount(long companyId) {
		return this.devicePersistence.countByCompanyId(companyId);
	}
}