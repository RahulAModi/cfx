/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.device.service.persistence;

import com.jio.account.device.exception.NoSuchDeviceException;
import com.jio.account.device.model.Device;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the device service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see DeviceUtil
 * @generated
 */
@ProviderType
public interface DevicePersistence extends BasePersistence<Device> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link DeviceUtil} to access the device persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	public Device findByVCId_StbNo(String vcId, String stbNo, long companyId)
		throws NoSuchDeviceException;

	/**
	 * Returns the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByVCId_StbNo(String vcId, String stbNo, long companyId);

	/**
	 * Returns the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByVCId_StbNo(
		String vcId, String stbNo, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the device where vcId = &#63; and stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the device that was removed
	 */
	public Device removeByVCId_StbNo(String vcId, String stbNo, long companyId)
		throws NoSuchDeviceException;

	/**
	 * Returns the number of devices where vcId = &#63; and stbNo = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	public int countByVCId_StbNo(String vcId, String stbNo, long companyId);

	/**
	 * Returns the device where vcId = &#63; and companyId = &#63; or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	public Device findByVCId(String vcId, long companyId)
		throws NoSuchDeviceException;

	/**
	 * Returns the device where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByVCId(String vcId, long companyId);

	/**
	 * Returns the device where vcId = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByVCId(
		String vcId, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the device where vcId = &#63; and companyId = &#63; from the database.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the device that was removed
	 */
	public Device removeByVCId(String vcId, long companyId)
		throws NoSuchDeviceException;

	/**
	 * Returns the number of devices where vcId = &#63; and companyId = &#63;.
	 *
	 * @param vcId the vc ID
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	public int countByVCId(String vcId, long companyId);

	/**
	 * Returns the device where stbNo = &#63; and companyId = &#63; or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	public Device findByStbNo(String stbNo, long companyId)
		throws NoSuchDeviceException;

	/**
	 * Returns the device where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByStbNo(String stbNo, long companyId);

	/**
	 * Returns the device where stbNo = &#63; and companyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByStbNo(
		String stbNo, long companyId, boolean retrieveFromCache);

	/**
	 * Removes the device where stbNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the device that was removed
	 */
	public Device removeByStbNo(String stbNo, long companyId)
		throws NoSuchDeviceException;

	/**
	 * Returns the number of devices where stbNo = &#63; and companyId = &#63;.
	 *
	 * @param stbNo the stb no
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	public int countByStbNo(String stbNo, long companyId);

	/**
	 * Returns all the devices where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching devices
	 */
	public java.util.List<Device> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the devices where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @return the range of matching devices
	 */
	public java.util.List<Device> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the devices where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching devices
	 */
	public java.util.List<Device> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Device>
			orderByComparator);

	/**
	 * Returns an ordered range of all the devices where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching devices
	 */
	public java.util.List<Device> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Device>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	public Device findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Device>
				orderByComparator)
		throws NoSuchDeviceException;

	/**
	 * Returns the first device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Device>
			orderByComparator);

	/**
	 * Returns the last device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching device
	 * @throws NoSuchDeviceException if a matching device could not be found
	 */
	public Device findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Device>
				orderByComparator)
		throws NoSuchDeviceException;

	/**
	 * Returns the last device in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching device, or <code>null</code> if a matching device could not be found
	 */
	public Device fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Device>
			orderByComparator);

	/**
	 * Returns the devices before and after the current device in the ordered set where companyId = &#63;.
	 *
	 * @param deviceId the primary key of the current device
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next device
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	public Device[] findByCompanyId_PrevAndNext(
			long deviceId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<Device>
				orderByComparator)
		throws NoSuchDeviceException;

	/**
	 * Removes all the devices where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of devices where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching devices
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Caches the device in the entity cache if it is enabled.
	 *
	 * @param device the device
	 */
	public void cacheResult(Device device);

	/**
	 * Caches the devices in the entity cache if it is enabled.
	 *
	 * @param devices the devices
	 */
	public void cacheResult(java.util.List<Device> devices);

	/**
	 * Creates a new device with the primary key. Does not add the device to the database.
	 *
	 * @param deviceId the primary key for the new device
	 * @return the new device
	 */
	public Device create(long deviceId);

	/**
	 * Removes the device with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param deviceId the primary key of the device
	 * @return the device that was removed
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	public Device remove(long deviceId) throws NoSuchDeviceException;

	public Device updateImpl(Device device);

	/**
	 * Returns the device with the primary key or throws a <code>NoSuchDeviceException</code> if it could not be found.
	 *
	 * @param deviceId the primary key of the device
	 * @return the device
	 * @throws NoSuchDeviceException if a device with the primary key could not be found
	 */
	public Device findByPrimaryKey(long deviceId) throws NoSuchDeviceException;

	/**
	 * Returns the device with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param deviceId the primary key of the device
	 * @return the device, or <code>null</code> if a device with the primary key could not be found
	 */
	public Device fetchByPrimaryKey(long deviceId);

	/**
	 * Returns all the devices.
	 *
	 * @return the devices
	 */
	public java.util.List<Device> findAll();

	/**
	 * Returns a range of all the devices.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @return the range of devices
	 */
	public java.util.List<Device> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the devices.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of devices
	 */
	public java.util.List<Device> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Device>
			orderByComparator);

	/**
	 * Returns an ordered range of all the devices.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>DeviceModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of devices
	 * @param end the upper bound of the range of devices (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of devices
	 */
	public java.util.List<Device> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Device>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the devices from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of devices.
	 *
	 * @return the number of devices
	 */
	public int countAll();

}