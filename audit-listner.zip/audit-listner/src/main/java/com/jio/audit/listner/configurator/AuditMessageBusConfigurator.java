package com.jio.audit.listner.configurator;

import com.liferay.portal.kernel.concurrent.CallerRunsPolicy;
import com.liferay.portal.kernel.concurrent.RejectedExecutionHandler;
import com.liferay.portal.kernel.concurrent.ThreadPoolExecutor;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Destination;
import com.liferay.portal.kernel.messaging.DestinationConfiguration;
import com.liferay.portal.kernel.messaging.DestinationFactory;
import com.liferay.portal.kernel.util.HashMapDictionary;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, service = AuditMessageBusConfigurator.class)
public class AuditMessageBusConfigurator {

	public final Log LOGGER = LogFactoryUtil.getLog(AuditMessageBusConfigurator.class);

	private final int _MAXIMUM_QUEUE_SIZE = 1000;

	private volatile BundleContext _bundleContext;

	@Reference
	private DestinationFactory _destinationFactory;

	private final Map<String, ServiceRegistration<Destination>> _serviceRegistrations = new HashMap<>();

	@Activate
	protected void activate(BundleContext context) {
		_bundleContext = context;
		startMessageBus("audit.ptob.destination");
		startMessageBus("servicelog.ptob.destination");
	}

	@Deactivate
	protected void deactivate() {
		for (ServiceRegistration<Destination> serviceRegistration : _serviceRegistrations.values()) {
			destroyMessageBus(serviceRegistration);
		}
		_serviceRegistrations.clear();
	}

	private void destroyMessageBus(ServiceRegistration<Destination> serviceRegistration) {
		Destination destination = _bundleContext.getService(serviceRegistration.getReference());
		serviceRegistration.unregister();
		destination.destroy();
	}

	private void startMessageBus(String busName) {
		Destination destination = createDestination(busName);
		Dictionary<String, Object> propeties = createDictionary(destination);
		createServiceRegistration(destination, propeties);
	}

	private void createServiceRegistration(Destination destination, Dictionary<String, Object> propeties) {
		ServiceRegistration<Destination> messageServiceRegistration = _bundleContext.registerService(Destination.class,
				destination, propeties);
		_serviceRegistrations.put(destination.getName(), messageServiceRegistration);
	}

	private Dictionary<String, Object> createDictionary(Destination destination) {
		Dictionary<String, Object> properties = new HashMapDictionary<>();
		properties.put("destination.name", destination.getName());
		return properties;
	}

	private Destination createDestination(String destinationName) {
		DestinationConfiguration destinationConfiguration = new DestinationConfiguration(
				DestinationConfiguration.DESTINATION_TYPE_PARALLEL, destinationName);

		destinationConfiguration.setMaximumQueueSize(_MAXIMUM_QUEUE_SIZE);

		RejectedExecutionHandler rejectedExecutionHandler = new CallerRunsPolicy() {

			@Override
			public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {

				if (LOGGER.isWarnEnabled()) {
					LOGGER.warn("The current thread will handle the request "
							+ "because the audit router's task queue is at " + "its maximum capacity");
				}

				super.rejectedExecution(runnable, threadPoolExecutor);
			}

		};

		destinationConfiguration.setRejectedExecutionHandler(rejectedExecutionHandler);

		return _destinationFactory.createDestination(destinationConfiguration);

	}

}
