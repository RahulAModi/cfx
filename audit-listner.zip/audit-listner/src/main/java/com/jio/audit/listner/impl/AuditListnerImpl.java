package com.jio.audit.listner.impl;

import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.model.Audit;
import com.jio.audit.service.AuditLocalService;
import com.jio.mongo.driver.service.MongoDriverService;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.util.GetterUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=audit.ptob.destination" }, service = MessageListener.class)
public class AuditListnerImpl implements MessageListener {

	public final Log LOGGER = LogFactoryUtil.getLog(AuditListnerImpl.class);

	@Reference
	private AuditLocalService auditLocalService;

	@Reference
	private CounterLocalService counterLocalService;

	@Reference
	private MongoDriverService mongoDriverService;

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	/**
	 * Audit operation details get from message
	 * 
	 * @param message
	 */
	private void doReceive(Message message) {

		try {
			DateFormat dateFormat = new SimpleDateFormat(AuditConstants.FULL_DATE_FORMAT);
			String data = GetterUtil.getString(message.get(AuditConstants.AUDIT_DATA));
			String action = GetterUtil.getString(message.get(AuditConstants.AUDIT_ACTION));
			long classNameId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_CLASSNAMEID));
			String classPK = GetterUtil.getString(message.get(AuditConstants.AUDIT_CLASSPK));
			String txRefNo = GetterUtil.getString(message.get(AuditConstants.AUDIT_TXREFNO));
			String referenceNumber = GetterUtil.getString(message.get(AuditConstants.AUDIT_REFERENCENUMBER));
			Date createdDate = GetterUtil.getDate(message.get(AuditConstants.AUDIT_CREATEDDATE), dateFormat);
			String createdBy = GetterUtil.getString(message.get(AuditConstants.AUDIT_CREATEBY));
			long userId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_USERID));
			long companyId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_COMPANYID));
			long groupId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_GROUPID));
			Audit audit = auditLocalService.createAudit(counterLocalService.increment(Audit.class.getName()));
			audit.setClassNameId(classNameId);
			audit.setClassPK(classPK);
			audit.setTxRefNo(txRefNo);
			audit.setReferenceNumber(referenceNumber);
			audit.setData(data);
			audit.setCreateDate(createdDate);
			audit.setAction(action);
			audit.setUserId(userId);
			audit.setCompanyId(companyId);
			audit.setGroupId(groupId);
			audit.setCreatedBy(createdBy);

			if (mongoDriverService.isEnableMongoDB()) {
				mongoDriverService.addAudit(audit.getAuditId(), audit.getGroupId(), audit.getCompanyId(), audit.getCreatedBy(), audit.getUserId(), audit.getCreateDate(), audit.getAction(), audit.getLabel(), audit.getClassNameId(), audit.getClassPK(), audit.getReferenceNumber(), audit.getTxRefNo(),
						audit.getData());
			} else {
				auditLocalService.addAudit(audit);
			}

		} catch (SystemException e) {
			LOGGER.error("SystemException : while audit entry");
		}

	}

}
