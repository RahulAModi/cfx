package com.jio.audit.listner.impl;

import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.model.ServiceLog;
import com.jio.audit.service.ServiceLogLocalService;
import com.jio.mongo.driver.service.MongoDriverService;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.util.GetterUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "destination.name=servicelog.ptob.destination" }, service = MessageListener.class)
public class ServiceLogListnerImpl implements MessageListener {

	public final Log LOGGER = LogFactoryUtil.getLog(ServiceLogListnerImpl.class);

	@Reference
	private ServiceLogLocalService serviceLogLocalService;

	@Reference
	private CounterLocalService counterLocalService;

	@Reference
	private MongoDriverService mongoDriverService;

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

	/**
	 * Audit operation details get from message
	 * 
	 * @param message
	 */
	private void doReceive(Message message) {

		try {
			DateFormat dateFormat = new SimpleDateFormat(AuditConstants.FULL_DATE_FORMAT);
			String data = GetterUtil.getString(message.get(AuditConstants.AUDIT_DATA));
			String action = GetterUtil.getString(message.get(AuditConstants.AUDIT_ACTION));
			String referenceNumber = GetterUtil.getString(message.get(AuditConstants.AUDIT_REFERENCENUMBER));
			String transactionRefNo = GetterUtil.getString(message.get(AuditConstants.AUDIT_TRANS_REFNO));
			String txRefNo = GetterUtil.getString(message.get(AuditConstants.AUDIT_TXREFNO));
			Date createdDate = GetterUtil.getDate(message.get(AuditConstants.AUDIT_CREATEDDATE), dateFormat);
			long userId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_USERID));
			long companyId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_COMPANYID));
			long groupId = GetterUtil.getLong(message.get(AuditConstants.AUDIT_GROUPID));
			String createdBy = GetterUtil.getString(message.get(AuditConstants.AUDIT_CREATEBY));

			ServiceLog serviceLog = serviceLogLocalService.createServiceLog(counterLocalService.increment(ServiceLog.class.getName()));
			serviceLog.setData(data);
			serviceLog.setAction(action);
			serviceLog.setTxRefNo(txRefNo);
			serviceLog.setReferenceNumber(referenceNumber);
			serviceLog.setTransactionRefNo(transactionRefNo);
			serviceLog.setCreateDate(createdDate);
			serviceLog.setUserId(userId);
			serviceLog.setCompanyId(companyId);
			serviceLog.setGroupId(groupId);
			serviceLog.setCreatedBy(createdBy);

			if (mongoDriverService.isEnableMongoDB()) {
				mongoDriverService.addServiceLog(serviceLog.getServiceLogId(), serviceLog.getGroupId(), serviceLog.getCompanyId(), serviceLog.getCreatedBy(), serviceLog.getUserId(), serviceLog.getCreateDate(), serviceLog.getName(), serviceLog.getAction(), serviceLog.getLabel(),
						serviceLog.getReferenceNumber(), serviceLog.getTxRefNo(), serviceLog.getTransactionRefNo(), serviceLog.getData());
			} else {
				serviceLogLocalService.addServiceLog(serviceLog);
			}

		} catch (SystemException e) {
			LOGGER.error("SystemException : while service entry");
		}

	}

}
