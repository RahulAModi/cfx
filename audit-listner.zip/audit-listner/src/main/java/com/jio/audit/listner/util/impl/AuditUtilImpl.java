package com.jio.audit.listner.util.impl;

import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.api.AuditUtil;
import com.jio.audit.props.util.AuditPropsValues;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.Validator;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, service = AuditUtil.class)
public class AuditUtilImpl implements AuditUtil {

	/**
	 * Audit entiry table with PTOB transaction reference number
	 * 
	 * @author vishal5.shah
	 * 
	 * @param object
	 * @param action
	 * @param txRefNo
	 */
	public void audit(Object object, String action, String txRefNo) {
		if (isNotRestrictClass(object)) {
			auditMessage(object, action, txRefNo);
		}
	}

	/**
	 * Audit entity tables
	 * 
	 * @author vishal5.shah
	 * 
	 * @param object
	 * @param action
	 */
	public void audit(Object object, String action) {
		if (isNotRestrictClass(object)) {
			auditMessage(object, action, StringPool.BLANK);
		}
	}

	/**
	 * Audit Message Entity
	 * 
	 * @author vishal5.shah
	 * 
	 * @param object
	 * @param action
	 */
	private void auditMessage(Object object, String action, String txRefNo) {
		Message message = new Message();
		message.put(AuditConstants.AUDIT_ACTION, action);
		message.put(AuditConstants.AUDIT_DATA, getValue(object, "toString"));
		message.put(AuditConstants.AUDIT_CLASSNAMEID, ClassNameLocalServiceUtil.getClassNameId(object.getClass()));
		message.put(AuditConstants.AUDIT_CLASSPK, getValue(object, "getPrimaryKey"));
		message.put(AuditConstants.AUDIT_TXREFNO, txRefNo);
		message.put(AuditConstants.AUDIT_REFERENCENUMBER, getValue(object, "getReferenceNumber"));
		message.put(AuditConstants.AUDIT_CREATEDDATE, new Date());
		message.put(AuditConstants.AUDIT_CREATEBY, getValue(object, "getCreatedBy"));
		message.put(AuditConstants.AUDIT_USERID, getValue(object, "getUserId"));
		message.put(AuditConstants.AUDIT_COMPANYID, getValue(object, "getCompanyId"));
		message.put(AuditConstants.AUDIT_GROUPID, getValue(object, "getGroupId"));
		MessageBusUtil.sendMessage("audit.ptob.destination", message);
	}

	/**
	 * Get value based through reflection of method
	 * 
	 * @author vishal5.shah
	 * 
	 * @param object
	 * @param methodName
	 * @return
	 */
	private String getValue(Object object, String methodName) {
		String value = StringPool.BLANK;
		Class<?> clz = object.getClass();
		try {
			Method method = clz.getMethod(methodName);
			if (Validator.isNotNull(method)) {
				value = String.valueOf(method.invoke(object));
			}
		} catch (IllegalAccessException e) {

		} catch (IllegalArgumentException e) {

		} catch (InvocationTargetException e) {

		} catch (NoSuchMethodException e) {

		} catch (SecurityException e) {

		}

		return value;
	}

	/**
	 * Not Restricted Class
	 * 
	 * @author vishal5.shah
	 * 
	 * @param object
	 * @return
	 */
	private boolean isNotRestrictClass(Object object) {
		return !isRestrictClass(object);
	}

	/**
	 * Restricted Class check based on the portlet-ext properties
	 * 
	 * @author vishal5.shah
	 * 
	 * @param object
	 * @return
	 */
	private boolean isRestrictClass(Object object) {
		String[] restrictionClasses = AuditPropsValues.AUDIT_RESTRICTION_CLASSES;
		String restrictedClass = object.getClass().getSimpleName();
		return ArrayUtil.contains(restrictionClasses, restrictedClass);
	}

}
