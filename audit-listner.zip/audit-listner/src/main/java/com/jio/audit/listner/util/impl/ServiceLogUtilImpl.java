package com.jio.audit.listner.util.impl;

import com.jio.audit.listner.constant.AuditConstants;
import com.jio.audit.listner.util.api.ServiceLogUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;

import java.util.Date;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, service = ServiceLogUtil.class)
public class ServiceLogUtilImpl implements ServiceLogUtil {

	public void sendRequest(String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, String data) {
		serviceLogMessage(AuditConstants.REQUEST, txRefNo, referenceNumber, transactionRefNo, new Date(), createdBy, userId, companyId, groupId, data);
	}

	public void getResponse(String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, String data) {
		serviceLogMessage(AuditConstants.RESPONSE, txRefNo, referenceNumber, transactionRefNo, new Date(), createdBy, userId, companyId, groupId, data);
	}

	public void getException(String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, String data) {
		serviceLogMessage(AuditConstants.EXCEPTION, txRefNo, referenceNumber, transactionRefNo, new Date(), createdBy, userId, companyId, groupId, data);
	}
	
	public void getNotification(String txRefNo, String referenceNumber, String transactionRefNo, String createdBy, long userId, long companyId, long groupId, String data) {
		serviceLogMessage(AuditConstants.NOTIFICATION, txRefNo, referenceNumber, transactionRefNo, new Date(), createdBy, userId, companyId, groupId, data);
	}

	/**
	 * 
	 * @param action
	 * @param txRefNo
	 * @param referenceNumber
	 * @param transactionRefNo
	 * @param createDate
	 * @param createdBy
	 * @param userId
	 * @param companyId
	 * @param groupId
	 * @param data
	 */
	private void serviceLogMessage(String action, String txRefNo, String referenceNumber, String transactionRefNo, Date createDate, String createdBy, long userId, long companyId, long groupId, String data) {
		Message message = new Message();
		message.put(AuditConstants.AUDIT_ACTION, action);
		message.put(AuditConstants.AUDIT_REFERENCENUMBER, referenceNumber);
		message.put(AuditConstants.AUDIT_TRANS_REFNO, transactionRefNo);
		message.put(AuditConstants.AUDIT_TXREFNO, txRefNo);
		message.put(AuditConstants.AUDIT_CREATEDDATE, createDate);
		message.put(AuditConstants.AUDIT_CREATEBY, createdBy);
		message.put(AuditConstants.AUDIT_USERID, userId);
		message.put(AuditConstants.AUDIT_COMPANYID, companyId);
		message.put(AuditConstants.AUDIT_GROUPID, groupId);
		message.put(AuditConstants.AUDIT_DATA, data);

		MessageBusUtil.sendMessage("servicelog.ptob.destination", message);
	}


	
}
