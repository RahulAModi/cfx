AUI().ready(

	/*
	This function gets loaded when all the HTML, not including the portlets, is
	loaded.
	*/

	function() {
	}
);

Liferay.Portlet.ready(

	/*
	This function gets loaded after each and every portlet on the page.

	portletId: the current portlet's id
	node: the Alloy Node object of the current portlet
	*/

	function(portletId, node) {
	}
);

Liferay.on(
	'allPortletsReady',

	/*
	This function gets loaded when everything, including the portlets, is on
	the page.
	*/

	function() {
	}
);
	

jQuery(function(){
	
	var scrollEnabled = true;
	var $tabs;
	var scrollEnabled;
	
	// To get the random tabs label with variable length for testing the calculations
	var keywords = ['Just a tab label', 'Long string', 'Short',
		'Very very long string', 'tab', 'New tab', 'This is a new tab'];
		
	
	/*jQuery('.tab-fix-ceontent').slimScroll({
		height: '425px',
		size: '3px',
		color: '#92bae5',
		opacity: 0.9,
		alwaysVisible: true,
		distance: '9px',
		railVisible: true,
		railColor: '#ddd',
		railOpacity: 0.9,
		wheelStep: 10,
		allowPageScroll: false,
		disableFadeOut: false
	});
	jQuery('.matrixheight').slimScroll({
		height: '370px',
		size: '3px',
		color: '#92bae5',
		opacity: 0.9,
		alwaysVisible: true,
		distance: '0px',
		railVisible: true,
		railColor: '#ddd',
		railOpacity: 0.9,
		wheelStep: 10,
		allowPageScroll: false,
		disableFadeOut: false
	});*/

	// jQuery('.single-item').slick({
	// 	dots: true,
	// 	autoplay: true,
	// 	autoplaySpeed: 2000
	// });
		
	// jQuery('.responsive_slider_4_3_2_1').slick({
	// 	dots: false,
	// 	infinite: false,
	// 	speed: 300,
	// 	slidesToShow: 4,
	// 	slidesToScroll: 4,
	// 	responsive: [
	// 	  {
	// 		breakpoint: 1024,
	// 		settings: {
	// 		  slidesToShow: 3,
	// 		  slidesToScroll: 3,
	// 		  infinite: true,
			  
	// 		}
	// 	  },
	// 	  {
	// 		breakpoint: 768,
	// 		settings: {
	// 		  slidesToShow: 2,
	// 		  slidesToScroll: 2
	// 		}
	// 	  },
	// 	  {
	// 		breakpoint: 480,
	// 		settings: {
	// 		  slidesToShow: 1,
	// 		  slidesToScroll: 1
	// 		}
	// 	  }
	// 	]
	// 	});

		jQuery('#comic-learn-fun .slimScrollBar, #comic-learn-fun .slimScrollRail').css('right','0');

		jQuery(".search-icon").on("click",function(){
			// jQuery(this).hide();
			// jQuery("#navigationMenu").hide();
			// jQuery(".search-container").show()
			// .stop().animate({
			// 	width: '100%'
			//   }, 'slow');
			jQuery(".search-container .search-bar-keywords-input-wrapper > .search-bar-keywords-input").focus();
		});

		// jQuery(".search-container .search-bar-keywords-input-wrapper > .search-bar-keywords-input")
		// .blur(function() {
		// 	jQuery('.search-container').stop().animate({
		// 		width: '0'
		// 	  }, 'slow')
		// 	  .hide();
		// 	  jQuery(".search-icon").show();
		// 	  jQuery("#navigationMenu").show();
		// });

		function openNav() {
			if(jQuery(window).width() > 767) {
				jQuery("#myNav").css({
					"width":"25%",
					"display": "block"
				});
			}
			else {
				jQuery("#myNav").css({
					"width": "80%",
					"display": "block"
				});
			}
			jQuery("body").addClass("noScroll");
		}
		
		function closeNav() {
			jQuery("#myNav").css({
				"width": "0%",
				"display": "none"
			});
			jQuery("body").removeClass("noScroll")
		}

		jQuery("#navigationMenu").on("click",function(){
			openNav();
			jQuery(".contentHolder").show();
		});

		jQuery(".contentHolder").on("click",function(){
			closeNav();
			jQuery(this).hide();
		});
	
		jQuery('#myNav .overlay-content').slimScroll({
			height: '100%',
			size: '3px',
			color: '#92bae5',
			opacity: 0.9,
			alwaysVisible: false,
			distance: '0px',
			railVisible: true,
			railColor: '#ddd',
			railOpacity: 0.9,
			wheelStep: 10,
			allowPageScroll: false,
			disableFadeOut: false
		});

});

