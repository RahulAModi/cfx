create table AN_NotificationLog (
	notificationId VARCHAR(75) not null primary key,
	customerAccountNo VARCHAR(75) null,
	customerScreenName VARCHAR(75) null,
	messageTemplateDescId LONG,
	messageTemplateCode VARCHAR(75) null,
	transactionNo VARCHAR(75) null,
	agentAccountNo VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	createBy VARCHAR(75) null,
	createDate DATE null,
	sendDate DATE null
);