/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.service.persistence.impl;

import com.jio.account.notification.exception.NoSuchNotificationLogException;
import com.jio.account.notification.model.NotificationLog;
import com.jio.account.notification.model.impl.NotificationLogImpl;
import com.jio.account.notification.model.impl.NotificationLogModelImpl;
import com.jio.account.notification.service.persistence.NotificationLogPersistence;
import com.jio.account.notification.service.persistence.impl.constants.ANPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.CompanyProvider;
import com.liferay.portal.kernel.service.persistence.CompanyProviderWrapper;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.sql.Timestamp;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the notification log service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = NotificationLogPersistence.class)
@ProviderType
public class NotificationLogPersistenceImpl
	extends BasePersistenceImpl<NotificationLog>
	implements NotificationLogPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>NotificationLogUtil</code> to access the notification log persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		NotificationLogImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByCompanyId;
	private FinderPath _finderPathWithoutPaginationFindByCompanyId;
	private FinderPath _finderPathCountByCompanyId;

	/**
	 * Returns all the notification logs where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCompanyId(long companyId) {
		return findByCompanyId(
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCompanyId(
		long companyId, int start, int end) {

		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByCompanyId(companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCompanyId;
			finderArgs = new Object[] {companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCompanyId;
			finderArgs = new Object[] {
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((companyId != notificationLog.getCompanyId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCompanyId_First(
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCompanyId_First(
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCompanyId_First(
		long companyId, OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByCompanyId(
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCompanyId_Last(
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCompanyId_Last(
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCompanyId_Last(
		long companyId, OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByCompanyId(
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByCompanyId_PrevAndNext(
			String notificationId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByCompanyId_PrevAndNext(
				session, notificationLog, companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByCompanyId_PrevAndNext(
				session, notificationLog, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByCompanyId_PrevAndNext(
		Session session, NotificationLog notificationLog, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCompanyId(long companyId) {
		for (NotificationLog notificationLog :
				findByCompanyId(
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByCompanyId(long companyId) {
		FinderPath finderPath = _finderPathCountByCompanyId;

		Object[] finderArgs = new Object[] {companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindBySendDate;
	private FinderPath _finderPathWithoutPaginationFindBySendDate;
	private FinderPath _finderPathCountBySendDate;

	/**
	 * Returns all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findBySendDate(Date sendDate, long companyId) {
		return findBySendDate(
			sendDate, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end) {

		return findBySendDate(sendDate, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findBySendDate(
			sendDate, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindBySendDate;
			finderArgs = new Object[] {_getTime(sendDate), companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindBySendDate;
			finderArgs = new Object[] {
				_getTime(sendDate), companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!Objects.equals(
							sendDate, notificationLog.getSendDate()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindSendDate = false;

			if (sendDate == null) {
				query.append(_FINDER_COLUMN_SENDDATE_SENDDATE_1);
			}
			else {
				bindSendDate = true;

				query.append(_FINDER_COLUMN_SENDDATE_SENDDATE_2);
			}

			query.append(_FINDER_COLUMN_SENDDATE_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSendDate) {
					qPos.add(new Timestamp(sendDate.getTime()));
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findBySendDate_First(
			Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchBySendDate_First(
			sendDate, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("sendDate=");
		msg.append(sendDate);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchBySendDate_First(
		Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findBySendDate(
			sendDate, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findBySendDate_Last(
			Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchBySendDate_Last(
			sendDate, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("sendDate=");
		msg.append(sendDate);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchBySendDate_Last(
		Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countBySendDate(sendDate, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findBySendDate(
			sendDate, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findBySendDate_PrevAndNext(
			String notificationId, Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getBySendDate_PrevAndNext(
				session, notificationLog, sendDate, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getBySendDate_PrevAndNext(
				session, notificationLog, sendDate, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getBySendDate_PrevAndNext(
		Session session, NotificationLog notificationLog, Date sendDate,
		long companyId, OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindSendDate = false;

		if (sendDate == null) {
			query.append(_FINDER_COLUMN_SENDDATE_SENDDATE_1);
		}
		else {
			bindSendDate = true;

			query.append(_FINDER_COLUMN_SENDDATE_SENDDATE_2);
		}

		query.append(_FINDER_COLUMN_SENDDATE_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindSendDate) {
			qPos.add(new Timestamp(sendDate.getTime()));
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where sendDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 */
	@Override
	public void removeBySendDate(Date sendDate, long companyId) {
		for (NotificationLog notificationLog :
				findBySendDate(
					sendDate, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countBySendDate(Date sendDate, long companyId) {
		FinderPath finderPath = _finderPathCountBySendDate;

		Object[] finderArgs = new Object[] {_getTime(sendDate), companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindSendDate = false;

			if (sendDate == null) {
				query.append(_FINDER_COLUMN_SENDDATE_SENDDATE_1);
			}
			else {
				bindSendDate = true;

				query.append(_FINDER_COLUMN_SENDDATE_SENDDATE_2);
			}

			query.append(_FINDER_COLUMN_SENDDATE_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSendDate) {
					qPos.add(new Timestamp(sendDate.getTime()));
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SENDDATE_SENDDATE_1 =
		"notificationLog.sendDate IS NULL AND ";

	private static final String _FINDER_COLUMN_SENDDATE_SENDDATE_2 =
		"notificationLog.sendDate = ? AND ";

	private static final String _FINDER_COLUMN_SENDDATE_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_SD_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_SD_CID;
	private FinderPath _finderPathCountByMT_SD_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId) {

		return findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end) {

		return findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end, OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end, OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_SD_CID;
			finderArgs = new Object[] {
				messageTemplateCode, _getTime(sendDate), companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_SD_CID;
			finderArgs = new Object[] {
				messageTemplateCode, _getTime(sendDate), companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						!Objects.equals(
							sendDate, notificationLog.getSendDate()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindSendDate = false;

			if (sendDate == null) {
				query.append(_FINDER_COLUMN_MT_SD_CID_SENDDATE_1);
			}
			else {
				bindSendDate = true;

				query.append(_FINDER_COLUMN_MT_SD_CID_SENDDATE_2);
			}

			query.append(_FINDER_COLUMN_MT_SD_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindSendDate) {
					qPos.add(new Timestamp(sendDate.getTime()));
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_SD_CID_First(
			String messageTemplateCode, Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_SD_CID_First(
			messageTemplateCode, sendDate, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", sendDate=");
		msg.append(sendDate);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_SD_CID_First(
		String messageTemplateCode, Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_SD_CID_Last(
			String messageTemplateCode, Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_SD_CID_Last(
			messageTemplateCode, sendDate, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", sendDate=");
		msg.append(sendDate);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_SD_CID_Last(
		String messageTemplateCode, Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_SD_CID(messageTemplateCode, sendDate, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_SD_CID_PrevAndNext(
			String notificationId, String messageTemplateCode, Date sendDate,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_SD_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode, sendDate,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_SD_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode, sendDate,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_SD_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_2);
		}

		boolean bindSendDate = false;

		if (sendDate == null) {
			query.append(_FINDER_COLUMN_MT_SD_CID_SENDDATE_1);
		}
		else {
			bindSendDate = true;

			query.append(_FINDER_COLUMN_MT_SD_CID_SENDDATE_2);
		}

		query.append(_FINDER_COLUMN_MT_SD_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		if (bindSendDate) {
			qPos.add(new Timestamp(sendDate.getTime()));
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_SD_CID(
					messageTemplateCode, sendDate, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		FinderPath finderPath = _finderPathCountByMT_SD_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, _getTime(sendDate), companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindSendDate = false;

			if (sendDate == null) {
				query.append(_FINDER_COLUMN_MT_SD_CID_SENDDATE_1);
			}
			else {
				bindSendDate = true;

				query.append(_FINDER_COLUMN_MT_SD_CID_SENDDATE_2);
			}

			query.append(_FINDER_COLUMN_MT_SD_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindSendDate) {
					qPos.add(new Timestamp(sendDate.getTime()));
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_2 =
		"notificationLog.messageTemplateCode = ? AND ";

	private static final String _FINDER_COLUMN_MT_SD_CID_MESSAGETEMPLATECODE_3 =
		"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String _FINDER_COLUMN_MT_SD_CID_SENDDATE_1 =
		"notificationLog.sendDate IS NULL AND ";

	private static final String _FINDER_COLUMN_MT_SD_CID_SENDDATE_2 =
		"notificationLog.sendDate = ? AND ";

	private static final String _FINDER_COLUMN_MT_SD_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_CID;
	private FinderPath _finderPathCountByMT_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId) {

		return findByMT_CID(
			messageTemplateCode, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end) {

		return findByMT_CID(messageTemplateCode, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_CID(
			messageTemplateCode, companyId, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_CID;
			finderArgs = new Object[] {messageTemplateCode, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_CID;
			finderArgs = new Object[] {
				messageTemplateCode, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CID_First(
			String messageTemplateCode, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CID_First(
			messageTemplateCode, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CID_First(
		String messageTemplateCode, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_CID(
			messageTemplateCode, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CID_Last(
			String messageTemplateCode, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CID_Last(
			messageTemplateCode, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CID_Last(
		String messageTemplateCode, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_CID(messageTemplateCode, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_CID(
			messageTemplateCode, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_CID_PrevAndNext(
			String notificationId, String messageTemplateCode, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_CID(String messageTemplateCode, long companyId) {
		for (NotificationLog notificationLog :
				findByMT_CID(
					messageTemplateCode, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_CID(String messageTemplateCode, long companyId) {
		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		FinderPath finderPath = _finderPathCountByMT_CID;

		Object[] finderArgs = new Object[] {messageTemplateCode, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_2 =
		"notificationLog.messageTemplateCode = ? AND ";

	private static final String _FINDER_COLUMN_MT_CID_MESSAGETEMPLATECODE_3 =
		"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String _FINDER_COLUMN_MT_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_AAN_CID;
	private FinderPath _finderPathCountByMT_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		return findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end) {

		return findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, agentAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, agentAccountNo, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_AAN_CID_First(
			String messageTemplateCode, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_AAN_CID_First(
			messageTemplateCode, agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_AAN_CID_First(
		String messageTemplateCode, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_AAN_CID_Last(
			String messageTemplateCode, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_AAN_CID_Last(
			messageTemplateCode, agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_AAN_CID_Last(
		String messageTemplateCode, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode, agentAccountNo,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode, agentAccountNo,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_AAN_CID(
					messageTemplateCode, agentAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_AAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String _FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MT_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_CAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_CAN_CID;
	private FinderPath _finderPathCountByMT_CAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		return findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end) {

		return findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_CAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_CAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerAccountNo, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_CAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CAN_CID_First(
			String messageTemplateCode, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CAN_CID_First(
			messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CAN_CID_First(
		String messageTemplateCode, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CAN_CID_Last(
			String messageTemplateCode, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CAN_CID_Last(
			messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CAN_CID_Last(
		String messageTemplateCode, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_CAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_CAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerAccountNo, companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_CAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerAccountNo, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_CAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_2);
		}

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_CAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_CAN_CID(
					messageTemplateCode, customerAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_CAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, customerAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_CAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_CAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String _FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_2 =
		"notificationLog.customerAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MT_CAN_CID_CUSTOMERACCOUNTNO_3 =
		"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_CAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_CSN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_CSN_CID;
	private FinderPath _finderPathCountByMT_CSN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId) {

		return findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end) {

		return findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_CSN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerScreenName, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_CSN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerScreenName, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_MT_CSN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CSN_CID_First(
			String messageTemplateCode, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CSN_CID_First(
			messageTemplateCode, customerScreenName, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CSN_CID_First(
		String messageTemplateCode, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CSN_CID_Last(
			String messageTemplateCode, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CSN_CID_Last(
			messageTemplateCode, customerScreenName, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CSN_CID_Last(
		String messageTemplateCode, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, count - 1,
			count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_CSN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_CSN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerScreenName, companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_CSN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerScreenName, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_CSN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_MT_CSN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_CSN_CID(
					messageTemplateCode, customerScreenName, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByMT_CSN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, customerScreenName, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_MT_CSN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_CSN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String _FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_2 =
		"notificationLog.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_MT_CSN_CID_CUSTOMERSCREENNAME_3 =
		"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_MT_CSN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_CAN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_CAN_AAN_CID;
	private FinderPath _finderPathCountByMT_CAN_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end) {

		return findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_CAN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerAccountNo, agentAccountNo,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_CAN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerAccountNo, agentAccountNo,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CAN_AAN_CID_First(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CAN_AAN_CID_First(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CAN_AAN_CID_First(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CAN_AAN_CID_Last(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CAN_AAN_CID_Last(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CAN_AAN_CID_Last(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_CAN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_CAN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerAccountNo, agentAccountNo, companyId, orderByComparator,
				true);

			array[1] = notificationLog;

			array[2] = getByMT_CAN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerAccountNo, agentAccountNo, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_CAN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_2);
		}

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_CAN_AAN_CID(
					messageTemplateCode, customerAccountNo, agentAccountNo,
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_CAN_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_CAN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_CAN_AAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_2 =
			"notificationLog.customerAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_CAN_AAN_CID_CUSTOMERACCOUNTNO_3 =
			"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MT_CAN_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_CAN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_CSN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_CSN_AAN_CID;
	private FinderPath _finderPathCountByMT_CSN_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		return findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end) {

		return findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_CSN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerScreenName, agentAccountNo,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_CSN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, customerScreenName, agentAccountNo,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CSN_AAN_CID_First(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CSN_AAN_CID_First(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CSN_AAN_CID_First(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_CSN_AAN_CID_Last(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_CSN_AAN_CID_Last(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_CSN_AAN_CID_Last(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_CSN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_CSN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerScreenName, agentAccountNo, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_CSN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				customerScreenName, agentAccountNo, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_CSN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_2);
		}

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_CSN_AAN_CID(
					messageTemplateCode, customerScreenName, agentAccountNo,
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_CSN_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, customerScreenName, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_CSN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_CSN_AAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_2 =
			"notificationLog.customerScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_CSN_AAN_CID_CUSTOMERSCREENNAME_3 =
			"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MT_CSN_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_CSN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMTD_CID;
	private FinderPath _finderPathWithoutPaginationFindByMTD_CID;
	private FinderPath _finderPathCountByMTD_CID;

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId) {

		return findByMTD_CID(
			messageTemplateDescId, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end) {

		return findByMTD_CID(
			messageTemplateDescId, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMTD_CID(
			messageTemplateDescId, companyId, start, end, orderByComparator,
			true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMTD_CID;
			finderArgs = new Object[] {messageTemplateDescId, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMTD_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_CID_MESSAGETEMPLATEDESCID_2);

			query.append(_FINDER_COLUMN_MTD_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CID_First(
			long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CID_First(
			messageTemplateDescId, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CID_First(
		long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMTD_CID(
			messageTemplateDescId, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CID_Last(
			long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CID_Last(
			messageTemplateDescId, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CID_Last(
		long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMTD_CID(messageTemplateDescId, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMTD_CID(
			messageTemplateDescId, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMTD_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMTD_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMTD_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMTD_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_MTD_CID_MESSAGETEMPLATEDESCID_2);

		query.append(_FINDER_COLUMN_MTD_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(messageTemplateDescId);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMTD_CID(long messageTemplateDescId, long companyId) {
		for (NotificationLog notificationLog :
				findByMTD_CID(
					messageTemplateDescId, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMTD_CID(long messageTemplateDescId, long companyId) {
		FinderPath finderPath = _finderPathCountByMTD_CID;

		Object[] finderArgs = new Object[] {messageTemplateDescId, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_CID_MESSAGETEMPLATEDESCID_2);

			query.append(_FINDER_COLUMN_MTD_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MTD_CID_MESSAGETEMPLATEDESCID_2 =
		"notificationLog.messageTemplateDescId = ? AND ";

	private static final String _FINDER_COLUMN_MTD_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMTD_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMTD_AAN_CID;
	private FinderPath _finderPathCountByMTD_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		return findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end) {

		return findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMTD_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, agentAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMTD_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, agentAccountNo, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_AAN_CID_First(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_AAN_CID_First(
			messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_AAN_CID_First(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_AAN_CID_Last(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_AAN_CID_Last(
			messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_AAN_CID_Last(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMTD_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMTD_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId, agentAccountNo,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMTD_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId, agentAccountNo,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMTD_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		long messageTemplateDescId, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MTD_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(messageTemplateDescId);

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMTD_AAN_CID(
					messageTemplateDescId, agentAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMTD_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateDescId, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String _FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MTD_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MTD_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMTD_CAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMTD_CAN_CID;
	private FinderPath _finderPathCountByMTD_CAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		return findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end) {

		return findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerAccountNo = Objects.toString(customerAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMTD_CAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMTD_CAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerAccountNo, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_CAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CAN_CID_First(
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CAN_CID_First(
			messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CAN_CID_First(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CAN_CID_Last(
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CAN_CID_Last(
			messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CAN_CID_Last(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, count - 1,
			count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMTD_CAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerAccountNo = Objects.toString(customerAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMTD_CAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerAccountNo, companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMTD_CAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerAccountNo, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMTD_CAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		long messageTemplateDescId, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MTD_CAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(messageTemplateDescId);

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMTD_CAN_CID(
					messageTemplateDescId, customerAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		customerAccountNo = Objects.toString(customerAccountNo, "");

		FinderPath finderPath = _finderPathCountByMTD_CAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateDescId, customerAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_CAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String _FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_2 =
		"notificationLog.customerAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MTD_CAN_CID_CUSTOMERACCOUNTNO_3 =
		"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MTD_CAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMTD_CSN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMTD_CSN_CID;
	private FinderPath _finderPathCountByMTD_CSN_CID;

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		return findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end) {

		return findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMTD_CSN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerScreenName, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMTD_CSN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerScreenName, companyId, start,
				end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_MTD_CSN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CSN_CID_First(
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CSN_CID_First(
			messageTemplateDescId, customerScreenName, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CSN_CID_First(
		long messageTemplateDescId, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CSN_CID_Last(
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CSN_CID_Last(
			messageTemplateDescId, customerScreenName, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CSN_CID_Last(
		long messageTemplateDescId, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, count - 1,
			count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMTD_CSN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerScreenName = Objects.toString(customerScreenName, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMTD_CSN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerScreenName, companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMTD_CSN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerScreenName, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMTD_CSN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		long messageTemplateDescId, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_MTD_CSN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(messageTemplateDescId);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		for (NotificationLog notificationLog :
				findByMTD_CSN_CID(
					messageTemplateDescId, customerScreenName, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByMTD_CSN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateDescId, customerScreenName, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(_FINDER_COLUMN_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_MTD_CSN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_2 =
			"notificationLog.customerScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CSN_CID_CUSTOMERSCREENNAME_3 =
			"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_MTD_CSN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMTD_CAN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMTD_CAN_AAN_CID;
	private FinderPath _finderPathCountByMTD_CAN_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end) {

		return findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMTD_CAN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerAccountNo, agentAccountNo,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMTD_CAN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerAccountNo, agentAccountNo,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(
				_FINDER_COLUMN_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(
					_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CAN_AAN_CID_First(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CAN_AAN_CID_First(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CAN_AAN_CID_First(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CAN_AAN_CID_Last(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CAN_AAN_CID_Last(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CAN_AAN_CID_Last(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMTD_CAN_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMTD_CAN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerAccountNo, agentAccountNo, companyId, orderByComparator,
				true);

			array[1] = notificationLog;

			array[2] = getByMTD_CAN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerAccountNo, agentAccountNo, companyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMTD_CAN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(messageTemplateDescId);

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMTD_CAN_AAN_CID(
					messageTemplateDescId, customerAccountNo, agentAccountNo,
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMTD_CAN_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(
				_FINDER_COLUMN_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(
					_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_CAN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2 =
			"notificationLog.customerAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3 =
			"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String
		_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2 =
			"notificationLog.agentAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3 =
			"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MTD_CAN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMTD_CSN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMTD_CSN_AAN_CID;
	private FinderPath _finderPathCountByMTD_CSN_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		return findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end) {

		return findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMTD_CSN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerScreenName, agentAccountNo,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMTD_CSN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateDescId, customerScreenName, agentAccountNo,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if ((messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			query.append(
				_FINDER_COLUMN_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CSN_AAN_CID_First(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CSN_AAN_CID_First(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CSN_AAN_CID_First(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMTD_CSN_AAN_CID_Last(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMTD_CSN_AAN_CID_Last(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMTD_CSN_AAN_CID_Last(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMTD_CSN_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMTD_CSN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerScreenName, agentAccountNo, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMTD_CSN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateDescId,
				customerScreenName, agentAccountNo, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMTD_CSN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(messageTemplateDescId);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMTD_CSN_AAN_CID(
					messageTemplateDescId, customerScreenName, agentAccountNo,
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMTD_CSN_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateDescId, customerScreenName, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			query.append(
				_FINDER_COLUMN_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MTD_CSN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2 =
			"notificationLog.customerScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3 =
			"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String
		_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2 =
			"notificationLog.agentAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3 =
			"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MTD_CSN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_MTD_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_MTD_CID;
	private FinderPath _finderPathCountByMT_MTD_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		return findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end) {

		return findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_MTD_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_MTD_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, companyId, start,
				end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATEDESCID_2);

			query.append(_FINDER_COLUMN_MT_MTD_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CID_First(
			messageTemplateCode, messageTemplateDescId, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CID_First(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CID_Last(
			messageTemplateCode, messageTemplateDescId, companyId,
			orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CID_Last(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, count - 1,
			count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_MTD_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_MTD_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_MTD_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_MTD_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATEDESCID_2);

		query.append(_FINDER_COLUMN_MT_MTD_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(messageTemplateDescId);

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		for (NotificationLog notificationLog :
				findByMT_MTD_CID(
					messageTemplateCode, messageTemplateDescId, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");

		FinderPath finderPath = _finderPathCountByMT_MTD_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, messageTemplateDescId, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATEDESCID_2);

			query.append(_FINDER_COLUMN_MT_MTD_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String _FINDER_COLUMN_MT_MTD_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_MTD_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_MTD_AAN_CID;
	private FinderPath _finderPathCountByMT_MTD_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		return findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end) {

		return findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_MTD_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, agentAccountNo,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_MTD_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, agentAccountNo,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_MTD_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_MTD_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, agentAccountNo, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_MTD_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, agentAccountNo, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_MTD_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(messageTemplateDescId);

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_MTD_AAN_CID(
					messageTemplateCode, messageTemplateDescId, agentAccountNo,
					companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_MTD_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_AAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String _FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_MT_MTD_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_MTD_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_MTD_CAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_MTD_CAN_CID;
	private FinderPath _finderPathCountByMT_MTD_CAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		return findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end) {

		return findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_MTD_CAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_MTD_CAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_MTD_CAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_MTD_CAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerAccountNo, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_MTD_CAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerAccountNo, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_MTD_CAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(messageTemplateDescId);

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_MTD_CAN_CID(
					messageTemplateCode, messageTemplateDescId,
					customerAccountNo, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_MTD_CAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_2 =
			"notificationLog.customerAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_CID_CUSTOMERACCOUNTNO_3 =
			"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_MTD_CAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_MTD_CSN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_MTD_CSN_CID;
	private FinderPath _finderPathCountByMT_MTD_CSN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		return findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end) {

		return findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_MTD_CSN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_MTD_CSN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					6 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CSN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CSN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CSN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CSN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CSN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CSN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_MTD_CSN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_MTD_CSN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerScreenName, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_MTD_CSN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerScreenName, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_MTD_CSN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				7 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(6);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(messageTemplateDescId);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_MTD_CSN_CID(
					messageTemplateCode, messageTemplateDescId,
					customerScreenName, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByMT_MTD_CSN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CSN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_2 =
			"notificationLog.customerScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_CID_CUSTOMERSCREENNAME_3 =
			"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_MT_MTD_CSN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_MTD_CAN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID;
	private FinderPath _finderPathCountByMT_MTD_CAN_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		return findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end) {

		return findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				agentAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_MTD_CAN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				agentAccountNo, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					7 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(7);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(
				_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CAN_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CAN_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CAN_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CAN_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CAN_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CAN_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_MTD_CAN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_MTD_CAN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerAccountNo, agentAccountNo,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_MTD_CAN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerAccountNo, agentAccountNo,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_MTD_CAN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				8 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(7);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(
				_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(
				_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(messageTemplateDescId);

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_MTD_CAN_AAN_CID(
					messageTemplateCode, messageTemplateDescId,
					customerAccountNo, agentAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_MTD_CAN_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(
				_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_2 =
			"notificationLog.customerAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_CUSTOMERACCOUNTNO_3 =
			"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_2 =
			"notificationLog.agentAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CAN_AAN_CID_AGENTACCOUNTNO_3 =
			"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_MTD_CAN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByMT_MTD_CSN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID;
	private FinderPath _finderPathCountByMT_MTD_CSN_AAN_CID;

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		return findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end) {

		return findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				agentAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByMT_MTD_CSN_AAN_CID;
			finderArgs = new Object[] {
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				agentAccountNo, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!messageTemplateCode.equals(
							notificationLog.getMessageTemplateCode()) ||
						(messageTemplateDescId !=
							notificationLog.getMessageTemplateDescId()) ||
						!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					7 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(7);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(
				_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CSN_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CSN_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CSN_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByMT_MTD_CSN_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByMT_MTD_CSN_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(12);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("messageTemplateCode=");
		msg.append(messageTemplateCode);

		msg.append(", messageTemplateDescId=");
		msg.append(messageTemplateDescId);

		msg.append(", customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByMT_MTD_CSN_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByMT_MTD_CSN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByMT_MTD_CSN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerScreenName, agentAccountNo,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByMT_MTD_CSN_AAN_CID_PrevAndNext(
				session, notificationLog, messageTemplateCode,
				messageTemplateDescId, customerScreenName, agentAccountNo,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByMT_MTD_CSN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				8 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(7);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindMessageTemplateCode = false;

		if (messageTemplateCode.isEmpty()) {
			query.append(
				_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_3);
		}
		else {
			bindMessageTemplateCode = true;

			query.append(
				_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(
				_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(
				_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindMessageTemplateCode) {
			qPos.add(messageTemplateCode);
		}

		qPos.add(messageTemplateDescId);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByMT_MTD_CSN_AAN_CID(
					messageTemplateCode, messageTemplateDescId,
					customerScreenName, agentAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		messageTemplateCode = Objects.toString(messageTemplateCode, "");
		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByMT_MTD_CSN_AAN_CID;

		Object[] finderArgs = new Object[] {
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(6);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindMessageTemplateCode = false;

			if (messageTemplateCode.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_3);
			}
			else {
				bindMessageTemplateCode = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_2);
			}

			query.append(
				_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(
					_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindMessageTemplateCode) {
					qPos.add(messageTemplateCode);
				}

				qPos.add(messageTemplateDescId);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_2 =
			"notificationLog.messageTemplateCode = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATECODE_3 =
			"(notificationLog.messageTemplateCode IS NULL OR notificationLog.messageTemplateCode = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_MESSAGETEMPLATEDESCID_2 =
			"notificationLog.messageTemplateDescId = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_2 =
			"notificationLog.customerScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_CUSTOMERSCREENNAME_3 =
			"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_2 =
			"notificationLog.agentAccountNo = ? AND ";

	private static final String
		_FINDER_COLUMN_MT_MTD_CSN_AAN_CID_AGENTACCOUNTNO_3 =
			"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_MT_MTD_CSN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByCAN_CID;
	private FinderPath _finderPathCountByCAN_CID;

	/**
	 * Returns all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId) {

		return findByCAN_CID(
			customerAccountNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end) {

		return findByCAN_CID(customerAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByCAN_CID(
			customerAccountNo, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerAccountNo = Objects.toString(customerAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCAN_CID;
			finderArgs = new Object[] {customerAccountNo, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCAN_CID;
			finderArgs = new Object[] {
				customerAccountNo, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_CAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCAN_CID_First(
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCAN_CID_First(
			customerAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCAN_CID_First(
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByCAN_CID(
			customerAccountNo, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCAN_CID_Last(
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCAN_CID_Last(
			customerAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCAN_CID_Last(
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByCAN_CID(customerAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByCAN_CID(
			customerAccountNo, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByCAN_CID_PrevAndNext(
			String notificationId, String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerAccountNo = Objects.toString(customerAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByCAN_CID_PrevAndNext(
				session, notificationLog, customerAccountNo, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByCAN_CID_PrevAndNext(
				session, notificationLog, customerAccountNo, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByCAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_CAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCAN_CID(String customerAccountNo, long companyId) {
		for (NotificationLog notificationLog :
				findByCAN_CID(
					customerAccountNo, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByCAN_CID(String customerAccountNo, long companyId) {
		customerAccountNo = Objects.toString(customerAccountNo, "");

		FinderPath finderPath = _finderPathCountByCAN_CID;

		Object[] finderArgs = new Object[] {customerAccountNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_CAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_2 =
		"notificationLog.customerAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_CAN_CID_CUSTOMERACCOUNTNO_3 =
		"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_CAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCSN_CID;
	private FinderPath _finderPathWithoutPaginationFindByCSN_CID;
	private FinderPath _finderPathCountByCSN_CID;

	/**
	 * Returns all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId) {

		return findByCSN_CID(
			customerScreenName, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end) {

		return findByCSN_CID(customerScreenName, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByCSN_CID(
			customerScreenName, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCSN_CID;
			finderArgs = new Object[] {customerScreenName, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCSN_CID;
			finderArgs = new Object[] {
				customerScreenName, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_CSN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCSN_CID_First(
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCSN_CID_First(
			customerScreenName, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCSN_CID_First(
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByCSN_CID(
			customerScreenName, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCSN_CID_Last(
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCSN_CID_Last(
			customerScreenName, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCSN_CID_Last(
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByCSN_CID(customerScreenName, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByCSN_CID(
			customerScreenName, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByCSN_CID_PrevAndNext(
			String notificationId, String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerScreenName = Objects.toString(customerScreenName, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByCSN_CID_PrevAndNext(
				session, notificationLog, customerScreenName, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByCSN_CID_PrevAndNext(
				session, notificationLog, customerScreenName, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByCSN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_2);
		}

		query.append(_FINDER_COLUMN_CSN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCSN_CID(String customerScreenName, long companyId) {
		for (NotificationLog notificationLog :
				findByCSN_CID(
					customerScreenName, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByCSN_CID(String customerScreenName, long companyId) {
		customerScreenName = Objects.toString(customerScreenName, "");

		FinderPath finderPath = _finderPathCountByCSN_CID;

		Object[] finderArgs = new Object[] {customerScreenName, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_2);
			}

			query.append(_FINDER_COLUMN_CSN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_2 =
		"notificationLog.customerScreenName = ? AND ";

	private static final String _FINDER_COLUMN_CSN_CID_CUSTOMERSCREENNAME_3 =
		"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_CSN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByAAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByAAN_CID;
	private FinderPath _finderPathCountByAAN_CID;

	/**
	 * Returns all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId) {

		return findByAAN_CID(
			agentAccountNo, companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end) {

		return findByAAN_CID(agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByAAN_CID(
			agentAccountNo, companyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByAAN_CID;
			finderArgs = new Object[] {agentAccountNo, companyId};
		}
		else {
			finderPath = _finderPathWithPaginationFindByAAN_CID;
			finderArgs = new Object[] {
				agentAccountNo, companyId, start, end, orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByAAN_CID_First(
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByAAN_CID_First(
			agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByAAN_CID_First(
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByAAN_CID(
			agentAccountNo, companyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByAAN_CID_Last(
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByAAN_CID_Last(
			agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByAAN_CID_Last(
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByAAN_CID(agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByAAN_CID(
			agentAccountNo, companyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByAAN_CID_PrevAndNext(
			String notificationId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByAAN_CID_PrevAndNext(
				session, notificationLog, agentAccountNo, companyId,
				orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByAAN_CID_PrevAndNext(
				session, notificationLog, agentAccountNo, companyId,
				orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByAAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog, String agentAccountNo,
		long companyId, OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(4);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByAAN_CID(String agentAccountNo, long companyId) {
		for (NotificationLog notificationLog :
				findByAAN_CID(
					agentAccountNo, companyId, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByAAN_CID(String agentAccountNo, long companyId) {
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByAAN_CID;

		Object[] finderArgs = new Object[] {agentAccountNo, companyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCAN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByCAN_AAN_CID;
	private FinderPath _finderPathCountByCAN_AAN_CID;

	/**
	 * Returns all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId) {

		return findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end) {

		return findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCAN_AAN_CID;
			finderArgs = new Object[] {
				customerAccountNo, agentAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCAN_AAN_CID;
			finderArgs = new Object[] {
				customerAccountNo, agentAccountNo, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!customerAccountNo.equals(
							notificationLog.getCustomerAccountNo()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_CAN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCAN_AAN_CID_First(
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCAN_AAN_CID_First(
			customerAccountNo, agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCAN_AAN_CID_First(
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCAN_AAN_CID_Last(
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCAN_AAN_CID_Last(
			customerAccountNo, agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerAccountNo=");
		msg.append(customerAccountNo);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCAN_AAN_CID_Last(
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByCAN_AAN_CID_PrevAndNext(
			String notificationId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByCAN_AAN_CID_PrevAndNext(
				session, notificationLog, customerAccountNo, agentAccountNo,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByCAN_AAN_CID_PrevAndNext(
				session, notificationLog, customerAccountNo, agentAccountNo,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByCAN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindCustomerAccountNo = false;

		if (customerAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
		}
		else {
			bindCustomerAccountNo = true;

			query.append(_FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_CAN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCustomerAccountNo) {
			qPos.add(customerAccountNo);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByCAN_AAN_CID(
					customerAccountNo, agentAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId) {

		customerAccountNo = Objects.toString(customerAccountNo, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByCAN_AAN_CID;

		Object[] finderArgs = new Object[] {
			customerAccountNo, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerAccountNo = false;

			if (customerAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_3);
			}
			else {
				bindCustomerAccountNo = true;

				query.append(_FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_CAN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerAccountNo) {
					qPos.add(customerAccountNo);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_2 =
		"notificationLog.customerAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_CAN_AAN_CID_CUSTOMERACCOUNTNO_3 =
		"(notificationLog.customerAccountNo IS NULL OR notificationLog.customerAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_CAN_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_CAN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	private FinderPath _finderPathWithPaginationFindByCSN_AAN_CID;
	private FinderPath _finderPathWithoutPaginationFindByCSN_AAN_CID;
	private FinderPath _finderPathCountByCSN_AAN_CID;

	/**
	 * Returns all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId) {

		return findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end) {

		return findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, start, end,
			orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	@Override
	public List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindByCSN_AAN_CID;
			finderArgs = new Object[] {
				customerScreenName, agentAccountNo, companyId
			};
		}
		else {
			finderPath = _finderPathWithPaginationFindByCSN_AAN_CID;
			finderArgs = new Object[] {
				customerScreenName, agentAccountNo, companyId, start, end,
				orderByComparator
			};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (NotificationLog notificationLog : list) {
					if (!customerScreenName.equals(
							notificationLog.getCustomerScreenName()) ||
						!agentAccountNo.equals(
							notificationLog.getAgentAccountNo()) ||
						(companyId != notificationLog.getCompanyId())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_CSN_AAN_CID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else if (pagination) {
				query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCSN_AAN_CID_First(
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCSN_AAN_CID_First(
			customerScreenName, agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCSN_AAN_CID_First(
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		List<NotificationLog> list = findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, 0, 1,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	@Override
	public NotificationLog findByCSN_AAN_CID_Last(
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByCSN_AAN_CID_Last(
			customerScreenName, agentAccountNo, companyId, orderByComparator);

		if (notificationLog != null) {
			return notificationLog;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("customerScreenName=");
		msg.append(customerScreenName);

		msg.append(", agentAccountNo=");
		msg.append(agentAccountNo);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append("}");

		throw new NoSuchNotificationLogException(msg.toString());
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	@Override
	public NotificationLog fetchByCSN_AAN_CID_Last(
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		int count = countByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId);

		if (count == 0) {
			return null;
		}

		List<NotificationLog> list = findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, count - 1, count,
			orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog[] findByCSN_AAN_CID_PrevAndNext(
			String notificationId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws NoSuchNotificationLogException {

		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		NotificationLog notificationLog = findByPrimaryKey(notificationId);

		Session session = null;

		try {
			session = openSession();

			NotificationLog[] array = new NotificationLogImpl[3];

			array[0] = getByCSN_AAN_CID_PrevAndNext(
				session, notificationLog, customerScreenName, agentAccountNo,
				companyId, orderByComparator, true);

			array[1] = notificationLog;

			array[2] = getByCSN_AAN_CID_PrevAndNext(
				session, notificationLog, customerScreenName, agentAccountNo,
				companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected NotificationLog getByCSN_AAN_CID_PrevAndNext(
		Session session, NotificationLog notificationLog,
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean previous) {

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(5);
		}

		query.append(_SQL_SELECT_NOTIFICATIONLOG_WHERE);

		boolean bindCustomerScreenName = false;

		if (customerScreenName.isEmpty()) {
			query.append(_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
		}
		else {
			bindCustomerScreenName = true;

			query.append(_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
		}

		boolean bindAgentAccountNo = false;

		if (agentAccountNo.isEmpty()) {
			query.append(_FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_3);
		}
		else {
			bindAgentAccountNo = true;

			query.append(_FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_2);
		}

		query.append(_FINDER_COLUMN_CSN_AAN_CID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(NotificationLogModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCustomerScreenName) {
			qPos.add(customerScreenName);
		}

		if (bindAgentAccountNo) {
			qPos.add(agentAccountNo);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						notificationLog)) {

				qPos.add(orderByConditionValue);
			}
		}

		List<NotificationLog> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	@Override
	public void removeByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId) {

		for (NotificationLog notificationLog :
				findByCSN_AAN_CID(
					customerScreenName, agentAccountNo, companyId,
					QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	@Override
	public int countByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId) {

		customerScreenName = Objects.toString(customerScreenName, "");
		agentAccountNo = Objects.toString(agentAccountNo, "");

		FinderPath finderPath = _finderPathCountByCSN_AAN_CID;

		Object[] finderArgs = new Object[] {
			customerScreenName, agentAccountNo, companyId
		};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_NOTIFICATIONLOG_WHERE);

			boolean bindCustomerScreenName = false;

			if (customerScreenName.isEmpty()) {
				query.append(_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_3);
			}
			else {
				bindCustomerScreenName = true;

				query.append(_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_2);
			}

			boolean bindAgentAccountNo = false;

			if (agentAccountNo.isEmpty()) {
				query.append(_FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_3);
			}
			else {
				bindAgentAccountNo = true;

				query.append(_FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_2);
			}

			query.append(_FINDER_COLUMN_CSN_AAN_CID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCustomerScreenName) {
					qPos.add(customerScreenName);
				}

				if (bindAgentAccountNo) {
					qPos.add(agentAccountNo);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_2 =
			"notificationLog.customerScreenName = ? AND ";

	private static final String
		_FINDER_COLUMN_CSN_AAN_CID_CUSTOMERSCREENNAME_3 =
			"(notificationLog.customerScreenName IS NULL OR notificationLog.customerScreenName = '') AND ";

	private static final String _FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_2 =
		"notificationLog.agentAccountNo = ? AND ";

	private static final String _FINDER_COLUMN_CSN_AAN_CID_AGENTACCOUNTNO_3 =
		"(notificationLog.agentAccountNo IS NULL OR notificationLog.agentAccountNo = '') AND ";

	private static final String _FINDER_COLUMN_CSN_AAN_CID_COMPANYID_2 =
		"notificationLog.companyId = ?";

	public NotificationLogPersistenceImpl() {
		setModelClass(NotificationLog.class);

		setModelImplClass(NotificationLogImpl.class);
		setModelPKClass(String.class);
	}

	/**
	 * Caches the notification log in the entity cache if it is enabled.
	 *
	 * @param notificationLog the notification log
	 */
	@Override
	public void cacheResult(NotificationLog notificationLog) {
		entityCache.putResult(
			entityCacheEnabled, NotificationLogImpl.class,
			notificationLog.getPrimaryKey(), notificationLog);

		notificationLog.resetOriginalValues();
	}

	/**
	 * Caches the notification logs in the entity cache if it is enabled.
	 *
	 * @param notificationLogs the notification logs
	 */
	@Override
	public void cacheResult(List<NotificationLog> notificationLogs) {
		for (NotificationLog notificationLog : notificationLogs) {
			if (entityCache.getResult(
					entityCacheEnabled, NotificationLogImpl.class,
					notificationLog.getPrimaryKey()) == null) {

				cacheResult(notificationLog);
			}
			else {
				notificationLog.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all notification logs.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(NotificationLogImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the notification log.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(NotificationLog notificationLog) {
		entityCache.removeResult(
			entityCacheEnabled, NotificationLogImpl.class,
			notificationLog.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<NotificationLog> notificationLogs) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (NotificationLog notificationLog : notificationLogs) {
			entityCache.removeResult(
				entityCacheEnabled, NotificationLogImpl.class,
				notificationLog.getPrimaryKey());
		}
	}

	/**
	 * Creates a new notification log with the primary key. Does not add the notification log to the database.
	 *
	 * @param notificationId the primary key for the new notification log
	 * @return the new notification log
	 */
	@Override
	public NotificationLog create(String notificationId) {
		NotificationLog notificationLog = new NotificationLogImpl();

		notificationLog.setNew(true);
		notificationLog.setPrimaryKey(notificationId);

		notificationLog.setCompanyId(companyProvider.getCompanyId());

		return notificationLog;
	}

	/**
	 * Removes the notification log with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log that was removed
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog remove(String notificationId)
		throws NoSuchNotificationLogException {

		return remove((Serializable)notificationId);
	}

	/**
	 * Removes the notification log with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the notification log
	 * @return the notification log that was removed
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog remove(Serializable primaryKey)
		throws NoSuchNotificationLogException {

		Session session = null;

		try {
			session = openSession();

			NotificationLog notificationLog = (NotificationLog)session.get(
				NotificationLogImpl.class, primaryKey);

			if (notificationLog == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchNotificationLogException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(notificationLog);
		}
		catch (NoSuchNotificationLogException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected NotificationLog removeImpl(NotificationLog notificationLog) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(notificationLog)) {
				notificationLog = (NotificationLog)session.get(
					NotificationLogImpl.class,
					notificationLog.getPrimaryKeyObj());
			}

			if (notificationLog != null) {
				session.delete(notificationLog);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (notificationLog != null) {
			clearCache(notificationLog);
		}

		return notificationLog;
	}

	@Override
	public NotificationLog updateImpl(NotificationLog notificationLog) {
		boolean isNew = notificationLog.isNew();

		if (!(notificationLog instanceof NotificationLogModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(notificationLog.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					notificationLog);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in notificationLog proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom NotificationLog implementation " +
					notificationLog.getClass());
		}

		NotificationLogModelImpl notificationLogModelImpl =
			(NotificationLogModelImpl)notificationLog;

		Session session = null;

		try {
			session = openSession();

			if (notificationLog.isNew()) {
				session.save(notificationLog);

				notificationLog.setNew(false);
			}
			else {
				notificationLog = (NotificationLog)session.merge(
					notificationLog);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCompanyId, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCompanyId, args);

			args = new Object[] {
				notificationLogModelImpl.getSendDate(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountBySendDate, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindBySendDate, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getSendDate(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_SD_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_SD_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_CAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_CAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_CSN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_CSN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_CAN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_CAN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_CSN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_CSN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMTD_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMTD_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMTD_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMTD_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMTD_CAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMTD_CAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMTD_CSN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMTD_CSN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMTD_CAN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMTD_CAN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMTD_CSN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMTD_CSN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_MTD_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_MTD_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_MTD_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_MTD_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_MTD_CAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_MTD_CAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByMT_MTD_CSN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_MTD_CSN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(
				_finderPathCountByMT_MTD_CAN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getMessageTemplateCode(),
				notificationLogModelImpl.getMessageTemplateDescId(),
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(
				_finderPathCountByMT_MTD_CSN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCSN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCSN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByAAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByAAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getCustomerAccountNo(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCAN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCAN_AAN_CID, args);

			args = new Object[] {
				notificationLogModelImpl.getCustomerScreenName(),
				notificationLogModelImpl.getAgentAccountNo(),
				notificationLogModelImpl.getCompanyId()
			};

			finderCache.removeResult(_finderPathCountByCSN_AAN_CID, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCSN_AAN_CID, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCompanyId.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);

				args = new Object[] {notificationLogModelImpl.getCompanyId()};

				finderCache.removeResult(_finderPathCountByCompanyId, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCompanyId, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindBySendDate.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalSendDate(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountBySendDate, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindBySendDate, args);

				args = new Object[] {
					notificationLogModelImpl.getSendDate(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountBySendDate, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindBySendDate, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_SD_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalSendDate(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_SD_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_SD_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getSendDate(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_SD_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_SD_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_CID.getColumnBitmask()) !=
					 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_CAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_CAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_CAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_CSN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_CSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CSN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_CSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CSN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_CAN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_CAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CAN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_CAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CAN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_CSN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_CSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CSN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_CSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_CSN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMTD_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMTD_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMTD_CAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_CAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_CAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMTD_CSN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_CSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CSN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMTD_CSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CSN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMTD_CAN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMTD_CAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CAN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMTD_CAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CAN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMTD_CSN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMTD_CSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CSN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMTD_CSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMTD_CSN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_MTD_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_MTD_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByMT_MTD_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_MTD_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_MTD_CAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_MTD_CSN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CSN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CSN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalMessageTemplateCode(),
					notificationLogModelImpl.getOriginalMessageTemplateDescId(),
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getMessageTemplateCode(),
					notificationLogModelImpl.getMessageTemplateDescId(),
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(
					_finderPathCountByMT_MTD_CSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCSN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCSN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCSN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCSN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByAAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByAAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByAAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCAN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalCustomerAccountNo(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCAN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getCustomerAccountNo(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCAN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCAN_AAN_CID, args);
			}

			if ((notificationLogModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCSN_AAN_CID.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					notificationLogModelImpl.getOriginalCustomerScreenName(),
					notificationLogModelImpl.getOriginalAgentAccountNo(),
					notificationLogModelImpl.getOriginalCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCSN_AAN_CID, args);

				args = new Object[] {
					notificationLogModelImpl.getCustomerScreenName(),
					notificationLogModelImpl.getAgentAccountNo(),
					notificationLogModelImpl.getCompanyId()
				};

				finderCache.removeResult(_finderPathCountByCSN_AAN_CID, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCSN_AAN_CID, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, NotificationLogImpl.class,
			notificationLog.getPrimaryKey(), notificationLog, false);

		notificationLog.resetOriginalValues();

		return notificationLog;
	}

	/**
	 * Returns the notification log with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the notification log
	 * @return the notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog findByPrimaryKey(Serializable primaryKey)
		throws NoSuchNotificationLogException {

		NotificationLog notificationLog = fetchByPrimaryKey(primaryKey);

		if (notificationLog == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchNotificationLogException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return notificationLog;
	}

	/**
	 * Returns the notification log with the primary key or throws a <code>NoSuchNotificationLogException</code> if it could not be found.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog findByPrimaryKey(String notificationId)
		throws NoSuchNotificationLogException {

		return findByPrimaryKey((Serializable)notificationId);
	}

	/**
	 * Returns the notification log with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log, or <code>null</code> if a notification log with the primary key could not be found
	 */
	@Override
	public NotificationLog fetchByPrimaryKey(String notificationId) {
		return fetchByPrimaryKey((Serializable)notificationId);
	}

	/**
	 * Returns all the notification logs.
	 *
	 * @return the notification logs
	 */
	@Override
	public List<NotificationLog> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of notification logs
	 */
	@Override
	public List<NotificationLog> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of notification logs
	 */
	@Override
	public List<NotificationLog> findAll(
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of notification logs
	 */
	@Override
	public List<NotificationLog> findAll(
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			pagination = false;
			finderPath = _finderPathWithoutPaginationFindAll;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<NotificationLog> list = null;

		if (retrieveFromCache) {
			list = (List<NotificationLog>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_NOTIFICATIONLOG);

				appendOrderByComparator(
					query, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_NOTIFICATIONLOG;

				if (pagination) {
					sql = sql.concat(NotificationLogModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<NotificationLog>)QueryUtil.list(
						q, getDialect(), start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the notification logs from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (NotificationLog notificationLog : findAll()) {
			remove(notificationLog);
		}
	}

	/**
	 * Returns the number of notification logs.
	 *
	 * @return the number of notification logs
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_NOTIFICATIONLOG);

				count = (Long)q.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "notificationId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_NOTIFICATIONLOG;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return NotificationLogModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the notification log persistence.
	 */
	@Activate
	public void activate() {
		NotificationLogModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		NotificationLogModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathWithPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] {Long.class.getName()},
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByCompanyId = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] {Long.class.getName()});

		_finderPathWithPaginationFindBySendDate = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBySendDate",
			new String[] {
				Date.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindBySendDate = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBySendDate",
			new String[] {Date.class.getName(), Long.class.getName()},
			NotificationLogModelImpl.SENDDATE_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountBySendDate = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBySendDate",
			new String[] {Date.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByMT_SD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_SD_CID",
			new String[] {
				String.class.getName(), Date.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_SD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_SD_CID",
			new String[] {
				String.class.getName(), Date.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.SENDDATE_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_SD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_SD_CID",
			new String[] {
				String.class.getName(), Date.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_CID",
			new String[] {String.class.getName(), Long.class.getName()},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_CID",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByMT_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_CAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_CAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_CAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_CSN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_CSN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_CSN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_CAN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_CAN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_CAN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_CSN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_CSN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_CSN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMTD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMTD_CID",
			new String[] {
				Long.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMTD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMTD_CID",
			new String[] {Long.class.getName(), Long.class.getName()},
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMTD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMTD_CID",
			new String[] {Long.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByMTD_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMTD_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMTD_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMTD_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMTD_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMTD_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMTD_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMTD_CAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMTD_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMTD_CAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMTD_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMTD_CAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMTD_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMTD_CSN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMTD_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMTD_CSN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMTD_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMTD_CSN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMTD_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMTD_CAN_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMTD_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMTD_CAN_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMTD_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMTD_CAN_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMTD_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMTD_CSN_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMTD_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMTD_CSN_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMTD_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMTD_CSN_AAN_CID",
			new String[] {
				Long.class.getName(), String.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_MTD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_MTD_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_MTD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_MTD_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_MTD_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_MTD_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_MTD_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_MTD_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_MTD_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_MTD_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_MTD_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_MTD_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_MTD_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_MTD_CAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_MTD_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_MTD_CAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_MTD_CAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_MTD_CAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_MTD_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_MTD_CSN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_MTD_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMT_MTD_CSN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_MTD_CSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMT_MTD_CSN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_MTD_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_MTD_CAN_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_MTD_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByMT_MTD_CAN_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_MTD_CAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByMT_MTD_CAN_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByMT_MTD_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMT_MTD_CSN_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByMT_MTD_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByMT_MTD_CSN_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.MESSAGETEMPLATECODE_COLUMN_BITMASK |
			NotificationLogModelImpl.MESSAGETEMPLATEDESCID_COLUMN_BITMASK |
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByMT_MTD_CSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByMT_MTD_CSN_AAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByCAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCAN_CID",
			new String[] {String.class.getName(), Long.class.getName()},
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByCAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCAN_CID",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByCSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCSN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCSN_CID",
			new String[] {String.class.getName(), Long.class.getName()},
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByCSN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCSN_CID",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByAAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAAN_CID",
			new String[] {
				String.class.getName(), Long.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByAAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAAN_CID",
			new String[] {String.class.getName(), Long.class.getName()},
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByAAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAAN_CID",
			new String[] {String.class.getName(), Long.class.getName()});

		_finderPathWithPaginationFindByCAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCAN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCAN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.CUSTOMERACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByCAN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCAN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});

		_finderPathWithPaginationFindByCSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCSN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, NotificationLogImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCSN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			},
			NotificationLogModelImpl.CUSTOMERSCREENNAME_COLUMN_BITMASK |
			NotificationLogModelImpl.AGENTACCOUNTNO_COLUMN_BITMASK |
			NotificationLogModelImpl.COMPANYID_COLUMN_BITMASK |
			NotificationLogModelImpl.CREATEDATE_COLUMN_BITMASK);

		_finderPathCountByCSN_AAN_CID = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCSN_AAN_CID",
			new String[] {
				String.class.getName(), String.class.getName(),
				Long.class.getName()
			});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(NotificationLogImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = ANPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.jio.account.notification.model.NotificationLog"),
			true);
	}

	@Override
	@Reference(
		target = ANPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = ANPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference(service = CompanyProviderWrapper.class)
	protected CompanyProvider companyProvider;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private Long _getTime(Date date) {
		if (date == null) {
			return null;
		}

		return date.getTime();
	}

	private static final String _SQL_SELECT_NOTIFICATIONLOG =
		"SELECT notificationLog FROM NotificationLog notificationLog";

	private static final String _SQL_SELECT_NOTIFICATIONLOG_WHERE =
		"SELECT notificationLog FROM NotificationLog notificationLog WHERE ";

	private static final String _SQL_COUNT_NOTIFICATIONLOG =
		"SELECT COUNT(notificationLog) FROM NotificationLog notificationLog";

	private static final String _SQL_COUNT_NOTIFICATIONLOG_WHERE =
		"SELECT COUNT(notificationLog) FROM NotificationLog notificationLog WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "notificationLog.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No NotificationLog exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No NotificationLog exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		NotificationLogPersistenceImpl.class);

}