/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.model.impl;

import com.jio.account.notification.model.NotificationLog;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The cache model class for representing NotificationLog in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class NotificationLogCacheModel
	implements CacheModel<NotificationLog>, Externalizable {

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof NotificationLogCacheModel)) {
			return false;
		}

		NotificationLogCacheModel notificationLogCacheModel =
			(NotificationLogCacheModel)obj;

		if (notificationId.equals(notificationLogCacheModel.notificationId)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, notificationId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(25);

		sb.append("{notificationId=");
		sb.append(notificationId);
		sb.append(", customerAccountNo=");
		sb.append(customerAccountNo);
		sb.append(", customerScreenName=");
		sb.append(customerScreenName);
		sb.append(", messageTemplateDescId=");
		sb.append(messageTemplateDescId);
		sb.append(", messageTemplateCode=");
		sb.append(messageTemplateCode);
		sb.append(", transactionNo=");
		sb.append(transactionNo);
		sb.append(", agentAccountNo=");
		sb.append(agentAccountNo);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createBy=");
		sb.append(createBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", sendDate=");
		sb.append(sendDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public NotificationLog toEntityModel() {
		NotificationLogImpl notificationLogImpl = new NotificationLogImpl();

		if (notificationId == null) {
			notificationLogImpl.setNotificationId("");
		}
		else {
			notificationLogImpl.setNotificationId(notificationId);
		}

		if (customerAccountNo == null) {
			notificationLogImpl.setCustomerAccountNo("");
		}
		else {
			notificationLogImpl.setCustomerAccountNo(customerAccountNo);
		}

		if (customerScreenName == null) {
			notificationLogImpl.setCustomerScreenName("");
		}
		else {
			notificationLogImpl.setCustomerScreenName(customerScreenName);
		}

		notificationLogImpl.setMessageTemplateDescId(messageTemplateDescId);

		if (messageTemplateCode == null) {
			notificationLogImpl.setMessageTemplateCode("");
		}
		else {
			notificationLogImpl.setMessageTemplateCode(messageTemplateCode);
		}

		if (transactionNo == null) {
			notificationLogImpl.setTransactionNo("");
		}
		else {
			notificationLogImpl.setTransactionNo(transactionNo);
		}

		if (agentAccountNo == null) {
			notificationLogImpl.setAgentAccountNo("");
		}
		else {
			notificationLogImpl.setAgentAccountNo(agentAccountNo);
		}

		notificationLogImpl.setGroupId(groupId);
		notificationLogImpl.setCompanyId(companyId);

		if (createBy == null) {
			notificationLogImpl.setCreateBy("");
		}
		else {
			notificationLogImpl.setCreateBy(createBy);
		}

		if (createDate == Long.MIN_VALUE) {
			notificationLogImpl.setCreateDate(null);
		}
		else {
			notificationLogImpl.setCreateDate(new Date(createDate));
		}

		if (sendDate == Long.MIN_VALUE) {
			notificationLogImpl.setSendDate(null);
		}
		else {
			notificationLogImpl.setSendDate(new Date(sendDate));
		}

		notificationLogImpl.resetOriginalValues();

		return notificationLogImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		notificationId = objectInput.readUTF();
		customerAccountNo = objectInput.readUTF();
		customerScreenName = objectInput.readUTF();

		messageTemplateDescId = objectInput.readLong();
		messageTemplateCode = objectInput.readUTF();
		transactionNo = objectInput.readUTF();
		agentAccountNo = objectInput.readUTF();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();
		createBy = objectInput.readUTF();
		createDate = objectInput.readLong();
		sendDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (notificationId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(notificationId);
		}

		if (customerAccountNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerAccountNo);
		}

		if (customerScreenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerScreenName);
		}

		objectOutput.writeLong(messageTemplateDescId);

		if (messageTemplateCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(messageTemplateCode);
		}

		if (transactionNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(transactionNo);
		}

		if (agentAccountNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(agentAccountNo);
		}

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		if (createBy == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(createBy);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(sendDate);
	}

	public String notificationId;
	public String customerAccountNo;
	public String customerScreenName;
	public long messageTemplateDescId;
	public String messageTemplateCode;
	public String transactionNo;
	public String agentAccountNo;
	public long groupId;
	public long companyId;
	public String createBy;
	public long createDate;
	public long sendDate;

}