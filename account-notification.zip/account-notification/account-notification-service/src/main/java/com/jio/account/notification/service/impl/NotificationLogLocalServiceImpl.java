/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.service.impl;

import com.jio.account.notification.model.NotificationLog;
import com.jio.account.notification.service.base.NotificationLogLocalServiceBaseImpl;
import com.liferay.portal.aop.AopService;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the notification log local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.jio.account.notification.service.NotificationLogLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see NotificationLogLocalServiceBaseImpl
 */
@Component(property = "model.class.name=com.jio.account.notification.model.NotificationLog", service = AopService.class)
public class NotificationLogLocalServiceImpl extends NotificationLogLocalServiceBaseImpl {

	@Override
	public NotificationLog addNotificationLog(NotificationLog notificationLog) {
		notificationLog.setCreateDate(new Date());
		return super.addNotificationLog(notificationLog);
	}

	public List<NotificationLog> getByCompanyId(long companyId, int start, int end) {
		return this.notificationLogPersistence.findByCompanyId(companyId, start, end);
	}

	public List<NotificationLog> getByCompanyId(long companyId) {
		return this.notificationLogPersistence.findByCompanyId(companyId);
	}

	public int getNotificationLogsCount(long companyId) {
		return this.notificationLogPersistence.countByCompanyId(companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, long companyId) {
		return this.notificationLogPersistence.findByMT_CID(messageTemplateCode, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_CID(messageTemplateCode, companyId, start, end);
	}

	public int getNotificationLogsCount(String messageTemplateCode, long companyId) {
		return this.notificationLogPersistence.countByMT_CID(messageTemplateCode, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, long messageTemplateDescId, long companyId) {
		return this.notificationLogPersistence.findByMT_MTD_CID(messageTemplateCode, messageTemplateDescId, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, long messageTemplateDescId, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_MTD_CID(messageTemplateCode, messageTemplateDescId, companyId, start, end);
	}

	public int getNotificationLogsCount(String messageTemplateCode, long messageTemplateDescId, long companyId) {
		return this.notificationLogPersistence.countByMT_MTD_CID(messageTemplateCode, messageTemplateDescId, companyId);
	}

	public List<NotificationLog> getNotificationLogs(long messageTemplateDescId, long companyId) {
		return this.notificationLogPersistence.findByMTD_CID(messageTemplateDescId, companyId);
	}

	public List<NotificationLog> getNotificationLogs(long messageTemplateDescId, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMTD_CID(messageTemplateDescId, companyId, start, end);
	}

	public int getNotificationLogsCount(long messageTemplateDescId, long companyId) {
		return this.notificationLogPersistence.countByMTD_CID(messageTemplateDescId, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_AAN_CID(messageTemplateCode, agentAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_AAN_CID(messageTemplateCode, agentAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCount(String messageTemplateCode, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_AAN_CID(messageTemplateCode, agentAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, long messageTemplateDescId, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_MTD_AAN_CID(messageTemplateCode, messageTemplateDescId, agentAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogs(String messageTemplateCode, long messageTemplateDescId, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_MTD_AAN_CID(messageTemplateCode, messageTemplateDescId, agentAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCount(String messageTemplateCode, long messageTemplateDescId, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_MTD_AAN_CID(messageTemplateCode, messageTemplateDescId, agentAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogs(long messageTemplateDescId, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMTD_AAN_CID(messageTemplateDescId, agentAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogs(long messageTemplateDescId, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMTD_AAN_CID(messageTemplateDescId, agentAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCount(long messageTemplateDescId, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMTD_AAN_CID(messageTemplateDescId, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByAgent(String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByAAN_CID(agentAccountNo, companyId);
	}

	public List<NotificationLog> getByAgent(String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByAAN_CID(agentAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCountByAgent(String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByAAN_CID(agentAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerScreenName(String messageTemplateCode, String customerScreenName, long companyId) {
		return this.notificationLogPersistence.findByMT_CSN_CID(messageTemplateCode, customerScreenName, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerScreenName(String messageTemplateCode, String customerScreenName, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_CSN_CID(messageTemplateCode, customerScreenName, companyId, start, end);
	}

	public int getNotificationLogsCountByCustomerScreenName(String messageTemplateCode, String customerScreenName, long companyId) {
		return this.notificationLogPersistence.countByMT_CSN_CID(messageTemplateCode, customerScreenName, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerScreenName(String messageTemplateCode, long messageTemplateDescId, String customerScreenName, long companyId) {
		return this.notificationLogPersistence.findByMT_MTD_CSN_CID(messageTemplateCode, messageTemplateDescId, customerScreenName, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerScreenName(String messageTemplateCode, long messageTemplateDescId, String customerScreenName, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_MTD_CSN_CID(messageTemplateCode, messageTemplateDescId, customerScreenName, companyId, start, end);
	}

	public int getNotificationLogsCountByCustomerScreenName(String messageTemplateCode, long messageTemplateDescId, String customerScreenName, long companyId) {
		return this.notificationLogPersistence.countByMT_MTD_CSN_CID(messageTemplateCode, messageTemplateDescId, customerScreenName, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerScreenName(long messageTemplateDescId, String customerScreenName, long companyId) {
		return this.notificationLogPersistence.findByMTD_CSN_CID(messageTemplateDescId, customerScreenName, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerScreenName(long messageTemplateDescId, String customerScreenName, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMTD_CSN_CID(messageTemplateDescId, customerScreenName, companyId, start, end);
	}

	public int getNotificationLogsCountByCustomerScreenName(long messageTemplateDescId, String customerScreenName, long companyId) {
		return this.notificationLogPersistence.countByMTD_CSN_CID(messageTemplateDescId, customerScreenName, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerAccountNo(String messageTemplateCode, String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_CAN_CID(messageTemplateCode, customerAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerAccountNo(String messageTemplateCode, String customerAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_CAN_CID(messageTemplateCode, customerAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCountByCustomerAccountNo(String messageTemplateCode, String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_CAN_CID(messageTemplateCode, customerAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerAccountNo(String messageTemplateCode, long messageTemplateDescId, String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_MTD_CAN_CID(messageTemplateCode, messageTemplateDescId, customerAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerAccountNo(String messageTemplateCode, long messageTemplateDescId, String customerAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_MTD_CAN_CID(messageTemplateCode, messageTemplateDescId, customerAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCountByCustomerAccountNo(String messageTemplateCode, long messageTemplateDescId, String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_MTD_CAN_CID(messageTemplateCode, messageTemplateDescId, customerAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerAccountNo(long messageTemplateDescId, String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMTD_CAN_CID(messageTemplateDescId, customerAccountNo, companyId);
	}

	public List<NotificationLog> getNotificationLogsByCustomerAccountNo(long messageTemplateDescId, String customerAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMTD_CAN_CID(messageTemplateDescId, customerAccountNo, companyId, start, end);
	}

	public int getNotificationLogsCountByCustomerAccountNo(long messageTemplateDescId, String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMTD_CAN_CID(messageTemplateDescId, customerAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String customerScreenName, long companyId) {
		return this.notificationLogPersistence.findByCSN_CID(customerScreenName, companyId);
	}

	public List<NotificationLog> getByCustomer(String customerScreenName, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByCSN_CID(customerScreenName, companyId);
	}

	public int countByCustomer(String customerScreenName, long companyId) {
		return this.notificationLogPersistence.countByCSN_CID(customerScreenName, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.findByCAN_CID(customerAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String customerAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByCAN_CID(customerAccountNo, companyId);
	}

	public int countByCustomerAccountNo(String customerAccountNo, long companyId) {
		return this.notificationLogPersistence.countByCAN_CID(customerAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByCSN_AAN_CID(customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String customerScreenName, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByCSN_AAN_CID(customerScreenName, agentAccountNo, companyId);
	}

	public int countByCustomer(String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByCSN_AAN_CID(customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByCAN_AAN_CID(customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String customerAccountNo, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByCAN_AAN_CID(customerAccountNo, agentAccountNo, companyId);
	}

	public int countByCustomerAccountNo(String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByCAN_AAN_CID(customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String messageTemplateCode, String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_CSN_AAN_CID(messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String messageTemplateCode, String customerScreenName, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_CSN_AAN_CID(messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	public int countByCustomer(String messageTemplateCode, String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_CSN_AAN_CID(messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String messageTemplateCode, String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_CAN_AAN_CID(messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String messageTemplateCode, String customerAccountNo, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_CAN_AAN_CID(messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	public int countByCustomerAccountNo(String messageTemplateCode, String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_CAN_AAN_CID(messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(long messageTemplateDescId, String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMTD_CSN_AAN_CID(messageTemplateDescId, customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(long messageTemplateDescId, String customerScreenName, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMTD_CSN_AAN_CID(messageTemplateDescId, customerScreenName, agentAccountNo, companyId);
	}

	public int countByCustomer(long messageTemplateDescId, String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMTD_CSN_AAN_CID(messageTemplateDescId, customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(long messageTemplateDescId, String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMTD_CAN_AAN_CID(messageTemplateDescId, customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(long messageTemplateDescId, String customerAccountNo, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMTD_CAN_AAN_CID(messageTemplateDescId, customerAccountNo, agentAccountNo, companyId);
	}

	public int countByCustomerAccountNo(long messageTemplateDescId, String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMTD_CAN_AAN_CID(messageTemplateDescId, customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String messageTemplateCode, long messageTemplateDescId, String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_MTD_CSN_AAN_CID(messageTemplateCode, messageTemplateDescId, customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomer(String messageTemplateCode, long messageTemplateDescId, String customerScreenName, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_MTD_CSN_AAN_CID(messageTemplateCode, messageTemplateDescId, customerScreenName, agentAccountNo, companyId);
	}

	public int countByCustomer(String messageTemplateCode, long messageTemplateDescId, String customerScreenName, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_MTD_CSN_AAN_CID(messageTemplateCode, messageTemplateDescId, customerScreenName, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String messageTemplateCode, long messageTemplateDescId, String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.findByMT_MTD_CAN_AAN_CID(messageTemplateCode, messageTemplateDescId, customerAccountNo, agentAccountNo, companyId);
	}

	public List<NotificationLog> getByCustomerAccountNo(String messageTemplateCode, long messageTemplateDescId, String customerAccountNo, String agentAccountNo, long companyId, int start, int end) {
		return this.notificationLogPersistence.findByMT_MTD_CAN_AAN_CID(messageTemplateCode, messageTemplateDescId, customerAccountNo, agentAccountNo, companyId);
	}

	public int countByCustomerAccountNo(String messageTemplateCode, long messageTemplateDescId, String customerAccountNo, String agentAccountNo, long companyId) {
		return this.notificationLogPersistence.countByMT_MTD_CAN_AAN_CID(messageTemplateCode, messageTemplateDescId, customerAccountNo, agentAccountNo, companyId);
	}

}