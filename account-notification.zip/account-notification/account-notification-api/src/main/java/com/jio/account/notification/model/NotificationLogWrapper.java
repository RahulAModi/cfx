/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link NotificationLog}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see NotificationLog
 * @generated
 */
@ProviderType
public class NotificationLogWrapper
	extends BaseModelWrapper<NotificationLog>
	implements NotificationLog, ModelWrapper<NotificationLog> {

	public NotificationLogWrapper(NotificationLog notificationLog) {
		super(notificationLog);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("notificationId", getNotificationId());
		attributes.put("customerAccountNo", getCustomerAccountNo());
		attributes.put("customerScreenName", getCustomerScreenName());
		attributes.put("messageTemplateDescId", getMessageTemplateDescId());
		attributes.put("messageTemplateCode", getMessageTemplateCode());
		attributes.put("transactionNo", getTransactionNo());
		attributes.put("agentAccountNo", getAgentAccountNo());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createBy", getCreateBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("sendDate", getSendDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String notificationId = (String)attributes.get("notificationId");

		if (notificationId != null) {
			setNotificationId(notificationId);
		}

		String customerAccountNo = (String)attributes.get("customerAccountNo");

		if (customerAccountNo != null) {
			setCustomerAccountNo(customerAccountNo);
		}

		String customerScreenName = (String)attributes.get(
			"customerScreenName");

		if (customerScreenName != null) {
			setCustomerScreenName(customerScreenName);
		}

		Long messageTemplateDescId = (Long)attributes.get(
			"messageTemplateDescId");

		if (messageTemplateDescId != null) {
			setMessageTemplateDescId(messageTemplateDescId);
		}

		String messageTemplateCode = (String)attributes.get(
			"messageTemplateCode");

		if (messageTemplateCode != null) {
			setMessageTemplateCode(messageTemplateCode);
		}

		String transactionNo = (String)attributes.get("transactionNo");

		if (transactionNo != null) {
			setTransactionNo(transactionNo);
		}

		String agentAccountNo = (String)attributes.get("agentAccountNo");

		if (agentAccountNo != null) {
			setAgentAccountNo(agentAccountNo);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String createBy = (String)attributes.get("createBy");

		if (createBy != null) {
			setCreateBy(createBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date sendDate = (Date)attributes.get("sendDate");

		if (sendDate != null) {
			setSendDate(sendDate);
		}
	}

	/**
	 * Returns the agent account no of this notification log.
	 *
	 * @return the agent account no of this notification log
	 */
	@Override
	public String getAgentAccountNo() {
		return model.getAgentAccountNo();
	}

	/**
	 * Returns the company ID of this notification log.
	 *
	 * @return the company ID of this notification log
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the create by of this notification log.
	 *
	 * @return the create by of this notification log
	 */
	@Override
	public String getCreateBy() {
		return model.getCreateBy();
	}

	/**
	 * Returns the create date of this notification log.
	 *
	 * @return the create date of this notification log
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the customer account no of this notification log.
	 *
	 * @return the customer account no of this notification log
	 */
	@Override
	public String getCustomerAccountNo() {
		return model.getCustomerAccountNo();
	}

	/**
	 * Returns the customer screen name of this notification log.
	 *
	 * @return the customer screen name of this notification log
	 */
	@Override
	public String getCustomerScreenName() {
		return model.getCustomerScreenName();
	}

	/**
	 * Returns the group ID of this notification log.
	 *
	 * @return the group ID of this notification log
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the message template code of this notification log.
	 *
	 * @return the message template code of this notification log
	 */
	@Override
	public String getMessageTemplateCode() {
		return model.getMessageTemplateCode();
	}

	/**
	 * Returns the message template desc ID of this notification log.
	 *
	 * @return the message template desc ID of this notification log
	 */
	@Override
	public long getMessageTemplateDescId() {
		return model.getMessageTemplateDescId();
	}

	/**
	 * Returns the notification ID of this notification log.
	 *
	 * @return the notification ID of this notification log
	 */
	@Override
	public String getNotificationId() {
		return model.getNotificationId();
	}

	/**
	 * Returns the primary key of this notification log.
	 *
	 * @return the primary key of this notification log
	 */
	@Override
	public String getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the send date of this notification log.
	 *
	 * @return the send date of this notification log
	 */
	@Override
	public Date getSendDate() {
		return model.getSendDate();
	}

	/**
	 * Returns the transaction no of this notification log.
	 *
	 * @return the transaction no of this notification log
	 */
	@Override
	public String getTransactionNo() {
		return model.getTransactionNo();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the agent account no of this notification log.
	 *
	 * @param agentAccountNo the agent account no of this notification log
	 */
	@Override
	public void setAgentAccountNo(String agentAccountNo) {
		model.setAgentAccountNo(agentAccountNo);
	}

	/**
	 * Sets the company ID of this notification log.
	 *
	 * @param companyId the company ID of this notification log
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the create by of this notification log.
	 *
	 * @param createBy the create by of this notification log
	 */
	@Override
	public void setCreateBy(String createBy) {
		model.setCreateBy(createBy);
	}

	/**
	 * Sets the create date of this notification log.
	 *
	 * @param createDate the create date of this notification log
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the customer account no of this notification log.
	 *
	 * @param customerAccountNo the customer account no of this notification log
	 */
	@Override
	public void setCustomerAccountNo(String customerAccountNo) {
		model.setCustomerAccountNo(customerAccountNo);
	}

	/**
	 * Sets the customer screen name of this notification log.
	 *
	 * @param customerScreenName the customer screen name of this notification log
	 */
	@Override
	public void setCustomerScreenName(String customerScreenName) {
		model.setCustomerScreenName(customerScreenName);
	}

	/**
	 * Sets the group ID of this notification log.
	 *
	 * @param groupId the group ID of this notification log
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the message template code of this notification log.
	 *
	 * @param messageTemplateCode the message template code of this notification log
	 */
	@Override
	public void setMessageTemplateCode(String messageTemplateCode) {
		model.setMessageTemplateCode(messageTemplateCode);
	}

	/**
	 * Sets the message template desc ID of this notification log.
	 *
	 * @param messageTemplateDescId the message template desc ID of this notification log
	 */
	@Override
	public void setMessageTemplateDescId(long messageTemplateDescId) {
		model.setMessageTemplateDescId(messageTemplateDescId);
	}

	/**
	 * Sets the notification ID of this notification log.
	 *
	 * @param notificationId the notification ID of this notification log
	 */
	@Override
	public void setNotificationId(String notificationId) {
		model.setNotificationId(notificationId);
	}

	/**
	 * Sets the primary key of this notification log.
	 *
	 * @param primaryKey the primary key of this notification log
	 */
	@Override
	public void setPrimaryKey(String primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the send date of this notification log.
	 *
	 * @param sendDate the send date of this notification log
	 */
	@Override
	public void setSendDate(Date sendDate) {
		model.setSendDate(sendDate);
	}

	/**
	 * Sets the transaction no of this notification log.
	 *
	 * @param transactionNo the transaction no of this notification log
	 */
	@Override
	public void setTransactionNo(String transactionNo) {
		model.setTransactionNo(transactionNo);
	}

	@Override
	protected NotificationLogWrapper wrap(NotificationLog notificationLog) {
		return new NotificationLogWrapper(notificationLog);
	}

}