/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@ProviderType
public class NotificationLogSoap implements Serializable {

	public static NotificationLogSoap toSoapModel(NotificationLog model) {
		NotificationLogSoap soapModel = new NotificationLogSoap();

		soapModel.setNotificationId(model.getNotificationId());
		soapModel.setCustomerAccountNo(model.getCustomerAccountNo());
		soapModel.setCustomerScreenName(model.getCustomerScreenName());
		soapModel.setMessageTemplateDescId(model.getMessageTemplateDescId());
		soapModel.setMessageTemplateCode(model.getMessageTemplateCode());
		soapModel.setTransactionNo(model.getTransactionNo());
		soapModel.setAgentAccountNo(model.getAgentAccountNo());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateBy(model.getCreateBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setSendDate(model.getSendDate());

		return soapModel;
	}

	public static NotificationLogSoap[] toSoapModels(NotificationLog[] models) {
		NotificationLogSoap[] soapModels =
			new NotificationLogSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static NotificationLogSoap[][] toSoapModels(
		NotificationLog[][] models) {

		NotificationLogSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels =
				new NotificationLogSoap[models.length][models[0].length];
		}
		else {
			soapModels = new NotificationLogSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static NotificationLogSoap[] toSoapModels(
		List<NotificationLog> models) {

		List<NotificationLogSoap> soapModels =
			new ArrayList<NotificationLogSoap>(models.size());

		for (NotificationLog model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new NotificationLogSoap[soapModels.size()]);
	}

	public NotificationLogSoap() {
	}

	public String getPrimaryKey() {
		return _notificationId;
	}

	public void setPrimaryKey(String pk) {
		setNotificationId(pk);
	}

	public String getNotificationId() {
		return _notificationId;
	}

	public void setNotificationId(String notificationId) {
		_notificationId = notificationId;
	}

	public String getCustomerAccountNo() {
		return _customerAccountNo;
	}

	public void setCustomerAccountNo(String customerAccountNo) {
		_customerAccountNo = customerAccountNo;
	}

	public String getCustomerScreenName() {
		return _customerScreenName;
	}

	public void setCustomerScreenName(String customerScreenName) {
		_customerScreenName = customerScreenName;
	}

	public long getMessageTemplateDescId() {
		return _messageTemplateDescId;
	}

	public void setMessageTemplateDescId(long messageTemplateDescId) {
		_messageTemplateDescId = messageTemplateDescId;
	}

	public String getMessageTemplateCode() {
		return _messageTemplateCode;
	}

	public void setMessageTemplateCode(String messageTemplateCode) {
		_messageTemplateCode = messageTemplateCode;
	}

	public String getTransactionNo() {
		return _transactionNo;
	}

	public void setTransactionNo(String transactionNo) {
		_transactionNo = transactionNo;
	}

	public String getAgentAccountNo() {
		return _agentAccountNo;
	}

	public void setAgentAccountNo(String agentAccountNo) {
		_agentAccountNo = agentAccountNo;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public String getCreateBy() {
		return _createBy;
	}

	public void setCreateBy(String createBy) {
		_createBy = createBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getSendDate() {
		return _sendDate;
	}

	public void setSendDate(Date sendDate) {
		_sendDate = sendDate;
	}

	private String _notificationId;
	private String _customerAccountNo;
	private String _customerScreenName;
	private long _messageTemplateDescId;
	private String _messageTemplateCode;
	private String _transactionNo;
	private String _agentAccountNo;
	private long _groupId;
	private long _companyId;
	private String _createBy;
	private Date _createDate;
	private Date _sendDate;

}