/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.service.persistence;

import com.jio.account.notification.exception.NoSuchNotificationLogException;
import com.jio.account.notification.model.NotificationLog;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the notification log service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see NotificationLogUtil
 * @generated
 */
@ProviderType
public interface NotificationLogPersistence
	extends BasePersistence<NotificationLog> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link NotificationLogUtil} to access the notification log persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the notification logs where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByCompanyId(long companyId);

	/**
	 * Returns a range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCompanyId(
		long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCompanyId_First(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCompanyId_Last(
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByCompanyId_PrevAndNext(
			String notificationId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public void removeByCompanyId(long companyId);

	/**
	 * Returns the number of notification logs where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByCompanyId(long companyId);

	/**
	 * Returns all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findBySendDate(
		Date sendDate, long companyId);

	/**
	 * Returns a range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findBySendDate_First(
			Date sendDate, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchBySendDate_First(
		Date sendDate, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findBySendDate_Last(
			Date sendDate, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchBySendDate_Last(
		Date sendDate, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findBySendDate_PrevAndNext(
			String notificationId, Date sendDate, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where sendDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 */
	public void removeBySendDate(Date sendDate, long companyId);

	/**
	 * Returns the number of notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countBySendDate(Date sendDate, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_SD_CID_First(
			String messageTemplateCode, Date sendDate, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_SD_CID_First(
		String messageTemplateCode, Date sendDate, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_SD_CID_Last(
			String messageTemplateCode, Date sendDate, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_SD_CID_Last(
		String messageTemplateCode, Date sendDate, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_SD_CID_PrevAndNext(
			String notificationId, String messageTemplateCode, Date sendDate,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 */
	public void removeByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CID_First(
			String messageTemplateCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CID_First(
		String messageTemplateCode, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CID_Last(
			String messageTemplateCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CID_Last(
		String messageTemplateCode, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_CID_PrevAndNext(
			String notificationId, String messageTemplateCode, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 */
	public void removeByMT_CID(String messageTemplateCode, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_CID(String messageTemplateCode, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_AAN_CID_First(
			String messageTemplateCode, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_AAN_CID_First(
		String messageTemplateCode, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_AAN_CID_Last(
			String messageTemplateCode, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_AAN_CID_Last(
		String messageTemplateCode, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CAN_CID_First(
			String messageTemplateCode, String customerAccountNo,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CAN_CID_First(
		String messageTemplateCode, String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CAN_CID_Last(
			String messageTemplateCode, String customerAccountNo,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CAN_CID_Last(
		String messageTemplateCode, String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_CAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public void removeByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CSN_CID_First(
			String messageTemplateCode, String customerScreenName,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CSN_CID_First(
		String messageTemplateCode, String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CSN_CID_Last(
			String messageTemplateCode, String customerScreenName,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CSN_CID_Last(
		String messageTemplateCode, String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_CSN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public void removeByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CAN_AAN_CID_First(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CAN_AAN_CID_First(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CAN_AAN_CID_Last(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CAN_AAN_CID_Last(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_CAN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerAccountNo, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CSN_AAN_CID_First(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CSN_AAN_CID_First(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_CSN_AAN_CID_Last(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_CSN_AAN_CID_Last(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_CSN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerScreenName, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CID_First(
			long messageTemplateDescId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CID_First(
		long messageTemplateDescId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CID_Last(
			long messageTemplateDescId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CID_Last(
		long messageTemplateDescId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMTD_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 */
	public void removeByMTD_CID(long messageTemplateDescId, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMTD_CID(long messageTemplateDescId, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_AAN_CID_First(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_AAN_CID_First(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_AAN_CID_Last(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_AAN_CID_Last(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMTD_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CAN_CID_First(
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CAN_CID_First(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CAN_CID_Last(
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CAN_CID_Last(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMTD_CAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public void removeByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CSN_CID_First(
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CSN_CID_First(
		long messageTemplateDescId, String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CSN_CID_Last(
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CSN_CID_Last(
		long messageTemplateDescId, String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMTD_CSN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public void removeByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CAN_AAN_CID_First(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CAN_AAN_CID_First(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CAN_AAN_CID_Last(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CAN_AAN_CID_Last(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMTD_CAN_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CSN_AAN_CID_First(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CSN_AAN_CID_First(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMTD_CSN_AAN_CID_Last(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMTD_CSN_AAN_CID_Last(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMTD_CSN_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CID_First(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CID_Last(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_MTD_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 */
	public void removeByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_MTD_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_MTD_CAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public void removeByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CSN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CSN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CSN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CSN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_MTD_CSN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public void removeByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CAN_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CAN_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CAN_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CAN_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_MTD_CAN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CSN_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CSN_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByMT_MTD_CSN_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByMT_MTD_CSN_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByMT_MTD_CSN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCAN_CID_First(
			String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCAN_CID_First(
		String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCAN_CID_Last(
			String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCAN_CID_Last(
		String customerAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByCAN_CID_PrevAndNext(
			String notificationId, String customerAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public void removeByCAN_CID(String customerAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByCAN_CID(String customerAccountNo, long companyId);

	/**
	 * Returns all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId);

	/**
	 * Returns a range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCSN_CID_First(
			String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCSN_CID_First(
		String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCSN_CID_Last(
			String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCSN_CID_Last(
		String customerScreenName, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByCSN_CID_PrevAndNext(
			String notificationId, String customerScreenName, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public void removeByCSN_CID(String customerScreenName, long companyId);

	/**
	 * Returns the number of notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByCSN_CID(String customerScreenName, long companyId);

	/**
	 * Returns all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByAAN_CID_First(
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByAAN_CID_First(
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByAAN_CID_Last(
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByAAN_CID_Last(
		String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByAAN_CID_PrevAndNext(
			String notificationId, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByAAN_CID(String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByAAN_CID(String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCAN_AAN_CID_First(
			String customerAccountNo, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCAN_AAN_CID_First(
		String customerAccountNo, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCAN_AAN_CID_Last(
			String customerAccountNo, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCAN_AAN_CID_Last(
		String customerAccountNo, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByCAN_AAN_CID_PrevAndNext(
			String notificationId, String customerAccountNo,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId);

	/**
	 * Returns all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId);

	/**
	 * Returns a range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end);

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public java.util.List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCSN_AAN_CID_First(
			String customerScreenName, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCSN_AAN_CID_First(
		String customerScreenName, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public NotificationLog findByCSN_AAN_CID_Last(
			String customerScreenName, String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public NotificationLog fetchByCSN_AAN_CID_Last(
		String customerScreenName, String agentAccountNo, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog[] findByCSN_AAN_CID_PrevAndNext(
			String notificationId, String customerScreenName,
			String agentAccountNo, long companyId,
			com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
				orderByComparator)
		throws NoSuchNotificationLogException;

	/**
	 * Removes all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public void removeByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId);

	/**
	 * Returns the number of notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public int countByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId);

	/**
	 * Caches the notification log in the entity cache if it is enabled.
	 *
	 * @param notificationLog the notification log
	 */
	public void cacheResult(NotificationLog notificationLog);

	/**
	 * Caches the notification logs in the entity cache if it is enabled.
	 *
	 * @param notificationLogs the notification logs
	 */
	public void cacheResult(java.util.List<NotificationLog> notificationLogs);

	/**
	 * Creates a new notification log with the primary key. Does not add the notification log to the database.
	 *
	 * @param notificationId the primary key for the new notification log
	 * @return the new notification log
	 */
	public NotificationLog create(String notificationId);

	/**
	 * Removes the notification log with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log that was removed
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog remove(String notificationId)
		throws NoSuchNotificationLogException;

	public NotificationLog updateImpl(NotificationLog notificationLog);

	/**
	 * Returns the notification log with the primary key or throws a <code>NoSuchNotificationLogException</code> if it could not be found.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public NotificationLog findByPrimaryKey(String notificationId)
		throws NoSuchNotificationLogException;

	/**
	 * Returns the notification log with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log, or <code>null</code> if a notification log with the primary key could not be found
	 */
	public NotificationLog fetchByPrimaryKey(String notificationId);

	/**
	 * Returns all the notification logs.
	 *
	 * @return the notification logs
	 */
	public java.util.List<NotificationLog> findAll();

	/**
	 * Returns a range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of notification logs
	 */
	public java.util.List<NotificationLog> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of notification logs
	 */
	public java.util.List<NotificationLog> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator);

	/**
	 * Returns an ordered range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of notification logs
	 */
	public java.util.List<NotificationLog> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<NotificationLog>
			orderByComparator,
		boolean retrieveFromCache);

	/**
	 * Removes all the notification logs from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of notification logs.
	 *
	 * @return the number of notification logs
	 */
	public int countAll();

}