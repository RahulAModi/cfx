/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.service;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the local service utility for NotificationLog. This utility wraps
 * <code>com.jio.account.notification.service.impl.NotificationLogLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see NotificationLogLocalService
 * @generated
 */
@ProviderType
public class NotificationLogLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.jio.account.notification.service.impl.NotificationLogLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the notification log to the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationLog the notification log
	 * @return the notification log that was added
	 */
	public static com.jio.account.notification.model.NotificationLog
		addNotificationLog(
			com.jio.account.notification.model.NotificationLog
				notificationLog) {

		return getService().addNotificationLog(notificationLog);
	}

	public static int countByCustomer(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		return getService().countByCustomer(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	public static int countByCustomer(
		String customerScreenName, long companyId) {

		return getService().countByCustomer(customerScreenName, companyId);
	}

	public static int countByCustomer(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		return getService().countByCustomer(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	public static int countByCustomer(
		String customerScreenName, String agentAccountNo, long companyId) {

		return getService().countByCustomer(
			customerScreenName, agentAccountNo, companyId);
	}

	public static int countByCustomer(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		return getService().countByCustomer(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	public static int countByCustomerAccountNo(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return getService().countByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	public static int countByCustomerAccountNo(
		String customerAccountNo, long companyId) {

		return getService().countByCustomerAccountNo(
			customerAccountNo, companyId);
	}

	public static int countByCustomerAccountNo(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		return getService().countByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	public static int countByCustomerAccountNo(
		String customerAccountNo, String agentAccountNo, long companyId) {

		return getService().countByCustomerAccountNo(
			customerAccountNo, agentAccountNo, companyId);
	}

	public static int countByCustomerAccountNo(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return getService().countByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Creates a new notification log with the primary key. Does not add the notification log to the database.
	 *
	 * @param notificationId the primary key for the new notification log
	 * @return the new notification log
	 */
	public static com.jio.account.notification.model.NotificationLog
		createNotificationLog(String notificationId) {

		return getService().createNotificationLog(notificationId);
	}

	/**
	 * Deletes the notification log from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationLog the notification log
	 * @return the notification log that was removed
	 */
	public static com.jio.account.notification.model.NotificationLog
		deleteNotificationLog(
			com.jio.account.notification.model.NotificationLog
				notificationLog) {

		return getService().deleteNotificationLog(notificationLog);
	}

	/**
	 * Deletes the notification log with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log that was removed
	 * @throws PortalException if a notification log with the primary key could not be found
	 */
	public static com.jio.account.notification.model.NotificationLog
			deleteNotificationLog(String notificationId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deleteNotificationLog(notificationId);
	}

	/**
	 * @throws PortalException
	 */
	public static com.liferay.portal.kernel.model.PersistedModel
			deletePersistedModel(
				com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery
		dynamicQuery() {

		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.notification.model.impl.NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.notification.model.impl.NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.account.notification.model.NotificationLog
		fetchNotificationLog(String notificationId) {

		return getService().fetchNotificationLog(notificationId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByAgent(
			String agentAccountNo, long companyId) {

		return getService().getByAgent(agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByAgent(
			String agentAccountNo, long companyId, int start, int end) {

		return getService().getByAgent(agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCompanyId(
			long companyId) {

		return getService().getByCompanyId(companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCompanyId(
			long companyId, int start, int end) {

		return getService().getByCompanyId(companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId) {

		return getService().getByCustomer(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId, int start, int end) {

		return getService().getByCustomer(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String customerScreenName, long companyId) {

		return getService().getByCustomer(customerScreenName, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String customerScreenName, long companyId, int start, int end) {

		return getService().getByCustomer(
			customerScreenName, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId) {

		return getService().getByCustomer(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			int start, int end) {

		return getService().getByCustomer(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String customerScreenName, String agentAccountNo, long companyId) {

		return getService().getByCustomer(
			customerScreenName, agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String customerScreenName, String agentAccountNo, long companyId,
			int start, int end) {

		return getService().getByCustomer(
			customerScreenName, agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId) {

		return getService().getByCustomer(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog> getByCustomer(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId, int start, int end) {

		return getService().getByCustomer(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				long messageTemplateDescId, String customerAccountNo,
				String agentAccountNo, long companyId) {

		return getService().getByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				long messageTemplateDescId, String customerAccountNo,
				String agentAccountNo, long companyId, int start, int end) {

		return getService().getByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(String customerAccountNo, long companyId) {

		return getService().getByCustomerAccountNo(
			customerAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String customerAccountNo, long companyId, int start, int end) {

		return getService().getByCustomerAccountNo(
			customerAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String messageTemplateCode, long messageTemplateDescId,
				String customerAccountNo, String agentAccountNo,
				long companyId) {

		return getService().getByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String messageTemplateCode, long messageTemplateDescId,
				String customerAccountNo, String agentAccountNo, long companyId,
				int start, int end) {

		return getService().getByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String customerAccountNo, String agentAccountNo,
				long companyId) {

		return getService().getByCustomerAccountNo(
			customerAccountNo, agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String customerAccountNo, String agentAccountNo, long companyId,
				int start, int end) {

		return getService().getByCustomerAccountNo(
			customerAccountNo, agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String messageTemplateCode, String customerAccountNo,
				String agentAccountNo, long companyId) {

		return getService().getByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getByCustomerAccountNo(
				String messageTemplateCode, String customerAccountNo,
				String agentAccountNo, long companyId, int start, int end) {

		return getService().getByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end);
	}

	/**
	 * Returns the notification log with the primary key.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log
	 * @throws PortalException if a notification log with the primary key could not be found
	 */
	public static com.jio.account.notification.model.NotificationLog
			getNotificationLog(String notificationId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getNotificationLog(notificationId);
	}

	/**
	 * Returns a range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.notification.model.impl.NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of notification logs
	 */
	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(int start, int end) {

		return getService().getNotificationLogs(start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(long messageTemplateDescId, long companyId) {

		return getService().getNotificationLogs(
			messageTemplateDescId, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				long messageTemplateDescId, long companyId, int start,
				int end) {

		return getService().getNotificationLogs(
			messageTemplateDescId, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				long messageTemplateDescId, String agentAccountNo,
				long companyId) {

		return getService().getNotificationLogs(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				long messageTemplateDescId, String agentAccountNo,
				long companyId, int start, int end) {

		return getService().getNotificationLogs(
			messageTemplateDescId, agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(String messageTemplateCode, long companyId) {

		return getService().getNotificationLogs(messageTemplateCode, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, long companyId, int start,
				int end) {

		return getService().getNotificationLogs(
			messageTemplateCode, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, long messageTemplateDescId,
				long companyId) {

		return getService().getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, long messageTemplateDescId,
				long companyId, int start, int end) {

		return getService().getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, long messageTemplateDescId,
				String agentAccountNo, long companyId) {

		return getService().getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, long messageTemplateDescId,
				String agentAccountNo, long companyId, int start, int end) {

		return getService().getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, String agentAccountNo,
				long companyId) {

		return getService().getNotificationLogs(
			messageTemplateCode, agentAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogs(
				String messageTemplateCode, String agentAccountNo,
				long companyId, int start, int end) {

		return getService().getNotificationLogs(
			messageTemplateCode, agentAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerAccountNo(
				long messageTemplateDescId, String customerAccountNo,
				long companyId) {

		return getService().getNotificationLogsByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerAccountNo(
				long messageTemplateDescId, String customerAccountNo,
				long companyId, int start, int end) {

		return getService().getNotificationLogsByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerAccountNo(
				String messageTemplateCode, long messageTemplateDescId,
				String customerAccountNo, long companyId) {

		return getService().getNotificationLogsByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerAccountNo(
				String messageTemplateCode, long messageTemplateDescId,
				String customerAccountNo, long companyId, int start, int end) {

		return getService().getNotificationLogsByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerAccountNo(
				String messageTemplateCode, String customerAccountNo,
				long companyId) {

		return getService().getNotificationLogsByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerAccountNo(
				String messageTemplateCode, String customerAccountNo,
				long companyId, int start, int end) {

		return getService().getNotificationLogsByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerScreenName(
				long messageTemplateDescId, String customerScreenName,
				long companyId) {

		return getService().getNotificationLogsByCustomerScreenName(
			messageTemplateDescId, customerScreenName, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerScreenName(
				long messageTemplateDescId, String customerScreenName,
				long companyId, int start, int end) {

		return getService().getNotificationLogsByCustomerScreenName(
			messageTemplateDescId, customerScreenName, companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerScreenName(
				String messageTemplateCode, long messageTemplateDescId,
				String customerScreenName, long companyId) {

		return getService().getNotificationLogsByCustomerScreenName(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerScreenName(
				String messageTemplateCode, long messageTemplateDescId,
				String customerScreenName, long companyId, int start, int end) {

		return getService().getNotificationLogsByCustomerScreenName(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, start, end);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerScreenName(
				String messageTemplateCode, String customerScreenName,
				long companyId) {

		return getService().getNotificationLogsByCustomerScreenName(
			messageTemplateCode, customerScreenName, companyId);
	}

	public static java.util.List
		<com.jio.account.notification.model.NotificationLog>
			getNotificationLogsByCustomerScreenName(
				String messageTemplateCode, String customerScreenName,
				long companyId, int start, int end) {

		return getService().getNotificationLogsByCustomerScreenName(
			messageTemplateCode, customerScreenName, companyId, start, end);
	}

	/**
	 * Returns the number of notification logs.
	 *
	 * @return the number of notification logs
	 */
	public static int getNotificationLogsCount() {
		return getService().getNotificationLogsCount();
	}

	public static int getNotificationLogsCount(long companyId) {
		return getService().getNotificationLogsCount(companyId);
	}

	public static int getNotificationLogsCount(
		long messageTemplateDescId, long companyId) {

		return getService().getNotificationLogsCount(
			messageTemplateDescId, companyId);
	}

	public static int getNotificationLogsCount(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		return getService().getNotificationLogsCount(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	public static int getNotificationLogsCount(
		String messageTemplateCode, long companyId) {

		return getService().getNotificationLogsCount(
			messageTemplateCode, companyId);
	}

	public static int getNotificationLogsCount(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		return getService().getNotificationLogsCount(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	public static int getNotificationLogsCount(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		return getService().getNotificationLogsCount(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	public static int getNotificationLogsCount(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		return getService().getNotificationLogsCount(
			messageTemplateCode, agentAccountNo, companyId);
	}

	public static int getNotificationLogsCountByAgent(
		String agentAccountNo, long companyId) {

		return getService().getNotificationLogsCountByAgent(
			agentAccountNo, companyId);
	}

	public static int getNotificationLogsCountByCustomerAccountNo(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		return getService().getNotificationLogsCountByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, companyId);
	}

	public static int getNotificationLogsCountByCustomerAccountNo(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		return getService().getNotificationLogsCountByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId);
	}

	public static int getNotificationLogsCountByCustomerAccountNo(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		return getService().getNotificationLogsCountByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, companyId);
	}

	public static int getNotificationLogsCountByCustomerScreenName(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		return getService().getNotificationLogsCountByCustomerScreenName(
			messageTemplateDescId, customerScreenName, companyId);
	}

	public static int getNotificationLogsCountByCustomerScreenName(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		return getService().getNotificationLogsCountByCustomerScreenName(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId);
	}

	public static int getNotificationLogsCountByCustomerScreenName(
		String messageTemplateCode, String customerScreenName, long companyId) {

		return getService().getNotificationLogsCountByCustomerScreenName(
			messageTemplateCode, customerScreenName, companyId);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	public static com.liferay.portal.kernel.model.PersistedModel
			getPersistedModel(java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the notification log in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param notificationLog the notification log
	 * @return the notification log that was updated
	 */
	public static com.jio.account.notification.model.NotificationLog
		updateNotificationLog(
			com.jio.account.notification.model.NotificationLog
				notificationLog) {

		return getService().updateNotificationLog(notificationLog);
	}

	public static NotificationLogLocalService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker
		<NotificationLogLocalService, NotificationLogLocalService>
			_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(
			NotificationLogLocalService.class);

		ServiceTracker<NotificationLogLocalService, NotificationLogLocalService>
			serviceTracker =
				new ServiceTracker
					<NotificationLogLocalService, NotificationLogLocalService>(
						bundle.getBundleContext(),
						NotificationLogLocalService.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}