/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides a wrapper for {@link NotificationLogLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see NotificationLogLocalService
 * @generated
 */
@ProviderType
public class NotificationLogLocalServiceWrapper
	implements NotificationLogLocalService,
			   ServiceWrapper<NotificationLogLocalService> {

	public NotificationLogLocalServiceWrapper(
		NotificationLogLocalService notificationLogLocalService) {

		_notificationLogLocalService = notificationLogLocalService;
	}

	/**
	 * Adds the notification log to the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationLog the notification log
	 * @return the notification log that was added
	 */
	@Override
	public com.jio.account.notification.model.NotificationLog
		addNotificationLog(
			com.jio.account.notification.model.NotificationLog
				notificationLog) {

		return _notificationLogLocalService.addNotificationLog(notificationLog);
	}

	@Override
	public int countByCustomer(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomer(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	@Override
	public int countByCustomer(String customerScreenName, long companyId) {
		return _notificationLogLocalService.countByCustomer(
			customerScreenName, companyId);
	}

	@Override
	public int countByCustomer(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomer(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	@Override
	public int countByCustomer(
		String customerScreenName, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomer(
			customerScreenName, agentAccountNo, companyId);
	}

	@Override
	public int countByCustomer(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomer(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	@Override
	public int countByCustomerAccountNo(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	@Override
	public int countByCustomerAccountNo(
		String customerAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomerAccountNo(
			customerAccountNo, companyId);
	}

	@Override
	public int countByCustomerAccountNo(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	@Override
	public int countByCustomerAccountNo(
		String customerAccountNo, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomerAccountNo(
			customerAccountNo, agentAccountNo, companyId);
	}

	@Override
	public int countByCustomerAccountNo(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return _notificationLogLocalService.countByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Creates a new notification log with the primary key. Does not add the notification log to the database.
	 *
	 * @param notificationId the primary key for the new notification log
	 * @return the new notification log
	 */
	@Override
	public com.jio.account.notification.model.NotificationLog
		createNotificationLog(String notificationId) {

		return _notificationLogLocalService.createNotificationLog(
			notificationId);
	}

	/**
	 * Deletes the notification log from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationLog the notification log
	 * @return the notification log that was removed
	 */
	@Override
	public com.jio.account.notification.model.NotificationLog
		deleteNotificationLog(
			com.jio.account.notification.model.NotificationLog
				notificationLog) {

		return _notificationLogLocalService.deleteNotificationLog(
			notificationLog);
	}

	/**
	 * Deletes the notification log with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log that was removed
	 * @throws PortalException if a notification log with the primary key could not be found
	 */
	@Override
	public com.jio.account.notification.model.NotificationLog
			deleteNotificationLog(String notificationId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _notificationLogLocalService.deleteNotificationLog(
			notificationId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _notificationLogLocalService.deletePersistedModel(
			persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _notificationLogLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _notificationLogLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.notification.model.impl.NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _notificationLogLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.notification.model.impl.NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _notificationLogLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _notificationLogLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _notificationLogLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.jio.account.notification.model.NotificationLog
		fetchNotificationLog(String notificationId) {

		return _notificationLogLocalService.fetchNotificationLog(
			notificationId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByAgent(String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByAgent(
			agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByAgent(String agentAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getByAgent(
			agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCompanyId(long companyId) {

		return _notificationLogLocalService.getByCompanyId(companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCompanyId(long companyId, int start, int end) {

		return _notificationLogLocalService.getByCompanyId(
			companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomer(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getByCustomer(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(String customerScreenName, long companyId) {

		return _notificationLogLocalService.getByCustomer(
			customerScreenName, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String customerScreenName, long companyId, int start, int end) {

		return _notificationLogLocalService.getByCustomer(
			customerScreenName, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomer(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			int start, int end) {

		return _notificationLogLocalService.getByCustomer(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String customerScreenName, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomer(
			customerScreenName, agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String customerScreenName, String agentAccountNo, long companyId,
			int start, int end) {

		return _notificationLogLocalService.getByCustomer(
			customerScreenName, agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomer(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomer(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getByCustomer(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(String customerAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			customerAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String customerAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			customerAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			int start, int end) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String customerAccountNo, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			customerAccountNo, agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String customerAccountNo, String agentAccountNo, long companyId,
			int start, int end) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			customerAccountNo, agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getByCustomerAccountNo(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getByCustomerAccountNo(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end);
	}

	/**
	 * Returns the notification log with the primary key.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log
	 * @throws PortalException if a notification log with the primary key could not be found
	 */
	@Override
	public com.jio.account.notification.model.NotificationLog
			getNotificationLog(String notificationId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _notificationLogLocalService.getNotificationLog(notificationId);
	}

	/**
	 * Returns a range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>com.jio.account.notification.model.impl.NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of notification logs
	 */
	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(long messageTemplateDescId, long companyId) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateDescId, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			long messageTemplateDescId, long companyId, int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateDescId, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			long messageTemplateDescId, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateDescId, agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(String messageTemplateCode, long companyId) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, long companyId, int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId, int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, agentAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogs(
			String messageTemplateCode, String agentAccountNo, long companyId,
			int start, int end) {

		return _notificationLogLocalService.getNotificationLogs(
			messageTemplateCode, agentAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerAccountNo(
			long messageTemplateDescId, String customerAccountNo,
			long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerAccountNo(
				messageTemplateDescId, customerAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerAccountNo(
			long messageTemplateDescId, String customerAccountNo,
			long companyId, int start, int end) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerAccountNo(
				messageTemplateDescId, customerAccountNo, companyId, start,
				end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerAccountNo(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerAccountNo(
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerAccountNo(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId, int start, int end) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerAccountNo(
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerAccountNo(
			String messageTemplateCode, String customerAccountNo,
			long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerAccountNo(
				messageTemplateCode, customerAccountNo, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerAccountNo(
			String messageTemplateCode, String customerAccountNo,
			long companyId, int start, int end) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerAccountNo(
				messageTemplateCode, customerAccountNo, companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerScreenName(
			long messageTemplateDescId, String customerScreenName,
			long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerScreenName(
				messageTemplateDescId, customerScreenName, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerScreenName(
			long messageTemplateDescId, String customerScreenName,
			long companyId, int start, int end) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerScreenName(
				messageTemplateDescId, customerScreenName, companyId, start,
				end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerScreenName(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerScreenName(
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerScreenName(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId, int start, int end) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerScreenName(
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				companyId, start, end);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerScreenName(
			String messageTemplateCode, String customerScreenName,
			long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerScreenName(
				messageTemplateCode, customerScreenName, companyId);
	}

	@Override
	public java.util.List<com.jio.account.notification.model.NotificationLog>
		getNotificationLogsByCustomerScreenName(
			String messageTemplateCode, String customerScreenName,
			long companyId, int start, int end) {

		return _notificationLogLocalService.
			getNotificationLogsByCustomerScreenName(
				messageTemplateCode, customerScreenName, companyId, start, end);
	}

	/**
	 * Returns the number of notification logs.
	 *
	 * @return the number of notification logs
	 */
	@Override
	public int getNotificationLogsCount() {
		return _notificationLogLocalService.getNotificationLogsCount();
	}

	@Override
	public int getNotificationLogsCount(long companyId) {
		return _notificationLogLocalService.getNotificationLogsCount(companyId);
	}

	@Override
	public int getNotificationLogsCount(
		long messageTemplateDescId, long companyId) {

		return _notificationLogLocalService.getNotificationLogsCount(
			messageTemplateDescId, companyId);
	}

	@Override
	public int getNotificationLogsCount(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogsCount(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	@Override
	public int getNotificationLogsCount(
		String messageTemplateCode, long companyId) {

		return _notificationLogLocalService.getNotificationLogsCount(
			messageTemplateCode, companyId);
	}

	@Override
	public int getNotificationLogsCount(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		return _notificationLogLocalService.getNotificationLogsCount(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	@Override
	public int getNotificationLogsCount(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogsCount(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	@Override
	public int getNotificationLogsCount(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogsCount(
			messageTemplateCode, agentAccountNo, companyId);
	}

	@Override
	public int getNotificationLogsCountByAgent(
		String agentAccountNo, long companyId) {

		return _notificationLogLocalService.getNotificationLogsCountByAgent(
			agentAccountNo, companyId);
	}

	@Override
	public int getNotificationLogsCountByCustomerAccountNo(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsCountByCustomerAccountNo(
				messageTemplateDescId, customerAccountNo, companyId);
	}

	@Override
	public int getNotificationLogsCountByCustomerAccountNo(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsCountByCustomerAccountNo(
				messageTemplateCode, messageTemplateDescId, customerAccountNo,
				companyId);
	}

	@Override
	public int getNotificationLogsCountByCustomerAccountNo(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsCountByCustomerAccountNo(
				messageTemplateCode, customerAccountNo, companyId);
	}

	@Override
	public int getNotificationLogsCountByCustomerScreenName(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsCountByCustomerScreenName(
				messageTemplateDescId, customerScreenName, companyId);
	}

	@Override
	public int getNotificationLogsCountByCustomerScreenName(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsCountByCustomerScreenName(
				messageTemplateCode, messageTemplateDescId, customerScreenName,
				companyId);
	}

	@Override
	public int getNotificationLogsCountByCustomerScreenName(
		String messageTemplateCode, String customerScreenName, long companyId) {

		return _notificationLogLocalService.
			getNotificationLogsCountByCustomerScreenName(
				messageTemplateCode, customerScreenName, companyId);
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _notificationLogLocalService.getOSGiServiceIdentifier();
	}

	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _notificationLogLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the notification log in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * @param notificationLog the notification log
	 * @return the notification log that was updated
	 */
	@Override
	public com.jio.account.notification.model.NotificationLog
		updateNotificationLog(
			com.jio.account.notification.model.NotificationLog
				notificationLog) {

		return _notificationLogLocalService.updateNotificationLog(
			notificationLog);
	}

	@Override
	public NotificationLogLocalService getWrappedService() {
		return _notificationLogLocalService;
	}

	@Override
	public void setWrappedService(
		NotificationLogLocalService notificationLogLocalService) {

		_notificationLogLocalService = notificationLogLocalService;
	}

	private NotificationLogLocalService _notificationLogLocalService;

}