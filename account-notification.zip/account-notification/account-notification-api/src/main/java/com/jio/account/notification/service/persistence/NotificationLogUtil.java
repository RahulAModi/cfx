/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.account.notification.service.persistence;

import com.jio.account.notification.model.NotificationLog;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the notification log service. This utility wraps <code>com.jio.account.notification.service.persistence.impl.NotificationLogPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see NotificationLogPersistence
 * @generated
 */
@ProviderType
public class NotificationLogUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(NotificationLog notificationLog) {
		getPersistence().clearCache(notificationLog);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, NotificationLog> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<NotificationLog> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<NotificationLog> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<NotificationLog> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static NotificationLog update(NotificationLog notificationLog) {
		return getPersistence().update(notificationLog);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static NotificationLog update(
		NotificationLog notificationLog, ServiceContext serviceContext) {

		return getPersistence().update(notificationLog, serviceContext);
	}

	/**
	 * Returns all the notification logs where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByCompanyId(long companyId) {
		return getPersistence().findByCompanyId(companyId);
	}

	/**
	 * Returns a range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByCompanyId(
		long companyId, int start, int end) {

		return getPersistence().findByCompanyId(companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCompanyId(
		long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCompanyId(
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCompanyId_First(
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCompanyId_First(
		long companyId, OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCompanyId_First(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCompanyId_Last(
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCompanyId_Last(
		long companyId, OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCompanyId_Last(
			companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByCompanyId_PrevAndNext(
			String notificationId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCompanyId_PrevAndNext(
			notificationId, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 */
	public static void removeByCompanyId(long companyId) {
		getPersistence().removeByCompanyId(companyId);
	}

	/**
	 * Returns the number of notification logs where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByCompanyId(long companyId) {
		return getPersistence().countByCompanyId(companyId);
	}

	/**
	 * Returns all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findBySendDate(
		Date sendDate, long companyId) {

		return getPersistence().findBySendDate(sendDate, companyId);
	}

	/**
	 * Returns a range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end) {

		return getPersistence().findBySendDate(sendDate, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findBySendDate(
			sendDate, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findBySendDate(
		Date sendDate, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findBySendDate(
			sendDate, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findBySendDate_First(
			Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findBySendDate_First(
			sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchBySendDate_First(
		Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchBySendDate_First(
			sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findBySendDate_Last(
			Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findBySendDate_Last(
			sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchBySendDate_Last(
		Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchBySendDate_Last(
			sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findBySendDate_PrevAndNext(
			String notificationId, Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findBySendDate_PrevAndNext(
			notificationId, sendDate, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where sendDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 */
	public static void removeBySendDate(Date sendDate, long companyId) {
		getPersistence().removeBySendDate(sendDate, companyId);
	}

	/**
	 * Returns the number of notification logs where sendDate = &#63; and companyId = &#63;.
	 *
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countBySendDate(Date sendDate, long companyId) {
		return getPersistence().countBySendDate(sendDate, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId) {

		return getPersistence().findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end) {

		return getPersistence().findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end, OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId, int start,
		int end, OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_SD_CID(
			messageTemplateCode, sendDate, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_SD_CID_First(
			String messageTemplateCode, Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_SD_CID_First(
			messageTemplateCode, sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_SD_CID_First(
		String messageTemplateCode, Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_SD_CID_First(
			messageTemplateCode, sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_SD_CID_Last(
			String messageTemplateCode, Date sendDate, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_SD_CID_Last(
			messageTemplateCode, sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_SD_CID_Last(
		String messageTemplateCode, Date sendDate, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_SD_CID_Last(
			messageTemplateCode, sendDate, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_SD_CID_PrevAndNext(
			String notificationId, String messageTemplateCode, Date sendDate,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_SD_CID_PrevAndNext(
			notificationId, messageTemplateCode, sendDate, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 */
	public static void removeByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId) {

		getPersistence().removeByMT_SD_CID(
			messageTemplateCode, sendDate, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and sendDate = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param sendDate the send date
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_SD_CID(
		String messageTemplateCode, Date sendDate, long companyId) {

		return getPersistence().countByMT_SD_CID(
			messageTemplateCode, sendDate, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId) {

		return getPersistence().findByMT_CID(messageTemplateCode, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end) {

		return getPersistence().findByMT_CID(
			messageTemplateCode, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_CID(
			messageTemplateCode, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CID(
		String messageTemplateCode, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_CID(
			messageTemplateCode, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CID_First(
			String messageTemplateCode, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CID_First(
			messageTemplateCode, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CID_First(
		String messageTemplateCode, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CID_First(
			messageTemplateCode, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CID_Last(
			String messageTemplateCode, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CID_Last(
			messageTemplateCode, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CID_Last(
		String messageTemplateCode, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CID_Last(
			messageTemplateCode, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_CID_PrevAndNext(
			String notificationId, String messageTemplateCode, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CID_PrevAndNext(
			notificationId, messageTemplateCode, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 */
	public static void removeByMT_CID(
		String messageTemplateCode, long companyId) {

		getPersistence().removeByMT_CID(messageTemplateCode, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_CID(
		String messageTemplateCode, long companyId) {

		return getPersistence().countByMT_CID(messageTemplateCode, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		return getPersistence().findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_AAN_CID_First(
			String messageTemplateCode, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_AAN_CID_First(
			messageTemplateCode, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_AAN_CID_First(
		String messageTemplateCode, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_AAN_CID_First(
			messageTemplateCode, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_AAN_CID_Last(
			String messageTemplateCode, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_AAN_CID_Last(
			messageTemplateCode, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_AAN_CID_Last(
		String messageTemplateCode, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_AAN_CID_Last(
			messageTemplateCode, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_AAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		getPersistence().removeByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_AAN_CID(
		String messageTemplateCode, String agentAccountNo, long companyId) {

		return getPersistence().countByMT_AAN_CID(
			messageTemplateCode, agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		return getPersistence().findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CAN_CID_First(
			String messageTemplateCode, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CAN_CID_First(
			messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CAN_CID_First(
		String messageTemplateCode, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CAN_CID_First(
			messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CAN_CID_Last(
			String messageTemplateCode, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CAN_CID_Last(
			messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CAN_CID_Last(
		String messageTemplateCode, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CAN_CID_Last(
			messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_CAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		getPersistence().removeByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_CAN_CID(
		String messageTemplateCode, String customerAccountNo, long companyId) {

		return getPersistence().countByMT_CAN_CID(
			messageTemplateCode, customerAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId) {

		return getPersistence().findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end) {

		return getPersistence().findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CSN_CID_First(
			String messageTemplateCode, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CSN_CID_First(
			messageTemplateCode, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CSN_CID_First(
		String messageTemplateCode, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CSN_CID_First(
			messageTemplateCode, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CSN_CID_Last(
			String messageTemplateCode, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CSN_CID_Last(
			messageTemplateCode, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CSN_CID_Last(
		String messageTemplateCode, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CSN_CID_Last(
			messageTemplateCode, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_CSN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CSN_CID_PrevAndNext(
			notificationId, messageTemplateCode, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public static void removeByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId) {

		getPersistence().removeByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_CSN_CID(
		String messageTemplateCode, String customerScreenName, long companyId) {

		return getPersistence().countByMT_CSN_CID(
			messageTemplateCode, customerScreenName, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return getPersistence().findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end) {

		return getPersistence().findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CAN_AAN_CID_First(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CAN_AAN_CID_First(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CAN_AAN_CID_First(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CAN_AAN_CID_First(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CAN_AAN_CID_Last(
			String messageTemplateCode, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CAN_AAN_CID_Last(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CAN_AAN_CID_Last(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CAN_AAN_CID_Last(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_CAN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CAN_AAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		getPersistence().removeByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_CAN_AAN_CID(
		String messageTemplateCode, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return getPersistence().countByMT_CAN_AAN_CID(
			messageTemplateCode, customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		return getPersistence().findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end) {

		return getPersistence().findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CSN_AAN_CID_First(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CSN_AAN_CID_First(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CSN_AAN_CID_First(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CSN_AAN_CID_First(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_CSN_AAN_CID_Last(
			String messageTemplateCode, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CSN_AAN_CID_Last(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_CSN_AAN_CID_Last(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_CSN_AAN_CID_Last(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_CSN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_CSN_AAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, customerScreenName,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		getPersistence().removeByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_CSN_AAN_CID(
		String messageTemplateCode, String customerScreenName,
		String agentAccountNo, long companyId) {

		return getPersistence().countByMT_CSN_AAN_CID(
			messageTemplateCode, customerScreenName, agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId) {

		return getPersistence().findByMTD_CID(messageTemplateDescId, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end) {

		return getPersistence().findByMTD_CID(
			messageTemplateDescId, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMTD_CID(
			messageTemplateDescId, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CID(
		long messageTemplateDescId, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMTD_CID(
			messageTemplateDescId, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CID_First(
			long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CID_First(
			messageTemplateDescId, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CID_First(
		long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CID_First(
			messageTemplateDescId, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CID_Last(
			long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CID_Last(
			messageTemplateDescId, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CID_Last(
		long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CID_Last(
			messageTemplateDescId, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMTD_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CID_PrevAndNext(
			notificationId, messageTemplateDescId, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 */
	public static void removeByMTD_CID(
		long messageTemplateDescId, long companyId) {

		getPersistence().removeByMTD_CID(messageTemplateDescId, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMTD_CID(
		long messageTemplateDescId, long companyId) {

		return getPersistence().countByMTD_CID(
			messageTemplateDescId, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		return getPersistence().findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_AAN_CID_First(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_AAN_CID_First(
			messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_AAN_CID_First(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_AAN_CID_First(
			messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_AAN_CID_Last(
			long messageTemplateDescId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_AAN_CID_Last(
			messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_AAN_CID_Last(
		long messageTemplateDescId, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_AAN_CID_Last(
			messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMTD_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_AAN_CID_PrevAndNext(
			notificationId, messageTemplateDescId, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		getPersistence().removeByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMTD_AAN_CID(
		long messageTemplateDescId, String agentAccountNo, long companyId) {

		return getPersistence().countByMTD_AAN_CID(
			messageTemplateDescId, agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		return getPersistence().findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CAN_CID_First(
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CAN_CID_First(
			messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CAN_CID_First(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CAN_CID_First(
			messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CAN_CID_Last(
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CAN_CID_Last(
			messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CAN_CID_Last(
		long messageTemplateDescId, String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CAN_CID_Last(
			messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMTD_CAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CAN_CID_PrevAndNext(
			notificationId, messageTemplateDescId, customerAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public static void removeByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		getPersistence().removeByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMTD_CAN_CID(
		long messageTemplateDescId, String customerAccountNo, long companyId) {

		return getPersistence().countByMTD_CAN_CID(
			messageTemplateDescId, customerAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		return getPersistence().findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end) {

		return getPersistence().findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CSN_CID_First(
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CSN_CID_First(
			messageTemplateDescId, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CSN_CID_First(
		long messageTemplateDescId, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CSN_CID_First(
			messageTemplateDescId, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CSN_CID_Last(
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CSN_CID_Last(
			messageTemplateDescId, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CSN_CID_Last(
		long messageTemplateDescId, String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CSN_CID_Last(
			messageTemplateDescId, customerScreenName, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMTD_CSN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CSN_CID_PrevAndNext(
			notificationId, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public static void removeByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		getPersistence().removeByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMTD_CSN_CID(
		long messageTemplateDescId, String customerScreenName, long companyId) {

		return getPersistence().countByMTD_CSN_CID(
			messageTemplateDescId, customerScreenName, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return getPersistence().findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end) {

		return getPersistence().findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CAN_AAN_CID_First(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CAN_AAN_CID_First(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CAN_AAN_CID_First(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CAN_AAN_CID_First(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CAN_AAN_CID_Last(
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CAN_AAN_CID_Last(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CAN_AAN_CID_Last(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CAN_AAN_CID_Last(
			messageTemplateDescId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMTD_CAN_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CAN_AAN_CID_PrevAndNext(
			notificationId, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		getPersistence().removeByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMTD_CAN_AAN_CID(
		long messageTemplateDescId, String customerAccountNo,
		String agentAccountNo, long companyId) {

		return getPersistence().countByMTD_CAN_AAN_CID(
			messageTemplateDescId, customerAccountNo, agentAccountNo,
			companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		return getPersistence().findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end) {

		return getPersistence().findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CSN_AAN_CID_First(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CSN_AAN_CID_First(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CSN_AAN_CID_First(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CSN_AAN_CID_First(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMTD_CSN_AAN_CID_Last(
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CSN_AAN_CID_Last(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMTD_CSN_AAN_CID_Last(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMTD_CSN_AAN_CID_Last(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMTD_CSN_AAN_CID_PrevAndNext(
			String notificationId, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMTD_CSN_AAN_CID_PrevAndNext(
			notificationId, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		getPersistence().removeByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMTD_CSN_AAN_CID(
		long messageTemplateDescId, String customerScreenName,
		String agentAccountNo, long companyId) {

		return getPersistence().countByMTD_CSN_AAN_CID(
			messageTemplateDescId, customerScreenName, agentAccountNo,
			companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		return getPersistence().findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end) {

		return getPersistence().findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CID_First(
			messageTemplateCode, messageTemplateDescId, companyId,
			orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CID_First(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CID_First(
			messageTemplateCode, messageTemplateDescId, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CID_Last(
			messageTemplateCode, messageTemplateDescId, companyId,
			orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CID_Last(
		String messageTemplateCode, long messageTemplateDescId, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CID_Last(
			messageTemplateCode, messageTemplateDescId, companyId,
			orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_MTD_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CID_PrevAndNext(
			notificationId, messageTemplateCode, messageTemplateDescId,
			companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 */
	public static void removeByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		getPersistence().removeByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_MTD_CID(
		String messageTemplateCode, long messageTemplateDescId,
		long companyId) {

		return getPersistence().countByMT_MTD_CID(
			messageTemplateCode, messageTemplateDescId, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		return getPersistence().findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end) {

		return getPersistence().findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_MTD_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_AAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, messageTemplateDescId,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		getPersistence().removeByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_MTD_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String agentAccountNo, long companyId) {

		return getPersistence().countByMT_MTD_AAN_CID(
			messageTemplateCode, messageTemplateDescId, agentAccountNo,
			companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		return getPersistence().findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end) {

		return getPersistence().findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_MTD_CAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerAccountNo,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, messageTemplateDescId,
			customerAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		getPersistence().removeByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_MTD_CAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, long companyId) {

		return getPersistence().countByMT_MTD_CAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		return getPersistence().findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end) {

		return getPersistence().findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CSN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CSN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CSN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CSN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CSN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CSN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CSN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CSN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_MTD_CSN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerScreenName,
			long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CSN_CID_PrevAndNext(
			notificationId, messageTemplateCode, messageTemplateDescId,
			customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public static void removeByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		getPersistence().removeByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_MTD_CSN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, long companyId) {

		return getPersistence().countByMT_MTD_CSN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		return getPersistence().findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CAN_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CAN_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CAN_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CAN_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CAN_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CAN_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CAN_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CAN_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_MTD_CAN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CAN_AAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, messageTemplateDescId,
			customerAccountNo, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		getPersistence().removeByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_MTD_CAN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerAccountNo, String agentAccountNo, long companyId) {

		return getPersistence().countByMT_MTD_CAN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerAccountNo,
			agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		return getPersistence().findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CSN_AAN_CID_First(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CSN_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CSN_AAN_CID_First(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CSN_AAN_CID_First(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByMT_MTD_CSN_AAN_CID_Last(
			String messageTemplateCode, long messageTemplateDescId,
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CSN_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByMT_MTD_CSN_AAN_CID_Last(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByMT_MTD_CSN_AAN_CID_Last(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByMT_MTD_CSN_AAN_CID_PrevAndNext(
			String notificationId, String messageTemplateCode,
			long messageTemplateDescId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByMT_MTD_CSN_AAN_CID_PrevAndNext(
			notificationId, messageTemplateCode, messageTemplateDescId,
			customerScreenName, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		getPersistence().removeByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where messageTemplateCode = &#63; and messageTemplateDescId = &#63; and customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param messageTemplateCode the message template code
	 * @param messageTemplateDescId the message template desc ID
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByMT_MTD_CSN_AAN_CID(
		String messageTemplateCode, long messageTemplateDescId,
		String customerScreenName, String agentAccountNo, long companyId) {

		return getPersistence().countByMT_MTD_CSN_AAN_CID(
			messageTemplateCode, messageTemplateDescId, customerScreenName,
			agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId) {

		return getPersistence().findByCAN_CID(customerAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end) {

		return getPersistence().findByCAN_CID(
			customerAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByCAN_CID(
			customerAccountNo, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCAN_CID(
		String customerAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCAN_CID(
			customerAccountNo, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCAN_CID_First(
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCAN_CID_First(
			customerAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCAN_CID_First(
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCAN_CID_First(
			customerAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCAN_CID_Last(
			String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCAN_CID_Last(
			customerAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCAN_CID_Last(
		String customerAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCAN_CID_Last(
			customerAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByCAN_CID_PrevAndNext(
			String notificationId, String customerAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCAN_CID_PrevAndNext(
			notificationId, customerAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where customerAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 */
	public static void removeByCAN_CID(
		String customerAccountNo, long companyId) {

		getPersistence().removeByCAN_CID(customerAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where customerAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByCAN_CID(String customerAccountNo, long companyId) {
		return getPersistence().countByCAN_CID(customerAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId) {

		return getPersistence().findByCSN_CID(customerScreenName, companyId);
	}

	/**
	 * Returns a range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end) {

		return getPersistence().findByCSN_CID(
			customerScreenName, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByCSN_CID(
			customerScreenName, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCSN_CID(
		String customerScreenName, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCSN_CID(
			customerScreenName, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCSN_CID_First(
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCSN_CID_First(
			customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCSN_CID_First(
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCSN_CID_First(
			customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCSN_CID_Last(
			String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCSN_CID_Last(
			customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCSN_CID_Last(
		String customerScreenName, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCSN_CID_Last(
			customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByCSN_CID_PrevAndNext(
			String notificationId, String customerScreenName, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCSN_CID_PrevAndNext(
			notificationId, customerScreenName, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where customerScreenName = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 */
	public static void removeByCSN_CID(
		String customerScreenName, long companyId) {

		getPersistence().removeByCSN_CID(customerScreenName, companyId);
	}

	/**
	 * Returns the number of notification logs where customerScreenName = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByCSN_CID(
		String customerScreenName, long companyId) {

		return getPersistence().countByCSN_CID(customerScreenName, companyId);
	}

	/**
	 * Returns all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId) {

		return getPersistence().findByAAN_CID(agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end) {

		return getPersistence().findByAAN_CID(
			agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByAAN_CID(
			agentAccountNo, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByAAN_CID(
		String agentAccountNo, long companyId, int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByAAN_CID(
			agentAccountNo, companyId, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByAAN_CID_First(
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByAAN_CID_First(
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByAAN_CID_First(
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByAAN_CID_First(
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByAAN_CID_Last(
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByAAN_CID_Last(
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByAAN_CID_Last(
		String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByAAN_CID_Last(
			agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByAAN_CID_PrevAndNext(
			String notificationId, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByAAN_CID_PrevAndNext(
			notificationId, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Removes all the notification logs where agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByAAN_CID(String agentAccountNo, long companyId) {
		getPersistence().removeByAAN_CID(agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByAAN_CID(String agentAccountNo, long companyId) {
		return getPersistence().countByAAN_CID(agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId) {

		return getPersistence().findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCAN_AAN_CID_First(
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCAN_AAN_CID_First(
			customerAccountNo, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCAN_AAN_CID_First(
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCAN_AAN_CID_First(
			customerAccountNo, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCAN_AAN_CID_Last(
			String customerAccountNo, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCAN_AAN_CID_Last(
			customerAccountNo, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCAN_AAN_CID_Last(
		String customerAccountNo, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCAN_AAN_CID_Last(
			customerAccountNo, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByCAN_AAN_CID_PrevAndNext(
			String notificationId, String customerAccountNo,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCAN_AAN_CID_PrevAndNext(
			notificationId, customerAccountNo, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId) {

		getPersistence().removeByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where customerAccountNo = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerAccountNo the customer account no
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByCAN_AAN_CID(
		String customerAccountNo, String agentAccountNo, long companyId) {

		return getPersistence().countByCAN_AAN_CID(
			customerAccountNo, agentAccountNo, companyId);
	}

	/**
	 * Returns all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the matching notification logs
	 */
	public static List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId) {

		return getPersistence().findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId);
	}

	/**
	 * Returns a range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of matching notification logs
	 */
	public static List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end) {

		return getPersistence().findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, start, end,
			orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of matching notification logs
	 */
	public static List<NotificationLog> findByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId,
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCSN_AAN_CID_First(
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCSN_AAN_CID_First(
			customerScreenName, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the first notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCSN_AAN_CID_First(
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCSN_AAN_CID_First(
			customerScreenName, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log
	 * @throws NoSuchNotificationLogException if a matching notification log could not be found
	 */
	public static NotificationLog findByCSN_AAN_CID_Last(
			String customerScreenName, String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCSN_AAN_CID_Last(
			customerScreenName, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the last notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching notification log, or <code>null</code> if a matching notification log could not be found
	 */
	public static NotificationLog fetchByCSN_AAN_CID_Last(
		String customerScreenName, String agentAccountNo, long companyId,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().fetchByCSN_AAN_CID_Last(
			customerScreenName, agentAccountNo, companyId, orderByComparator);
	}

	/**
	 * Returns the notification logs before and after the current notification log in the ordered set where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param notificationId the primary key of the current notification log
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog[] findByCSN_AAN_CID_PrevAndNext(
			String notificationId, String customerScreenName,
			String agentAccountNo, long companyId,
			OrderByComparator<NotificationLog> orderByComparator)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByCSN_AAN_CID_PrevAndNext(
			notificationId, customerScreenName, agentAccountNo, companyId,
			orderByComparator);
	}

	/**
	 * Removes all the notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63; from the database.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 */
	public static void removeByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId) {

		getPersistence().removeByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId);
	}

	/**
	 * Returns the number of notification logs where customerScreenName = &#63; and agentAccountNo = &#63; and companyId = &#63;.
	 *
	 * @param customerScreenName the customer screen name
	 * @param agentAccountNo the agent account no
	 * @param companyId the company ID
	 * @return the number of matching notification logs
	 */
	public static int countByCSN_AAN_CID(
		String customerScreenName, String agentAccountNo, long companyId) {

		return getPersistence().countByCSN_AAN_CID(
			customerScreenName, agentAccountNo, companyId);
	}

	/**
	 * Caches the notification log in the entity cache if it is enabled.
	 *
	 * @param notificationLog the notification log
	 */
	public static void cacheResult(NotificationLog notificationLog) {
		getPersistence().cacheResult(notificationLog);
	}

	/**
	 * Caches the notification logs in the entity cache if it is enabled.
	 *
	 * @param notificationLogs the notification logs
	 */
	public static void cacheResult(List<NotificationLog> notificationLogs) {
		getPersistence().cacheResult(notificationLogs);
	}

	/**
	 * Creates a new notification log with the primary key. Does not add the notification log to the database.
	 *
	 * @param notificationId the primary key for the new notification log
	 * @return the new notification log
	 */
	public static NotificationLog create(String notificationId) {
		return getPersistence().create(notificationId);
	}

	/**
	 * Removes the notification log with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log that was removed
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog remove(String notificationId)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().remove(notificationId);
	}

	public static NotificationLog updateImpl(NotificationLog notificationLog) {
		return getPersistence().updateImpl(notificationLog);
	}

	/**
	 * Returns the notification log with the primary key or throws a <code>NoSuchNotificationLogException</code> if it could not be found.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log
	 * @throws NoSuchNotificationLogException if a notification log with the primary key could not be found
	 */
	public static NotificationLog findByPrimaryKey(String notificationId)
		throws com.jio.account.notification.exception.
			NoSuchNotificationLogException {

		return getPersistence().findByPrimaryKey(notificationId);
	}

	/**
	 * Returns the notification log with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param notificationId the primary key of the notification log
	 * @return the notification log, or <code>null</code> if a notification log with the primary key could not be found
	 */
	public static NotificationLog fetchByPrimaryKey(String notificationId) {
		return getPersistence().fetchByPrimaryKey(notificationId);
	}

	/**
	 * Returns all the notification logs.
	 *
	 * @return the notification logs
	 */
	public static List<NotificationLog> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @return the range of notification logs
	 */
	public static List<NotificationLog> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of notification logs
	 */
	public static List<NotificationLog> findAll(
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the notification logs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not <code>QueryUtil#ALL_POS</code>), then the query will include the default ORDER BY logic from <code>NotificationLogModelImpl</code>. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of notification logs
	 * @param end the upper bound of the range of notification logs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of notification logs
	 */
	public static List<NotificationLog> findAll(
		int start, int end,
		OrderByComparator<NotificationLog> orderByComparator,
		boolean retrieveFromCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, retrieveFromCache);
	}

	/**
	 * Removes all the notification logs from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of notification logs.
	 *
	 * @return the number of notification logs
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static NotificationLogPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker
		<NotificationLogPersistence, NotificationLogPersistence>
			_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(
			NotificationLogPersistence.class);

		ServiceTracker<NotificationLogPersistence, NotificationLogPersistence>
			serviceTracker =
				new ServiceTracker
					<NotificationLogPersistence, NotificationLogPersistence>(
						bundle.getBundleContext(),
						NotificationLogPersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}